"""Dependency-free same-host monotonic telemetry for Isaac and ROS processes."""

from __future__ import annotations

import atexit
import json
import os
from pathlib import Path
import socket
import threading
import time


_streams = {}
_lock = threading.Lock()


def timing_enabled():
    return bool(os.environ.get("TITA_TIMING_DIR"))


def trace_event(component, event, *, at_ns=None, **fields):
    directory = os.environ.get("TITA_TIMING_DIR")
    if not directory:
        return
    timestamp = time.monotonic_ns() if at_ns is None else at_ns
    process_id = os.getpid()
    key = (directory, process_id, component)
    record = {"event": event, "monotonic_ns": timestamp, **fields}
    with _lock:
        if key not in _streams:
            output = Path(directory)
            output.mkdir(parents=True, exist_ok=True)
            stream = (output / f"{component}_{process_id}.jsonl").open("x", buffering=1)
            _streams[key] = stream
            stream.write(json.dumps({
                "event": "clock_identity", "monotonic_ns": timestamp,
                "component": component, "pid": process_id,
                "hostname": socket.gethostname(),
                "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
                "clock": time.get_clock_info("monotonic").implementation,
                "clock_resolution_s": time.get_clock_info("monotonic").resolution,
            }) + "\n")
        _streams[key].write(json.dumps(record, allow_nan=False) + "\n")


def close_timing_traces():
    with _lock:
        for stream in _streams.values():
            stream.close()
        _streams.clear()


atexit.register(close_timing_traces)
