"""Auditable speed protocols and spatial trajectory comparison, without ROS."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from .navigation_maze import route_geometry_features, sample_polyline


def protocol_speed_cap(config, protocol, algorithm):
    if protocol not in config["protocols"] or algorithm not in ("neupan", "dct", "rl"):
        raise ValueError("unknown benchmark protocol or algorithm")
    cap = float(config["protocols"][protocol][f"{algorithm}_max_mps"])
    if not np.isfinite(cap) or not 0 < cap <= float(config["cruise_gear_max_mps"]):
        raise ValueError("invalid protocol speed cap")
    return cap


def path_length(points):
    points = np.asarray(points, dtype=float).reshape(-1, 2)
    if not np.isfinite(points).all():
        raise ValueError("path must be finite")
    return float(np.linalg.norm(np.diff(points, axis=0), axis=1).sum())


def distances_to_path(points, reference):
    points = np.asarray(points, dtype=float).reshape(-1, 2)
    reference = np.asarray(reference, dtype=float).reshape(-1, 2)
    if not len(reference) or not np.isfinite(points).all() or not np.isfinite(reference).all():
        raise ValueError("finite reference and points required")
    if len(reference) == 1:
        return np.linalg.norm(points - reference[0], axis=1)
    starts = reference[:-1]
    vectors = np.diff(reference, axis=0)
    norm_squared = np.sum(vectors * vectors, axis=1)
    distances = []
    for offset in range(0, len(points), 256):
        delta = points[offset:offset + 256, None, :] - starts
        fractions = np.clip(np.sum(delta * vectors, axis=2) / np.maximum(norm_squared, 1e-20), 0.0, 1.0)
        distances.extend(np.min(np.linalg.norm(delta - fractions[..., None] * vectors, axis=2), axis=1))
    return np.asarray(distances)


def path_comparison(actual, reference, *, spacing_m=0.05, tolerance_m=0.20):
    if not np.isfinite(tolerance_m) or tolerance_m <= 0:
        raise ValueError("overlap tolerance must be positive")
    actual_samples = sample_polyline(actual, spacing_m)
    reference_samples = sample_polyline(reference, spacing_m)
    actual_error = distances_to_path(actual_samples, reference)
    reference_error = distances_to_path(reference_samples, actual)
    actual_fraction = float(np.mean(actual_error <= tolerance_m))
    reference_fraction = float(np.mean(reference_error <= tolerance_m))
    return {
        "actual_within_reference_fraction": actual_fraction,
        "reference_covered_fraction": reference_fraction,
        "symmetric_path_overlap": (actual_fraction + reference_fraction) / 2.0,
        "mean_tracking_error_m": float(np.mean(actual_error)),
        "p95_tracking_error_m": float(np.percentile(actual_error, 95)),
        "symmetric_chamfer_m": float((np.mean(actual_error) + np.mean(reference_error)) / 2),
        "hausdorff_m": float(max(np.max(actual_error), np.max(reference_error))),
        "spatial_sample_spacing_m": spacing_m,
        "overlap_tolerance_m": tolerance_m,
        "definition": "arc-length-resampled symmetric centerline coverage; not occupancy IoU or a success criterion",
    }


def competing_branch_comparison(actual, branches):
    comparisons = {branch: path_comparison(actual, postures["MID"]["xy_m"])
                   for branch, postures in branches.items()}
    closest = min(comparisons, key=lambda branch: comparisons[branch]["mean_tracking_error_m"])
    return {"selected_branch": closest, "comparison_to_closest_branch": comparisons[closest],
            "comparison_to_all_branches": comparisons,
            "branch_selection_scope": "posthoc geometric classification, not an RL branch-action log"}


def truncate_at_goal_region(reference, goal_xy, tolerance_m):
    reference = np.asarray(reference, dtype=float).reshape(-1, 2)
    goal = np.asarray(goal_xy, dtype=float)
    if tolerance_m <= 0 or len(reference) < 1:
        raise ValueError("reference and positive goal tolerance required")
    if np.linalg.norm(reference[0] - goal) <= tolerance_m:
        return reference[:1]
    for segment_index, (start, end) in enumerate(zip(reference[:-1], reference[1:])):
        direction = end - start
        offset = start - goal
        quadratic = float(direction @ direction)
        if quadratic < 1e-20:
            continue
        linear = float(2 * offset @ direction)
        constant = float(offset @ offset - tolerance_m ** 2)
        discriminant = linear ** 2 - 4 * quadratic * constant
        if discriminant < 0:
            continue
        fraction = (-linear - np.sqrt(discriminant)) / (2 * quadratic)
        if 0 <= fraction <= 1:
            return np.concatenate((reference[:segment_index + 1], [start + fraction * direction]))
    return reference


def summarize_physical_run(directory, reference, config, protocol, algorithm):
    directory = Path(directory)
    evaluation = json.loads((directory / "evaluation/evaluation_summary.json").read_text())
    if not evaluation["complete"] or len(evaluation["episodes"]) != 1:
        raise ValueError("requires one completed physical evaluation episode")
    episode = evaluation["episodes"][0]
    rows = [json.loads(line) for line in (directory / "control_trace.jsonl").read_text().splitlines() if line.strip()]
    rows = [row for row in rows if row["episode_id"] == episode["episode_id"]]
    if not rows:
        raise ValueError("physical trace is empty")
    trajectory = [row["position"][:2] for row in rows]
    speeds = np.array([np.linalg.norm(row["linear_b"][:2]) for row in rows])
    desired = np.array([np.linalg.norm(row["desired"][:2]) for row in rows])
    cap = protocol_speed_cap(config, protocol, algorithm)
    successful = bool(episode["success"] and not episode["hard_failure"])
    length = float(episode["distance_m"])
    evaluation_reference = truncate_at_goal_region(reference, reference[-1], config["goal_tolerance_m"])
    reference_length = path_length(evaluation_reference)
    efficiency = reference_length / max(length, 1e-12)
    result = {
        "algorithm": algorithm, "protocol": protocol, "directory": str(directory.resolve()),
        "complete": True, "success": successful, "hard_failure": episode["hard_failure"],
        "truncated": episode["truncated"], "navigation_time_s": float(episode["elapsed_s"]),
        "navigation_time_success_only_s": float(episode["elapsed_s"]) if successful else None,
        "distance_m": length, "mechanical_energy_j": float(episode["energy_j"]),
        "energy_j_per_m": float(episode["energy_j"]) / max(length, 1e-12),
        "reference_path_length_m": path_length(reference),
        "reference_length_to_goal_region_m": reference_length,
        "path_efficiency_success_only": efficiency if successful else None,
        "success_weighted_path_efficiency": min(1.0, efficiency) if successful else 0.0,
        "idealized_reference_travel_time_s": reference_length / cap,
        "reference_relative_time_efficiency_success_only": min(1.0, reference_length / cap / float(episode["elapsed_s"])) if successful else None,
        "speed_cap_mps": cap, "desired_speed_max_mps": float(desired.max()),
        "command_cap_passed": bool(desired.max() <= cap + 1e-6),
        "measured_speed_max_mps": float(speeds.max()),
        "measured_speed_exceedance_fraction": float(np.mean(speeds > cap + config["speed_exceedance_tolerance_mps"])),
        "speed_cv_after_5s": None,
        "posture_action_histogram": {str(action_id): sum(row["action_id"] == action_id for row in rows) for action_id in range(9)},
        "comparison_to_first_selected_plan": path_comparison(trajectory, reference, spacing_m=config["path_sample_spacing_m"], tolerance_m=config["path_overlap_tolerance_m"]),
        "trajectory_xy_m": trajectory,
        "reference_scope": "first selected inflated-grid A* path truncated at shared goal tolerance; reference-relative efficiency, not certified geodesic SPL",
        "scope": "physical simulation pilot, not a statistically validated algorithm ranking",
    }
    settled = speeds[np.array([row["sim_time_s"] for row in rows]) >= 5.0]
    if len(settled):
        result["speed_cv_after_5s"] = float(np.std(settled) / max(np.mean(settled), 1e-12))
        result["measured_speed_max_after_5s_mps"] = float(np.max(settled))
        result["measured_speed_exceedance_fraction_after_5s"] = float(np.mean(settled > cap + config["speed_exceedance_tolerance_mps"]))
    return result


def executed_geometry_features(scene, rows):
    features = []
    for posture_index in range(3):
        points = [row["position"][:2] for row in rows if row["action_id"] // 3 == posture_index]
        features.extend(route_geometry_features(scene, [point], posture_index) for point in points)
    if not features:
        raise ValueError("no valid posture actions in physical trace")
    return {
        "lateral_clearance_m": min(feature["lateral_clearance_m"] for feature in features),
        "overhead_margin_m": min(feature["overhead_margin_m"] for feature in features),
        "geometry_source": "oracle_scene_at_measured_positions_with_commanded_posture_envelope",
        "scope": "nominal circular planar footprint and commanded posture height; not full swept-volume or contact certification",
        "online_perception": False,
    }
