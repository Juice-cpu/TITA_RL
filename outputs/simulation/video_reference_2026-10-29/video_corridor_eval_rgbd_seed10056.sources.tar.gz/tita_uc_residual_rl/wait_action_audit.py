import math


def audit_wait_action_risk(document):
    failures = []
    if document.get('upper_wait_action_contract') not in ('tita.risk_priced_wait.v1', 'tita.risk_priced_wait.v2_periodic_risk'):
        return {'passed': False, 'failures': ['risk_priced_wait_contract_required'], 'wait_steps': 0, 'motion_steps': 0}
    trajectory = document.get('trajectory', [])
    events = document.get('decision_events', [])
    if not trajectory or not events or document.get('completed_steps', 0) <= 0:
        return {'passed': False, 'failures': ['actual_trajectory_and_decisions_required'], 'wait_steps': 0, 'motion_steps': 0}
    dt = document['elapsed_simulation_s'] / document['completed_steps']
    risk_weight = document['upper_reward_weights']['risk']
    threshold = document['upper_safety_config']['dynamic_risk_stop']
    if not all(math.isfinite(value) for value in (dt, risk_weight, threshold)) or min(dt, risk_weight) <= 0.:
        return {'passed': False, 'failures': ['invalid_risk_units_or_threshold'], 'wait_steps': 0, 'motion_steps': 0}
    if document['upper_wait_action_contract'] == 'tita.risk_priced_wait.v2_periodic_risk':
        try:
            invocation = document['invocation']
            period_steps = int(invocation[invocation.index('--upper-period-steps') + 1])
            period_s = float(document['upper_action_risk_cost_period_s'])
            if period_steps <= 0 or not math.isfinite(period_s) or not math.isclose(period_s, period_steps * dt, abs_tol=1e-9):
                failures.append('periodic_risk_cost_not_bound_to_actual_decision_period')
        except (KeyError, ValueError, TypeError, IndexError):
            failures.append('periodic_risk_cost_period_evidence_missing')
    first_steps = {}
    for row in trajectory:
        first_steps[row['episode']] = min(first_steps.get(row['episode'], row['step']), row['step'])
    event_steps = {(event['episode'], first_steps[event['episode']] + round(event['time_s'] / dt)): event for event in events}
    selected = {}
    counts = {'wait_steps': 0, 'motion_steps': 0, 'unavoidable_stop_decisions': 0}
    maximum_feature_error = 0.
    maximum_reward_error = 0.
    for row in trajectory:
        episode = row['episode']
        event = event_steps.get((episode, row['step']))
        if event is not None:
            selected[episode] = event
            if not event['decision']['valid']:
                if not event['valid_actions'][-1]:
                    failures.append(f'wait_mask_bypassed:{episode}:{row["step"]}')
                if event['action_features'][-1][8] >= threshold:
                    if any(event['valid_actions'][:-1]):
                        failures.append(f'unsafe_voluntary_wait:{episode}:{row["step"]}')
                    counts['unavoidable_stop_decisions'] += 1
        event = selected.get(episode)
        if event is None:
            failures.append(f'missing_initial_decision:{episode}:{row["step"]}')
            continue
        valid = event['decision']['valid']
        action = event['decision']['action_id'] if valid else -1
        expected = event['action_features'][action][8]
        source = 'selected_motion' if valid else 'selected_wait_contingency'
        observed = row.get('decision_dynamic_risk', float('nan'))
        if not math.isfinite(observed) or not 0. <= observed <= 1. or not math.isfinite(expected) or not 0. <= expected <= 1.:
            failures.append(f'invalid_risk_feedback:{episode}:{row["step"]}')
            continue
        maximum_feature_error = max(maximum_feature_error, abs(observed - expected))
        reward = row['upper_reward_terms']['risk']
        if not math.isfinite(reward):
            failures.append(f'invalid_risk_reward:{episode}:{row["step"]}')
            continue
        maximum_reward_error = max(maximum_reward_error, abs(reward + risk_weight * observed * dt))
        if row.get('decision_dynamic_risk_source') != source:
            failures.append(f'wrong_risk_source:{episode}:{row["step"]}')
        counts['motion_steps' if valid else 'wait_steps'] += 1
    if maximum_feature_error > 1e-6:
        failures.append('decision_risk_not_bound_to_selected_action_feature')
    if maximum_reward_error > 1e-9:
        failures.append('reward_risk_not_bound_to_same_decision_feedback')
    return {'passed': not failures, 'failures': failures, **counts,
        'maximum_feature_error': maximum_feature_error, 'maximum_reward_error': maximum_reward_error,
        'navigation_success_or_stationary_safety_certificate': False}
