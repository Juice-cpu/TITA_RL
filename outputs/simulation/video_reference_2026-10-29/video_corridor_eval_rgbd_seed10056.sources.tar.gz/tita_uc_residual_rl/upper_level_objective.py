"""Objective, feasibility mask, and deterministic upper-level baselines."""

from __future__ import annotations

from dataclasses import replace
import math
import time
from typing import Protocol

import numpy as np

from .upper_level_types import (
    SPEED_RATIOS,
    UpperDecision,
    UpperNormalization,
    UpperObjectiveTerms,
    UpperObjectiveWeights,
    UpperObservation,
    UpperSafetyConfig,
    decode_action,
    encode_action,
)


class UpperPolicy(Protocol):
    def decide(self, observation: UpperObservation) -> UpperDecision: ...


def braking_clearance(speed_mps: float, route_index: int, safety: UpperSafetyConfig) -> float:
    speed = abs(float(speed_mps))
    deceleration = safety.braking_accel_mps2[route_index]
    return (
        safety.minimum_lateral_clearance_m
        + safety.reaction_time_s * speed
        + speed * speed / (2.0 * deceleration)
        + safety.envelope_margin_m
    )


def action_mask(observation: UpperObservation, safety: UpperSafetyConfig) -> np.ndarray:
    """Return the nine hard-feasibility flags for an observation."""

    mask = np.zeros(9, dtype=np.bool_)
    common_valid = (
        observation.sensor_valid
        and observation.path_age_s <= safety.maximum_path_age_s
        and observation.goal_age_s <= safety.maximum_goal_age_s
        and abs(observation.roll_rad) < safety.attitude_hard_rad
        and abs(observation.pitch_rad) < safety.attitude_hard_rad
    )
    if not common_valid:
        return mask

    versions = {
        (route.path_version, route.goal_version)
        for route in observation.routes
        if route.valid
    }
    version_consistent = len(versions) <= 1
    if not version_consistent:
        return mask

    can_switch = (
        abs(observation.speed_mps) <= safety.switch_speed_max_mps
        and abs(observation.roll_rad) <= safety.switch_roll_max_rad
        and abs(observation.pitch_rad) <= safety.switch_pitch_max_rad
        and observation.stable_elapsed_s >= safety.switch_hold_time_s
        and not observation.route_locked
    )
    for route_index, route in enumerate(observation.routes):
        if not route.valid or route.overhead_margin_m < 0.0:
            continue
        if route_index != observation.current_route and not can_switch:
            continue
        vmax = safety.posture_vmax_mps[route_index]
        for speed_index, ratio in enumerate(SPEED_RATIOS):
            target_speed = ratio * vmax
            if route.lateral_clearance_m < braking_clearance(target_speed, route_index, safety):
                continue
            mask[encode_action(route_index, speed_index)] = True
    return mask


def clearance_risk(overhead_margin_m: float, safety: UpperSafetyConfig) -> float:
    deficit = max(0.0, safety.clearance_soft_margin_m - float(overhead_margin_m))
    return (deficit / safety.clearance_soft_margin_m) ** 2


def attitude_penalty(roll_rad: float, pitch_rad: float, safety: UpperSafetyConfig) -> float:
    scale = safety.attitude_hard_rad - safety.attitude_soft_rad
    roll = max(0.0, abs(float(roll_rad)) - safety.attitude_soft_rad) / scale
    pitch = max(0.0, abs(float(pitch_rad)) - safety.attitude_soft_rad) / scale
    return roll * roll + pitch * pitch


def incremental_terms(
    *,
    energy_j: float,
    elapsed_s: float,
    distance_m: float,
    overhead_margin_m: float,
    switched: bool,
    roll_rad: float,
    pitch_rad: float,
    normalization: UpperNormalization,
    safety: UpperSafetyConfig,
    clearance_violation: bool = False,
    height_violation: bool = False,
) -> UpperObjectiveTerms:
    return UpperObjectiveTerms(
        energy=max(0.0, float(energy_j)) / normalization.energy_ref_j,
        time=max(0.0, float(elapsed_s)) / normalization.time_ref_s,
        length=max(0.0, float(distance_m)) / normalization.length_ref_m,
        clearance=clearance_risk(overhead_margin_m, safety),
        switch=float(switched),
        clearance_violation=float(clearance_violation),
        height_violation=float(height_violation),
        attitude=attitude_penalty(roll_rad, pitch_rad, safety),
    )


def scalar_cost(terms: UpperObjectiveTerms, weights: UpperObjectiveWeights) -> float:
    return float(
        weights.energy * terms.energy
        + weights.time * terms.time
        + weights.length * terms.length
        + weights.clearance * terms.clearance
        + weights.switch * terms.switch
        + weights.clearance_violation * terms.clearance_violation
        + weights.height_violation * terms.height_violation
        + weights.attitude * terms.attitude
    )


def sensitivity_weights(
    weights: UpperObjectiveWeights, term: str, factor: float
) -> UpperObjectiveWeights:
    if term not in ("energy", "time", "length", "clearance", "switch", "attitude"):
        raise ValueError(f"unsupported sensitivity term {term!r}")
    if factor <= 0.0:
        raise ValueError("sensitivity factor must be positive")
    return replace(weights, **{term: getattr(weights, term) * factor})


def estimate_remaining_action_cost(
    observation: UpperObservation,
    action_id: int,
    normalization: UpperNormalization,
    weights: UpperObjectiveWeights,
    safety: UpperSafetyConfig,
) -> float:
    """Model-based whole-route score used by the enumeration baseline."""

    route_index, speed_index = decode_action(action_id)
    route = observation.routes[route_index]
    speed = SPEED_RATIOS[speed_index] * safety.posture_vmax_mps[route_index]
    speed = max(speed, 1e-4)
    time_s = route.remaining_length_m / speed
    slope_load = 1.0 + 3.0 * abs(route.mean_slope_rad)
    terrain_load = 1.0 + 8.0 * route.roughness_rms_m + route.curvature_integral
    posture_power = (0.24, 0.20, 0.22)[route_index]
    power = posture_power + 5.0 * speed * speed * slope_load * terrain_load
    energy = power * time_s
    terms = incremental_terms(
        energy_j=energy,
        elapsed_s=time_s,
        distance_m=route.remaining_length_m,
        overhead_margin_m=route.overhead_margin_m,
        switched=route_index != observation.current_route,
        roll_rad=observation.roll_rad,
        pitch_rad=observation.pitch_rad,
        normalization=normalization,
        safety=safety,
    )
    return scalar_cost(terms, weights)


class ShortestRoutePolicy:
    """Traditional baseline: shortest hard-feasible route at speed ratio 0.7."""

    def __init__(self, safety: UpperSafetyConfig | None = None) -> None:
        self.safety = safety or UpperSafetyConfig()

    def decide(self, observation: UpperObservation) -> UpperDecision:
        mask = action_mask(observation, self.safety)
        candidates = []
        for route_index, route in enumerate(observation.routes):
            action_id = encode_action(route_index, 1)
            if mask[action_id]:
                candidates.append((route.remaining_length_m, route_index, action_id))
        if not candidates:
            return UpperDecision.stop("no_feasible_action")
        _, _, action_id = min(candidates)
        return UpperDecision.from_action(action_id, observation, "shortest_feasible_route")


class EnumeratedObjectivePolicy:
    """Non-learning baseline: score all feasible actions and take argmin."""

    def __init__(
        self,
        normalization: UpperNormalization,
        weights: UpperObjectiveWeights | None = None,
        safety: UpperSafetyConfig | None = None,
    ) -> None:
        self.normalization = normalization
        self.weights = weights or UpperObjectiveWeights()
        self.safety = safety or UpperSafetyConfig()

    def decide(self, observation: UpperObservation) -> UpperDecision:
        mask = action_mask(observation, self.safety)
        feasible = np.flatnonzero(mask)
        if feasible.size == 0:
            return UpperDecision.stop("no_feasible_action")
        scores = [
            (
                estimate_remaining_action_cost(
                    observation,
                    int(action),
                    self.normalization,
                    self.weights,
                    self.safety,
                ),
                int(action),
            )
            for action in feasible
        ]
        score, action_id = min(scores)
        return UpperDecision.from_action(
            action_id, observation, f"enumerated_argmin_cost={score:.8f}"
        )


def timed_decision(policy: UpperPolicy, observation: UpperObservation) -> tuple[UpperDecision, float]:
    started = time.perf_counter_ns()
    decision = policy.decide(observation)
    elapsed_ms = (time.perf_counter_ns() - started) / 1e6
    return decision, elapsed_ms

