from __future__ import annotations

from dataclasses import dataclass
import math


@dataclass
class ModeExecutionGuard:
    mode: int = 1
    transition_s: float = 6.0
    minimum_hold_s: float = 3.0
    stable_hold_s: float = 0.5
    stable_attitude_max_rad: float = 0.12
    last_switch_s: float = 0.0
    stable_since_s: float | None = None
    ready: bool = False
    stable_feedback: bool = False
    has_switched: bool = False
    pending_mode: int | None = None
    pending_since_s: float | None = None

    def execution_timed_out(self, time_s: float, maximum_wait_s: float = 24.) -> bool:
        if not math.isfinite(time_s) or not math.isfinite(maximum_wait_s) or maximum_wait_s <= self.transition_s:
            raise ValueError("execution timeout must be finite and exceed transition time")
        waiting_since = self.pending_since_s if self.pending_mode is not None else self.last_switch_s if not self.ready else None
        return waiting_since is not None and time_s - waiting_since >= maximum_wait_s

    def command_phase(self, time_s: float, control_dt_s: float) -> float:
        if (not math.isfinite(time_s) or not math.isfinite(control_dt_s) or control_dt_s <= 0.
                or time_s < self.last_switch_s):
            raise ValueError("transition phase requires finite monotonic time and positive control period")
        if not self.has_switched:
            return 0.
        phase = (time_s - self.last_switch_s + control_dt_s) / self.transition_s
        return min(phase, 1.) if phase <= 1. + 1e-9 else 0.

    def observe(self, time_s: float, measured_height_m: float, target_height_m: float,
                speed_mps: float, roll_rad: float, pitch_rad: float, wheels_grounded: bool) -> bool:
        values = (time_s, measured_height_m, target_height_m, speed_mps, roll_rad, pitch_rad)
        if not all(math.isfinite(value) for value in values) or time_s < self.last_switch_s:
            raise ValueError("execution feedback must be finite and monotonic")
        stable = (abs(measured_height_m - target_height_m) <= 0.025 and abs(roll_rad) <= self.stable_attitude_max_rad
                  and abs(pitch_rad) <= self.stable_attitude_max_rad and speed_mps <= 0.08 and wheels_grounded)
        self.stable_feedback = bool(stable)
        if not stable:
            self.stable_since_s = None
        elif self.stable_since_s is None:
            self.stable_since_s = time_s
        if not self.ready:
            self.ready = bool(time_s - self.last_switch_s + 1e-9 >= self.transition_s and self.stable_since_s is not None
                              and time_s - self.stable_since_s + 1e-9 >= self.stable_hold_s)
        return self.ready

    def may_switch(self, time_s: float) -> bool:
        return (self.ready and self.stable_feedback and self.stable_since_s is not None
                and time_s - self.stable_since_s + 1e-9 >= self.stable_hold_s
                and time_s - self.last_switch_s >= self.transition_s + (self.minimum_hold_s if self.has_switched else 0.))

    def select(self, mode: int, time_s: float) -> bool:
        if mode not in range(3):
            raise ValueError("mode must be LOW, MID or HIGH index")
        if mode == self.mode:
            return True
        if not self.may_switch(time_s):
            return False
        self.mode = mode
        self.has_switched = True
        self.last_switch_s = time_s
        self.stable_since_s = None
        self.ready = False
        self.pending_mode = None
        self.pending_since_s = None
        return True

    def request(self, mode: int, time_s: float) -> bool:
        if mode not in range(3):
            raise ValueError("mode must be LOW, MID or HIGH index")
        if mode == self.mode:
            return True
        if self.pending_mode != mode:
            self.pending_since_s = time_s
        self.pending_mode = mode
        return self.select(mode, time_s)

    def advance(self, time_s: float) -> bool:
        return self.pending_mode is not None and self.select(self.pending_mode, time_s)
