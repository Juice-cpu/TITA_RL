import tempfile


def create_runtime_asset_directory(parent=None):
    return tempfile.mkdtemp(prefix='tita_usd_', dir=parent)
