import math

import numpy as np

from .dynamic_perception import PedestrianMotionContext
from .joint_navigation import JointSafetyConfig, PathCandidate, Pedestrian, PedestrianPredictor
from .observed_shuttle_prediction import ObservedShuttleForecaster


def audit_observed_shuttle_contexts(document):
    failures = []
    enabled = document.get('observed_shuttle_prediction', {}).get('enabled', False)
    rows = document.get('sensor_records', [])
    if not enabled:
        present = any(context.get('shuttle_prediction') is not None for row in rows for context in row['motion_context'])
        return {'passed': not present, 'failures': ['disabled_predictor_emitted_forecast'] if present else [],
            'forecast_contexts': 0, 'sensor_frames': len(rows)}
    if (document['observed_shuttle_prediction'].get('contract') != 'tita.observed_shuttle_forecast.v1'
            or not document.get('upper_safety_config', {}).get('observed_shuttle_prediction')
            or '--observed-shuttle-prediction' not in document.get('invocation', [])):
        failures.append('enabled_predictor_contract_not_bound_to_safety_and_invocation')
    if not rows:
        failures.append('missing_actual_sensor_records')
    plateau = document['observed_shuttle_prediction'].get('motion_plateau_gate', False)
    if (plateau != ('--observed-shuttle-plateau-gate' in document.get('invocation', []))
            or plateau and document['observed_shuttle_prediction'].get('motion_plateau_contract') != 'tita.observed_closed_motion_plateaus.v1'):
        failures.append('motion_plateau_gate_not_bound_to_invocation_and_contract')
    forecasters = {}
    last_times = {}
    forecasts = 0
    maximum_point_error = 0.
    for row in rows:
        try:
            episode, timestamp = row['episode'], row['observation_time_s']
            if not math.isfinite(timestamp) or episode in last_times and timestamp <= last_times[episode]:
                raise ValueError('nonmonotonic sensor timestamp')
            last_times[episode] = timestamp
            forecaster = forecasters.setdefault(episode, ObservedShuttleForecaster(plateau))
            observations = row['motion_track_observations']
            metadata = {value['identifier']: value for value in observations}
            if len(metadata) != len(observations) or len(row['tracks']) != len(row['motion_context']):
                raise ValueError('misaligned observation identifiers')
            for person, context in zip(row['tracks'], row['motion_context']):
                state = metadata[context['identifier']]
                if (not isinstance(state['observations'], int) or state['observations'] < 1
                        or not math.isfinite(state['last_seen_s']) or state['last_seen_s'] > timestamp):
                    raise ValueError('invalid fresh observation evidence')
                if state['observations'] >= 3 and state['last_seen_s'] == timestamp:
                    forecaster.update(context['identifier'], timestamp, [person['x'], person['y']], [person['vx'], person['vy']])
            for person, context in zip(row['tracks'], row['motion_context']):
                expected = forecaster.forecast(context['identifier'], timestamp)
                actual = context.get('shuttle_prediction')
                if expected is None or actual is None:
                    if expected != actual:
                        raise ValueError('forecast presence differs from causal replay')
                    continue
                PedestrianMotionContext(**context)
                if plateau and expected['motion_plateau_evidence'] != actual.get('motion_plateau_evidence'):
                    raise ValueError('motion plateau evidence differs from causal replay')
                for field in ('schema', 'times_s', 'source', 'contributor_ids', 'identity_reidentification_claimed',
                        'future_actor_waypoints_or_labels_used', 'computed_at_s'):
                    if expected[field] != actual[field]:
                        raise ValueError(f'forecast metadata differs:{field}')
                point_error = float(np.max(np.abs(np.asarray(expected['points_xy_m']) - np.asarray(actual['points_xy_m']))))
                maximum_point_error = max(maximum_point_error, point_error)
                if point_error > 1e-9 or not math.isclose(expected['uncertainty_radius_m'], actual['uncertainty_radius_m'], abs_tol=1e-9):
                    raise ValueError('forecast trajectory or uncertainty differs from causal replay')
                if np.linalg.norm(np.asarray(actual['points_xy_m'][0]) - np.asarray([person['x'], person['y']])) > .05:
                    raise ValueError('forecast not anchored to actual tracked position')
                forecasts += 1
        except (KeyError, TypeError, ValueError, IndexError) as error:
            failures.append(f'{row.get("episode")}:{row.get("step")}:{error}')
            break
    if document['observed_shuttle_prediction'].get('forecast_contexts') != forecasts:
        failures.append('terminal_forecast_count_not_bound_to_contexts')
    return {'passed': not failures, 'failures': failures, 'forecast_contexts': forecasts,
        'sensor_frames': len(rows), 'maximum_causal_forecast_point_error_m': maximum_point_error,
        'actor_truth_or_future_script_fields_used': False}


def audit_observed_shuttle_risk_binding(document):
    failures = []
    if not document.get('observed_shuttle_prediction', {}).get('enabled'):
        return {'passed': True, 'failures': [], 'risk_values_checked': 0, 'risk_values_changed_from_restart_only': 0}
    if not document.get('trajectory') or not document.get('decision_events'):
        return {'passed': False, 'failures': ['actual_trajectory_and_decisions_required'], 'risk_values_checked': 0}
    safety = JointSafetyConfig(**document['upper_safety_config'])
    dt = document['elapsed_simulation_s'] / document['completed_steps']
    trajectory = {(row['episode'], row['step']): row for row in document['trajectory']}
    sensors = {(row['episode'], row['step']): row for row in document['sensor_records']}
    first_steps = {}
    for row in document['trajectory']:
        first_steps.setdefault(row['episode'], row['step'])
    predictor = PedestrianPredictor()
    maximum_error = 0.
    checked = 0
    changed = 0
    for event in document['decision_events']:
        try:
            key = event['episode'], first_steps[event['episode']] + round(event['time_s'] / dt)
            row, sensor = trajectory[key], sensors[key]
            people = tuple(Pedestrian(**person) for person in sensor['tracks'])
            contexts = tuple(PedestrianMotionContext(**context) for context in sensor['motion_context'])
            current_mode = ('LOW', 'MID', 'HIGH').index(event['actual_posture'])
            measured_speed = float(np.linalg.norm(row['measured_velocity_before'][:2]))
            options = dict(pedestrian_motion_context=contexts, stationary_restart=safety.stationary_restart_prediction,
                stationary_speed_threshold_mps=safety.stationary_speed_threshold_mps,
                restart_speed_margin_mps=safety.restart_speed_margin_mps, moving_speed_envelope=safety.moving_speed_prediction)
            for action in np.flatnonzero(event['valid_actions'][:-1]):
                path_index, offset = divmod(int(action), 9)
                selected_mode = offset // 3
                candidate = event['candidates'][path_index]
                route = PathCandidate(candidate['id'], np.asarray(candidate['points_xy_m']), candidate['length_m'], 1, .2)
                target = event['action_features'][action][6]
                switched = selected_mode != current_mode
                settling = safety.command_settling_delay_s(selected_mode, 0. if switched else measured_speed, target) if safety.execution_timing_prediction else 0.
                delay = settling + (safety.expected_transition_costs_s[current_mode][selected_mode] if switched else 0.)
                radius = .5 + (max(0., measured_speed - target) * settling if not switched and safety.execution_timing_prediction else 0.)
                minimum_delay = safety.minimum_mode_motion_hold_s if switched else 0.
                if switched and minimum_delay > 0.:
                    radius += measured_speed * safety.braking_horizon_s(current_mode, measured_speed) + safety.transition_position_margin_m
                if switched or safety.execution_timing_prediction:
                    calculate = lambda enabled: predictor.transition_risk_for_path(route, people, target, delay, radius,
                        observed_shuttle_prediction=enabled, minimum_delay_s=minimum_delay, **options)
                else:
                    calculate = lambda enabled: predictor.timed_risk_for_path(route, people, target,
                        observed_shuttle_prediction=enabled, **options)
                actual = calculate(True)
                if not math.isfinite(event['action_features'][action][8]) or not math.isfinite(actual):
                    raise ValueError('nonfinite action risk evidence')
                maximum_error = max(maximum_error, abs(actual - event['action_features'][action][8]))
                changed += abs(actual - calculate(False)) > 1e-6
                checked += 1
            wait_path = PathCandidate('audit_wait', np.asarray([event['pose_xy_m']] * 2), 0., 1, 0.)
            braking = safety.braking_horizon_s(current_mode, measured_speed)
            wait_options = dict(horizon_s=max(safety.wait_risk_horizon_s, braking), robot_radius_m=.5 + measured_speed * braking, **options)
            actual_wait = predictor.timed_risk_for_path(wait_path, people, 0., observed_shuttle_prediction=True, **wait_options)
            original_wait = predictor.timed_risk_for_path(wait_path, people, 0., **wait_options)
            if not math.isfinite(event['action_features'][-1][8]) or not math.isfinite(actual_wait):
                raise ValueError('nonfinite WAIT risk evidence')
            maximum_error = max(maximum_error, abs(actual_wait - event['action_features'][-1][8]))
            changed += abs(actual_wait - original_wait) > 1e-6
            checked += 1
        except (KeyError, TypeError, ValueError, IndexError) as error:
            failures.append(f'{event.get("episode")}:{event.get("time_s")}:{error}')
            break
    if maximum_error > 1e-6:
        failures.append('recorded_action_or_wait_risk_not_bound_to_forecast_predictor')
    return {'passed': not failures, 'failures': failures, 'risk_values_checked': checked,
        'risk_values_changed_from_restart_only': int(changed), 'maximum_risk_binding_error': maximum_error}


def audit_observed_shuttle_prediction(document):
    contexts = audit_observed_shuttle_contexts(document)
    risks = audit_observed_shuttle_risk_binding(document) if contexts['passed'] else {
        'passed': False, 'failures': ['causal_context_replay_failed']}
    return {'passed': contexts['passed'] and risks['passed'], 'contexts': contexts, 'risks': risks,
        'scope': 'Causal reconstruction from logged measured tracks plus action/WAIT risk binding; not new physics, a human-motion bound, or an execution certificate.'}
