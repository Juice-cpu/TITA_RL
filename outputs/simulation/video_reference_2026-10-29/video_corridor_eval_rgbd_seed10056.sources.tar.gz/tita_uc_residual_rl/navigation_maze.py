"""Static oracle maze geometry shared by physics, maps and benchmark features."""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

import numpy as np

from .three_route_scene import SceneBox


def load_maze(path):
    scene = json.loads(Path(path).read_text())
    if scene.get("schema") != "tita.navigation_maze.v1" or scene.get("simulation_only") is not True:
        raise ValueError("expected a simulation-only navigation maze")
    for key in ("start_xy_m", "goal_xy_m", "bounds_xy_m", "posture_envelope_height_m"):
        if not np.isfinite(scene[key]).all():
            raise ValueError(f"nonfinite scene field: {key}")
    if len(scene["start_xy_m"]) != 2 or len(scene["goal_xy_m"]) != 2:
        raise ValueError("maze start and goal must be planar")
    bounds = scene["bounds_xy_m"]
    if len(bounds) != 4 or bounds[0] >= bounds[1] or bounds[2] >= bounds[3]:
        raise ValueError("maze bounds must have positive area")
    heights = scene["posture_envelope_height_m"]
    if len(heights) != 3 or not 0 < heights[0] < heights[1] < heights[2]:
        raise ValueError("maze requires three increasing positive posture envelopes")
    for key in ("map_resolution_m", "planning_inflation_m", "footprint_radius_m", "open_overhead_reporting_cap_m"):
        if not math.isfinite(scene[key]) or scene[key] <= 0:
            raise ValueError(f"{key} must be positive and finite")
    if not math.isfinite(scene["floor_height_m"]):
        raise ValueError("floor height must be finite")
    for box in scene["boxes"]:
        if len(box["center"]) != 3 or len(box["size"]) != 3:
            raise ValueError("boxes require three-dimensional geometry")
        if not np.isfinite(box["center"]).all() or not np.isfinite(box["size"]).all() or min(box["size"]) <= 0:
            raise ValueError("boxes require finite centers and positive sizes")
        if box["kind"] not in ("wall", "roof"):
            raise ValueError("unsupported box kind")
    return scene


def validate_execution_terrain(scene, terrain, goal_xy_m, *, calibrated, stair_start_m=1.2,
                               stair_width_m=1.3, stair_count=1, stair_tread_m=.6,
                               stair_landing_m=5.):
    if (not calibrated or scene["start_xy_m"] != [0., 0.] or scene["floor_height_m"] != 0.
            or list(scene["goal_xy_m"]) != list(goal_xy_m)):
        raise ValueError("authored execution requires calibration, zero origin/floor, and matching goal")
    if terrain == "flat":
        return
    if terrain not in ("stairs", "mixed"):
        raise ValueError("authored execution supports flat or bounded stair support, not duplicate tunnel geometry")
    if terrain == "mixed":
        roof_boxes = [box for box in scene.get("boxes", ()) if box.get("kind") == "roof"]
        if not roof_boxes:
            raise ValueError("mixed authored execution requires at least one explicit low-clearance roof")
        if any(not np.isfinite(box.get("center", [])).all()
               or not np.isfinite(box.get("size", [])).all()
               or min(box.get("size", [0.])) <= 0.
               for box in roof_boxes):
            raise ValueError("mixed authored roofs require finite positive geometry")
    dimensions = [stair_start_m, stair_width_m, stair_count, stair_tread_m, stair_landing_m]
    if not np.isfinite(dimensions).all() or min(dimensions) <= 0. or int(stair_count) != stair_count:
        raise ValueError("authored stair support dimensions must be positive and finite")
    bounds = scene["bounds_xy_m"]
    support_end = stair_start_m + stair_count * stair_tread_m + stair_landing_m
    if terrain == "stairs":
        if (bounds[2] < -stair_width_m / 2. or bounds[3] > stair_width_m / 2.
                or bounds[1] > support_end or not stair_start_m < goal_xy_m[0] < support_end):
            raise ValueError("authored route bounds and goal must remain inside the stair support extent")
    elif (not stair_start_m < goal_xy_m[0] < support_end
          or abs(goal_xy_m[1]) > stair_width_m / 2.):
        raise ValueError("mixed terrain goal must remain inside the verified stair support extent")


def maze_boxes(scene, origin_xy=(0.0, 0.0)):
    return tuple(SceneBox(
        box["name"],
        (box["center"][0] + origin_xy[0], box["center"][1] + origin_xy[1], box["center"][2]),
        tuple(box["size"]),
        (217, 163, 66, 255) if box["kind"] == "roof" else (92, 117, 137, 255),
    ) for box in scene["boxes"])


def box_distance_xy(points, box):
    points = np.asarray(points, dtype=float).reshape(-1, 2)
    delta = np.abs(points - np.asarray(box["center"][:2])) - np.asarray(box["size"][:2]) / 2.0
    return np.linalg.norm(np.maximum(delta, 0.0), axis=1) + np.minimum(np.max(delta, axis=1), 0.0)


def segment_intersects_box_xy(start, goal, box):
    start = np.asarray(start, dtype=float)
    direction = np.asarray(goal, dtype=float) - start
    lower = np.asarray(box["center"][:2]) - np.asarray(box["size"][:2]) / 2
    upper = np.asarray(box["center"][:2]) + np.asarray(box["size"][:2]) / 2
    enter, leave = 0.0, 1.0
    for dimension in range(2):
        if abs(direction[dimension]) < 1e-12:
            if start[dimension] < lower[dimension] or start[dimension] > upper[dimension]:
                return False
        else:
            crossings = sorted(((lower[dimension] - start[dimension]) / direction[dimension],
                                (upper[dimension] - start[dimension]) / direction[dimension]))
            enter, leave = max(enter, crossings[0]), min(leave, crossings[1])
            if enter > leave:
                return False
    return True


def audit_competing_routes(scene, branches):
    contract = scene["competing_routes"]
    boxes = {box["name"]: box for box in scene["boxes"]}
    errors, measurements = [], {}
    direct_blocked = segment_intersects_box_xy(scene["start_xy_m"], scene["goal_xy_m"], boxes[contract["central_blocker"]])
    if not direct_blocked:
        errors.append("central obstacle does not block the direct start-goal segment")
    direct_length = np.linalg.norm(np.asarray(scene["goal_xy_m"]) - scene["start_xy_m"])
    for branch, postures in branches.items():
        blocker = boxes[contract["branches"][branch]["goal_line_blocker"]]
        anchor = contract["branches"][branch]["visibility_anchor_xy_m"]
        goal_line_blocked = segment_intersects_box_xy(anchor, scene["goal_xy_m"], blocker)
        if not goal_line_blocked:
            errors.append(f"{branch}: secondary obstacle does not block anchor-goal visibility")
        measurements[branch] = {}
        for posture, path in postures.items():
            points = np.asarray(path["xy_m"])
            samples = sample_polyline(points, spacing_m=0.01)
            length = float(np.linalg.norm(np.diff(points, axis=0), axis=1).sum())
            side = 1 if branch == "north" else -1
            split_points = samples[np.abs(samples[:, 0] - contract["split_x_m"]) <= 0.02]
            if not len(split_points) or np.min(side * (split_points[:, 1] - contract["partition_y_m"])) <= 0:
                errors.append(f"{branch}/{posture}: route does not use its distinct side of the central island")
            if not np.allclose(points[0], scene["start_xy_m"]) or not np.allclose(points[-1], scene["goal_xy_m"]):
                errors.append(f"{branch}/{posture}: route endpoints differ from scene")
            for box in scene["boxes"]:
                if box["kind"] == "wall" and np.min(box_distance_xy(samples, box)) <= scene["footprint_radius_m"]:
                    errors.append(f"{branch}/{posture}: nominal swept footprint collides with {box['name']}")
            if length < direct_length * contract["minimum_detour_ratio"]:
                errors.append(f"{branch}/{posture}: route lacks the required detour")
            if path["features"]["lateral_clearance_m"] < scene["planning_inflation_m"] - scene["footprint_radius_m"] - scene["map_resolution_m"]:
                errors.append(f"{branch}/{posture}: route cuts inside the conservative planning envelope")
            measurements[branch][posture] = {"length_m": length, "goal_line_blocked": goal_line_blocked,
                                            "lateral_clearance_m": path["features"]["lateral_clearance_m"]}
    ratios = {}
    for posture in ("LOW", "MID", "HIGH"):
        lengths = [measurements[branch][posture]["length_m"] for branch in ("north", "south")]
        ratios[posture] = max(lengths) / min(lengths)
        if ratios[posture] > contract["maximum_length_ratio"]:
            errors.append(f"{posture}: branch lengths differ beyond the contract")
    return {"passed": not errors, "errors": errors, "direct_start_goal_blocked": direct_blocked,
            "branch_length_ratios": ratios, "branches": measurements,
            "scope": "oracle geometry and offline branch references; not two additional learned RL actions"}


def sample_polyline(points, spacing_m=0.05):
    points = np.asarray(points, dtype=float).reshape(-1, 2)
    if len(points) == 0 or not math.isfinite(spacing_m) or spacing_m <= 0 or not np.isfinite(points).all():
        raise ValueError("a finite nonempty polyline and positive spacing are required")
    if len(points) == 1:
        return points.copy()
    lengths = np.linalg.norm(np.diff(points, axis=0), axis=1)
    keep = np.concatenate(([True], lengths > 1e-12))
    points = points[keep]
    if len(points) == 1:
        return points.copy()
    cumulative = np.concatenate(([0.0], np.cumsum(np.linalg.norm(np.diff(points, axis=0), axis=1))))
    distances = np.concatenate((np.arange(0.0, cumulative[-1], spacing_m), [cumulative[-1]]))
    return np.column_stack([np.interp(distances, cumulative, points[:, dimension]) for dimension in range(2)])


def route_geometry_features(scene, points, posture_index):
    if posture_index not in range(3):
        raise ValueError("posture index must be 0, 1 or 2")
    samples = sample_polyline(points)
    radius = float(scene["footprint_radius_m"])
    wall_clearance = np.full(len(samples), np.inf)
    overhead = np.full(len(samples), float(scene["open_overhead_reporting_cap_m"]))
    envelope = float(scene["posture_envelope_height_m"][posture_index])
    for box in scene["boxes"]:
        distance = box_distance_xy(samples, box)
        if box["kind"] == "wall":
            wall_clearance = np.minimum(wall_clearance, distance - radius)
        else:
            covered = distance <= radius
            underside = box["center"][2] - box["size"][2] / 2.0
            overhead[covered] = np.minimum(overhead[covered], underside - envelope)
    floor_samples = np.full(len(samples), float(scene["floor_height_m"]))
    step_length = np.linalg.norm(np.diff(samples, axis=0), axis=1)
    slopes = np.arctan2(np.diff(floor_samples), np.maximum(step_length, 1e-12))
    return {
        "lateral_clearance_m": float(np.min(wall_clearance)),
        "overhead_margin_m": float(np.min(overhead)),
        "mean_slope_rad": float(np.mean(np.abs(slopes))) if len(slopes) else 0.0,
        "max_slope_rad": float(np.max(np.abs(slopes))) if len(slopes) else 0.0,
        "roughness_rms_m": float(np.sqrt(np.mean((floor_samples - np.mean(floor_samples)) ** 2))),
        "geometry_source": "oracle_static_collision_boxes_and_analytical_floor",
        "online_perception": False,
        "geometry_sample_count": len(samples),
        "geometry_scope": "minimum along the supplied candidate polyline, not live sensor measurement",
        "open_overhead_reporting_cap_m": scene["open_overhead_reporting_cap_m"],
        "robot_envelope_source": "existing_nominal_envelope_not_new_swept_volume_validation",
    }


def maze_hmap_points(scene, origin_xy=(0.0, 0.0)):
    layers = [[], [], []]
    resolution = float(scene["map_resolution_m"])
    for layer_index, envelope in enumerate(scene["posture_envelope_height_m"]):
        for box in scene["boxes"]:
            bottom = box["center"][2] - box["size"][2] / 2.0
            if box["kind"] == "roof" and envelope < bottom:
                continue
            count_x = max(1, math.ceil(box["size"][0] / resolution))
            count_y = max(1, math.ceil(box["size"][1] / resolution))
            for x_index in range(count_x + 1):
                for y_index in range(count_y + 1):
                    layers[layer_index].append([
                        round(box["center"][0] - box["size"][0] / 2 + x_index * box["size"][0] / count_x + origin_xy[0], 4),
                        round(box["center"][1] - box["size"][1] / 2 + y_index * box["size"][1] / count_y + origin_xy[1], 4),
                        (0.20, 0.30, 0.40)[layer_index],
                    ])
    return layers


def scene_digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
