import math

import numpy as np


def _validated_points(path):
    points = np.asarray(path.points_xy_m, dtype=float)
    if points.ndim != 2 or points.shape[1] != 2 or len(points) < 2 or not np.isfinite(points).all():
        raise ValueError('route continuity requires finite planar polylines')
    return points


def _projected_suffix(points, position):
    delta = np.diff(points, axis=0)
    squared = np.sum(delta * delta, axis=1)
    fractions = np.clip(np.sum((position - points[:-1]) * delta, axis=1) / np.maximum(squared, 1e-15), 0., 1.)
    projections = points[:-1] + fractions[:, None] * delta
    nearest = int(np.argmin(np.linalg.norm(projections - position, axis=1)))
    return np.vstack((projections[nearest], points[nearest + 1:]))


def _sample_prefix(points, length, spacing):
    lengths = np.linalg.norm(np.diff(points, axis=0), axis=1)
    distances = np.r_[0., np.cumsum(lengths)]
    keep = np.r_[True, np.diff(distances) > 1e-12]
    points, distances = points[keep], distances[keep]
    if len(points) == 1:
        return points
    queries = np.linspace(0., min(length, distances[-1]), max(2, int(math.ceil(length / spacing)) + 1))
    return np.column_stack([np.interp(queries, distances, points[:, axis]) for axis in range(2)])


def _directed_distance(samples, segments):
    if len(segments) == 1:
        return float(np.linalg.norm(samples - segments[0], axis=1).max())
    delta = np.diff(segments, axis=0)
    squared = np.maximum(np.sum(delta * delta, axis=1), 1e-15)
    displacement = samples[:, None, :] - segments[:-1]
    fractions = np.clip(np.sum(displacement * delta, axis=2) / squared, 0., 1.)
    distances = np.linalg.norm(displacement - fractions[:, :, None] * delta, axis=2)
    return float(distances.min(axis=1).max())


def route_change_distance(previous_path, current_path, position_xy_m, lookahead_m=3., sample_spacing_m=.05):
    if (not math.isfinite(lookahead_m) or lookahead_m <= 0.
            or not math.isfinite(sample_spacing_m) or sample_spacing_m <= 0.):
        raise ValueError('route continuity requires positive finite lookahead and spacing')
    position = np.asarray(position_xy_m, dtype=float)
    if position.shape != (2,) or not np.isfinite(position).all():
        raise ValueError('route continuity requires a finite robot position')
    if previous_path is None:
        _validated_points(current_path)
        return 0.
    previous = _projected_suffix(_validated_points(previous_path), position)
    current = _projected_suffix(_validated_points(current_path), position)
    common_length = min(lookahead_m, *(float(np.linalg.norm(np.diff(points, axis=0), axis=1).sum())
                                      for points in (previous, current)))
    previous_samples = _sample_prefix(previous, common_length, sample_spacing_m)
    current_samples = _sample_prefix(current, common_length, sample_spacing_m)
    return max(_directed_distance(previous_samples, current_samples), _directed_distance(current_samples, previous_samples))
