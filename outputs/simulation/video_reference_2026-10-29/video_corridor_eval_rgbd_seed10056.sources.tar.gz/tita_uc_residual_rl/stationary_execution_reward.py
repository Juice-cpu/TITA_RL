import math

import torch


def stationary_execution_reward(previous_hold_s, command, linear_velocity, angular_velocity,
                                 gravity, contacts, height_error_m, phase, failed, dt_s,
                                 reward_per_second=0., interruption_penalty=0.):
    if (not all(math.isfinite(value) for value in (dt_s, reward_per_second, interruption_penalty))
            or dt_s <= 0. or min(reward_per_second, interruption_penalty) < 0.):
        raise ValueError('stationary reward requires positive time and nonnegative finite weights')
    count = len(previous_hold_s)
    if (any(value.shape != (count, 3) for value in (command, linear_velocity, angular_velocity, gravity))
            or contacts.shape != (count, 2) or contacts.dtype != torch.bool
            or any(value.shape != (count,) for value in (height_error_m, phase, failed))):
        raise ValueError('stationary reward requires aligned physical feedback')
    requested_stop = (torch.linalg.vector_norm(command[:, :2], dim=1) <= .005) & (command[:, 2].abs() <= .005)
    eligible = requested_stop & (phase <= 1e-6) & ~failed
    roll = torch.atan2(gravity[:, 1], -gravity[:, 2])
    pitch = torch.atan2(-gravity[:, 0], torch.linalg.vector_norm(gravity[:, 1:], dim=1))
    stable = (eligible & contacts.all(1) & (height_error_m.abs() <= .025)
              & (torch.linalg.vector_norm(linear_velocity[:, :2], dim=1) <= .03)
              & (linear_velocity[:, 2].abs() <= .10) & (angular_velocity[:, 2].abs() <= .05)
              & (roll.abs() <= .12) & (pitch.abs() <= .12))
    hold_s = torch.where(stable, previous_hold_s + dt_s, torch.zeros_like(previous_hold_s))
    interrupted = eligible & ~stable & (previous_hold_s >= .2)
    reward = reward_per_second * dt_s * (hold_s >= 1. - 1e-6) - interruption_penalty * interrupted
    return hold_s, reward
