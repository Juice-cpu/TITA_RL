"""Dependency-free UDP transport used between Isaac Sim and a ROS2 bridge."""

from __future__ import annotations

import json
import math
import socket
import time
from typing import Any

import torch

from tita_realtime_trace import timing_enabled, trace_event


UDP_SAFE_PAYLOAD_BYTES = 48 * 1024
HMAP_POINTS_PER_CHUNK = 400


def governed_policy_command(
    desired: tuple[float, float, float],
    measured: tuple[float, float, float],
    *,
    linear_bias: float,
    linear_scale: float,
    linear_kp: float,
    angular_kp: float,
    max_linear_command: float,
    max_angular_command: float,
    angular_bias: float = 0.0,
    angular_scale: float = 1.0,
    lateral_kp: float | None = None,
) -> tuple[float, float, float]:
    """Close a small velocity loop around the frozen official TITA actor.

    NeuPAN emits physical body velocity targets.  The official actor is frozen,
    but its small-command response in Isaac is not an ideal velocity servo and
    a zero target alone does not actively stop rolling wheels.  This adapter
    only reshapes the actor's command input; it never modifies policy weights.

    ``linear_bias`` and ``linear_scale`` are an inverse calibration from a
    physical forward-velocity target to the frozen actor's command space.  The
    bias applies only to the forward axis: applying it to the lateral axis
    would create a sideways command for a zero lateral target.  Yaw optionally
    uses its own measured inverse calibration before feedback correction.
    """

    lateral_kp = linear_kp if lateral_kp is None else lateral_kp
    configuration = (
        linear_bias,
        linear_scale,
        linear_kp,
        angular_kp,
        max_linear_command,
        max_angular_command,
        angular_bias,
        angular_scale,
        lateral_kp,
    )
    if not all(math.isfinite(float(value)) for value in configuration):
        raise ValueError("velocity governor calibration must be finite")
    if linear_scale <= 0.0 or angular_scale <= 0.0:
        raise ValueError("velocity governor inverse-map scales must be positive")
    if min(linear_kp, angular_kp, lateral_kp, max_linear_command, max_angular_command) < 0.0:
        raise ValueError("velocity governor gains and limits must be non-negative")
    if not all(math.isfinite(float(value)) for value in (*desired, *measured)):
        return (0.0, 0.0, 0.0)

    x = linear_bias + linear_scale * desired[0]
    x += linear_kp * (desired[0] - measured[0])
    y = linear_scale * desired[1]
    y += lateral_kp * (desired[1] - measured[1])
    linear_norm = math.hypot(x, y)
    if linear_norm > max_linear_command > 0.0:
        scale = max_linear_command / linear_norm
        x, y = x * scale, y * scale
    elif max_linear_command == 0.0:
        x, y = 0.0, 0.0
    yaw = angular_bias + angular_scale * desired[2]
    yaw += angular_kp * (desired[2] - measured[2])
    yaw = max(-max_angular_command, min(max_angular_command, yaw))
    return float(x), float(y), float(yaw)


def chunk_hmap_points(
    layers: list[list[list[float]]],
    *,
    map_version: int = 1,
    points_per_chunk: int = HMAP_POINTS_PER_CHUNK,
) -> list[dict[str, Any]]:
    """Split three HMAP layers into datagrams well below UDP's size limit."""

    if len(layers) != 3:
        raise ValueError("HMAP transport requires exactly three layers")
    if points_per_chunk <= 0:
        raise ValueError("points_per_chunk must be positive")
    chunks: list[dict[str, Any]] = []
    for layer_index, points in enumerate(layers):
        layer_chunks = [
            points[start:start + points_per_chunk]
            for start in range(0, len(points), points_per_chunk)
        ] or [[]]
        for chunk_index, chunk in enumerate(layer_chunks):
            message = {
                "format_version": 1,
                "message_type": "hmap_chunk",
                "map_version": int(map_version),
                "layer_index": layer_index,
                "chunk_index": chunk_index,
                "chunk_count": len(layer_chunks),
                "points": chunk,
            }
            encoded_size = len(json.dumps(message, separators=(",", ":")).encode("utf-8"))
            if encoded_size > UDP_SAFE_PAYLOAD_BYTES:
                raise ValueError(
                    f"HMAP chunk is {encoded_size} bytes; reduce points_per_chunk"
                )
            chunks.append(message)
    return chunks


class IsaacUdpBridge:
    """Exchange simulator state and gated Twist values without importing rclpy."""

    def __init__(self, env: Any, *, host: str = "127.0.0.1", tx_port: int = 19001,
                 rx_port: int = 19002, command_timeout_s: float = 0.30,
                 goal_x: float = 8.0, goal_y: float = 0.0, goal_yaw: float = 0.0,
                 velocity_governor: bool = True,
                 governor_linear_bias: float = -0.72,
                 governor_linear_scale: float = 0.93,
                 governor_linear_kp: float = 0.8,
                 governor_angular_kp: float = 0.5,
                 governor_max_linear_command: float = 0.90,
                 governor_max_angular_command: float = 1.00,
                 governor_profiles: dict | None = None,
                 governor_transition_s: float = 0.0,
                 command_shaping: dict | None = None,
                 planner_physics_lockstep: bool = False,
                 training_lockstep: bool = False) -> None:
        if planner_physics_lockstep and not training_lockstep:
            raise ValueError("planner physics lockstep requires acknowledged training windows")
        if env.num_envs != 1:
            raise ValueError("IsaacUdpBridge requires --num_envs 1")
        self.env = env
        from .training_contract import TrainingActionWindow

        self.training_window = TrainingActionWindow() if training_lockstep else None
        if self.training_window is not None:
            self.env._defer_navigation_reset = True
        self.destination = (host, int(tx_port))
        self.command_timeout_s = float(command_timeout_s)
        self.goal = (float(goal_x), float(goal_y), float(goal_yaw))
        self.velocity_governor = bool(velocity_governor)
        self.governor_linear_bias = float(governor_linear_bias)
        self.governor_linear_scale = float(governor_linear_scale)
        self.governor_linear_kp = float(governor_linear_kp)
        self.governor_angular_kp = float(governor_angular_kp)
        self.governor_max_linear_command = float(governor_max_linear_command)
        self.governor_max_angular_command = float(governor_max_angular_command)
        from .velocity_calibration import validate_governor_profiles
        self.governor_profiles = (None if governor_profiles is None
                                  else validate_governor_profiles(governor_profiles))
        self.governor_transition_s = float(governor_transition_s)
        if not math.isfinite(self.governor_transition_s) or self.governor_transition_s < 0.0:
            raise ValueError("governor transition time must be finite and non-negative")
        self._blended_governor_parameters = (dict(self.governor_profiles["MID"])
                                             if self.governor_profiles is not None else None)
        from .motion_profile import CommandShapingConfig, PhysicsCommandShaper
        self.command_shaper = (PhysicsCommandShaper(CommandShapingConfig(**command_shaping))
                               if command_shaping is not None else None)
        self._safety_override = False
        self._linear_command_limit = None
        self._angular_command_limit = None
        governed_policy_command(
            (0.0, 0.0, 0.0),
            (0.0, 0.0, 0.0),
            linear_bias=self.governor_linear_bias,
            linear_scale=self.governor_linear_scale,
            linear_kp=self.governor_linear_kp,
            angular_kp=self.governor_angular_kp,
            max_linear_command=self.governor_max_linear_command,
            max_angular_command=self.governor_max_angular_command,
        )
        self._socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._socket.setblocking(False)
        self._socket.bind((host, int(rx_port)))
        self._latest_cmd = (0.0, 0.0, 0.0)
        self._requested_desired_command = (0.0, 0.0, 0.0)
        self._applied_desired_command = (0.0, 0.0, 0.0)
        self._command_trace = None
        self._command_received_sim_time_s = None
        self._command_stale = True
        self.planner_physics_lockstep = bool(planner_physics_lockstep)
        self._planner_source = None
        self._latest_cmd_time = 0.0
        self._latest_policy_cmd = (0.0, 0.0, 0.0)
        self._latest_measured_velocity = (0.0, 0.0, 0.0)
        self._posture_index = 1
        self._last_publish = 0.0
        self._closed = False
        self._state_sequence = 0
        self._command_packets_received = 0
        self._nonzero_command_packets_received = 0
        self._last_command_sequence = 0
        self._transition_sequence = 0
        self._episode_id = 0
        self._sim_time_s = 0.0
        self._posture_stable_since_s = None
        self._mechanical_energy_total_j = 0.0
        self._distance_total_m = 0.0
        self._hard_failure_count = 0
        self._success_count = 0
        self._last_transition = {
            "energy_j": 0.0,
            "distance_m": 0.0,
            "terminated": False,
            "truncated": False,
            "success": False,
            "hard_reasons": [],
        }
        self._hmap_points = self._make_hmap_points()
        self._hmap_map_version = 1
        self._hmap_chunks = chunk_hmap_points(
            self._hmap_points, map_version=self._hmap_map_version
        )
        self._hmap_chunk_cursor = 0
        trace_event("isaac", "boundary_ready", episode_id=self._episode_id, start_sequence=0)

    @property
    def posture_index(self) -> int:
        return self._posture_index

    def spin_once(self) -> None:
        while True:
            try:
                payload, _ = self._socket.recvfrom(65535)
            except BlockingIOError:
                return
            try:
                message = json.loads(payload.decode("utf-8"))
                command = message.get("cmd", {})
                values = (float(command.get("x", 0.0)), float(command.get("y", 0.0)),
                          float(command.get("z", 0.0)))
                if not all(math.isfinite(value) for value in values):
                    continue
                linear_limit = message.get("linear_limit_mps")
                if linear_limit is not None:
                    linear_limit = float(linear_limit)
                    if not math.isfinite(linear_limit) or linear_limit < 0.0:
                        continue
                angular_limit = message.get("angular_limit_radps")
                if angular_limit is not None:
                    angular_limit = float(angular_limit)
                    if not math.isfinite(angular_limit) or angular_limit < 0.0:
                        continue
                if self.training_window is not None:
                    decision = message.get("decision", {})
                    training = message.get("training", {})
                    if training.get("kind", "action") == "action":
                        action_id = int(decision.get("action_id", -1))
                        if (not bool(decision.get("valid", False))
                                or int(decision.get("route_index", -1)) != action_id // 3):
                            continue
                    accepted = self.training_window.accept(
                        training, int(decision.get("action_id", -1)))
                    if not accepted:
                        continue
                if all(math.isfinite(value) for value in values):
                    received_ns = time.monotonic_ns()
                    self._latest_cmd = values
                    trace = message.get("command_trace")
                    self._command_trace = trace if isinstance(trace, dict) else None
                    self._command_received_sim_time_s = self._sim_time_s
                    self._planner_source = message.get("planner_source")
                    self._safety_override = bool(message.get("safety_override", False))
                    self._linear_command_limit = linear_limit
                    self._angular_command_limit = angular_limit
                    self._latest_cmd_time = time.monotonic()
                    self._command_packets_received += 1
                    self._nonzero_command_packets_received += int(
                        any(abs(value) > 1e-6 for value in values)
                    )
                    self._last_command_sequence = int(
                        message.get("command_sequence", self._last_command_sequence)
                    )
                    if self.training_window is not None:
                        trace_event("isaac", "command_received", at_ns=received_ns,
                                    episode_id=self._episode_id,
                                    decision_id=self.training_window.decision_id,
                                    command_sequence=self._last_command_sequence,
                                    control_sequence=self.training_window.sequence,
                                    planner_source=self._planner_source,
                                    command=list(values), safety_override=self._safety_override)
                decision = message.get("decision", {})
                if bool(decision.get("valid", False)) and int(decision.get("route_index", -1)) in (0, 1, 2):
                    self._posture_index = int(decision["route_index"])
            except (UnicodeDecodeError, TypeError, ValueError, json.JSONDecodeError):
                continue

    def command_tensor(self, device: torch.device, count: int) -> torch.Tensor:
        stale = time.monotonic() - self._latest_cmd_time > self.command_timeout_s
        self._command_stale = stale
        if stale:
            command = (0.0, 0.0, 0.0)
        else:
            command = self._latest_cmd
        self._requested_desired_command = command
        if self.command_shaper is not None:
            command = self.command_shaper.step(
                command, float(self.env.step_dt),
                safety_override=stale or self._safety_override,
                linear_limit=self._linear_command_limit,
                angular_limit=self._angular_command_limit,
            )
        self._applied_desired_command = command
        root_linear = self.env.robot.data.root_lin_vel_b[0]
        root_angular = self.env.robot.data.root_ang_vel_b[0]
        measured = (
            float(root_linear[0].item()),
            float(root_linear[1].item()),
            float(root_angular[2].item()),
        )
        if self.governor_profiles is not None and self.governor_transition_s > 0.0:
            from .velocity_calibration import blend_governor_parameters
            target = self.governor_profiles[("LOW", "MID", "HIGH")[self._posture_index]]
            self._blended_governor_parameters = blend_governor_parameters(
                self._blended_governor_parameters, target,
                min(float(self.env.step_dt) / self.governor_transition_s, 1.0),
            )
        policy_command = (
            governed_policy_command(
                command,
                measured,
                **self.governor_parameters(),
            )
            if self.velocity_governor
            else command
        )
        self._latest_measured_velocity = measured
        self._latest_policy_cmd = policy_command
        trace_event("isaac", "cmd_vel_applied",
                    sim_time_s=self._sim_time_s,
                    command=list(policy_command),
                    planner_source=self._planner_source,
                    posture_index=self._posture_index)
        return torch.tensor(
            policy_command, dtype=torch.float32, device=device
        ).repeat(count, 1)

    def planner_command_ready(self) -> bool:
        from .motion_profile import planner_command_current
        return (not self.planner_physics_lockstep
                or planner_command_current(self.training_window.sequence, self._episode_id,
                                           self._planner_source))

    def governor_parameters(self) -> dict[str, float]:
        if self.governor_profiles is not None:
            if self.governor_transition_s > 0.0:
                return dict(self._blended_governor_parameters)
            return dict(self.governor_profiles[("LOW", "MID", "HIGH")[self._posture_index]])
        return {
            "linear_bias": self.governor_linear_bias,
            "linear_scale": self.governor_linear_scale,
            "linear_kp": self.governor_linear_kp,
            "angular_kp": self.governor_angular_kp,
            "max_linear_command": self.governor_max_linear_command,
            "max_angular_command": self.governor_max_angular_command,
        }

    def finish_training_reset(self) -> None:
        if self.training_window is None:
            raise RuntimeError("acknowledged reset requires training lockstep")
        self.training_window.finish_reset()
        self._episode_id = self.training_window.episode_id
        self._last_transition = {"sequence": self.training_window.sequence}
        self._posture_index = 1
        self._posture_stable_since_s = None
        if self.governor_profiles is not None:
            self._blended_governor_parameters = dict(self.governor_profiles["MID"])
        self._latest_cmd = (0.0, 0.0, 0.0)
        self._command_trace = None
        self._command_received_sim_time_s = None
        self._command_stale = True
        self._planner_source = None
        self._requested_desired_command = (0.0, 0.0, 0.0)
        if self.command_shaper is not None:
            self.command_shaper.reset()
        self._safety_override = False
        self._linear_command_limit = None
        self._angular_command_limit = None
        self._applied_desired_command = (0.0, 0.0, 0.0)
        self._latest_policy_cmd = (0.0, 0.0, 0.0)
        self._latest_cmd_time = 0.0
        self._latest_measured_velocity = (
            float(self.env.robot.data.root_lin_vel_b[0, 0]),
            float(self.env.robot.data.root_lin_vel_b[0, 1]),
            float(self.env.robot.data.root_ang_vel_b[0, 2]),
        )
        trace_event("isaac", "boundary_ready", episode_id=self._episode_id,
                    start_sequence=self.training_window.sequence)

    def posture_execution_state(self) -> dict[str, Any]:
        error = 0.0
        if hasattr(self.env, "_posture_offset"):
            target = self.env._posture_offset.new_tensor(
                self.env.cfg.posture_joint_anchors[self._posture_index]
            ) - self.env.default_joint_target()[0]
            error = float((target - self.env._posture_offset[0]).abs().max())
        settled = error <= 0.02
        stable_elapsed = (max(0.0, self._sim_time_s - self._posture_stable_since_s)
                          if settled and self._posture_stable_since_s is not None else 0.0)
        return {
            "posture_feedforward_error_rad": error,
            "posture_feedforward_settled": settled,
            "posture_transition_phase": 0.0 if settled else min(error / 0.5, 1.0),
            "posture_stable_elapsed_s": stable_elapsed,
        }

    def record_step(self, *, energy_j: float, distance_m: float,
                    terminated: bool, truncated: bool,
                    success: bool,
                    hard_reasons: list[bool]) -> None:
        """Record the exact Isaac transition consumed by the upper trainer."""

        energy = float(energy_j)
        distance = float(distance_m)
        if not all(math.isfinite(value) and value >= 0.0 for value in (energy, distance)):
            raise ValueError("Isaac transition energy and distance must be finite and non-negative")
        if self.training_window is not None:
            self.training_window.record(
                energy_j=energy, distance_m=distance, elapsed_s=float(self.env.step_dt),
                terminated=terminated, truncated=truncated, success=success,
                hard_reasons=hard_reasons,
                desired_velocity=self._applied_desired_command,
                measured_velocity=(float(self.env.robot.data.root_lin_vel_b[0, 0]),
                                   float(self.env.robot.data.root_lin_vel_b[0, 1]),
                                   float(self.env.robot.data.root_ang_vel_b[0, 2])),
            )
            if self.training_window.ready:
                trace_event("isaac", "boundary_ready", episode_id=self._episode_id,
                            start_sequence=self.training_window.sequence,
                            terminated=terminated, truncated=truncated)
        completed_episode_id = self._episode_id
        self._transition_sequence += 1
        self._sim_time_s += float(self.env.step_dt)
        if self.posture_execution_state()["posture_feedforward_settled"]:
            if self._posture_stable_since_s is None:
                self._posture_stable_since_s = self._sim_time_s
        else:
            self._posture_stable_since_s = None
        self._mechanical_energy_total_j += energy
        self._distance_total_m += distance
        self._last_transition = {
            "sequence": self._transition_sequence,
            "episode_id": completed_episode_id,
            "energy_j": energy,
            "distance_m": distance,
            "terminated": bool(terminated),
            "truncated": bool(truncated),
            "success": bool(success),
            "hard_reasons": [bool(value) for value in hard_reasons],
        }
        self._hard_failure_count += int(bool(terminated) and any(hard_reasons))
        self._success_count += int(bool(success))
        if (terminated or truncated) and self.training_window is None:
            self._episode_id += 1

    @staticmethod
    def _yaw(quaternion: torch.Tensor) -> float:
        w, x, y, z = [float(value) for value in quaternion]
        return math.atan2(2.0 * (w * z + x * y), 1.0 - 2.0 * (y * y + z * z))

    def _state(self) -> dict[str, Any]:
        snapshot_ns = time.monotonic_ns()
        robot = self.env.robot
        position = robot.data.root_pos_w[0].detach().cpu().tolist()
        quaternion = robot.data.root_quat_w[0].detach().cpu().tolist()
        lin = robot.data.root_lin_vel_b[0].detach().cpu().tolist()
        ang = robot.data.root_ang_vel_b[0].detach().cpu().tolist()
        ranges = self.env.navigation_lidar_ranges
        lidar = [] if ranges is None else [float(value) for value in ranges[0].detach().cpu().tolist()]
        q = robot.data.joint_pos[0, self.env._joint_ids].detach().cpu().tolist()
        qd = robot.data.joint_vel[0, self.env._joint_ids].detach().cpu().tolist()
        tau = robot.data.applied_torque[0, self.env._joint_ids].detach().cpu().tolist()
        gravity = robot.data.projected_gravity_b[0].detach().cpu().tolist()
        command_active = time.monotonic() - self._latest_cmd_time <= self.command_timeout_s
        return {
            "stamp": time.time(), "position": position, "quaternion_wxyz": quaternion,
            **({"sudden_obstacle_probe": self.env.sudden_obstacle_probe.state()}
               if hasattr(self.env, "sudden_obstacle_probe") else {}),
            "linear_b": lin, "angular_b": ang, "gravity_b": gravity,
            "lidar": lidar, "joint_position": q, "joint_velocity": qd, "torque": tau,
            "goal": self.goal, "posture_index": self._posture_index,
            "format_version": 1,
            "message_type": "state",
            "hmap_map_version": self._hmap_map_version,
            "bridge": {
                "state_sequence": self._state_sequence,
                "command_packets_received": self._command_packets_received,
                "nonzero_command_packets_received": self._nonzero_command_packets_received,
                "last_command_sequence": self._last_command_sequence,
                "command_active": command_active,
                "desired_command": list(self._latest_cmd if command_active else (0.0, 0.0, 0.0)),
                "shaped_desired_command": list(self._applied_desired_command),
                "command_shaping_enabled": self.command_shaper is not None,
                "safety_override": self._safety_override,
                "policy_command": list(self._latest_policy_cmd),
                "measured_body_velocity": [lin[0], lin[1], ang[2]],
                "governor_input_velocity": list(self._latest_measured_velocity),
                "velocity_governor_enabled": self.velocity_governor,
                "governor_posture_profile": (("LOW", "MID", "HIGH")[self._posture_index]
                                             if self.governor_profiles is not None else "legacy_scalar"),
                "governor_parameters": self.governor_parameters(),
                "governor_transition_s": self.governor_transition_s,
            },
            "training": {
                **({"timing": {"state_snapshot_start_ns": snapshot_ns,
                               "state_sequence": self._state_sequence}}
                   if timing_enabled() else {}),
                "episode_id": self._episode_id,
                "sim_time_s": self._sim_time_s,
                "planning_state": [position[0], position[1], self._yaw(robot.data.root_quat_w[0])],
                "mechanical_energy_total_j": self._mechanical_energy_total_j,
                "distance_total_m": self._distance_total_m,
                "hard_failure_count": self._hard_failure_count,
                "success_count": self._success_count,
                "transition": self._last_transition,
                "lockstep": self.training_window is not None,
                "window": (self.training_window.payload()
                           if self.training_window is not None else None),
                "physical_state": {
                    "position": position, "quaternion_wxyz": quaternion,
                    "linear_b": lin, "angular_b": ang,
                    "posture_index": self._posture_index,
                    "posture_height_m": float(self.env.posture_height[0]),
                    "posture_target_height_m": float(self.env.posture_target_height[0]),
                    **self.posture_execution_state(),
                    "goal": self.goal,
                    "success_goal_xy_m": getattr(self.env.cfg, "navigation_goal_xy_m", None),
                    "success_goal_tolerance_m": getattr(self.env.cfg, "navigation_goal_tolerance_m", None),
                },
            },
        }

    def _make_hmap_points(self) -> list[list[list[float]]]:
        """Rasterize the diagnostic three-route boxes into three HMAP slices."""
        if not bool(getattr(self.env.cfg, "three_route_enabled", False)):
            return [[], [], []]
        from .three_route_scene import three_route_hmap_points

        origin = self.env._environment_origins()[0, :2].detach().cpu().tolist()
        if getattr(self.env.cfg, "navigation_scene_file", ""):
            from .navigation_maze import load_maze, maze_hmap_points
            return maze_hmap_points(load_maze(self.env.cfg.navigation_scene_file), tuple(origin))
        return three_route_hmap_points((float(origin[0]), float(origin[1])))

    def _refresh_dynamic_hmap(self) -> None:
        """Publish a new map version when the sudden probe changes position."""

        probe = getattr(self.env, "sudden_obstacle_probe", None)
        if probe is None or not probe.active:
            return
        static_points = self._make_hmap_points()
        dynamic_points = probe.hmap_points()
        candidate = [
            list(static_points[layer]) + [point for point in dynamic_points if point[2] == height]
            for layer, height in enumerate((0.20, 0.30, 0.40))
        ]
        if candidate == self._hmap_points:
            return
        self._hmap_points = candidate
        self._hmap_map_version += 1
        self._hmap_chunks = chunk_hmap_points(
            self._hmap_points, map_version=self._hmap_map_version
        )
        self._hmap_chunk_cursor = 0
        trace_event("isaac", "map_updated", at_ns=time.monotonic_ns(),
                    map_version=self._hmap_map_version,
                    obstacle_moving=probe.obstacle_moving)

    def publish(self) -> None:
        self._refresh_dynamic_hmap()
        now = time.monotonic()
        if now - self._last_publish < 0.05:
            return
        self._last_publish = now
        self._state_sequence += 1
        state_payload = json.dumps(
            self._state(), separators=(",", ":")
        ).encode("utf-8")
        if len(state_payload) > UDP_SAFE_PAYLOAD_BYTES:
            raise RuntimeError(
                f"Isaac state payload unexpectedly grew to {len(state_payload)} bytes"
            )
        self._socket.sendto(state_payload, self.destination)
        # Send one map fragment beside each high-rate state packet.  The ROS
        # bridge caches complete layers, and continuously cycling the chunks
        # makes startup robust to UDP loss without ever risking fragmentation.
        if self._hmap_chunks:
            chunk = self._hmap_chunks[self._hmap_chunk_cursor]
            chunk_payload = json.dumps(chunk, separators=(",", ":")).encode("utf-8")
            self._socket.sendto(chunk_payload, self.destination)
            self._hmap_chunk_cursor = (
                self._hmap_chunk_cursor + 1
            ) % len(self._hmap_chunks)

    def close(self) -> None:
        if not self._closed:
            self._closed = True
            self._socket.close()
