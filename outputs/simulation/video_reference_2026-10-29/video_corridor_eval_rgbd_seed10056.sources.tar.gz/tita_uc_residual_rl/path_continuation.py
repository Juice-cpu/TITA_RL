import math

import numpy as np

from .grid_path_geometry import polyline_cells
from .route_continuity import route_change_distance
from .start_recovery import StartRecoveryConnector, path_sample_free


def continued_path_candidate(scene, previous_path, position_xy_m, goal_xy_m, connector_lookahead_m=.25,
                             maximum_connector_m=.5):
    if previous_path is None or scene.recovery_geometry is None:
        return None
    if (not all(math.isfinite(value) for value in (connector_lookahead_m, maximum_connector_m))
            or not 0. < connector_lookahead_m <= maximum_connector_m):
        raise ValueError('path continuation requires positive bounded connector lengths')
    position = np.asarray(position_xy_m, dtype=float)
    goal = np.asarray(goal_xy_m, dtype=float)
    if position.shape != (2,) or goal.shape != (2,) or not np.isfinite([position, goal]).all():
        raise ValueError('path continuation requires finite planar feedback and goal')
    points = np.asarray(previous_path.points_xy_m, dtype=float)
    if np.linalg.norm(points[-1] - goal) > scene.resolution_m:
        return None
    segments = np.diff(points, axis=0)
    squared = np.sum(segments * segments, axis=1)
    fractions = np.clip(np.sum((position - points[:-1]) * segments, axis=1) / np.maximum(squared, 1e-15), 0., 1.)
    projections = points[:-1] + fractions[:, None] * segments
    nearest = int(np.argmin(np.linalg.norm(projections - position, axis=1)))
    suffix = np.vstack((projections[nearest], points[nearest + 1:]))
    suffix = suffix[np.r_[True, np.linalg.norm(np.diff(suffix, axis=0), axis=1) > 1e-9]]
    if len(suffix) < 2:
        return None
    distances = np.r_[0., np.cumsum(np.linalg.norm(np.diff(suffix, axis=0), axis=1))]
    progress = min(connector_lookahead_m, distances[-1])
    anchor = np.asarray([np.interp(progress, distances, suffix[:, axis]) for axis in range(2)])
    length = float(np.linalg.norm(anchor - position))
    geometry = scene.recovery_geometry
    if (not 1e-9 < length <= maximum_connector_m or not geometry.segment_safe(position, anchor)):
        return None
    start = scene.world_to_cell(position)
    anchor_cell = scene.world_to_cell(anchor)
    if not scene.in_bounds(start) or not scene.in_bounds(anchor_cell) or scene.occupancy[anchor_cell[1], anchor_cell[0]]:
        return None
    connector_cells, _ = polyline_cells(scene, np.vstack((position, anchor)))
    if not all(scene.in_bounds(cell) for cell in connector_cells):
        return None
    recovery = None
    if scene.occupancy[start[1], start[0]]:
        recovery = StartRecoveryConnector(tuple(position), tuple(anchor))
    elif any(scene.occupancy[cell[1], cell[0]] for cell in connector_cells):
        return None
    remaining = suffix[distances > progress + 1e-9]
    continued = np.vstack((position, anchor, remaining))
    from .joint_navigation import PathCandidate
    candidate = PathCandidate(previous_path.path_id, continued,
        float(np.linalg.norm(np.diff(continued, axis=0), axis=1).sum()), previous_path.path_version,
        previous_path.risk_weight, True, recovery, previous_path.path_id)
    cells, sample_distances = polyline_cells(scene, candidate.points_xy_m)
    if not path_sample_free(scene, candidate, cells, sample_distances).all():
        return None
    return candidate


def with_continuation_candidate(scene, paths, previous_path, position_xy_m, goal_xy_m, posture_specs, limit=3):
    if limit not in (1, 2, 3):
        raise ValueError('joint policy supports one to three global path candidates')
    if limit == 1:
        return paths
    candidate = continued_path_candidate(scene, previous_path, position_xy_m, goal_xy_m)
    if candidate is None:
        return paths
    from .joint_navigation import path_mode_feasibility
    if not path_mode_feasibility(scene, candidate, posture_specs, 0.).any():
        return paths
    alternatives = list(paths)
    if len(alternatives) >= limit:
        closest = min(range(len(alternatives)), key=lambda index:
            route_change_distance(candidate, alternatives[index], position_xy_m))
        alternatives.pop(closest)
    return (candidate, *alternatives[:limit - 1])
