from bisect import bisect_right
import hashlib
import json
import math

import numpy as np

from .observed_neupan_flow import OBSERVED_NEUPAN_FLOW_CONTRACT
from .observed_shuttle_audit import audit_observed_shuttle_contexts


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def _added_flow(observations, times, samples):
    directions = np.column_stack((np.cos(np.arange(samples) * (2. * np.pi / samples)),
        np.sin(np.arange(samples) * (2. * np.pi / samples))))
    additions = []
    for observation in observations:
        forecast = observation['forecast']
        points = np.asarray(forecast['points_xy_m'], dtype=float)
        centers = np.column_stack([np.interp(times + observation['age_s'], forecast['times_s'], points[:, axis])
            for axis in range(2)])
        radius = observation['pedestrian']['radius_m'] + forecast['uncertainty_radius_m']
        boundaries = centers[:, None, :] + radius * directions[None, :, :]
        additions.append(np.concatenate((centers[:, None, :], boundaries), axis=1))
    values = np.concatenate(additions, axis=1).transpose(0, 2, 1)
    return hashlib.sha256(np.asarray(values, dtype='<f4').tobytes()).hexdigest()


def audit_observed_neupan_flow(document, require_exercised=False):
    failures = []
    metadata = document.get('observed_shuttle_prediction', {})
    enabled = metadata.get('local_neupan_flow_enabled', False)
    records = document.get('observed_neupan_flow_records', [])
    invoked = '--observed-shuttle-neupan-flow' in document.get('invocation', [])
    exercised = 0
    replayed = 0
    contexts = audit_observed_shuttle_contexts(document)
    if not contexts['passed']:
        failures.append('causal_sensor_forecast_replay_failed')
    if enabled != invoked:
        failures.append('local_flow_flag_not_bound_to_report')
    if not enabled:
        if records:
            failures.append('disabled_local_flow_has_records')
        if require_exercised:
            failures.append('local_flow_not_exercised')
        return {'passed': not failures, 'failures': failures, 'enabled': enabled,
            'records_replayed': 0, 'exercised_records': 0, 'causal_contexts': contexts}
    if (metadata.get('local_neupan_flow_contract') != OBSERVED_NEUPAN_FLOW_CONTRACT
            or not metadata.get('enabled') or not records or document.get('backend') != 'vendor'):
        failures.append('enabled_local_flow_missing_contract_predictor_or_records')
    sensors = {}
    for row in document.get('sensor_records', []):
        sensors.setdefault(row['episode'], []).append(row)
    last_steps = {}
    last_calls = {}
    try:
        control_dt = document['runtime_versions']['control_step_s']
        if not math.isfinite(control_dt) or control_dt <= 0.:
            raise ValueError('invalid actual control period')
        for row in records:
            episode, step, mode = row['episode'], row['step'], row['mode_solver']
            if mode not in ('LOW', 'MID', 'HIGH', 'single') or not isinstance(step, int):
                raise ValueError('invalid local flow mode or step')
            key = (episode, mode)
            summary = row['summary']
            if step <= last_steps.get(key, -1) or summary['call_index'] <= last_calls.get(mode, 0):
                raise ValueError('nonmonotonic local flow record')
            last_steps[key], last_calls[mode] = step, summary['call_index']
            if summary['contract'] != OBSERVED_NEUPAN_FLOW_CONTRACT:
                raise ValueError('local flow record contract mismatch')
            episode_sensors = sensors.get(episode, [])
            index = bisect_right([value['step'] for value in episode_sensors], step) - 1
            if index < 0:
                raise ValueError('local flow has no preceding measured sensor context')
            sensor = episode_sensors[index]
            timestamp = sensor['observation_time_s'] + (step - sensor['step']) * control_dt
            if (not math.isfinite(summary['control_time_s'])
                    or abs(timestamp - summary['control_time_s']) > 1e-7):
                raise ValueError('local control time differs from actual sensor step clock')
            times = np.asarray(summary['mpc_relative_times_s'], dtype=float)
            if (times.ndim != 1 or len(times) < 2 or not np.isfinite(times).all()
                    or times[0] != 0. or np.any(np.diff(times) <= 0.)
                    or not np.allclose(np.diff(times), times[1], rtol=0., atol=1e-10)):
                raise ValueError('invalid original MPC relative times')
            expected = []
            for person, context in zip(sensor['tracks'], sensor['motion_context']):
                forecast = context.get('shuttle_prediction')
                if forecast is None:
                    continue
                age = timestamp - forecast['computed_at_s']
                if age < -1e-8:
                    raise ValueError('future measured forecast in local flow')
                if age > .2:
                    continue
                if age + times[-1] > forecast['times_s'][-1] + 1e-9:
                    continue
                expected.append({'pedestrian': person, 'forecast': forecast, 'age_s': max(age, 0.),
                    'forecast_sha256': _digest(forecast)})
            if not summary['added_columns']:
                if (summary['forecast_tracks'] != 0
                        or not summary.get('original_flow_returned_without_modification')):
                    raise ValueError('no-forecast original-flow passthrough contract failed')
                if expected:
                    raise ValueError('eligible measured forecasts omitted from local flow')
            else:
                if (summary['boundary_samples'] != 16 or summary['forecast_tracks'] != len(expected)
                        or not expected or summary['added_columns'] != len(expected) * 17):
                    raise ValueError('local flow dimensions differ from locked wrapper settings')
                actual = summary['forecast_observations']
                if len(actual) != len(expected):
                    raise ValueError('local flow forecast count mismatch')
                for recorded, measured in zip(actual, expected):
                    if (recorded['pedestrian'] != measured['pedestrian']
                            or recorded['forecast'] != measured['forecast']
                            or recorded['forecast_sha256'] != measured['forecast_sha256']
                            or not math.isfinite(recorded['age_s'])
                            or abs(recorded['age_s'] - measured['age_s']) > 1e-7):
                        raise ValueError('local flow forecast is not the latest causal measured context')
                if summary['added_world_flow_sha256'] != _added_flow(actual, times, 16):
                    raise ValueError('local flow added points do not match independent float32 replay')
                if (not summary['original_input_flow_retained_bitwise']
                        or summary['original_world_flow_sha256'] != summary['extended_original_prefix_sha256']
                        or summary['future_actor_waypoints_or_labels_used'] is not False
                        or summary['vendor_DUNE_NRMP_weights_and_solver_not_replaced'] is not True):
                    raise ValueError('original vendor prefix or causal source contract failed')
                exercised += 1
            replayed += 1
    except (KeyError, TypeError, ValueError, IndexError) as error:
        failures.append(str(error))
    if require_exercised and not exercised:
        failures.append('local_flow_not_exercised')
    return {'passed': not failures, 'failures': failures, 'enabled': enabled, 'records_replayed': replayed,
        'exercised_records': exercised, 'causal_contexts': contexts,
        'scope': 'Independent measured-sensor forecast replay and added world-point float32 hash reconstruction. '
            'Original raw-cloud prefix retention is checked via recorded hashes plus source/unit tests, not '
            'independent replay of the unlogged raw lidar cloud. Unchanged NRMP top-k may select different points; '
            'this is not a collision certificate, physical success, or proof of improvement.'}
