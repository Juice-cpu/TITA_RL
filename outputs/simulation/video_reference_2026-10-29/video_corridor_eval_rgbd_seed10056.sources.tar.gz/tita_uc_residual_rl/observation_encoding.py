from __future__ import annotations

import math

import torch
from torch import nn


def encode_robot_observation(observation, version):
    if version == 0:
        return observation
    if version == 2:
        if observation.shape[-1] != 64:
            raise ValueError("signed path encoding requires the 64-dimensional observation contract")
        prefix = encode_robot_observation(observation[..., :62], 1)
        suffix = observation[..., 62:].clone()
        suffix[..., 0] /= .3
        return torch.cat((prefix, suffix.clamp(-4., 4.)), dim=-1)
    if version != 1 or observation.shape[-1] != 62:
        raise ValueError("bounded robot encoding requires the 62-dimensional observation contract")
    encoded = observation.clone()
    encoded[..., 12] = 0.
    encoded[..., 16] = 0.
    encoded[..., 17:25] = encoded[..., 17:25] / 25.
    encoded[..., 36:40] = encoded[..., 36:40] / 5.
    encoded[..., 47] = torch.log1p(encoded[..., 47].clamp_min(0.)) / math.log1p(10000.)
    encoded[..., 48] = encoded[..., 48] / 10.
    encoded[..., 49] = encoded[..., 49] / 60.
    return encoded.clamp(-4., 4.)


class EncodedValueNetwork(nn.Sequential):
    def __init__(self, *layers):
        super().__init__(*layers)
        self.register_buffer("observation_encoding_version", torch.tensor(0, dtype=torch.int64))

    def forward(self, observation):
        return super().forward(encode_robot_observation(observation, int(self.observation_encoding_version)))
