import math

import torch


class GuardedPostureSchedule:
    def __init__(self, schedule, count, device, dt_s=.02, minimum_stage_s=6., maximum_stage_s=24., hold_s=1.):
        if (not schedule or any(mode not in (0, 1, 2) for mode in schedule) or count < 1
                or not all(math.isfinite(value) and value > 0. for value in (dt_s, minimum_stage_s, maximum_stage_s, hold_s))
                or maximum_stage_s <= minimum_stage_s):
            raise ValueError('guarded posture schedule requires valid modes and finite execution windows')
        self.schedule = torch.tensor(schedule, device=device)
        self.stage = torch.zeros(count, device=device, dtype=torch.long)
        self.elapsed = torch.zeros(count, device=device)
        self.hold = torch.zeros_like(self.elapsed)
        self.failed = torch.zeros(count, device=device, dtype=torch.bool)
        self.timed_out = torch.zeros_like(self.failed)
        self.accepted_duration = torch.full((len(schedule), count), float('nan'), device=device)
        self.dt_s, self.minimum_stage_s, self.maximum_stage_s, self.hold_s = dt_s, minimum_stage_s, maximum_stage_s, hold_s

    @property
    def modes(self):
        return self.schedule[self.stage.clamp(max=len(self.schedule) - 1)]

    @property
    def done(self):
        return (self.stage >= len(self.schedule)) | self.failed | self.timed_out

    @property
    def phase(self):
        phase = (self.elapsed + self.dt_s) / self.minimum_stage_s
        return torch.where(~self.done & (self.stage > 0) & (phase <= 1. + 1e-6), phase.clamp(max=1.), torch.zeros_like(phase))

    def observe(self, stable, failed):
        if stable.shape != self.stage.shape or failed.shape != self.stage.shape or stable.dtype != torch.bool or failed.dtype != torch.bool:
            raise ValueError('guarded schedule needs aligned boolean physical feedback')
        self.failed |= failed
        active = ~self.done
        self.elapsed[active] += self.dt_s
        self.hold = torch.where(active & stable, self.hold + self.dt_s, torch.zeros_like(self.hold))
        advance = active & (self.elapsed >= self.minimum_stage_s - 1e-5) & (self.hold >= self.hold_s - 1e-5)
        indices = torch.nonzero(advance).flatten()
        self.accepted_duration[self.stage[indices], indices] = self.elapsed[indices]
        self.stage[advance] += 1
        self.elapsed[advance] = 0.
        self.hold[advance] = 0.
        self.timed_out |= active & ~advance & (self.elapsed >= self.maximum_stage_s - 1e-5)
