"""Unified static/dynamic navigation comparison and PPO behavior diagnostics.

This module is deliberately independent of ROS/Isaac.  It consumes exported
trial records and event traces so that A* + NeuPAN, A* + DCT and A* + RL +
NeuPAN are evaluated with the same definitions and clocks.
"""

from __future__ import annotations

from collections import Counter
from itertools import combinations
import math
from typing import Iterable, Mapping, Sequence

import numpy as np

from .navigation_benchmark import path_comparison, path_length
from .realtime_metrics import timing_statistics
from .upper_level_types import POSTURE_NAMES, SPEED_RATIOS, decode_action

METHODS = ("astar_neupan", "astar_dct", "astar_rl_neupan")
METHOD_ALIASES = {
    "neupan": "astar_neupan",
    "dct": "astar_dct",
    "dct-core": "astar_dct",
    "rl": "astar_rl_neupan",
    "rl+neupan": "astar_rl_neupan",
}
REQUIRED_DYNAMIC_EVENTS = (
    "obstacle_appeared",
    "perception_first_hit",
    "map_updated",
    "astar_completed",
    "candidates_published",
    "local_planner_completed",
    "control_applied",
    "avoidance_confirmed",
)
FORMAL_DYNAMIC_EVENTS = (
    "obstacle_appeared", "perception_first_hit", "map_updated",
    "astar_started", "astar_completed", "candidates_published",
    "local_planner_started", "local_planner_completed", "control_applied",
    "avoidance_confirmed",
)

EVENT_ALIASES = {
    "lidar_first_hit": "perception_first_hit",
    "dynamic_map_updated": "map_updated",
    "astar_finished": "astar_completed",
    "candidate_routes_published": "candidates_published",
    "planner_solve_started": "local_planner_started",
    "planner_solve": "local_planner_completed",
    "planner_solve_completed": "local_planner_completed",
    "upper_inference": "rl_decision_completed",
    "rl_decision": "rl_decision_completed",
    "control_input_applied": "control_applied",
    "cmd_vel_applied": "control_applied",
    "obstacle_clearance_confirmed": "avoidance_confirmed",
}


def _finite(value: object, name: str) -> float:
    number = float(value)
    if not math.isfinite(number):
        raise ValueError(f"{name} must be finite")
    return number


def _event_time(record: Mapping[str, object]) -> int:
    value = record.get("monotonic_ns", record.get("at_ns"))
    if type(value) is not int:
        raise ValueError("events require integer monotonic_ns")
    return value


def _first_event(events: Sequence[Mapping[str, object]], name: str) -> Mapping[str, object]:
    matching = [event for event in events if event.get("event") == name]
    if not matching:
        raise ValueError(f"missing event: {name}")
    return min(matching, key=_event_time)


def _canonical_dynamic_events(events: Sequence[Mapping[str, object]]) -> list[dict[str, object]]:
    """Normalize trace names and span records without changing source data."""

    normalized = []
    for source in events:
        row = dict(source)
        source_name = str(row.get("event", ""))
        name = EVENT_ALIASES.get(source_name, source_name)
        if source_name in ("planner_solve", "planner_solve_completed") and row.get("start_ns") is not None:
            started = dict(row)
            started["event"] = "local_planner_started"
            started["monotonic_ns"] = row["start_ns"]
            normalized.append(started)
        if source_name in ("astar_finished", "astar_completed") and row.get("start_ns") is not None:
            started = dict(row)
            started["event"] = "astar_started"
            started["monotonic_ns"] = row["start_ns"]
            normalized.append(started)
        if source_name in ("upper_inference", "rl_decision") and row.get("start_ns") is not None:
            started = dict(row)
            started["event"] = "rl_decision_started"
            started["monotonic_ns"] = row["start_ns"]
            normalized.append(started)
        row["event"] = name
        if "monotonic_ns" not in row and "at_ns" in row:
            row["monotonic_ns"] = row["at_ns"]
        if name == "local_planner_started" and "monotonic_ns" not in row:
            row["monotonic_ns"] = row.get("start_ns")
        if name == "local_planner_completed" and "monotonic_ns" not in row:
            row["monotonic_ns"] = row.get("end_ns", row.get("start_ns"))
        if name == "astar_completed" and "monotonic_ns" not in row:
            row["monotonic_ns"] = row.get("end_ns", row.get("start_ns"))
        if name in ("rl_decision_completed", "route_selected") and "monotonic_ns" not in row:
            row["monotonic_ns"] = row.get("end_ns", row.get("start_ns"))
        if row.get("monotonic_ns") is not None:
            normalized.append(row)
    return normalized


def _metric_summary(values: Sequence[float]) -> dict[str, object]:
    finite = [_finite(value, "metric") for value in values]
    return {
        "n": len(finite),
        "mean": float(np.mean(finite)) if finite else None,
        "std": float(np.std(finite, ddof=1)) if len(finite) > 1 else None,
        "p50": _percentile(finite, 50),
        "p95": _percentile(finite, 95),
        "max": max(finite) if finite else None,
    }


def _duration_ms(start: Mapping[str, object], end: Mapping[str, object]) -> float:
    delta = _event_time(end) - _event_time(start)
    if delta < 0:
        raise ValueError("event timestamps are not monotonic")
    return delta / 1e6


def _percentile(values: Sequence[float], percentile: float) -> float | None:
    if not values:
        return None
    return float(np.percentile(np.asarray(values, dtype=float), percentile))


def normalize_method(method: object) -> str:
    normalized = str(method).strip().lower()
    normalized = METHOD_ALIASES.get(normalized, normalized)
    if normalized not in METHODS:
        raise ValueError(f"unknown method {method!r}; expected one of {METHODS}")
    return normalized


def compare_trial(
    trial: Mapping[str, object],
    *,
    reference_path: Sequence[Sequence[float]] | None = None,
    common_reference_path: Sequence[Sequence[float]] | None = None,
    overlap_spacing_m: float = 0.05,
    overlap_tolerance_m: float = 0.20,
) -> dict[str, object]:
    """Normalize one exported trial into comparable path/time/efficiency fields."""
    method = normalize_method(trial.get("method", trial.get("algorithm", "")))
    result = dict(trial)
    result["method"] = method
    trajectory = trial.get("trajectory_xy_m")
    if trajectory is not None:
        actual_length = path_length(trajectory)
        result["actual_path_length_m"] = actual_length
        if reference_path is not None:
            result["reference_path_overlap"] = path_comparison(
                trajectory, reference_path, spacing_m=overlap_spacing_m, tolerance_m=overlap_tolerance_m
            )
        if common_reference_path is not None:
            common_length = path_length(common_reference_path)
            result["common_reference_length_m"] = common_length
            result["path_length_ratio"] = actual_length / max(common_length, 1e-12)
            result["path_efficiency"] = min(1.0, common_length / max(actual_length, 1e-12))
    if "planned_path_length_m" not in result:
        for key in ("planning_path_length_m", "reference_path_length_m", "selected_plan_length_m"):
            if trial.get(key) is not None:
                result["planned_path_length_m"] = _finite(trial[key], key)
                break
    if "hard_constraint_violation" not in result:
        result["hard_constraint_violation"] = bool(trial.get("hard_failure", False))
    if "safety_constraint_violation" not in result:
        result["safety_constraint_violation"] = bool(trial.get("clearance_violation", False))
    if "navigation_time_s" in trial:
        navigation_time = _finite(trial["navigation_time_s"], "navigation_time_s")
        result["navigation_time_s"] = navigation_time
        if common_reference_path is not None and "speed_cap_mps" in trial:
            ideal_time = path_length(common_reference_path) / max(_finite(trial["speed_cap_mps"], "speed_cap_mps"), 1e-12)
            result["time_efficiency"] = min(1.0, ideal_time / max(navigation_time, 1e-12))
    if "success" not in result:
        result["success"] = bool(trial.get("status") == "success")
    result["success"] = bool(result["success"])
    return result


def summarize_trials(trials: Iterable[Mapping[str, object]]) -> dict[str, object]:
    """Aggregate comparable trial records without hiding failed or missing runs."""
    rows = [dict(trial) for trial in trials]
    by_method: dict[str, list[dict[str, object]]] = {method: [] for method in METHODS}
    for row in rows:
        by_method[normalize_method(row.get("method", row.get("algorithm")))].append(row)

    metrics = (
        "navigation_time_s", "planned_path_length_m", "actual_path_length_m",
        "path_length_ratio", "path_efficiency", "time_efficiency",
        "energy_j_per_m", "minimum_clearance_m",
    )
    summary: dict[str, object] = {}
    for method, method_rows in by_method.items():
        successful = [row for row in method_rows if bool(row.get("success"))]
        method_summary: dict[str, object] = {
            "planned_or_observed_trials": len(method_rows),
            "successful_trials": len(successful),
            "success_rate": len(successful) / len(method_rows) if method_rows else None,
            "collision_rate": sum(bool(row.get("collision", False)) for row in method_rows) / len(method_rows) if method_rows else None,
            "hard_constraint_violation_rate": sum(
                bool(row.get("hard_constraint_violation", row.get("hard_failure", False)))
                for row in method_rows
            ) / len(method_rows) if method_rows else None,
            "safety_constraint_violation_rate": sum(
                bool(row.get("safety_constraint_violation", row.get("clearance_violation", False)))
                for row in method_rows
            ) / len(method_rows) if method_rows else None,
            "metrics_success_only": {},
            "metrics_all_trials": {},
        }
        for metric in metrics:
            values = [_finite(row[metric], metric) for row in successful if row.get(metric) is not None]
            method_summary["metrics_success_only"][metric] = {
                **_metric_summary(values),
                "median": float(np.median(values)) if values else None,
                "min": min(values) if values else None,
            }
            all_values = [_finite(row[metric], metric) for row in method_rows if row.get(metric) is not None]
            method_summary["metrics_all_trials"][metric] = {
                **_metric_summary(all_values),
                "median": float(np.median(all_values)) if all_values else None,
                "min": min(all_values) if all_values else None,
            }
        summary[method] = method_summary
    return {"methods": list(METHODS), "trial_count": len(rows), "by_method": summary, "trials": rows}


def analyze_dynamic_events(
    events: Sequence[Mapping[str, object]],
    *,
    obstacle_still_moving: bool | None = None,
    required_events: Sequence[str] = REQUIRED_DYNAMIC_EVENTS,
) -> dict[str, object]:
    """Measure event-to-event latency and verify genuine online avoidance.

    A successful real-time avoidance requires ``avoidance_confirmed`` to occur
    before ``obstacle_motion_stopped`` when the latter is present.  If no stop
    event is exported, the result is explicitly ``unknown`` rather than being
    called real-time.
    """
    if not events:
        raise ValueError("dynamic event trace is empty")
    ordered = sorted(_canonical_dynamic_events(events), key=_event_time)
    for previous, current in zip(ordered, ordered[1:]):
        if _event_time(current) < _event_time(previous):
            raise ValueError("events must use one monotonic clock")
    anchors = {name: _first_event(ordered, name) for name in required_events}
    for optional_name in (
        "astar_started", "rl_decision_started", "rl_decision_completed",
        "local_planner_started",
    ):
        if optional_name not in anchors:
            matching = [event for event in ordered if event.get("event") == optional_name]
            if matching:
                anchors[optional_name] = min(matching, key=_event_time)
    obstacle = anchors["obstacle_appeared"]
    stage_pairs = {
        "appearance_to_perception_ms": ("obstacle_appeared", "perception_first_hit"),
        "perception_to_map_update_ms": ("perception_first_hit", "map_updated"),
        "map_update_to_astar_start_ms": ("map_updated", "astar_started"),
        "map_update_to_astar_ms": ("map_updated", "astar_completed"),
        "astar_to_candidates_ms": ("astar_completed", "candidates_published"),
        "candidates_to_rl_ms": ("candidates_published", "rl_decision_completed"),
        "rl_to_local_planner_ms": ("rl_decision_completed", "local_planner_started"),
        "local_planner_compute_ms": ("local_planner_started", "local_planner_completed"),
        "candidates_to_local_planner_ms": ("candidates_published", "local_planner_completed"),
        "local_planner_to_control_ms": ("local_planner_completed", "control_applied"),
        "appearance_to_control_ms": ("obstacle_appeared", "control_applied"),
        "appearance_to_avoidance_confirmation_ms": ("obstacle_appeared", "avoidance_confirmed"),
    }
    latencies = {
        name: _duration_ms(anchors[start], anchors[end])
        for name, (start, end) in stage_pairs.items()
        if start in anchors and end in anchors
    }
    stage_durations = {
        "perception": latencies.get("appearance_to_perception_ms"),
        "map_update": latencies.get("perception_to_map_update_ms"),
        "astar": latencies.get("map_update_to_astar_ms"),
        "candidate_publish": latencies.get("astar_to_candidates_ms"),
        "rl_decision": latencies.get("candidates_to_rl_ms"),
        "local_planner": latencies.get("local_planner_compute_ms"),
        "control_response": latencies.get("local_planner_to_control_ms"),
    }
    stop_events = [event for event in ordered if event.get("event") == "obstacle_motion_stopped"]
    confirmed = anchors["avoidance_confirmed"]
    if stop_events:
        stop = min(stop_events, key=_event_time)
        real_time_status = "yes" if _event_time(confirmed) <= _event_time(stop) else "no"
        confirmed_before_stop_ms = _duration_ms(obstacle, confirmed) if real_time_status == "yes" else None
    elif obstacle_still_moving is True:
        real_time_status = "yes_unbounded_stop_not_logged"
        confirmed_before_stop_ms = latencies["appearance_to_avoidance_confirmation_ms"]
    else:
        real_time_status = "unknown"
        confirmed_before_stop_ms = None
    astar_starts = [event for event in ordered if event.get("event") == "astar_started"]
    replans = sum(1 for event in ordered if event.get("event") == "astar_completed")
    moving_flags = [event.get("obstacle_moving") for event in ordered if event.get("event") == "avoidance_confirmed"]
    timeout_ms = {}
    deadlines = {
        "appearance_to_perception_ms": 250.0,
        "perception_to_map_update_ms": 250.0,
        "map_update_to_astar_ms": 250.0,
        "astar_to_candidates_ms": 100.0,
        "candidates_to_local_planner_ms": 250.0,
        "local_planner_to_control_ms": 100.0,
        "appearance_to_control_ms": 1000.0,
    }
    for name, limit in deadlines.items():
        value = latencies.get(name)
        timeout_ms[name] = bool(value is not None and value > limit)
    frequencies = event_frequencies(ordered)
    return {
        "required_events": list(required_events),
        "event_count": len(ordered),
        "latency_ms": latencies,
        "stage_durations_ms": stage_durations,
        "deadline_ms": deadlines,
        "timeout_flags": timeout_ms,
        "timeout_count": sum(timeout_ms.values()),
        "frequencies": frequencies,
        "astar_replan_count": replans,
        "astar_start_count": len(astar_starts),
        "obstacle_still_moving_at_confirmation": moving_flags[0] if moving_flags else obstacle_still_moving,
        "real_time_avoidance": real_time_status,
        "confirmed_before_stop_ms": confirmed_before_stop_ms,
        "collision": bool(any(event.get("event") == "collision" for event in ordered)),
        "event_trace_scope": "online dynamic obstacle response; requires obstacle/map/A*/control event correlation",
    }


def event_frequencies(events: Sequence[Mapping[str, object]]) -> dict[str, object]:
    """Report event periods in both simulated time and wall-clock time.

    A one-shot event has no meaningful frequency; it is reported with an
    explicit ``insufficient_samples`` status rather than as an artificial Hz.
    """

    grouped: dict[str, list[Mapping[str, object]]] = {}
    for event in _canonical_dynamic_events(events):
        grouped.setdefault(str(event.get("event")), []).append(event)
    output = {}
    for name, rows in grouped.items():
        rows = sorted(rows, key=_event_time)
        wall_periods = [(_event_time(second) - _event_time(first)) / 1e9
                        for first, second in zip(rows, rows[1:])]
        sim_values = [row.get("sim_time_s") for row in rows]
        sim_periods = [float(second) - float(first) for first, second in zip(sim_values, sim_values[1:])
                       if second is not None and first is not None]
        wall = _metric_summary(wall_periods)
        sim = _metric_summary(sim_periods)
        output[name] = {
            "count": len(rows),
            "wall_period_s": wall,
            "sim_period_s": sim,
            "wall_hz": (1.0 / wall["mean"]) if wall["mean"] else None,
            "sim_hz": (1.0 / sim["mean"]) if sim["mean"] else None,
            "status": "measurable" if len(rows) >= 2 else "insufficient_samples",
        }
    return output


def summarize_dynamic_runs(runs: Iterable[Mapping[str, object]]) -> dict[str, object]:
    rows = list(runs)
    by_method: dict[str, list[Mapping[str, object]]] = {method: [] for method in METHODS}
    for row in rows:
        method = normalize_method(row.get("method", row.get("algorithm", "")))
        by_method[method].append(row)
    output: dict[str, object] = {}
    for method, method_rows in by_method.items():
        response_values = [
            _finite(row["latency_ms"]["appearance_to_avoidance_confirmation_ms"], "avoidance latency")
            for row in method_rows if row.get("latency_ms", {}).get("appearance_to_avoidance_confirmation_ms") is not None
        ]
        latency_names = sorted({
            name for row in method_rows for name in row.get("latency_ms", {})
        })
        latency_statistics = {
            name: _metric_summary([
                _finite(row["latency_ms"][name], name)
                for row in method_rows if row.get("latency_ms", {}).get(name) is not None
            ])
            for name in latency_names
        }
        timeout_values = [int(row.get("timeout_count", 0)) for row in method_rows]
        output[method] = {
            "n": len(method_rows),
            "real_time_yes_rate": sum(str(row.get("real_time_avoidance", "")) in ("yes", "yes_unbounded_stop_not_logged") for row in method_rows) / len(method_rows) if method_rows else None,
            "real_time_verified_yes_rate": sum(row.get("real_time_avoidance") == "yes" for row in method_rows) / len(method_rows) if method_rows else None,
            "collision_rate": sum(bool(row.get("collision")) for row in method_rows) / len(method_rows) if method_rows else None,
            "avoidance_latency_ms": timing_statistics(response_values) if response_values else None,
            "latency_ms": latency_statistics,
            "timeout_runs": sum(value > 0 for value in timeout_values),
            "timeout_events": sum(timeout_values),
            "mean_astar_replan_count": float(np.mean([row.get("astar_replan_count", 0) for row in method_rows])) if method_rows else None,
        }
    return {"by_method": output, "runs": rows}


def diagnose_ppo_policy(
    action_histogram: Mapping[int | str, int | float],
    *,
    state_action_records: Sequence[Mapping[str, object]] | None = None,
    dominant_share_threshold: float = 0.80,
    minimum_unique_action_count: int = 2,
) -> dict[str, object]:
    """Diagnose collapse versus context-dependent mixed behavior.

    The result intentionally says ``insufficient_evidence`` when only a global
    histogram is provided; a mixed histogram alone can still be random rather
    than adaptive.  State/action records are needed to establish conditional
    switching.
    """
    counts = Counter()
    for raw_action, raw_count in action_histogram.items():
        action = int(raw_action)
        count = float(raw_count)
        if action not in range(9) or count < 0 or not math.isfinite(count):
            raise ValueError("action histogram must contain finite non-negative counts for actions 0..8")
        counts[action] += count
    total = sum(counts.values())
    if total <= 0:
        raise ValueError("action histogram must contain a positive count")
    probabilities = {action: counts[action] / total for action in range(9)}
    entropy = -sum(probability * math.log(probability) for probability in probabilities.values() if probability > 0)
    dominant_action, dominant_count = max(counts.items(), key=lambda item: (item[1], -item[0]))
    dominant_share = dominant_count / total
    route_counts = Counter()
    speed_counts = Counter()
    for action, count in counts.items():
        route_index, speed_index = decode_action(action)
        route_counts[POSTURE_NAMES[route_index]] += count
        speed_counts[SPEED_RATIOS[speed_index]] += count
    unique_actions = sum(count > 0 for count in counts.values())
    conditional_switching = None
    if state_action_records:
        groups: dict[str, list[int]] = {}
        for record in state_action_records:
            if "state_key" not in record or "action_id" not in record:
                raise ValueError("state_action_records require state_key and action_id")
            groups.setdefault(str(record["state_key"]), []).append(int(record["action_id"]))
        distinct_state_actions = len({actions[0] for actions in groups.values() if actions})
        conditional_switching = {
            "state_count": len(groups),
            "states_with_multiple_actions": sum(len(set(actions)) > 1 for actions in groups.values()),
            "distinct_dominant_actions": distinct_state_actions,
            "state_action_sets": {key: sorted(set(actions)) for key, actions in groups.items()},
        }
    if dominant_share >= dominant_share_threshold and unique_actions < minimum_unique_action_count + 1:
        diagnosis = "collapse_likely"
        conclusion = "PPO is effectively using one action; it has not demonstrated the desired mixed policy."
    elif conditional_switching is None:
        diagnosis = "mixed_histogram_but_adaptation_unverified"
        conclusion = "The action histogram is not collapsed, but conditional state-dependent switching is not yet proven."
    elif conditional_switching["distinct_dominant_actions"] < 2:
        diagnosis = "state_conditioning_unverified"
        conclusion = "The observed states do not map to distinct actions; context-dependent adaptation is unverified."
    else:
        diagnosis = "context_dependent_mixing_observed"
        conclusion = "The logged states show context-dependent action switching; check safety and held-out generalization next."
    return {
        "total_action_count": total,
        "action_probabilities": probabilities,
        "entropy_nats": entropy,
        "dominant_action": dominant_action,
        "dominant_action_label": {"route": POSTURE_NAMES[decode_action(dominant_action)[0]], "speed_ratio": SPEED_RATIOS[decode_action(dominant_action)[1]]},
        "dominant_share": dominant_share,
        "unique_action_count": unique_actions,
        "route_histogram": dict(route_counts),
        "speed_ratio_histogram": {str(key): value for key, value in speed_counts.items()},
        "conditional_switching": conditional_switching,
        "diagnosis": diagnosis,
        "conclusion": conclusion,
        "argmin_reference": "Use the explicit objective-function enumeration policy as a diagnostic oracle, not as evidence that PPO is trained well.",
    }


def pairwise_method_deltas(summary: Mapping[str, object], metric: str) -> list[dict[str, object]]:
    by_method = summary["by_method"]
    output = []
    for first, second in combinations(METHODS, 2):
        first_value = by_method[first]["metrics_success_only"].get(metric, {}).get("mean")
        second_value = by_method[second]["metrics_success_only"].get(metric, {}).get("mean")
        output.append({"first": first, "second": second, "metric": metric, "delta_second_minus_first": None if first_value is None or second_value is None else second_value - first_value})
    return output
