from __future__ import annotations

import numpy as np

from .collision_envelope import quaternion_matrix
from .isaac_scene_query import DepthScan


def depth_image_scan(depth_image, intrinsics, position_world, quaternion_ros, timestamp_s, stride=4, max_range_m=8.):
    depth = np.asarray(depth_image, dtype=float).squeeze()
    intrinsic = np.asarray(intrinsics, dtype=float)
    if depth.ndim != 2 or intrinsic.shape != (3, 3) or stride < 1 or intrinsic[0, 0] <= 0 or intrinsic[1, 1] <= 0:
        raise ValueError("depth conversion requires calibrated image intrinsics")
    vertical, horizontal = np.meshgrid(np.arange(0, depth.shape[0], stride), np.arange(0, depth.shape[1], stride), indexing="ij")
    sampled = depth[vertical, horizontal]
    valid = np.isfinite(sampled) & (sampled > .05) & (sampled < max_range_m)
    cleaned = np.where(valid, sampled, 0.)
    camera_points = np.stack(((horizontal + .5 - intrinsic[0, 2]) / intrinsic[0, 0] * cleaned,
                              (vertical + .5 - intrinsic[1, 2]) / intrinsic[1, 1] * cleaned, cleaned), -1)
    normals = np.zeros_like(camera_points)
    if min(sampled.shape) > 1:
        horizontal_delta = camera_points[:-1, 1:] - camera_points[:-1, :-1]
        vertical_delta = camera_points[1:, :-1] - camera_points[:-1, :-1]
        local_normals = np.cross(horizontal_delta, vertical_delta)
        normal_lengths = np.linalg.norm(local_normals, axis=-1)
        smooth = (valid[:-1, :-1] & valid[:-1, 1:] & valid[1:, :-1]
                  & (np.abs(cleaned[:-1, 1:] - cleaned[:-1, :-1]) < .10)
                  & (np.abs(cleaned[1:, :-1] - cleaned[:-1, :-1]) < .10))
        local_normals /= np.maximum(normal_lengths[..., None], 1e-10)
        facing_away = np.sum(local_normals * camera_points[:-1, :-1], axis=-1) > 0
        local_normals[facing_away] *= -1
        normals[:-1, :-1] = np.where(smooth[..., None], local_normals, 0.)
    rotation = quaternion_matrix(np.asarray(quaternion_ros, dtype=float))
    points = camera_points[valid] @ rotation.T + np.asarray(position_world)
    world_normals = normals[valid] @ rotation.T
    return DepthScan(float(timestamp_s), points, sampled[valid], tuple("rgbd_surface" for _ in points),
                     source="isaac_rendered_rgbd_camera", normals_world=world_normals)
