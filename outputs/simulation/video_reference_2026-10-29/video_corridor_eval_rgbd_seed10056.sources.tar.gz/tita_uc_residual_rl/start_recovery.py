from dataclasses import dataclass
import math

import numpy as np

from .grid_path_geometry import polyline_cells


@dataclass(frozen=True)
class ContinuousRecoveryGeometry:
    wall_rectangles_xy_m: tuple
    body_clearance_radius_m: float
    raster_padding_m: float

    def __post_init__(self):
        rectangles = np.asarray(self.wall_rectangles_xy_m, dtype=float)
        if (rectangles.ndim != 2 or rectangles.shape[1] != 4 or not len(rectangles)
                or not np.isfinite(rectangles).all()
                or (rectangles[:, 2:] <= rectangles[:, :2]).any()
                or not math.isfinite(self.body_clearance_radius_m) or self.body_clearance_radius_m <= 0.
                or not math.isfinite(self.raster_padding_m) or self.raster_padding_m < 0.):
            raise ValueError('start recovery requires finite wall boxes and conservative body clearance')
        object.__setattr__(self, 'wall_rectangles_xy_m', tuple(map(tuple, rectangles)))

    def occupancy_for(self, shape, resolution_m, origin_xy):
        horizontal, vertical = np.meshgrid(origin_xy[0] + (np.arange(shape[1]) + .5) * resolution_m,
                                          origin_xy[1] + (np.arange(shape[0]) + .5) * resolution_m)
        inflation = self.body_clearance_radius_m + self.raster_padding_m
        occupancy = np.zeros(shape, dtype=bool)
        for left, bottom, right, top in self.wall_rectangles_xy_m:
            occupancy |= ((horizontal >= left - inflation) & (horizontal <= right + inflation)
                          & (vertical >= bottom - inflation) & (vertical <= top + inflation))
        return occupancy

    def segment_safe(self, start_xy, end_xy):
        start, end = np.asarray(start_xy, dtype=float), np.asarray(end_xy, dtype=float)
        if start.shape != (2,) or end.shape != (2,) or not np.isfinite([start, end]).all():
            raise ValueError('recovery segment requires finite planar endpoints')
        direction = end - start
        for rectangle in self.wall_rectangles_xy_m:
            lower = np.asarray(rectangle[:2])
            upper = np.asarray(rectangle[2:])
            enter, leave = 0., 1.
            for axis in range(2):
                if abs(direction[axis]) < 1e-12:
                    if start[axis] < lower[axis] - 1e-9 or start[axis] > upper[axis] + 1e-9:
                        enter, leave = 1., 0.
                        break
                else:
                    interval = sorted(((lower[axis] - start[axis]) / direction[axis],
                                       (upper[axis] - start[axis]) / direction[axis]))
                    enter, leave = max(enter, interval[0]), min(leave, interval[1])
            if enter <= leave + 1e-9:
                return False
            endpoints = np.vstack((start, end))
            offsets = np.maximum(np.maximum(lower - endpoints, endpoints - upper), 0.)
            distance_squared = float(np.sum(offsets * offsets, axis=1).min())
            vertices = np.asarray(((lower[0], lower[1]), (lower[0], upper[1]),
                                   (upper[0], lower[1]), (upper[0], upper[1])))
            length_squared = float(np.dot(direction, direction))
            fractions = np.clip((vertices - start) @ direction / max(length_squared, 1e-15), 0., 1.)
            distances = vertices - (start + fractions[:, None] * direction)
            distance_squared = min(distance_squared, float(np.sum(distances * distances, axis=1).min()))
            if distance_squared <= (self.body_clearance_radius_m + 1e-9) ** 2:
                return False
        return True


@dataclass(frozen=True)
class StartRecoveryConnector:
    start_xy_m: tuple[float, float]
    anchor_xy_m: tuple[float, float]

    def __post_init__(self):
        if (len(self.start_xy_m) != 2 or len(self.anchor_xy_m) != 2
                or not np.isfinite([self.start_xy_m, self.anchor_xy_m]).all()
                or np.linalg.norm(np.subtract(self.anchor_xy_m, self.start_xy_m)) <= 1e-9):
            raise ValueError('recovery connector requires distinct finite planar endpoints')
        object.__setattr__(self, 'start_xy_m', tuple(map(float, self.start_xy_m)))
        object.__setattr__(self, 'anchor_xy_m', tuple(map(float, self.anchor_xy_m)))


def verified_recovery_prefix(scene, path):
    connector = path.start_recovery
    geometry = scene.recovery_geometry
    if connector is None or geometry is None or not path.continuous_geometry:
        return None
    if (not np.array_equal(path.points_xy_m[0], connector.start_xy_m)
            or not np.array_equal(path.points_xy_m[1], connector.anchor_xy_m)
            or not geometry.segment_safe(connector.start_xy_m, connector.anchor_xy_m)):
        return None
    anchor_cells, _ = polyline_cells(scene, [connector.anchor_xy_m, connector.anchor_xy_m])
    prefix_cells, _ = polyline_cells(scene, path.points_xy_m[:2])
    if (not all(scene.in_bounds(cell) for cell in prefix_cells)
            or not all(scene.in_bounds(cell) and not scene.occupancy[cell[1], cell[0]] for cell in anchor_cells)):
        return None
    return set(prefix_cells), float(np.linalg.norm(path.points_xy_m[1] - path.points_xy_m[0]))


def path_sample_free(scene, path, cells, distances):
    free = np.asarray([scene.in_bounds(cell) and not scene.occupancy[cell[1], cell[0]] for cell in cells])
    prefix = verified_recovery_prefix(scene, path)
    if prefix is not None:
        prefix_cells, length = prefix
        free |= np.asarray([cell in prefix_cells and distance <= length + 1e-9
                            for cell, distance in zip(cells, distances)])
    return free


def recovery_anchors(scene, start_xy, maximum_distance_m, start_yaw_rad=None):
    geometry = scene.recovery_geometry
    if geometry is None or not geometry.segment_safe(start_xy, start_xy):
        return ()
    if start_yaw_rad is not None and not math.isfinite(start_yaw_rad):
        raise ValueError('recovery heading must be finite')
    start = np.asarray(start_xy, dtype=float)
    center = scene.world_to_cell(start)
    radius = int(math.ceil(maximum_distance_m / scene.resolution_m))
    candidates = []
    for horizontal in range(center[0] - radius, center[0] + radius + 1):
        for vertical in range(center[1] - radius, center[1] + radius + 1):
            cell = horizontal, vertical
            if not scene.in_bounds(cell) or scene.occupancy[vertical, horizontal]:
                continue
            anchor = scene.cell_to_world(cell)
            displacement = np.subtract(anchor, start)
            distance = float(np.linalg.norm(displacement))
            if distance <= 1e-9 or distance > maximum_distance_m or not geometry.segment_safe(start, anchor):
                continue
            angle = math.atan2(displacement[1], displacement[0])
            heading_change = 0. if start_yaw_rad is None else abs(math.atan2(math.sin(angle - start_yaw_rad), math.cos(angle - start_yaw_rad)))
            candidates.append((distance + .15 * heading_change, anchor))
    return tuple(anchor for _, anchor in sorted(candidates))
