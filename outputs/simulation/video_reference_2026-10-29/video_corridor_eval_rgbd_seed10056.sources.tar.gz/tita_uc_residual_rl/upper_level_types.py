"""Public data contract for the three-route upper-level navigation policy.

The HMAP heights are route-layer identifiers.  They are deliberately kept
separate from the simulated or measured robot collision-envelope heights.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


ROUTE_HEIGHTS_CM = (20, 30, 40)
POSTURE_NAMES = ("LOW", "MID", "HIGH")
SPEED_RATIOS = (0.4, 0.7, 1.0)
ROUTE_FEATURE_NAMES = (
    "valid",
    "remaining_length_m",
    "lateral_clearance_m",
    "overhead_margin_m",
    "mean_slope_rad",
    "max_slope_rad",
    "roughness_rms_m",
    "curvature_integral",
)
ROUTE_FEATURE_COUNT = len(ROUTE_FEATURE_NAMES)
UPPER_OBSERVATION_DIM = 38
UPPER_ACTION_COUNT = 9


def encode_action(route_index: int, speed_index: int) -> int:
    """Encode ``(route, speed)`` using the frozen 3x3 action contract."""

    if route_index not in range(3) or speed_index not in range(3):
        raise ValueError("route_index and speed_index must be in [0, 2]")
    return 3 * int(route_index) + int(speed_index)


def decode_action(action_id: int) -> tuple[int, int]:
    """Return ``(route_index, speed_index)`` for one policy action."""

    if action_id not in range(UPPER_ACTION_COUNT):
        raise ValueError("action_id must be in [0, 8]")
    return divmod(int(action_id), 3)


@dataclass(frozen=True)
class RouteCandidate:
    """Features of one A* candidate bound to exactly one posture."""

    height_cm: int
    valid: bool
    remaining_length_m: float
    lateral_clearance_m: float
    overhead_margin_m: float
    mean_slope_rad: float = 0.0
    max_slope_rad: float = 0.0
    roughness_rms_m: float = 0.0
    curvature_integral: float = 0.0
    path_version: int = 0
    goal_version: int = 0
    failure_reason: str = ""

    def __post_init__(self) -> None:
        if self.height_cm not in ROUTE_HEIGHTS_CM:
            raise ValueError("height_cm must be 20, 30, or 40")
        finite = (
            self.remaining_length_m,
            self.lateral_clearance_m,
            self.overhead_margin_m,
            self.mean_slope_rad,
            self.max_slope_rad,
            self.roughness_rms_m,
            self.curvature_integral,
        )
        if not np.all(np.isfinite(finite)):
            raise ValueError("route features must be finite")
        if self.remaining_length_m < 0.0:
            raise ValueError("remaining route length must be non-negative")

    @property
    def route_index(self) -> int:
        return ROUTE_HEIGHTS_CM.index(self.height_cm)

    @property
    def posture_name(self) -> str:
        return POSTURE_NAMES[self.route_index]

    def feature_vector(self) -> np.ndarray:
        return np.asarray(
            (
                float(self.valid),
                self.remaining_length_m,
                self.lateral_clearance_m,
                self.overhead_margin_m,
                self.mean_slope_rad,
                self.max_slope_rad,
                self.roughness_rms_m,
                self.curvature_integral,
            ),
            dtype=np.float32,
        )


@dataclass(frozen=True)
class UpperObservation:
    """One upper-level decision observation before numerical normalization."""

    routes: tuple[RouteCandidate, RouteCandidate, RouteCandidate]
    speed_mps: float = 0.0
    roll_rad: float = 0.0
    pitch_rad: float = 0.0
    current_route: int = 1
    previous_speed_index: int = 1
    transition_phase: float = 0.0
    energy_accumulator_j: float = 0.0
    remaining_goal_distance_m: float = 0.0
    path_age_s: float = 0.0
    goal_age_s: float = 0.0
    stable_elapsed_s: float = 0.0
    route_locked: bool = False
    sensor_valid: bool = True

    def __post_init__(self) -> None:
        if len(self.routes) != 3:
            raise ValueError("exactly three route candidates are required")
        if tuple(route.height_cm for route in self.routes) != ROUTE_HEIGHTS_CM:
            raise ValueError("routes must be ordered as 20/30/40 cm")
        if self.current_route not in range(3):
            raise ValueError("current_route must be in [0, 2]")
        if self.previous_speed_index not in range(3):
            raise ValueError("previous_speed_index must be in [0, 2]")

    def vector(self) -> np.ndarray:
        route_features = np.concatenate([route.feature_vector() for route in self.routes])
        current_route = np.eye(3, dtype=np.float32)[self.current_route]
        previous_speed = np.eye(3, dtype=np.float32)[self.previous_speed_index]
        global_features = np.concatenate(
            (
                np.asarray(
                    (self.speed_mps, self.roll_rad, self.pitch_rad), dtype=np.float32
                ),
                current_route,
                previous_speed,
                np.asarray(
                    (
                        self.transition_phase,
                        self.energy_accumulator_j,
                        self.remaining_goal_distance_m,
                        self.path_age_s,
                        self.goal_age_s,
                    ),
                    dtype=np.float32,
                ),
            )
        )
        output = np.concatenate((route_features, global_features))
        if output.shape != (UPPER_OBSERVATION_DIM,):
            raise RuntimeError(f"unexpected upper observation shape {output.shape}")
        return output


@dataclass(frozen=True)
class UpperDecision:
    """Atomic route/posture/speed result; action ``-1`` means safe stop."""

    valid: bool
    action_id: int = -1
    route_index: int = -1
    height_cm: int = 0
    posture_name: str = ""
    speed_index: int = -1
    speed_ratio: float = 0.0
    path_version: int = 0
    goal_version: int = 0
    reason: str = ""

    @classmethod
    def stop(cls, reason: str) -> "UpperDecision":
        return cls(valid=False, reason=str(reason))

    @classmethod
    def from_action(
        cls, action_id: int, observation: UpperObservation, reason: str = ""
    ) -> "UpperDecision":
        route_index, speed_index = decode_action(action_id)
        route = observation.routes[route_index]
        return cls(
            valid=True,
            action_id=action_id,
            route_index=route_index,
            height_cm=route.height_cm,
            posture_name=POSTURE_NAMES[route_index],
            speed_index=speed_index,
            speed_ratio=SPEED_RATIOS[speed_index],
            path_version=route.path_version,
            goal_version=route.goal_version,
            reason=reason,
        )


@dataclass(frozen=True)
class UpperObjectiveWeights:
    energy: float = 0.30
    time: float = 0.25
    length: float = 0.15
    clearance: float = 0.25
    switch: float = 0.05
    clearance_violation: float = 2.0
    height_violation: float = 2.0
    attitude: float = 1.0


@dataclass(frozen=True)
class UpperNormalization:
    """Frozen episode-level references; never updated from a PPO batch."""

    energy_ref_j: float = 20.0
    time_ref_s: float = 40.0
    length_ref_m: float = 5.0

    def __post_init__(self) -> None:
        if min(self.energy_ref_j, self.time_ref_s, self.length_ref_m) <= 0.0:
            raise ValueError("all upper objective references must be positive")


@dataclass(frozen=True)
class UpperSafetyConfig:
    decision_dt_s: float = 0.5
    clearance_soft_margin_m: float = 0.05
    envelope_margin_m: float = 0.03
    minimum_lateral_clearance_m: float = 0.10
    reaction_time_s: float = 0.15
    braking_accel_mps2: tuple[float, float, float] = (0.25, 0.25, 0.25)
    posture_vmax_mps: tuple[float, float, float] = (0.10, 0.13, 0.15)
    switch_speed_max_mps: float = 0.20
    switch_roll_max_rad: float = 0.12
    switch_pitch_max_rad: float = 0.12
    switch_hold_time_s: float = 0.20
    attitude_soft_rad: float = 0.12
    attitude_hard_rad: float = 0.25
    maximum_path_age_s: float = 0.75
    maximum_goal_age_s: float = 0.75

    def __post_init__(self) -> None:
        positive = (
            self.decision_dt_s,
            self.clearance_soft_margin_m,
            self.minimum_lateral_clearance_m,
            self.reaction_time_s,
            *self.braking_accel_mps2,
            *self.posture_vmax_mps,
            self.switch_speed_max_mps,
            self.switch_roll_max_rad,
            self.switch_pitch_max_rad,
            self.switch_hold_time_s,
            self.attitude_soft_rad,
            self.attitude_hard_rad,
            self.maximum_path_age_s,
            self.maximum_goal_age_s,
        )
        if min(positive) <= 0.0:
            raise ValueError("upper safety values must be positive")
        if self.attitude_hard_rad <= self.attitude_soft_rad:
            raise ValueError("hard attitude limit must exceed its soft limit")


@dataclass(frozen=True)
class UpperObjectiveTerms:
    energy: float = 0.0
    time: float = 0.0
    length: float = 0.0
    clearance: float = 0.0
    switch: float = 0.0
    clearance_violation: float = 0.0
    height_violation: float = 0.0
    attitude: float = 0.0

    def as_dict(self) -> dict[str, float]:
        return {
            name: float(getattr(self, name))
            for name in self.__dataclass_fields__
        }


@dataclass
class EpisodeMetrics:
    method: str
    seed: int
    episode: int
    success: bool
    collision: bool
    hard_violation: bool
    total_cost: float
    total_reward: float
    elapsed_s: float
    distance_m: float
    mechanical_energy_j: float
    mechanical_cot: float
    switches: int
    minimum_overhead_margin_m: float
    minimum_lateral_clearance_m: float
    maximum_abs_roll_rad: float
    maximum_abs_pitch_rad: float
    decision_latency_ms: list[float] = field(default_factory=list)

