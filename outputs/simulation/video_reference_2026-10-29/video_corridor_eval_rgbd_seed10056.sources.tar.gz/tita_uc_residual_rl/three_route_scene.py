"""Geometry and route contract for the first three-route upper-level RL scene.

The special 0 cm hmap is retained as a perception/reference layer.  It is not
an RL posture action.  The three posture actions correspond to the +20, +30,
and +40 cm hmaps respectively.
"""

from __future__ import annotations

from dataclasses import dataclass
import math


SPECIAL_HMAP_OFFSET_M = 0.0
POSTURE_HMAP_OFFSETS_M = {
    "LOW": 0.20,
    "MID": 0.30,
    "HIGH": 0.40,
}
HMAP_OFFSETS_M = (SPECIAL_HMAP_OFFSET_M, *POSTURE_HMAP_OFFSETS_M.values())


@dataclass(frozen=True)
class SceneBox:
    """One axis-aligned collision box in the three-route scene."""

    name: str
    center: tuple[float, float, float]
    size: tuple[float, float, float]
    color: tuple[int, int, int, int]


@dataclass(frozen=True)
class RouteDefinition:
    """A fixed candidate path and its overhead-clearance contract."""

    name: str
    description: str
    center_y_m: float
    width_m: float
    ceiling_clearance_m: float | None
    hmap_zero_clearance_m: float
    points: tuple[tuple[float, float], ...]

    @property
    def length_m(self) -> float:
        return sum(
            math.dist(start, end) for start, end in zip(self.points, self.points[1:])
        )

    def allows_posture(self, posture: str) -> bool:
        """Return whether the posture's hmap height clears this route's roof.

        The actual robot-envelope safety margin is applied later by the upper
        level feasibility checker.  These scene clearances deliberately sit
        between adjacent hmap heights, so the intended discrete feasibility is
        unambiguous before randomization is introduced.
        """

        try:
            posture_offset = POSTURE_HMAP_OFFSETS_M[posture]
        except KeyError as exc:
            raise ValueError("posture must be LOW, MID, or HIGH") from exc
        return (
            self.ceiling_clearance_m is None
            or self.hmap_zero_clearance_m + posture_offset
            < self.ceiling_clearance_m
        )

    @property
    def allowed_postures(self) -> tuple[str, ...]:
        return tuple(
            posture for posture in POSTURE_HMAP_OFFSETS_M if self.allows_posture(posture)
        )


@dataclass(frozen=True)
class ThreeRouteSceneConfig:
    """Deterministic three-route scene used before the full navigation stack.

    The four hmap values are offsets from the prone/0-layer datum, not absolute
    roof heights above the ground.  The default simulation datum is 0.30 m,
    making the LOW/MID/HIGH envelope levels 0.50/0.60/0.70 m.  This datum is a
    scene parameter and must later be replaced by the measured physical prone
    envelope.  The geometry is deliberately exaggerated for diagnosis:

    * LOW takes a straight, narrow 8 m corridor with only 1 cm roof margin.
    * MID detours through a medium-width corridor with 8 cm roof margin.
    * HIGH takes the longest but widest route with open overhead clearance.

    The routes are returned in LOW/MID/HIGH action order even though the open
    corridor is physically below the LOW corridor and the MID corridor is
    above it.  This makes the three A* results and objective trade-offs easy to
    inspect before introducing randomized training scenes.
    """

    start_x_m: float = 0.0
    goal_x_m: float = 8.0
    corridor_start_x_m: float = 1.50
    corridor_end_x_m: float = 6.50
    wall_height_m: float = 0.90
    wall_thickness_m: float = 0.12
    outer_wall_extension_m: float = 0.50
    ceiling_start_x_m: float = 2.75
    ceiling_end_x_m: float = 5.25
    ceiling_thickness_m: float = 0.10
    hmap_zero_clearance_m: float = 0.30

    route_1_center_y_m: float = 0.0
    route_1_width_m: float = 1.40
    route_1_clearance_m: float = 0.51

    route_2_center_y_m: float = -3.20
    route_2_width_m: float = 2.40

    route_3_center_y_m: float = 1.80
    route_3_width_m: float = 1.80
    route_3_clearance_m: float = 0.68

    planning_inflation_radius_m: float = 0.45
    open_overhead_margin_m: float = 0.50

    def __post_init__(self) -> None:
        positive = (
            self.goal_x_m - self.start_x_m,
            self.corridor_end_x_m - self.corridor_start_x_m,
            self.wall_height_m,
            self.wall_thickness_m,
            self.outer_wall_extension_m,
            self.ceiling_end_x_m - self.ceiling_start_x_m,
            self.ceiling_thickness_m,
            self.hmap_zero_clearance_m,
            self.route_1_width_m,
            self.route_2_width_m,
            self.route_3_width_m,
            self.route_1_clearance_m,
            self.route_3_clearance_m,
            self.planning_inflation_radius_m,
            self.open_overhead_margin_m,
        )
        if any(value <= 0.0 for value in positive):
            raise ValueError("three-route dimensions must be positive")
        if not (
            self.start_x_m
            < self.corridor_start_x_m
            < self.ceiling_start_x_m
            < self.ceiling_end_x_m
            < self.corridor_end_x_m
            < self.goal_x_m
        ):
            raise ValueError("three-route x coordinates must be strictly ordered")
        route_1_top = self.route_1_center_y_m + self.route_1_width_m / 2.0
        route_3_bottom = self.route_3_center_y_m - self.route_3_width_m / 2.0
        route_2_top = self.route_2_center_y_m + self.route_2_width_m / 2.0
        route_1_bottom = self.route_1_center_y_m - self.route_1_width_m / 2.0
        if route_3_bottom <= route_1_top or route_2_top >= route_1_bottom:
            raise ValueError("three-route corridors must not overlap")
        low_height = self.hmap_zero_clearance_m + POSTURE_HMAP_OFFSETS_M["LOW"]
        mid_height = self.hmap_zero_clearance_m + POSTURE_HMAP_OFFSETS_M["MID"]
        high_height = self.hmap_zero_clearance_m + POSTURE_HMAP_OFFSETS_M["HIGH"]
        if not low_height < self.route_1_clearance_m < mid_height:
            raise ValueError("route 1 clearance must admit LOW and reject MID")
        if not mid_height < self.route_3_clearance_m < high_height:
            raise ValueError("route 3 clearance must admit MID and reject HIGH")

    def routes(self) -> tuple[RouteDefinition, ...]:
        def points(center_y: float) -> tuple[tuple[float, float], ...]:
            return (
                (self.start_x_m, 0.0),
                (self.corridor_start_x_m, center_y),
                (self.corridor_end_x_m, center_y),
                (self.goal_x_m, 0.0),
            )

        return (
            RouteDefinition(
                name="route_1_low_short",
                description="shortest route; LOW only",
                center_y_m=self.route_1_center_y_m,
                width_m=self.route_1_width_m,
                ceiling_clearance_m=self.route_1_clearance_m,
                hmap_zero_clearance_m=self.hmap_zero_clearance_m,
                points=points(self.route_1_center_y_m),
            ),
            RouteDefinition(
                name="route_2_mid_medium",
                description="intermediate route selected by the MID layer",
                center_y_m=self.route_3_center_y_m,
                width_m=self.route_3_width_m,
                ceiling_clearance_m=self.route_3_clearance_m,
                hmap_zero_clearance_m=self.hmap_zero_clearance_m,
                points=points(self.route_3_center_y_m),
            ),
            RouteDefinition(
                name="route_3_high_open_long",
                description="longest and widest route selected by the HIGH layer",
                center_y_m=self.route_2_center_y_m,
                width_m=self.route_2_width_m,
                ceiling_clearance_m=None,
                hmap_zero_clearance_m=self.hmap_zero_clearance_m,
                points=points(self.route_2_center_y_m),
            ),
        )


def three_route_boxes(
    origin_xy: tuple[float, float], config: ThreeRouteSceneConfig | None = None
) -> tuple[SceneBox, ...]:
    """Return world-space collision boxes for one three-route environment."""

    cfg = config or ThreeRouteSceneConfig()
    origin_x, origin_y = origin_xy
    corridor_length = cfg.corridor_end_x_m - cfg.corridor_start_x_m
    corridor_center_x = origin_x + (
        cfg.corridor_start_x_m + cfg.corridor_end_x_m
    ) / 2.0
    wall_center_z = cfg.wall_height_m / 2.0
    outer_wall_length = (
        cfg.goal_x_m - cfg.start_x_m + 2.0 * cfg.outer_wall_extension_m
    )
    outer_wall_center_x = origin_x + (cfg.start_x_m + cfg.goal_x_m) / 2.0

    route_1_top = cfg.route_1_center_y_m + cfg.route_1_width_m / 2.0
    route_1_bottom = cfg.route_1_center_y_m - cfg.route_1_width_m / 2.0
    route_2_top = cfg.route_2_center_y_m + cfg.route_2_width_m / 2.0
    route_2_bottom = cfg.route_2_center_y_m - cfg.route_2_width_m / 2.0
    route_3_top = cfg.route_3_center_y_m + cfg.route_3_width_m / 2.0
    route_3_bottom = cfg.route_3_center_y_m - cfg.route_3_width_m / 2.0

    wall_color = (72, 78, 84, 255)
    boxes = [
        # Solid divider bands prevent changing routes inside the test section.
        SceneBox(
            "upper_divider",
            (
                corridor_center_x,
                origin_y + (route_1_top + route_3_bottom) / 2.0,
                wall_center_z,
            ),
            (corridor_length, route_3_bottom - route_1_top, cfg.wall_height_m),
            wall_color,
        ),
        SceneBox(
            "lower_divider",
            (
                corridor_center_x,
                origin_y + (route_2_top + route_1_bottom) / 2.0,
                wall_center_z,
            ),
            (corridor_length, route_1_bottom - route_2_top, cfg.wall_height_m),
            wall_color,
        ),
        SceneBox(
            "upper_outer_wall",
            (
                outer_wall_center_x,
                origin_y + route_3_top + cfg.wall_thickness_m / 2.0,
                wall_center_z,
            ),
            (outer_wall_length, cfg.wall_thickness_m, cfg.wall_height_m),
            wall_color,
        ),
        SceneBox(
            "lower_outer_wall",
            (
                outer_wall_center_x,
                origin_y + route_2_bottom - cfg.wall_thickness_m / 2.0,
                wall_center_z,
            ),
            (outer_wall_length, cfg.wall_thickness_m, cfg.wall_height_m),
            wall_color,
        ),
    ]

    ceiling_length = cfg.ceiling_end_x_m - cfg.ceiling_start_x_m
    ceiling_center_x = origin_x + (
        cfg.ceiling_start_x_m + cfg.ceiling_end_x_m
    ) / 2.0
    boxes.extend(
        (
            SceneBox(
                "route_1_low_ceiling",
                (
                    ceiling_center_x,
                    origin_y + cfg.route_1_center_y_m,
                    cfg.route_1_clearance_m + cfg.ceiling_thickness_m / 2.0,
                ),
                (
                    ceiling_length,
                    cfg.route_1_width_m,
                    cfg.ceiling_thickness_m,
                ),
                (206, 92, 74, 255),
            ),
            SceneBox(
                "route_3_mid_ceiling",
                (
                    ceiling_center_x,
                    origin_y + cfg.route_3_center_y_m,
                    cfg.route_3_clearance_m + cfg.ceiling_thickness_m / 2.0,
                ),
                (
                    ceiling_length,
                    cfg.route_3_width_m,
                    cfg.ceiling_thickness_m,
                ),
                (218, 157, 63, 255),
            ),
        )
    )
    return tuple(boxes)


def three_route_hmap_points(
    origin_xy: tuple[float, float] = (0.0, 0.0),
    config: ThreeRouteSceneConfig | None = None,
    *,
    sample_m: float = 0.10,
) -> list[list[list[float]]]:
    """Rasterize the diagnostic collision boxes into the three HMAP slices.

    The returned layers are ordered as +20/+30/+40 cm.  A roof appears in a
    layer only when that posture envelope reaches it: LOW sees neither roof,
    MID sees the LOW roof, and HIGH sees both roofs.  Static walls appear in
    all layers.  Points are occupancy samples of a complete simulator map,
    not individual lidar ray endpoints.
    """

    if not math.isfinite(sample_m) or sample_m <= 0.0:
        raise ValueError("sample_m must be finite and positive")
    cfg = config or ThreeRouteSceneConfig()
    layers: list[list[list[float]]] = [[], [], []]
    for layer, offset in enumerate(POSTURE_HMAP_OFFSETS_M.values()):
        envelope_height = cfg.hmap_zero_clearance_m + offset
        for box in three_route_boxes(origin_xy, cfg):
            is_ceiling = "ceiling" in box.name
            box_bottom = box.center[2] - box.size[2] / 2.0
            if is_ceiling and envelope_height < box_bottom:
                continue
            min_x = box.center[0] - box.size[0] / 2.0
            max_x = box.center[0] + box.size[0] / 2.0
            min_y = box.center[1] - box.size[1] / 2.0
            max_y = box.center[1] + box.size[1] / 2.0
            count_x = max(1, int(math.ceil((max_x - min_x) / sample_m)))
            count_y = max(1, int(math.ceil((max_y - min_y) / sample_m)))
            for ix in range(count_x + 1):
                x = min_x + (max_x - min_x) * ix / count_x
                for iy in range(count_y + 1):
                    y = min_y + (max_y - min_y) * iy / count_y
                    layers[layer].append([round(x, 4), round(y, 4), offset])
    return layers
