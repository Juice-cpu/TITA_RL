from dataclasses import asdict
import math

from .joint_reward import JointRewardWeights


def select_joint_training_episode(document):
    if document.get('upper_trained_here') is not True or document.get('backend') != 'vendor':
        raise ValueError('joint checkpoint selection requires actual vendor-backed upper training')
    if document.get('upper_reward_weights') != asdict(JointRewardWeights()):
        raise ValueError('training selection requires the declared closed reward weights')
    results, trajectory = document['episode_results'], document['trajectory']
    if not results or len({row['episode'] for row in results}) != len(results):
        raise ValueError('training results require unique completed episodes')
    if document.get('completed_steps') != len(trajectory):
        raise ValueError('training reward trajectory must be complete')
    required = set(asdict(JointRewardWeights()))
    scores = {}
    for result in results:
        episode = result['episode']
        if not isinstance(episode, int) or isinstance(episode, bool) or episode < 0:
            raise ValueError('training episode identifier must be a nonnegative integer')
        scores[episode] = {'episode': episode, 'steps': result['steps'], 'path_length_m': result['path_length_m'],
            'terms': {name: [] for name in required}, 'rows': [],
            'strict_result': result['success'] is True and result['hard_failure'] is False
                and result['nominal_overlap'] is False and result['horizon'] is False
                and result['execution_timeout_reason'] is None}
    for row in trajectory:
        episode = row['episode']
        if episode not in scores:
            raise ValueError('trajectory contains an unclosed or unregistered training episode')
        terms = row['upper_reward_terms']
        if set(terms) != required or not all(math.isfinite(value) for value in terms.values()):
            raise ValueError('training selection requires all finite closed reward terms')
        for name, value in terms.items():
            scores[episode]['terms'][name].append(value)
        scores[episode]['rows'].append(row)
    aggregate = {}
    for name in required:
        aggregate[name] = math.fsum(value for score in scores.values() for value in score['terms'][name])
        recorded = document['upper_reward_totals'].get(name)
        if recorded is None or not math.isfinite(recorded) or not math.isclose(recorded, aggregate[name], rel_tol=1e-9, abs_tol=1e-7):
            raise ValueError('training rewards do not match the recorded aggregate')
    candidates, summaries = [], []
    for score in scores.values():
        rows = score.pop('rows')
        if (len(rows) != score['steps'] or score['steps'] <= 0
                or not math.isfinite(score['path_length_m']) or score['path_length_m'] < 0.):
            raise ValueError('completed training episode length is inconsistent')
        score['terms'] = {name: math.fsum(values) for name, values in score['terms'].items()}
        score['reward_sum'] = math.fsum(score['terms'].values())
        score['physical_rows_clear'] = all(
            row['nominal_pedestrian_clearance_m'] is not None
            and not math.isnan(row['nominal_pedestrian_clearance_m']) and row['nominal_pedestrian_clearance_m'] >= 0.
            and math.isfinite(row['physical_pedestrian_contact_force_n']) and 0. <= row['physical_pedestrian_contact_force_n'] <= 1.
            and row['terminated'] is False and row['truncated'] is False
            and row['execution_timeout_reason'] is None for row in rows)
        score['terminal_reward_matches_success'] = (score['terms']['success'] == JointRewardWeights().success
            and score['terms']['failure'] == 0. and rows[-1]['upper_reward_terms']['success'] == JointRewardWeights().success)
        score['eligible'] = score['strict_result'] and score['physical_rows_clear'] and score['terminal_reward_matches_success']
        summaries.append(score)
        if score['eligible']:
            candidates.append(score)
    selected = min(candidates, key=lambda row: (-row['reward_sum'], row['steps'], row['path_length_m'], row['episode'])) if candidates else None
    return {'schema': 'tita.closed_reward_training_selection.v1', 'selected': selected, 'episodes': summaries,
        'selection': 'maximum closed training reward among strict successful episodes, then fewer steps and shorter path',
        'independent_outcomes_used': False, 'independent_navigation_acceptance_proven': False}
