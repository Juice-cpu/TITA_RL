"""Load read-only real-robot posture seeds for Isaac Lab configuration."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .config import TITA_JOINT_NAMES


def load_posture_calibration(path: str | Path) -> dict[str, Any]:
    """Validate and load a posture snapshot without treating it as geometry calibration."""
    source = Path(path).expanduser().resolve()
    with source.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if tuple(payload.get("joint_order", ())) != TITA_JOINT_NAMES:
        raise ValueError("posture calibration joint_order does not match the official 8-DOF order")
    profiles = payload.get("profiles")
    if not isinstance(profiles, dict) or set(("LOW", "MID", "HIGH")) - profiles.keys():
        raise ValueError("posture calibration must contain LOW, MID, and HIGH profiles")
    for name in ("LOW", "MID", "HIGH"):
        profile = profiles[name]
        q = profile.get("joint_position_rad")
        if not isinstance(q, list) or len(q) != len(TITA_JOINT_NAMES):
            raise ValueError(f"{name} joint_position_rad must contain 8 values")
        if float(profile.get("command_height_m", 0.0)) <= 0.0:
            raise ValueError(f"{name} command_height_m must be positive")
    return payload


def posture_anchors(payload: dict[str, Any]) -> tuple[tuple[float, ...], ...]:
    """Return leg posture anchors while keeping wheel targets at the simulator default (zero)."""
    wheel_indices = set(int(index) for index in payload.get("wheel_joint_indices", (3, 7)))
    anchors = []
    for name in ("LOW", "MID", "HIGH"):
        q = [float(value) for value in payload["profiles"][name]["joint_position_rad"]]
        for index in wheel_indices:
            q[index] = 0.0
        anchors.append(tuple(q))
    return tuple(anchors)

