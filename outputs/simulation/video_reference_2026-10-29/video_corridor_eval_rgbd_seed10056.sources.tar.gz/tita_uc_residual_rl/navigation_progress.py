from dataclasses import dataclass
import math


@dataclass
class NavigationProgressGuard:
    maximum_wait_s: float = 60.
    minimum_progress_m: float = .05
    reference_distance_m: float | None = None
    last_progress_s: float | None = None
    last_observation_s: float | None = None

    def __post_init__(self):
        if not math.isfinite(self.maximum_wait_s) or not math.isfinite(self.minimum_progress_m) or min(self.maximum_wait_s, self.minimum_progress_m) <= 0.:
            raise ValueError("navigation progress limits must be finite and positive")

    def observe(self, time_s: float, goal_distance_m: float) -> bool:
        if (not math.isfinite(time_s) or not math.isfinite(goal_distance_m) or goal_distance_m < 0.
                or self.last_observation_s is not None and time_s < self.last_observation_s):
            raise ValueError("navigation progress feedback must be finite, nonnegative and monotonic")
        self.last_observation_s = time_s
        if self.reference_distance_m is None or self.reference_distance_m - goal_distance_m >= self.minimum_progress_m:
            self.reference_distance_m = goal_distance_m
            self.last_progress_s = time_s
        return time_s - self.last_progress_s >= self.maximum_wait_s
