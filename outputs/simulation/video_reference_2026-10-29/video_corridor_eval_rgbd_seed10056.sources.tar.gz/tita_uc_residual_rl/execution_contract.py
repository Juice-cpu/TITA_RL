from __future__ import annotations


def residual_training_scope(payload):
    configuration = payload.get("training_config", {})
    fixed = configuration.get("fixed_posture") or payload.get("training_args", {}).get("fixed_posture")
    if fixed:
        scope = [fixed]
    elif configuration.get("posture_curriculum", {}).get("enabled") or payload.get("training_args", {}).get("posture_curriculum"):
        curriculum = configuration.get("posture_curriculum", {})
        scope = (["MID"] if curriculum.get("mid_only_fraction", 0.) >= 1.
                 else ["LOW", "MID"] if curriculum.get("low_mid_fraction", 0.) >= 1. else ["LOW", "MID", "HIGH"])
    else:
        scope = payload.get("execution_config", {}).get("residual_postures", ["LOW"])
    if not scope or any(name not in ("LOW", "MID", "HIGH") for name in scope):
        raise ValueError("invalid residual execution scope")
    return list(scope)


def validate_high_specialist(base_execution, specialist_payload):
    if residual_training_scope(specialist_payload) != ["HIGH"]:
        raise ValueError("the HIGH specialist must have an explicit HIGH-only training scope")
    execution = specialist_payload.get("execution_config", {})
    for name in ("asset_sha256", "official_checkpoint_sha256", "posture_joint_anchors", "posture_heights",
                 "residual_filter_alpha", "acceleration_limit", "enforce_acceleration_limit", "velocity_calibration_prior"):
        if name not in execution or name not in base_execution or execution[name] != base_execution[name]:
            raise ValueError(f"HIGH specialist execution {name} mismatch")
    return execution
