from dataclasses import dataclass
import math

import numpy as np


@dataclass(frozen=True)
class PathHeadingGuardConfig:
    enter_error_rad: float = .45
    release_error_rad: float = .15
    stopped_speed_mps: float = .025
    turn_speed_alarm_mps: float = .06

    def __post_init__(self):
        values = (self.enter_error_rad, self.release_error_rad, self.stopped_speed_mps, self.turn_speed_alarm_mps)
        if (not all(math.isfinite(value) for value in values) or min(values) <= 0.
                or not self.release_error_rad < self.enter_error_rad < math.pi
                or self.turn_speed_alarm_mps <= self.stopped_speed_mps):
            raise ValueError('heading guard requires finite positive hysteresis and stopped-speed bounds')


class PathHeadingGuard:
    def __init__(self, config=None):
        self.config = config or PathHeadingGuardConfig()
        self.active = False
        self.turn_started = False
        self.last_status = {'phase': 'not_observed', 'active': False}

    def reset(self):
        self.active = False
        self.turn_started = False
        self.last_status = {'phase': 'reset', 'active': False}

    def apply(self, pose, path, vendor_command, measured_speed_mps, recovery_geometry, reference_heading_rad=None):
        command = np.asarray(vendor_command, dtype=float)
        if (command.shape != (2,) or not np.isfinite(command).all()
                or not all(math.isfinite(value) for value in (pose.x, pose.y, pose.yaw, measured_speed_mps))
                or measured_speed_mps < 0.):
            raise ValueError('heading guard requires finite vendor command and measured feedback')
        if reference_heading_rad is not None and not math.isfinite(reference_heading_rad):
            raise ValueError('heading guard requires a finite vendor reference heading')
        if path is None or recovery_geometry is None or reference_heading_rad is None:
            self.active = False
            self.turn_started = False
            self.last_status = {'phase': 'unavailable_vendor_reference_geometry_or_path', 'active': False}
            return command.tolist()
        circle_clear = recovery_geometry.segment_safe((pose.x, pose.y), (pose.x, pose.y))
        error = math.atan2(math.sin(reference_heading_rad - pose.yaw), math.cos(reference_heading_rad - pose.yaw))
        if not circle_clear:
            self.active = True
            self.turn_started = False
            result, phase = [0., 0.], 'uncertified_turn_volume_stop'
        else:
            if self.active and abs(error) <= self.config.release_error_rad:
                self.active = False
                self.turn_started = False
            elif not self.active and abs(error) >= self.config.enter_error_rad:
                self.active = True
                self.turn_started = False
            if self.active:
                if self.turn_started and measured_speed_mps > self.config.turn_speed_alarm_mps:
                    self.turn_started = False
                    result, phase = [0., 0.], 'turn_translation_alarm_braking'
                elif self.turn_started or measured_speed_mps <= self.config.stopped_speed_mps:
                    self.turn_started = True
                    result, phase = [0., float(command[1])], 'vendor_turn_in_place'
                else:
                    result, phase = [0., 0.], 'braking_before_turn'
            else:
                result, phase = command.tolist(), 'tracking'
        self.last_status = {'phase': phase, 'active': self.active, 'heading_error_rad': error,
                            'turn_started_after_observed_stop': self.turn_started,
                            'turn_translation_alarm_mps': self.config.turn_speed_alarm_mps,
                            'vendor_reference_heading_rad': reference_heading_rad, 'continuous_turn_volume_clear': circle_clear,
                            'vendor_yaw_never_replaced': True, 'forward_speed_only_suppressed': True}
        return result
