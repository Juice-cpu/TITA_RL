"""Online joint navigation core for the biped TITA upper-level policy.

The module is deliberately simulator independent.  It owns the contract that
Isaac/ROS adapters must satisfy: A* produces versioned candidate paths,
geometry masks unsafe posture choices, a pedestrian predictor supplies point
velocities to NeuPAN, and the policy selects an independent
``path x posture x speed`` action.  When the vendor NeuPAN dependencies are
not installed, the controller uses a deterministic pure-pursuit fallback and
marks the run as ``fallback`` rather than pretending that NeuPAN was executed.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
import heapq
import json
import math
import os
from pathlib import Path
import sys
import time
import types
from typing import Iterable, Sequence

import numpy as np

from .navigation_formula import decode_action, encode_action
from .grid_path_geometry import polyline_cells, simplify_free_polyline
from .mode_transition_calibration import DEFAULT_TRANSITION_COSTS_S, transition_cost_matrix
from .start_recovery import ContinuousRecoveryGeometry, StartRecoveryConnector, path_sample_free, recovery_anchors


POSTURES = ("LOW", "MID", "HIGH")
SPEEDS = (0.4, 0.7, 1.0)
ACTION_COUNT_PER_PATH = 9


def _clip(value: float, low: float, high: float) -> float:
    return float(np.clip(float(value), low, high))


def _angle_wrap(value: float) -> float:
    return math.atan2(math.sin(value), math.cos(value))


@dataclass(frozen=True)
class Pose2D:
    x: float
    y: float
    yaw: float = 0.0


@dataclass(frozen=True)
class Pedestrian:
    x: float
    y: float
    vx: float
    vy: float
    radius_m: float = 0.30

    def __post_init__(self) -> None:
        if not all(math.isfinite(value) for value in (self.x, self.y, self.vx, self.vy, self.radius_m)) or self.radius_m < 0.0:
            raise ValueError("pedestrian state must be finite with a non-negative radius")


def pedestrian_obstacle_points(pedestrians: Sequence[Pedestrian], samples: int = 16) -> tuple[np.ndarray, np.ndarray]:
    if samples < 3:
        raise ValueError("pedestrian boundary requires at least three samples")
    angles = np.linspace(0.0, 2.0 * math.pi, samples, endpoint=False)
    directions = np.column_stack((np.cos(angles), np.sin(angles)))
    points, velocities = [], []
    for person in pedestrians:
        points.extend(np.asarray((person.x, person.y)) + person.radius_m * directions)
        velocities.extend([(person.vx, person.vy)] * samples)
    return np.asarray(points, dtype=float).reshape(-1, 2), np.asarray(velocities, dtype=float).reshape(-1, 2)


def fused_navigation_obstacles(pedestrians, observed_points=None, observed_velocities=None):
    boundaries, boundary_velocities = pedestrian_obstacle_points(pedestrians)
    if observed_points is None:
        if observed_velocities is not None:
            raise ValueError('obstacle velocities require observed points')
        return boundaries, boundary_velocities
    points = np.asarray(observed_points, dtype=float)
    velocities = np.zeros_like(points) if observed_velocities is None else np.asarray(observed_velocities, dtype=float)
    if (points.ndim != 2 or points.shape[1] != 2 or velocities.shape != points.shape
            or not np.isfinite(points).all() or not np.isfinite(velocities).all()):
        raise ValueError('navigation obstacle points and velocities must be finite aligned planar arrays')
    return np.vstack((boundaries, points)), np.vstack((boundary_velocities, velocities))


def nominal_pedestrian_clearance(pose: Pose2D, vertices_xy_m: np.ndarray, pedestrians: Sequence[Pedestrian]) -> float:
    if not pedestrians:
        return float("inf")
    vertices = np.asarray(vertices_xy_m, dtype=float)
    if vertices.ndim != 2 or vertices.shape[1] != 2 or len(vertices) < 3 or not np.isfinite(vertices).all():
        raise ValueError("nominal footprint must be a finite polygon")
    following = np.roll(vertices, -1, axis=0)
    segments = following - vertices
    lengths = np.sum(segments * segments, axis=1)
    if np.any(lengths <= 0.0):
        raise ValueError("nominal footprint cannot contain zero-length edges")
    clearance = float("inf")
    cosine, sine = math.cos(pose.yaw), math.sin(pose.yaw)
    for person in pedestrians:
        delta = np.asarray((person.x - pose.x, person.y - pose.y))
        point = np.asarray((cosine * delta[0] + sine * delta[1], -sine * delta[0] + cosine * delta[1]))
        fractions = np.clip(np.sum((point - vertices) * segments, axis=1) / lengths, 0.0, 1.0)
        distance = float(np.linalg.norm(point - (vertices + fractions[:, None] * segments), axis=1).min())
        crossing = (vertices[:, 1] > point[1]) != (following[:, 1] > point[1])
        crossing_indices = np.flatnonzero(crossing)
        intersections = vertices[crossing_indices, 0] + (
            (point[1] - vertices[crossing_indices, 1]) * segments[crossing_indices, 0]
            / segments[crossing_indices, 1]
        )
        inside = bool(np.count_nonzero(point[0] < intersections) % 2)
        clearance = min(clearance, (-distance if inside else distance) - person.radius_m)
    return clearance


@dataclass(frozen=True)
class PostureSpec:
    name: str
    body_height_m: float
    base_clearance_m: float
    max_step_m: float
    vmax_mps: float
    allowed_speeds_mps: tuple[float, ...] = ()

    def supports_speed(self, speed_mps):
        return (0. < speed_mps <= self.vmax_mps + 1e-6
                and (not self.allowed_speeds_mps or any(abs(speed_mps - allowed) < 1e-6 for allowed in self.allowed_speeds_mps)))


POSTURE_SPECS = (
    PostureSpec("LOW", 0.68, 0.08, 0.03, 0.55),
    PostureSpec("MID", 0.94, 0.14, 0.08, 0.85),
    PostureSpec("HIGH", 1.18, 0.22, 0.18, 1.10),
)


@dataclass(frozen=True)
class GridScene:
    """Static occupancy and terrain geometry on a square grid."""

    occupancy: np.ndarray
    ceiling_height_m: np.ndarray
    step_height_m: np.ndarray
    resolution_m: float = 0.5
    origin_xy: tuple[float, float] = (0.0, 0.0)
    recovery_geometry: ContinuousRecoveryGeometry | None = None

    def __post_init__(self) -> None:
        occupancy = np.asarray(self.occupancy, dtype=bool)
        ceiling = np.asarray(self.ceiling_height_m, dtype=float)
        step = np.asarray(self.step_height_m, dtype=float)
        if occupancy.ndim != 2 or ceiling.shape != occupancy.shape or step.shape != occupancy.shape:
            raise ValueError("scene layers must be 2-D arrays with identical shapes")
        if self.resolution_m <= 0.0 or not np.isfinite(ceiling).all() or not np.isfinite(step).all():
            raise ValueError("invalid scene geometry")
        if self.recovery_geometry is not None and not np.array_equal(occupancy,
                self.recovery_geometry.occupancy_for(occupancy.shape, self.resolution_m, self.origin_xy)):
            raise ValueError('continuous recovery geometry must explain every occupied and free raster cell')
        occupancy.setflags(write=False); ceiling.setflags(write=False); step.setflags(write=False)
        object.__setattr__(self, "occupancy", occupancy)
        object.__setattr__(self, "ceiling_height_m", ceiling)
        object.__setattr__(self, "step_height_m", step)

    @property
    def shape(self) -> tuple[int, int]:
        return tuple(self.occupancy.shape)  # type: ignore[return-value]

    def world_to_cell(self, point: Sequence[float]) -> tuple[int, int]:
        x = int(math.floor((float(point[0]) - self.origin_xy[0]) / self.resolution_m))
        y = int(math.floor((float(point[1]) - self.origin_xy[1]) / self.resolution_m))
        return x, y

    def cell_to_world(self, cell: tuple[int, int]) -> tuple[float, float]:
        return (
            self.origin_xy[0] + (cell[0] + 0.5) * self.resolution_m,
            self.origin_xy[1] + (cell[1] + 0.5) * self.resolution_m,
        )

    def in_bounds(self, cell: tuple[int, int]) -> bool:
        return 0 <= cell[0] < self.shape[1] and 0 <= cell[1] < self.shape[0]


@dataclass(frozen=True)
class PathCandidate:
    path_id: str
    points_xy_m: np.ndarray
    length_m: float
    path_version: int
    risk_weight: float
    continuous_geometry: bool = False
    start_recovery: StartRecoveryConnector | None = None
    continuation_of_path_id: str | None = None

    def __post_init__(self) -> None:
        points = np.asarray(self.points_xy_m, dtype=float)
        if points.ndim != 2 or points.shape[1] != 2 or len(points) < 2 or not np.isfinite(points).all():
            raise ValueError("path points must have shape (N, 2)")
        points.setflags(write=False)
        object.__setattr__(self, "points_xy_m", points)


@dataclass(frozen=True)
class AStarConfig:
    candidate_count: int = 3
    diagonal: bool = False
    clearance_weight: float = 0.18
    path_separation_penalty: float = 2.0
    diverse_routes: bool = False
    route_separation_radius_m: float = .5
    simplify_paths: bool = False
    dynamic_cost_weight: float = 20.
    dynamic_horizon_s: float = 8.
    dynamic_robot_radius_m: float = .6
    start_recovery_distance_m: float = .5
    observed_shuttle_cost: bool = False

    def __post_init__(self) -> None:
        if not isinstance(self.observed_shuttle_cost, bool):
            raise ValueError('observed shuttle A* cost gate must be boolean')
        if (not np.isfinite([self.dynamic_cost_weight, self.dynamic_horizon_s, self.dynamic_robot_radius_m]).all()
                or self.dynamic_cost_weight < 0. or min(self.dynamic_horizon_s, self.dynamic_robot_radius_m) <= 0.):
            raise ValueError("dynamic A* planning requires finite nonnegative costs and positive dimensions")
        if self.candidate_count < 1 or not math.isfinite(self.clearance_weight) or self.clearance_weight < 0.:
            raise ValueError("A* requires positive candidate count and finite nonnegative clearance weight")
        if not math.isfinite(self.start_recovery_distance_m) or self.start_recovery_distance_m < 0.:
            raise ValueError('A* recovery distance must be finite and nonnegative')
        if (not math.isfinite(self.path_separation_penalty) or self.path_separation_penalty < 0.
                or not math.isfinite(self.route_separation_radius_m) or self.route_separation_radius_m < 0.):
            raise ValueError("A* route diversity requires finite nonnegative separation costs and radius")


class AStarPlanner:
    """Grid A* with deterministic alternatives and monotonically increasing versions."""

    def __init__(self, config: AStarConfig | None = None) -> None:
        self.config = config or AStarConfig()
        self.replan_id = 0

    def _neighbors(self, cell: tuple[int, int]) -> Iterable[tuple[tuple[int, int], float]]:
        steps = ((1, 0), (-1, 0), (0, 1), (0, -1))
        if self.config.diagonal:
            steps += ((1, 1), (1, -1), (-1, 1), (-1, -1))
        for dx, dy in steps:
            yield (cell[0] + dx, cell[1] + dy), math.hypot(dx, dy)

    def _astar(
        self,
        scene: GridScene,
        start: tuple[int, int],
        goal: tuple[int, int],
        blocked: set[tuple[int, int]],
        risk_weight: float,
        clearance_cost: np.ndarray,
        separation_cost: np.ndarray,
    ) -> list[tuple[int, int]]:
        queue: list[tuple[float, int, tuple[int, int]]] = [(0.0, 0, start)]
        came: dict[tuple[int, int], tuple[int, int]] = {}
        cost = {start: 0.0}
        serial = 0
        while queue:
            _, _, current = heapq.heappop(queue)
            if current == goal:
                cells = [current]
                while current in came:
                    current = came[current]; cells.append(current)
                return list(reversed(cells))
            for nxt, step_cost in self._neighbors(current):
                if not scene.in_bounds(nxt) or scene.occupancy[nxt[1], nxt[0]] or nxt in blocked:
                    continue
                if nxt[0] != current[0] and nxt[1] != current[1]:
                    corners = ((nxt[0], current[1]), (current[0], nxt[1]))
                    if any(scene.occupancy[corner[1], corner[0]] or corner in blocked for corner in corners):
                        continue
                local = max(0.0, 1.0 - scene.ceiling_height_m[nxt[1], nxt[0]] / 2.0)
                new_cost = cost[current] + step_cost * (1.0 + risk_weight * local + clearance_cost[nxt[1], nxt[0]] + separation_cost[nxt[1], nxt[0]])
                if new_cost < cost.get(nxt, float("inf")):
                    cost[nxt] = new_cost
                    came[nxt] = current
                    serial += 1
                    heuristic = math.hypot(goal[0] - nxt[0], goal[1] - nxt[1])
                    heapq.heappush(queue, (new_cost + heuristic, serial, nxt))
        return []

    def _clearance_cost(self, scene: GridScene) -> np.ndarray:
        distance_cells = np.where(scene.occupancy, 0., np.inf)
        for axis in (0, 1):
            coordinates = np.arange(scene.shape[axis], dtype=float)
            coordinates = coordinates[:, None] if axis == 0 else coordinates[None, :]
            forward = np.minimum.accumulate(distance_cells - coordinates, axis=axis) + coordinates
            backward = np.flip(np.minimum.accumulate(np.flip(distance_cells + coordinates, axis=axis), axis=axis), axis=axis) - coordinates
            distance_cells = np.minimum(forward, backward)
        return self.config.clearance_weight / np.maximum(distance_cells * scene.resolution_m, scene.resolution_m)

    @staticmethod
    def _is_pathological_start_detour(points: np.ndarray, start_xy_m: Sequence[float], goal_xy_m: Sequence[float], length_m: float) -> bool:
        direct = np.asarray(goal_xy_m, dtype=float) - np.asarray(start_xy_m, dtype=float)
        direct_length = float(np.linalg.norm(direct))
        if direct_length <= 1e-9 or length_m <= max(1.75 * direct_length, direct_length + 1.0):
            return False
        direction = direct / direct_length
        for delta in np.diff(np.asarray(points, dtype=float), axis=0):
            segment_length = float(np.linalg.norm(delta))
            if segment_length > 1e-9:
                return float(np.dot(delta / segment_length, direction)) < 0.25
        return False

    def plan_candidates(
        self,
        scene: GridScene,
        start_xy_m: Sequence[float],
        goal_xy_m: Sequence[float],
        posture_specs: Sequence[PostureSpec] | None = None,
        navigation_cost: np.ndarray | None = None,
        start_yaw_rad: float | None = None,
    ) -> tuple[PathCandidate, ...]:
        start = scene.world_to_cell(start_xy_m); goal = scene.world_to_cell(goal_xy_m)
        if not scene.in_bounds(start) or not scene.in_bounds(goal):
            return tuple()
        if scene.occupancy[goal[1], goal[0]]:
            return tuple()
        if scene.occupancy[start[1], start[0]]:
            for anchor in recovery_anchors(scene, start_xy_m, self.config.start_recovery_distance_m, start_yaw_rad)[:8]:
                suffixes = self.plan_candidates(scene, anchor, goal_xy_m, posture_specs, navigation_cost)
                if not suffixes:
                    continue
                connector = StartRecoveryConnector(tuple(start_xy_m), tuple(anchor))
                prefix_length = float(np.linalg.norm(np.subtract(anchor, start_xy_m)))
                return tuple(PathCandidate(f'{path.path_id}-certified-start', np.vstack((start_xy_m, path.points_xy_m)),
                    path.length_m + prefix_length, path.path_version, path.risk_weight, True, connector) for path in suffixes)
            return tuple()
        self.replan_id += 1
        paths: list[PathCandidate] = []
        blocked: set[tuple[int, int]] = set()
        clearance_cost = self._clearance_cost(scene)
        if navigation_cost is not None:
            navigation_cost = np.asarray(navigation_cost, dtype=float)
            if navigation_cost.shape != scene.shape or not np.isfinite(navigation_cost).all() or (navigation_cost < 0.).any():
                raise ValueError("navigation cost must be aligned, finite and nonnegative")
            clearance_cost = clearance_cost + navigation_cost
        separation_cost = np.zeros(scene.shape)
        signatures = set()
        deferred_paths: list[PathCandidate] = []
        if self.config.diverse_routes and posture_specs is not None:
            for specification in posture_specs:
                unavailable = (scene.ceiling_height_m < specification.body_height_m + .04) | (scene.step_height_m > specification.max_step_m + 1e-6)
                if unavailable[start[1], start[0]] or unavailable[goal[1], goal[0]]:
                    continue
                forbidden = set(zip(*np.nonzero(unavailable)[::-1]))
                cells = self._astar(scene, start, goal, forbidden, .2, clearance_cost, np.zeros(scene.shape))
                if not cells or tuple(cells) in signatures:
                    continue
                signatures.add(tuple(cells))
                points = np.asarray([scene.cell_to_world(cell) for cell in cells], dtype=float)
                if self.config.simplify_paths:
                    points = simplify_free_polyline(scene, points, unavailable, traversal_cost=navigation_cost)
                length = float(np.linalg.norm(np.diff(points, axis=0), axis=1).sum())
                candidate = PathCandidate(f"astar-{self.replan_id}-mode-{specification.name}", points, length, self.replan_id, .2, self.config.simplify_paths)
                if self._is_pathological_start_detour(points, start_xy_m, goal_xy_m, length):
                    deferred_paths.append(candidate)
                else:
                    paths.append(candidate)
                separation_cost += self._route_overlap_band(scene, cells) * self.config.path_separation_penalty
                if len(paths) >= self.config.candidate_count:
                    return tuple(paths)
        for index in range(self.config.candidate_count):
            if len(paths) >= self.config.candidate_count:
                break
            cells = self._astar(scene, start, goal, blocked, 0.2 + index * 0.9, clearance_cost, separation_cost)
            if not cells:
                continue
            signature = tuple(cells)
            if self.config.diverse_routes and signature in signatures:
                continue
            signatures.add(signature)
            points = np.asarray([scene.cell_to_world(cell) for cell in cells], dtype=float)
            if self.config.simplify_paths:
                points = simplify_free_polyline(scene, points, traversal_cost=navigation_cost)
            if self.config.diverse_routes:
                separation_cost += self._route_overlap_band(scene, cells) * self.config.path_separation_penalty
            elif len(points) > 2:
                # Keep a stable set of alternatives without introducing a
                # geometry-changing smoothing step.
                blocked.update(cells[1:-1:index + 2])
            length = float(np.linalg.norm(np.diff(points, axis=0), axis=1).sum())
            candidate = PathCandidate(f"astar-{self.replan_id}-{index}", points, length, self.replan_id, 0.2 + index * 0.9, self.config.simplify_paths)
            if self._is_pathological_start_detour(points, start_xy_m, goal_xy_m, length):
                deferred_paths.append(candidate)
            else:
                paths.append(candidate)
        for candidate in sorted(deferred_paths, key=lambda path: path.length_m):
            if len(paths) >= self.config.candidate_count:
                break
            paths.append(candidate)
        return tuple(paths)

    def _route_overlap_band(self, scene, cells):
        band = np.zeros(scene.shape, dtype=bool)
        radius_cells = int(math.ceil(self.config.route_separation_radius_m / scene.resolution_m))
        for horizontal, vertical in cells[1:-1]:
            lower_horizontal, upper_horizontal = max(0, horizontal - radius_cells), min(scene.shape[1], horizontal + radius_cells + 1)
            lower_vertical, upper_vertical = max(0, vertical - radius_cells), min(scene.shape[0], vertical + radius_cells + 1)
            delta_horizontal = np.arange(lower_horizontal, upper_horizontal) - horizontal
            delta_vertical = np.arange(lower_vertical, upper_vertical) - vertical
            band[lower_vertical:upper_vertical, lower_horizontal:upper_horizontal] |= (
                delta_vertical[:, None] ** 2 + delta_horizontal[None, :] ** 2
                <= (self.config.route_separation_radius_m / scene.resolution_m) ** 2)
        return band


@dataclass(frozen=True)
class PedestrianPrediction:
    points_xy_m: np.ndarray
    velocities_xy_mps: np.ndarray
    min_distance_m: float
    collision_probability: float


class PedestrianPredictor:
    def __init__(self, horizon_s: float = 2.0, samples: int = 10, sigma_m: float = 0.55) -> None:
        self.horizon_s = horizon_s; self.samples = samples; self.sigma_m = sigma_m

    def predict(self, pedestrians: Sequence[Pedestrian]) -> PedestrianPrediction:
        if not pedestrians:
            return PedestrianPrediction(np.empty((0, 2)), np.empty((0, 2)), float("inf"), 0.0)
        times = np.linspace(0.0, self.horizon_s, self.samples)
        points, velocities = [], []
        for person in pedestrians:
            for t in times:
                points.append((person.x + person.vx * t, person.y + person.vy * t))
                velocities.append((person.vx, person.vy))
        return PedestrianPrediction(np.asarray(points), np.asarray(velocities), float("inf"), 0.0)

    def risk_for_path(self, path: PathCandidate, pedestrians: Sequence[Pedestrian]) -> PedestrianPrediction:
        prediction = self.predict(pedestrians)
        if len(prediction.points_xy_m) == 0:
            return prediction
        distances = np.linalg.norm(prediction.points_xy_m[:, None, :] - path.points_xy_m[None, :, :], axis=2)
        radii = np.repeat([person.radius_m for person in pedestrians], self.samples)
        min_distance = float(np.maximum(distances - radii[:, None], 0.0).min())
        risk = float(np.exp(-0.5 * (min_distance / self.sigma_m) ** 2))
        return PedestrianPrediction(prediction.points_xy_m, prediction.velocities_xy_mps, min_distance, _clip(risk, 0.0, 1.0))

    def timed_risk_for_path(self, path: PathCandidate, pedestrians: Sequence[Pedestrian], speed_mps: float,
                            horizon_s: float = 5.0, robot_radius_m: float = .5, start_delay_s: float = 0.,
                            pedestrian_motion_context=(), stationary_restart=False,
                            stationary_speed_threshold_mps=.05, restart_speed_margin_mps=.05,
                            moving_speed_envelope=False, observed_shuttle_prediction=False) -> float:
        if (not all(math.isfinite(value) for value in (speed_mps, horizon_s, robot_radius_m, start_delay_s))
                or min(speed_mps, robot_radius_m, start_delay_s) < 0. or horizon_s <= 0.):
            raise ValueError('timed pedestrian risk requires finite nonnegative dynamics and a positive horizon')
        if pedestrian_motion_context and len(pedestrian_motion_context) != len(pedestrians):
            raise ValueError('restart prediction history must align with observed pedestrians')
        if not pedestrians:
            return 0.0
        points = np.asarray(path.points_xy_m, dtype=float)
        if points.ndim != 2 or points.shape[1] != 2 or not len(points) or not np.isfinite(points).all():
            raise ValueError('timed pedestrian risk requires a finite nonempty planar path')
        points = points[np.r_[True, np.linalg.norm(np.diff(points, axis=0), axis=1) > 0.]]
        lengths = np.r_[0., np.cumsum(np.linalg.norm(np.diff(points, axis=0), axis=1))]
        corners = start_delay_s + lengths / speed_mps if speed_mps > 0. else np.empty(0)
        times = np.unique(np.r_[0., horizon_s, np.clip(corners, 0., horizon_s)])
        distances = np.maximum(times - start_delay_s, 0.) * speed_mps
        robot = np.column_stack([np.interp(distances, lengths, points[:, axis]) for axis in range(2)])
        clearance = float('inf')
        for person_index, person in enumerate(pedestrians):
            context = pedestrian_motion_context[person_index] if pedestrian_motion_context else None
            forecast = getattr(context, 'shuttle_prediction', None)
            if observed_shuttle_prediction and forecast is not None:
                from .observed_shuttle_prediction import observed_shuttle_minimum_distance
                if np.linalg.norm(np.asarray(forecast['points_xy_m'][0]) - np.asarray([person.x, person.y])) > .05:
                    raise ValueError('observed shuttle forecast is not anchored to the current measured pedestrian')
                distance = observed_shuttle_minimum_distance(times, robot, forecast)
                if distance is not None:
                    clearance = min(clearance, distance - person.radius_m - robot_radius_m)
                    continue
            if stationary_restart or moving_speed_envelope:
                from .pedestrian_restart_risk import minimum_restart_tube_distance, observed_moving_velocity_segment, observed_restart_velocity
                context = pedestrian_motion_context[person_index] if pedestrian_motion_context else None
                restart_velocity = observed_restart_velocity(person, context, stationary_speed_threshold_mps, restart_speed_margin_mps) if stationary_restart else None
                segment = (np.asarray([person.vx, person.vy]), restart_velocity) if restart_velocity is not None else None
                if segment is None and moving_speed_envelope:
                    segment = observed_moving_velocity_segment(person, context, stationary_speed_threshold_mps, restart_speed_margin_mps)
                if segment is not None:
                    distance = minimum_restart_tube_distance(times, robot, (person.x, person.y),
                        segment[0], segment[1])
                    clearance = min(clearance, distance - person.radius_m - robot_radius_m)
                    continue
            relative = robot - np.column_stack((person.x + person.vx * times, person.y + person.vy * times))
            relative_delta = np.diff(relative, axis=0)
            squared_motion = np.einsum('ij,ij->i', relative_delta, relative_delta)
            fraction = np.divide(-np.einsum('ij,ij->i', relative[:-1], relative_delta), squared_motion,
                                 out=np.zeros_like(squared_motion), where=squared_motion > 0.)
            closest = relative[:-1] + np.clip(fraction, 0., 1.)[:, None] * relative_delta
            clearance = min(clearance, float(np.linalg.norm(closest, axis=1).min()) - person.radius_m - robot_radius_m)
        return math.exp(-.5 * (max(clearance, 0.) / .35) ** 2)

    def transition_risk_for_path(self, path: PathCandidate, pedestrians: Sequence[Pedestrian], speed_mps: float,
                                 maximum_delay_s: float, robot_radius_m: float = .5,
                                 pedestrian_motion_context=(), stationary_restart=False,
                                 stationary_speed_threshold_mps=.05, restart_speed_margin_mps=.05,
                                 moving_speed_envelope=False, observed_shuttle_prediction=False,
                                 minimum_delay_s=0.) -> float:
        if (not all(math.isfinite(value) for value in (speed_mps, maximum_delay_s, robot_radius_m, minimum_delay_s))
                or min(speed_mps, maximum_delay_s, robot_radius_m, minimum_delay_s) < 0.
                or minimum_delay_s > maximum_delay_s):
            raise ValueError('transition prediction requires finite nonnegative dynamics and delay bound')
        if not pedestrians:
            return 0.
        intervals = max(1, int(math.ceil((maximum_delay_s - minimum_delay_s) / .5)))
        inflation = speed_mps * (maximum_delay_s - minimum_delay_s) / (2. * intervals)
        return max(self.timed_risk_for_path(path, pedestrians, speed_mps,
                   horizon_s=max(5., maximum_delay_s + 3.), robot_radius_m=robot_radius_m + inflation,
                   start_delay_s=float(delay), pedestrian_motion_context=pedestrian_motion_context,
                   stationary_restart=stationary_restart, stationary_speed_threshold_mps=stationary_speed_threshold_mps,
                   restart_speed_margin_mps=restart_speed_margin_mps,
                   moving_speed_envelope=moving_speed_envelope,
                   observed_shuttle_prediction=observed_shuttle_prediction) for delay in np.linspace(minimum_delay_s, maximum_delay_s, intervals + 1))


@dataclass(frozen=True)
class JointDecision:
    valid: bool
    action_id: int = -1
    path_index: int = -1
    posture_index: int = -1
    speed_index: int = -1
    path_id: str = ""
    posture: str = ""
    speed_ratio: float = 0.0
    reason: str = ""


@dataclass(frozen=True)
class JointObservation:
    paths: tuple[PathCandidate, ...]
    valid_actions: np.ndarray
    current_posture: int
    current_speed_mps: float
    pedestrian_risk: float
    terrain_mode: int
    replan_id: int
    action_features: np.ndarray | None = None


@dataclass(frozen=True)
class JointSafetyConfig:
    switch_speed_max_mps: float = 0.20
    switch_attitude_max_rad: float = 0.12
    switch_hold_s: float = 0.20
    min_path_clearance_m: float = 0.18
    dynamic_risk_stop: float = 0.97
    geometry_lookahead_m: float = float("inf")
    timed_dynamic_safety: bool = False
    staged_mode_switches: bool = False
    transition_position_margin_m: float = 0.
    expected_transition_costs_s: tuple = DEFAULT_TRANSITION_COSTS_S
    braking_decelerations_mps2: tuple = (.30, .30, .30)
    braking_filter_times_s: tuple = (0., 0., 0.)
    braking_reaction_time_s: float = .30
    braking_residual_speed_mps: float = .005
    stationary_restart_prediction: bool = False
    moving_speed_prediction: bool = False
    observed_shuttle_prediction: bool = False
    minimum_mode_motion_hold_s: float = 0.
    execution_timing_prediction: bool = False
    risk_priced_wait: bool = False
    stationary_speed_threshold_mps: float = .05
    restart_speed_margin_mps: float = .05
    wait_risk_horizon_s: float = 5.

    def __post_init__(self):
        transition_cost_matrix(self.expected_transition_costs_s)
        if not math.isfinite(self.wait_risk_horizon_s) or self.wait_risk_horizon_s < 5.:
            raise ValueError('wait risk horizon must be finite and at least five seconds')
        if not math.isfinite(self.minimum_mode_motion_hold_s) or self.minimum_mode_motion_hold_s < 0.:
            raise ValueError('minimum mode motion hold must be finite and nonnegative')
        if (not math.isfinite(self.stationary_speed_threshold_mps) or self.stationary_speed_threshold_mps <= 0.
                or not math.isfinite(self.restart_speed_margin_mps) or self.restart_speed_margin_mps < 0.):
            raise ValueError('stationary restart prediction requires valid speed threshold and margin')
        if not math.isfinite(self.transition_position_margin_m) or self.transition_position_margin_m < 0.:
            raise ValueError("mode transition position margin must be finite and nonnegative")
        decelerations = np.asarray(self.braking_decelerations_mps2, dtype=float)
        filters = np.asarray(self.braking_filter_times_s, dtype=float)
        if (decelerations.shape != (3,) or filters.shape != (3,)
                or not np.isfinite([decelerations, filters]).all()
                or (decelerations <= 0.).any() or (filters < 0.).any()
                or not math.isfinite(self.braking_reaction_time_s) or self.braking_reaction_time_s < 0.
                or not math.isfinite(self.braking_residual_speed_mps) or self.braking_residual_speed_mps <= 0.):
            raise ValueError('braking model requires three positive decelerations, nonnegative filters and valid reaction/settling bounds')

    def braking_horizon_s(self, posture_index, measured_speed_mps):
        if posture_index not in range(3) or not math.isfinite(measured_speed_mps) or measured_speed_mps < 0.:
            raise ValueError('braking horizon requires a valid current posture and nonnegative finite speed')
        filter_tail = self.braking_filter_times_s[posture_index] * math.log(max(1., measured_speed_mps / self.braking_residual_speed_mps))
        return self.braking_reaction_time_s + measured_speed_mps / self.braking_decelerations_mps2[posture_index] + filter_tail


    def command_settling_delay_s(self, posture_index, measured_speed_mps, target_speed_mps):
        if (posture_index not in range(3) or not np.isfinite([measured_speed_mps, target_speed_mps]).all()
                or min(measured_speed_mps, target_speed_mps) < 0.):
            raise ValueError('command settling requires valid mode and nonnegative finite speeds')
        error = abs(target_speed_mps - measured_speed_mps)
        if error <= self.braking_residual_speed_mps:
            return 0.
        return self.braking_horizon_s(posture_index, error)


def transition_mode_feasible(scene, position_xy, specification, position_margin_m):
    position = np.asarray(position_xy, dtype=float)
    if position.shape != (2,) or not np.isfinite(position).all() or not math.isfinite(position_margin_m) or position_margin_m < 0.:
        raise ValueError("mode transition feasibility needs finite position and nonnegative margin")
    center = scene.world_to_cell(position)
    radius_cells = int(math.ceil(position_margin_m / scene.resolution_m)) + 1
    for horizontal in range(center[0] - radius_cells, center[0] + radius_cells + 1):
        for vertical in range(center[1] - radius_cells, center[1] + radius_cells + 1):
            delta = np.maximum(np.abs(np.asarray(scene.cell_to_world((horizontal, vertical))) - position) - scene.resolution_m / 2., 0.)
            if np.linalg.norm(delta) > position_margin_m + 1e-9:
                continue
            if (not scene.in_bounds((horizontal, vertical)) or scene.occupancy[vertical, horizontal]
                    or scene.ceiling_height_m[vertical, horizontal] < specification.body_height_m + .04
                    or scene.step_height_m[vertical, horizontal] > specification.max_step_m + 1e-6):
                return False
    return True


def path_mode_feasibility(scene: GridScene, path: PathCandidate, specs: Sequence[PostureSpec], lookahead_m: float) -> np.ndarray:
    if path.continuous_geometry:
        cells, distances = polyline_cells(scene, path.points_xy_m)
    else:
        cells = [scene.world_to_cell(point) for point in path.points_xy_m]
        distances = np.r_[0., np.cumsum(np.linalg.norm(np.diff(path.points_xy_m, axis=0), axis=1))]
    if not cells or not all(scene.in_bounds(cell) for cell in cells):
        return np.zeros(3, dtype=bool)
    heights = np.asarray([scene.ceiling_height_m[cell[1], cell[0]] for cell in cells])
    steps = np.asarray([scene.step_height_m[cell[1], cell[0]] for cell in cells])
    free = path_sample_free(scene, path, cells, distances)
    feasible = np.column_stack([(heights >= spec.body_height_m + 0.04) & (steps <= spec.max_step_m + 1e-6) & free for spec in specs])
    local = distances <= lookahead_m
    result = np.zeros(3, dtype=bool)
    for initial in range(3):
        if not feasible[local, initial].all():
            continue
        reachable = np.zeros(3, dtype=bool)
        reachable[initial] = True
        for index in range(len(cells)):
            reachable &= feasible[index]
            if not reachable.any():
                break
            if not local[index]:
                reachable |= feasible[index]
        result[initial] = reachable.any()
    return result


def action_mask(
    scene: GridScene,
    paths: Sequence[PathCandidate],
    pedestrians: Sequence[Pedestrian],
    current_posture: int,
    current_speed_mps: float,
    roll_rad: float = 0.0,
    pitch_rad: float = 0.0,
    safety: JointSafetyConfig | None = None,
    posture_specs: Sequence[PostureSpec] | None = None,
    current_position_xy_m: Sequence[float] | None = None,
    pedestrian_motion_context=(),
) -> tuple[np.ndarray, dict[int, float]]:
    safety = safety or JointSafetyConfig()
    specs = tuple(posture_specs or POSTURE_SPECS)
    if len(specs) != 3:
        raise ValueError("exactly three posture specifications are required")
    mask = np.zeros(max(1, len(paths) * ACTION_COUNT_PER_PATH) + 1, dtype=bool)
    risks: dict[int, float] = {}
    predictor = PedestrianPredictor()
    prediction_options = dict(pedestrian_motion_context=pedestrian_motion_context,
        stationary_restart=safety.stationary_restart_prediction,
        stationary_speed_threshold_mps=safety.stationary_speed_threshold_mps,
        restart_speed_margin_mps=safety.restart_speed_margin_mps,
        moving_speed_envelope=safety.moving_speed_prediction,
        observed_shuttle_prediction=safety.observed_shuttle_prediction)
    for path_index, path in enumerate(paths):
        prediction = predictor.risk_for_path(path, pedestrians)
        feasible_modes = path_mode_feasibility(scene, path, specs, safety.geometry_lookahead_m)
        for posture_index, posture in enumerate(specs):
            if not feasible_modes[posture_index]:
                continue
            if (posture_index != current_posture and safety.transition_position_margin_m > 0.
                    and not transition_mode_feasible(scene, path.points_xy_m[0] if current_position_xy_m is None else current_position_xy_m,
                                                     posture, safety.transition_position_margin_m)):
                continue
            if safety.timed_dynamic_safety:
                stopping_horizon = safety.braking_horizon_s(current_posture, current_speed_mps)
                if predictor.timed_risk_for_path(path, pedestrians, current_speed_mps, stopping_horizon, **prediction_options) >= safety.dynamic_risk_stop:
                    continue
            elif prediction.min_distance_m < safety.min_path_clearance_m and prediction.collision_probability >= safety.dynamic_risk_stop:
                continue
            switched = posture_index != current_posture
            if switched and not safety.staged_mode_switches and (abs(current_speed_mps) > safety.switch_speed_max_mps or abs(roll_rad) > safety.switch_attitude_max_rad or abs(pitch_rad) > safety.switch_attitude_max_rad):
                continue
            for speed_index in range(3):
                if not posture.supports_speed(posture.vmax_mps * SPEEDS[speed_index]):
                    continue
                if safety.timed_dynamic_safety:
                    target_speed = posture.vmax_mps * SPEEDS[speed_index]
                    settling_delay = (safety.command_settling_delay_s(posture_index, 0. if switched else current_speed_mps, target_speed)
                                      if safety.execution_timing_prediction else 0.)
                    if switched:
                        transition_radius = .5
                        if safety.minimum_mode_motion_hold_s > 0.:
                            transition_radius += current_speed_mps * safety.braking_horizon_s(current_posture, current_speed_mps) + safety.transition_position_margin_m
                        action_risk = predictor.transition_risk_for_path(path, pedestrians,
                            target_speed, safety.expected_transition_costs_s[current_posture][posture_index] + settling_delay,
                            robot_radius_m=transition_radius, minimum_delay_s=safety.minimum_mode_motion_hold_s,
                            **prediction_options)
                    elif safety.execution_timing_prediction:
                        coast_margin = max(0., current_speed_mps - target_speed) * settling_delay
                        action_risk = predictor.transition_risk_for_path(path, pedestrians, target_speed, settling_delay,
                            robot_radius_m=.5 + coast_margin, **prediction_options)
                    else:
                        action_risk = predictor.timed_risk_for_path(path, pedestrians, target_speed, **prediction_options)
                    if action_risk >= safety.dynamic_risk_stop:
                        continue
                action = encode_action(path_index, posture_index, speed_index, len(paths))
                mask[action] = True; risks[action] = action_risk if safety.timed_dynamic_safety else prediction.collision_probability
    mask[-1] = not bool(mask[:-1].any())
    return mask, risks


def infer_terrain_mode(scene: GridScene, path: PathCandidate, posture_specs: Sequence[PostureSpec] | None = None, lookahead_m: float = float("inf")) -> int:
    specs = tuple(posture_specs or POSTURE_SPECS)
    cells = [scene.world_to_cell(point) for point in path.points_xy_m]
    distances = np.r_[0.0, np.cumsum(np.linalg.norm(np.diff(path.points_xy_m, axis=0), axis=1))]
    cells = [cell for cell, distance in zip(cells, distances) if distance <= lookahead_m and scene.in_bounds(cell)]
    if not cells:
        return 0
    ceiling = min(scene.ceiling_height_m[y, x] for x, y in cells if scene.in_bounds((x, y)))
    steps = max(scene.step_height_m[y, x] for x, y in cells if scene.in_bounds((x, y)))
    if ceiling < specs[1].body_height_m + 0.04:
        return 1
    if steps > specs[1].max_step_m:
        return 2
    return 0


class JointLinearQPolicy:
    """Small masked tabular Q learner used for repeatable upper-policy training."""

    def __init__(self, max_paths: int = 3, seed: int = 11) -> None:
        self.max_paths = max_paths
        self.action_count = max_paths * ACTION_COUNT_PER_PATH + 1
        self.rng = np.random.default_rng(seed)
        self.q: dict[tuple[int, int, int, int], np.ndarray] = {}

    def _state_key(self, observation: JointObservation) -> tuple[int, int, int, int]:
        risk_bucket = int(np.clip(math.floor(observation.pedestrian_risk * 3.0), 0, 2))
        return (observation.terrain_mode, risk_bucket, observation.current_posture, min(len(observation.paths), self.max_paths))

    def _row(self, observation: JointObservation) -> np.ndarray:
        key = self._state_key(observation)
        return self.q.setdefault(key, np.zeros(self.action_count, dtype=float))

    def act(self, observation: JointObservation, epsilon: float = 0.0) -> JointDecision:
        mask = observation.valid_actions
        valid = np.flatnonzero(mask)
        if len(valid) == 0 or (len(valid) == 1 and valid[0] == len(mask) - 1):
            return JointDecision(False, reason="safe_stop_no_feasible_action")
        row = self._row(observation)
        if epsilon > 0.0 and self.rng.random() < epsilon:
            action = int(self.rng.choice(valid[valid < len(mask) - 1]))
        else:
            values = np.full(self.action_count, -np.inf, dtype=float)
            values[: len(mask) - 1] = np.where(mask[:-1], row[: len(mask) - 1], -np.inf)
            if observation.pedestrian_risk > 0.5:
                for candidate in np.flatnonzero(mask[:-1]):
                    _, posture_index, speed_index = decode_action(int(candidate), len(observation.paths))
                    values[candidate] -= observation.pedestrian_risk * (
                        0.8 + 1.5 * speed_index / 2.0 + 0.35 * posture_index
                    )
            action = int(np.argmax(values))
        path_index, posture_index, speed_index = decode_action(action, len(observation.paths))
        path = observation.paths[path_index]
        return JointDecision(True, action, path_index, posture_index, speed_index, path.path_id, POSTURES[posture_index], SPEEDS[speed_index], "q_policy")

    def update(self, observation: JointObservation, action_id: int, reward: float, next_observation: JointObservation | None, done: bool, alpha: float = 0.18, gamma: float = 0.96) -> None:
        row = self._row(observation)
        target = reward
        if not done and next_observation is not None:
            next_row = self._row(next_observation)
            next_values = np.full(self.action_count, -np.inf, dtype=float)
            next_values[: len(next_observation.valid_actions) - 1] = np.where(
                next_observation.valid_actions[:-1],
                next_row[: len(next_observation.valid_actions) - 1],
                -np.inf,
            )
            if np.isfinite(next_values).any():
                target += gamma * float(np.max(next_values))
        row[action_id] += alpha * (target - row[action_id])

    def save(self, path: str | Path) -> None:
        payload = {"max_paths": self.max_paths, "states": {"|".join(map(str, key)): row.tolist() for key, row in self.q.items()}}
        Path(path).write_text(json.dumps(payload, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: str | Path) -> "JointLinearQPolicy":
        payload = json.loads(Path(path).read_text(encoding="utf-8")); policy = cls(int(payload["max_paths"]))
        policy.q = {tuple(map(int, key.split("|"))): np.asarray(value, dtype=float) for key, value in payload["states"].items()}
        return policy


class NeuPANBridge:
    """NeuPAN API adapter with explicit vendor/fallback status."""

    def __init__(self, yaml_path: str | Path | None = None, vendor_root: str | Path | None = None, robot_limits=None) -> None:
        self.backend = "fallback"
        self.planner = None
        self.last_latency_ms = 0.0
        self.init_error = ""
        self._last_path_id = ""
        self.last_status = {}
        if vendor_root is not None and str(vendor_root) not in sys.path:
            sys.path.insert(0, str(vendor_root))
        if yaml_path is not None:
            try:
                resolved_yaml_path = str(Path(yaml_path).expanduser().resolve())
                try:
                    import tkinter  # noqa: F401
                except ModuleNotFoundError:
                    # gctl imports tkinter.Scale only for its optional mouse
                    # waypoint UI.  Isaac headless runs use curve_style=line.
                    tkinter_stub = types.ModuleType("tkinter")
                    tkinter_stub.Scale = type("Scale", (), {})
                    sys.modules["tkinter"] = tkinter_stub
                from neupan.neupan import neupan
                initialization_options = {}
                if robot_limits is not None:
                    import yaml
                    robot_config = yaml.safe_load(Path(resolved_yaml_path).read_text())['robot']
                    for key in ('max_speed', 'max_acce'):
                        bound = np.asarray(robot_limits[key], dtype=float)
                        if bound.shape != (2,) or not np.isfinite(bound).all() or (bound <= 0.).any():
                            raise ValueError('NeuPAN execution bounds must be positive finite forward/yaw pairs')
                        robot_config[key] = np.minimum(bound, robot_config[key]).tolist()
                    initialization_options['robot'] = robot_config
                if vendor_root is not None:
                    previous_cwd = os.getcwd()
                    os.chdir(str(vendor_root))
                    try:
                        self.planner = neupan.init_from_yaml(resolved_yaml_path, **initialization_options)
                    finally:
                        os.chdir(previous_cwd)
                else:
                    self.planner = neupan.init_from_yaml(resolved_yaml_path, **initialization_options)
                self.backend = "vendor"
            except Exception as exc:
                self.planner = None
                self.init_error = f"{type(exc).__name__}: {exc}"

    def reset(self):
        if self.planner is not None:
            self.planner.reset()
        self._last_path_id = ''
        self.last_status = {}

    def command(self, state: Pose2D, path: PathCandidate, obstacles_xy: np.ndarray | None = None, velocities_xy: np.ndarray | None = None, speed_mps: float = 0.4) -> tuple[float, float]:
        if not math.isfinite(speed_mps) or speed_mps < 0.:
            raise ValueError('NeuPAN reference speed must be finite and nonnegative')
        started = time.perf_counter()
        if self.planner is not None:
            if path.path_id != self._last_path_id:
                points = []
                for index, point in enumerate(path.points_xy_m):
                    if index + 1 < len(path.points_xy_m):
                        delta = path.points_xy_m[index + 1] - point
                        yaw = math.atan2(float(delta[1]), float(delta[0]))
                    elif index > 0:
                        delta = point - path.points_xy_m[index - 1]
                        yaw = math.atan2(float(delta[1]), float(delta[0]))
                    else:
                        yaw = state.yaw
                    points.append(np.asarray([[point[0]], [point[1]], [yaw], [1.0]], dtype=float))
                self.planner.set_initial_path(points)
                self._last_path_id = path.path_id
            self.planner.set_reference_speed(float(speed_mps))
            state_array = np.asarray([[state.x], [state.y], [state.yaw]], dtype=float)
            points = None if obstacles_xy is None or len(obstacles_xy) == 0 else np.asarray(obstacles_xy, dtype=float).T
            velocities = None if velocities_xy is None or len(velocities_xy) == 0 else np.asarray(velocities_xy, dtype=float).T
            action, info = self.planner.forward(state_array, points, velocities)
            self.last_status = {name: bool(info.get(name, False)) for name in ("stop", "arrive", "collision")}
            reference_states = info.get('ref_state_list')
            if reference_states:
                self.last_status['reference_heading_rad'] = float(reference_states[-1][2, 0])
            self.last_status["minimum_point_distance_m"] = float(self.planner.min_distance) if points is not None else None
            output = (float(action[0, 0]), float(action[1, 0]))
        else:
            deltas = path.points_xy_m - np.asarray([state.x, state.y])
            index = int(np.argmin(np.linalg.norm(deltas, axis=1)))
            target = path.points_xy_m[min(index + 3, len(path.points_xy_m) - 1)]
            desired = math.atan2(target[1] - state.y, target[0] - state.x)
            yaw_error = _angle_wrap(desired - state.yaw)
            output = (_clip(speed_mps * math.cos(yaw_error), -1.1, 1.1), _clip(2.0 * yaw_error, -1.2, 1.2))
        self.last_latency_ms = (time.perf_counter() - started) * 1000.0
        return output


@dataclass(frozen=True)
class IsaacJointFeedback:
    pose: Pose2D
    goal_xy_m: tuple[float, float]
    scene: GridScene
    pedestrians: tuple[Pedestrian, ...] = ()
    roll_rad: float = 0.0
    pitch_rad: float = 0.0
    measured_speed_mps: float | None = None
    obstacle_points_xy_m: np.ndarray | None = None
    obstacle_velocities_xy_mps: np.ndarray | None = None
    mode_switch_allowed: bool = True
    executed_posture_index: int | None = None
    pedestrian_motion_context: tuple = ()
    previous_path: PathCandidate | None = None


class IsaacJointNavigationAdapter:
    """One-cycle adapter for an Isaac sensor/control callback."""

    def __init__(self, policy: JointLinearQPolicy, controller: NeuPANBridge | None = None, posture_specs: Sequence[PostureSpec] | None = None, safety: JointSafetyConfig | None = None) -> None:
        self.policy = policy
        self.controller = controller or NeuPANBridge()
        self.astar = AStarPlanner()
        self.predictor = PedestrianPredictor()
        self.posture_specs = tuple(posture_specs or POSTURE_SPECS)
        self.current_posture = 1
        self.current_speed_mps = 0.0
        self.safety = safety or JointSafetyConfig()
        self.last_navigation_cost_summary = None
        self.wait_decision_streak = 0

    def step(self, feedback: IsaacJointFeedback) -> tuple[JointDecision, tuple[float, float], JointObservation]:
        if self.astar.config.observed_shuttle_cost and not self.safety.observed_shuttle_prediction:
            raise ValueError('observed shuttle A* cost requires explicit observed risk prediction')
        if feedback.executed_posture_index is not None:
            if feedback.executed_posture_index not in range(3):
                raise ValueError("executed posture must be LOW, MID or HIGH index")
            self.current_posture = feedback.executed_posture_index
        measured_speed = self.current_speed_mps if feedback.measured_speed_mps is None else feedback.measured_speed_mps
        if not math.isfinite(measured_speed) or measured_speed < 0.0:
            raise ValueError("measured planar speed must be finite and non-negative")
        navigation_cost = None
        self.last_navigation_cost_summary = None
        if feedback.pedestrians and self.astar.config.dynamic_cost_weight > 0.:
            from .pedestrian_navigation_cost import pedestrian_cost_summary, predicted_pedestrian_cost
            navigation_cost = predicted_pedestrian_cost(feedback.scene, feedback.pedestrians,
                horizon_s=self.astar.config.dynamic_horizon_s, robot_radius_m=self.astar.config.dynamic_robot_radius_m,
                weight=self.astar.config.dynamic_cost_weight,
                pedestrian_motion_context=feedback.pedestrian_motion_context,
                observed_shuttle_prediction=self.astar.config.observed_shuttle_cost)
            if self.astar.config.observed_shuttle_cost:
                self.last_navigation_cost_summary = pedestrian_cost_summary(feedback.scene, feedback.pedestrians,
                    feedback.pedestrian_motion_context, navigation_cost, horizon_s=self.astar.config.dynamic_horizon_s,
                    robot_radius_m=self.astar.config.dynamic_robot_radius_m, weight=self.astar.config.dynamic_cost_weight)
        paths = self.astar.plan_candidates(feedback.scene, (feedback.pose.x, feedback.pose.y), feedback.goal_xy_m,
                                          self.posture_specs if self.astar.config.diverse_routes else None,
                                          navigation_cost=navigation_cost, start_yaw_rad=feedback.pose.yaw)
        if self.safety.timed_dynamic_safety and feedback.previous_path is not None:
            from .path_continuation import with_continuation_candidate
            paths = with_continuation_candidate(feedback.scene, paths, feedback.previous_path,
                (feedback.pose.x, feedback.pose.y), feedback.goal_xy_m, self.posture_specs,
                limit=self.astar.config.candidate_count)
        mask, action_risks = action_mask(
            feedback.scene,
            paths,
            feedback.pedestrians,
            self.current_posture,
            measured_speed,
            feedback.roll_rad,
            feedback.pitch_rad,
            safety=self.safety,
            posture_specs=self.posture_specs,
            current_position_xy_m=(feedback.pose.x, feedback.pose.y),
            pedestrian_motion_context=feedback.pedestrian_motion_context,
        )
        pathological_paths = {
            path_index for path_index, path in enumerate(paths)
            if self.astar._is_pathological_start_detour(path.points_xy_m, (feedback.pose.x, feedback.pose.y), feedback.goal_xy_m, path.length_m)
        }
        normal_paths_have_actions = any(
            bool(mask[path_index * ACTION_COUNT_PER_PATH:(path_index + 1) * ACTION_COUNT_PER_PATH].any())
            for path_index in range(len(paths)) if path_index not in pathological_paths
        )
        if normal_paths_have_actions:
            for path_index in pathological_paths:
                mask[path_index * ACTION_COUNT_PER_PATH:(path_index + 1) * ACTION_COUNT_PER_PATH] = False
        risk = max(
            (self.predictor.risk_for_path(path, feedback.pedestrians).collision_probability for path in paths),
            default=0.0,
        )
        if not feedback.mode_switch_allowed and not self.safety.staged_mode_switches:
            for action in np.flatnonzero(mask[:-1]):
                if decode_action(int(action), len(paths))[1] != self.current_posture:
                    mask[action] = False
            mask[-1] = not bool(mask[:-1].any())
        terrain = infer_terrain_mode(feedback.scene, paths[0], self.posture_specs, self.safety.geometry_lookahead_m) if paths else 0
        from .joint_ppo import joint_action_features
        if self.safety.timed_dynamic_safety:
            path_risks = [[action_risks.get(path_index * ACTION_COUNT_PER_PATH + offset, 1.)
                           for offset in range(ACTION_COUNT_PER_PATH)] for path_index in range(len(paths))]
        else:
            path_risks = [self.predictor.risk_for_path(path, feedback.pedestrians).collision_probability for path in paths]
        features = joint_action_features(feedback.scene, paths, self.posture_specs, self.current_posture, measured_speed, risk, path_risks,
                                         transition_costs_s=self.safety.expected_transition_costs_s,
                                         pedestrians=feedback.pedestrians,
                                         pedestrian_motion_context=feedback.pedestrian_motion_context,
                                         pose=feedback.pose, previous_path=feedback.previous_path)
        if self.safety.risk_priced_wait:
            current_mode_references, other_mode_references = [], []
            for path_index, path in enumerate(paths):
                geometric_modes = path_mode_feasibility(feedback.scene, path, self.posture_specs, self.safety.geometry_lookahead_m)
                for mode, specification in enumerate(self.posture_specs):
                    if not geometric_modes[mode]:
                        continue
                    if (mode != self.current_posture and not transition_mode_feasible(feedback.scene,
                            (feedback.pose.x, feedback.pose.y), specification, self.safety.transition_position_margin_m)):
                        continue
                    for speed_index, ratio in enumerate(SPEEDS):
                        if specification.supports_speed(specification.vmax_mps * ratio):
                            action = path_index * ACTION_COUNT_PER_PATH + mode * 3 + speed_index
                            (current_mode_references if mode == self.current_posture else other_mode_references).append(action)
            references = current_mode_references or other_mode_references
            if references:
                reference = min(references, key=lambda action: 4.8 * features[action, 2] + 1.5 * features[action, 1]
                    + .25 * features[action, 9] + 4.8 * features[action, 35] + .05 * features[action, 33])
                features[-1] = features[reference].copy()
            else:
                features[-1, 2] = 5.
            features[-1, 6:8] = (0., measured_speed)
            features[-1, 23] = 1.
            wait_path = PathCandidate('observed_stationary_wait', np.asarray([[feedback.pose.x, feedback.pose.y]] * 2), 0., 1, 0.)
            braking_horizon = self.safety.braking_horizon_s(self.current_posture, measured_speed)
            wait_risk = self.predictor.timed_risk_for_path(wait_path, feedback.pedestrians, 0.,
                horizon_s=max(self.safety.wait_risk_horizon_s, braking_horizon), robot_radius_m=.5 + measured_speed * braking_horizon,
                pedestrian_motion_context=feedback.pedestrian_motion_context,
                stationary_restart=self.safety.stationary_restart_prediction,
                stationary_speed_threshold_mps=self.safety.stationary_speed_threshold_mps,
                restart_speed_margin_mps=self.safety.restart_speed_margin_mps,
                moving_speed_envelope=self.safety.moving_speed_prediction,
                observed_shuttle_prediction=self.safety.observed_shuttle_prediction)
            features[-1, 8] = wait_risk
            wait_geometry_clear = transition_mode_feasible(feedback.scene, (feedback.pose.x, feedback.pose.y),
                self.posture_specs[self.current_posture], 0.)
            mask[-1] = (wait_risk < self.safety.dynamic_risk_stop and wait_geometry_clear) or not bool(mask[:-1].any())
            if self.wait_decision_streak >= 8 and bool(mask[:-1].any()):
                low_actions = []
                for action in np.flatnonzero(mask[:-1]):
                    _, mode, speed_index = decode_action(int(action), len(paths))
                    if mode == 0 and speed_index <= 1 and action_risks.get(int(action), 1.) < self.safety.dynamic_risk_stop:
                        low_actions.append(int(action))
                if low_actions:
                    mask[-1] = False
        observation = JointObservation(paths, mask, self.current_posture, measured_speed, risk, terrain, self.astar.replan_id, features)
        decision = self.policy.act(observation)
        if not decision.valid:
            self.current_speed_mps = 0.0
            self.wait_decision_streak += 1
            return decision, (0.0, 0.0), observation
        self.wait_decision_streak = 0
        self.current_posture = decision.posture_index
        if hasattr(self.controller, 'select_execution_mode'):
            self.controller.select_execution_mode(self.current_posture)
        self.current_speed_mps = self.posture_specs[decision.posture_index].vmax_mps * decision.speed_ratio
        path = paths[decision.path_index]
        obstacle_points, obstacle_velocities = fused_navigation_obstacles(feedback.pedestrians,
            feedback.obstacle_points_xy_m, feedback.obstacle_velocities_xy_mps)
        command = self.controller.command(feedback.pose, path, obstacle_points, obstacle_velocities, self.current_speed_mps)
        return decision, command, observation


@dataclass
class EpisodeResult:
    scenario: str
    success: bool
    collision: bool
    hard_failure: bool
    steps: int
    elapsed_s: float
    path_length_m: float
    switches: int
    replans: int
    astar_latency_ms_mean: float
    planner_latency_ms_mean: float
    pedestrian_risk_max: float
    selected_postures: list[str] = field(default_factory=list)
    neu_pan_backend: str = "fallback"


class JointNavigationEnv:
    def __init__(self, scene: GridScene, start: Pose2D, goal_xy_m: Sequence[float], pedestrians: Sequence[Pedestrian], scenario: str, seed: int = 11, dt_s: float = 0.1, neupan_yaml: str | Path | None = None, vendor_root: str | Path | None = None) -> None:
        self.scene = scene; self.start = start; self.goal_xy_m = np.asarray(goal_xy_m, dtype=float)
        self.pedestrians = list(pedestrians); self.scenario = scenario; self.dt_s = dt_s; self.rng = np.random.default_rng(seed)
        self.astar = AStarPlanner(); self.predictor = PedestrianPredictor(); self.controller = NeuPANBridge(neupan_yaml, vendor_root)
        self.reset()

    def reset(self) -> JointObservation:
        self.state = self.start; self.current_posture = 1; self.current_speed_mps = 0.0; self.steps = 0; self.path_length = 0.0; self.switches = 0
        self.replans = 0; self.astar_times = []; self.planner_times = []; self.risks = []; self.selected_postures = []
        self.collision = False; self.success = False
        self.paths = self._replan(); return self.observation()

    def _replan(self) -> tuple[PathCandidate, ...]:
        started = time.perf_counter(); paths = self.astar.plan_candidates(self.scene, (self.state.x, self.state.y), self.goal_xy_m)
        self.astar_times.append((time.perf_counter() - started) * 1000.0); self.replans += 1; self.paths = paths; return paths

    def _pedestrians_now(self) -> list[Pedestrian]:
        return [Pedestrian(p.x + p.vx * self.steps * self.dt_s, p.y + p.vy * self.steps * self.dt_s, p.vx, p.vy, p.radius_m) for p in self.pedestrians]

    def observation(self) -> JointObservation:
        pedestrians = self._pedestrians_now(); risk = 0.0
        for path in self.paths:
            risk = max(risk, self.predictor.risk_for_path(path, pedestrians).collision_probability)
        mask, _ = action_mask(self.scene, self.paths, pedestrians, self.current_posture, self.current_speed_mps)
        terrain = infer_terrain_mode(self.scene, self.paths[0]) if self.paths else 0
        return JointObservation(self.paths, mask, self.current_posture, self.current_speed_mps, risk, terrain, self.astar.replan_id)

    def step(self, decision: JointDecision) -> tuple[JointObservation, float, bool, dict[str, object]]:
        if not decision.valid or decision.path_index >= len(self.paths) or not self.observation().valid_actions[decision.action_id]:
            return self.observation(), -5.0, True, {"success": False, "hard_failure": True, "reason": "invalid_or_masked_action"}
        pedestrians = self._pedestrians_now(); path = self.paths[decision.path_index]; posture = POSTURE_SPECS[decision.posture_index]
        switched = decision.posture_index != self.current_posture
        if switched:
            self.switches += 1
        self.current_posture = decision.posture_index; self.current_speed_mps = posture.vmax_mps * decision.speed_ratio
        self.selected_postures.append(posture.name)
        points = self.predictor.predict(pedestrians)
        started = time.perf_counter(); vx, wz = self.controller.command(self.state, path, points.points_xy_m, points.velocities_xy_mps, self.current_speed_mps); self.planner_times.append((time.perf_counter() - started) * 1000.0)
        new_yaw = _angle_wrap(self.state.yaw + _clip(wz, -1.2, 1.2) * self.dt_s)
        distance = _clip(vx * self.dt_s, -0.15, 0.15); new_state = Pose2D(self.state.x + distance * math.cos(new_yaw), self.state.y + distance * math.sin(new_yaw), new_yaw)
        self.path_length += abs(distance); self.state = new_state; self.steps += 1
        self.risks.append(max((self.predictor.risk_for_path(path, pedestrians).collision_probability,), default=0.0))
        collision = any(math.hypot(self.state.x - p.x, self.state.y - p.y) < p.radius_m + 0.22 for p in pedestrians)
        goal = float(np.linalg.norm(np.asarray([self.state.x, self.state.y]) - self.goal_xy_m)) < 0.45
        self.collision = self.collision or collision; self.success = self.success or goal
        timeout = self.steps >= 900
        if self.steps % 10 == 0 and not goal and not collision:
            self._replan()
        next_obs = self.observation()
        switch_penalty = 0.08 if switched else 0.0
        dynamic_risk_penalty = self.risks[-1] * (0.35 + 1.8 * decision.speed_index / 2.0 + 0.25 * decision.posture_index)
        reward = -0.02 - 0.015 * self.current_speed_mps - dynamic_risk_penalty - switch_penalty
        if collision: reward -= 10.0
        if goal: reward += 10.0
        done = collision or goal or timeout
        info = {"success": goal and not collision, "collision": collision, "hard_failure": collision or timeout, "replan_id": self.astar.replan_id, "selected_posture": posture.name}
        return next_obs, float(reward), done, info

    def run(self, policy: JointLinearQPolicy, train: bool = False, epsilon: float = 0.0) -> EpisodeResult:
        observation = self.reset(); done = False; elapsed = 0.0
        while not done:
            decision = policy.act(observation, epsilon=epsilon)
            next_observation, reward, done, _ = self.step(decision)
            if train and decision.valid:
                policy.update(observation, decision.action_id, reward, next_observation, done)
            observation = next_observation; elapsed += self.dt_s
        return EpisodeResult(self.scenario, bool(self.success and not self.collision), bool(self.collision), bool(self.steps >= 900 and not self.success), self.steps, elapsed, self.path_length, self.switches, self.replans, float(np.mean(self.astar_times)) if self.astar_times else 0.0, float(np.mean(self.planner_times)) if self.planner_times else 0.0, float(max(self.risks) if self.risks else 0.0), self.selected_postures, self.controller.backend)


def make_scenario(name: str, seed: int = 11, neupan_yaml: str | Path | None = None, vendor_root: str | Path | None = None) -> JointNavigationEnv:
    width, height = 28, 14
    occupancy = np.zeros((height, width), dtype=bool); ceiling = np.full((height, width), 2.2); steps = np.zeros((height, width))
    start = Pose2D(1.0, 3.25); goal = (12.5, 3.25)
    if name == "flat":
        pass
    elif name == "low_tunnel":
        ceiling[:, 7:20] = 0.82
        occupancy[:, 7:20] = True
        occupancy[7, 7:20] = False
        start = Pose2D(1.0, 3.75); goal = (12.5, 3.75)
    elif name == "stairs":
        steps[6, 12:18] = 0.16
        occupancy[:, 12:18] = True
        occupancy[6, 12:18] = False
    elif name == "dynamic_pedestrian":
        occupancy[4, 8:20] = True; occupancy[9, 8:20] = True
    else:
        raise ValueError(f"unknown scenario {name}")
    scene = GridScene(occupancy, ceiling, steps, resolution_m=0.5)
    pedestrians = [Pedestrian(6.5, 3.25, 0.0, 0.45)] if name == "dynamic_pedestrian" else []
    return JointNavigationEnv(scene, start, goal, pedestrians, name, seed=seed, neupan_yaml=neupan_yaml, vendor_root=vendor_root)


def train_policy(episodes: int = 240, seed: int = 11) -> JointLinearQPolicy:
    policy = JointLinearQPolicy(seed=seed)
    names = ("flat", "low_tunnel", "stairs", "dynamic_pedestrian")
    for episode in range(episodes):
        env = make_scenario(names[episode % len(names)], seed=seed + episode)
        env.run(policy, train=True, epsilon=max(0.03, 0.35 * (1.0 - episode / max(1, episodes))))
    return policy


def evaluate_policy(policy: JointLinearQPolicy, episodes_per_scenario: int = 8, neupan_yaml: str | Path | None = None, vendor_root: str | Path | None = None) -> list[EpisodeResult]:
    results = []
    for name in ("flat", "low_tunnel", "stairs", "dynamic_pedestrian"):
        for seed in range(100, 100 + episodes_per_scenario):
            results.append(make_scenario(name, seed=seed, neupan_yaml=neupan_yaml, vendor_root=vendor_root).run(policy))
    return results


def results_summary(results: Sequence[EpisodeResult]) -> dict[str, object]:
    by_scenario = {}
    for name in sorted({item.scenario for item in results}):
        subset = [item for item in results if item.scenario == name]
        by_scenario[name] = {
            "episodes": len(subset), "success_rate": float(np.mean([item.success for item in subset])),
            "collision_rate": float(np.mean([item.collision for item in subset])),
            "hard_failure_rate": float(np.mean([item.hard_failure for item in subset])),
            "mean_time_s": float(np.mean([item.elapsed_s for item in subset])),
            "mean_path_length_m": float(np.mean([item.path_length_m for item in subset])),
            "mean_switches": float(np.mean([item.switches for item in subset])),
            "mean_replans": float(np.mean([item.replans for item in subset])),
            "mean_astar_latency_ms": float(np.mean([item.astar_latency_ms_mean for item in subset])),
            "mean_planner_latency_ms": float(np.mean([item.planner_latency_ms_mean for item in subset])),
            "max_pedestrian_risk": float(max(item.pedestrian_risk_max for item in subset)),
            "postures": sorted({posture for item in subset for posture in item.selected_postures}),
            "neu_pan_backends": sorted({item.neu_pan_backend for item in subset}),
        }
    return {"episodes": len(results), "scenarios": by_scenario}


__all__ = [
    "AStarPlanner", "EpisodeResult", "GridScene", "JointDecision", "JointLinearQPolicy", "JointNavigationEnv",
    "IsaacJointFeedback", "IsaacJointNavigationAdapter", "NeuPANBridge", "Pedestrian", "PedestrianPredictor", "PathCandidate", "Pose2D", "action_mask",
    "evaluate_policy", "make_scenario", "results_summary", "train_policy",
]
