"""Import-safe bridge contract for feeding an upper decision to Isaac/MPPI.

The adapter intentionally does not import ``omni``.  It converts a selected
upper action into a bounded MPPI command and exposes the exact hooks that an
Isaac Lab task must call once the swept-body geometry is available.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any

import numpy as np

from .three_route_scene import POSTURE_HMAP_OFFSETS_M, ThreeRouteSceneConfig
from .upper_level_types import (
    ROUTE_HEIGHTS_CM,
    SPEED_RATIOS,
    RouteCandidate,
    UpperDecision,
    UpperObservation,
    UpperSafetyConfig,
)


@dataclass(frozen=True)
class MPPILowLevelContract:
    """Frozen lower-controller timing and velocity contract."""

    controller_hz: float = 10.0
    low_level_hz: float = 50.0
    vx_max_mps: float = 0.15
    wz_max_rps: float = 0.30


def route_candidates_from_scene(
    config: ThreeRouteSceneConfig | None = None,
    *,
    path_versions: tuple[int, int, int] = (0, 0, 0),
    goal_version: int = 0,
) -> tuple[RouteCandidate, RouteCandidate, RouteCandidate]:
    """Create path features from the deterministic Isaac scene contract."""

    scene = config or ThreeRouteSceneConfig()
    routes = scene.routes()

    def curvature_integral(points: tuple[tuple[float, float], ...]) -> float:
        headings = [
            math.atan2(end[1] - start[1], end[0] - start[0])
            for start, end in zip(points, points[1:])
        ]
        return float(sum(
            abs(math.atan2(math.sin(second - first), math.cos(second - first)))
            for first, second in zip(headings, headings[1:])
        ))

    return tuple(
        RouteCandidate(
            height_cm=ROUTE_HEIGHTS_CM[index],
            valid=True,
            remaining_length_m=route.length_m,
            lateral_clearance_m=max(
                0.0, route.width_m / 2.0 - scene.planning_inflation_radius_m
            ),
            overhead_margin_m=(
                scene.open_overhead_margin_m
                if route.ceiling_clearance_m is None
                else route.ceiling_clearance_m
                - scene.hmap_zero_clearance_m
                - tuple(POSTURE_HMAP_OFFSETS_M.values())[index]
            ),
            curvature_integral=curvature_integral(route.points),
            path_version=path_versions[index],
            goal_version=goal_version,
        )
        for index, route in enumerate(routes)
    )  # type: ignore[return-value]


class IsaacUpperDecisionAdapter:
    """Apply an atomic upper decision to the frozen MPPI command interface."""

    def __init__(
        self,
        safety: UpperSafetyConfig | None = None,
        low_level: MPPILowLevelContract | None = None,
    ) -> None:
        self.safety = safety or UpperSafetyConfig()
        self.low_level = low_level or MPPILowLevelContract()
        self.last_decision: UpperDecision | None = None

    def select_velocity(self, decision: UpperDecision) -> float:
        if not decision.valid:
            return 0.0
        vmax = self.safety.posture_vmax_mps[decision.route_index]
        return float(np.clip(decision.speed_ratio * vmax, 0.0, self.low_level.vx_max_mps))

    def apply_to_mppi_command(
        self, decision: UpperDecision, *, vx_mps: float, wz_rps: float
    ) -> tuple[float, float, str]:
        """Return a bounded command; caller forwards it to the frozen MPPI layer."""

        self.last_decision = decision
        if not decision.valid:
            return 0.0, 0.0, "safe_stop_invalid_upper_decision"
        requested_speed = self.select_velocity(decision)
        sign = -1.0 if vx_mps < 0.0 else 1.0
        bounded_vx = sign * min(abs(float(vx_mps)), requested_speed)
        bounded_wz = float(np.clip(float(wz_rps), -self.low_level.wz_max_rps, self.low_level.wz_max_rps))
        return bounded_vx, bounded_wz, "upper_decision_applied_to_frozen_mppi"

    def validate_lower_controller(self, mppi_config: dict[str, Any]) -> None:
        """Reject accidental lower-controller changes in a comparison run."""

        expected = {
            "controller_hz": self.low_level.controller_hz,
            "time_steps": 30,
            "model_dt": 0.10,
            "batch_size": 1600,
            "iteration_count": 2,
            "vx_max": self.low_level.vx_max_mps,
            "wz_max": self.low_level.wz_max_rps,
        }
        for key, value in expected.items():
            if key in mppi_config and not np.isclose(float(mppi_config[key]), float(value)):
                raise ValueError(
                    f"frozen MPPI contract mismatch for {key}: expected {value}, got {mppi_config[key]}"
                )
