from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import io
from pathlib import Path
import tarfile


def snapshot_sources(repository, destination, vendor_root=None):
    repository = Path(repository)
    destination = Path(destination)
    if destination.exists():
        raise ValueError("source snapshot must be new")
    paths = [(source.relative_to(repository).as_posix(), source)
             for directory in ("tita_uc_residual_rl", "scripts")
             for source in sorted((repository / directory).rglob("*.py"))]
    paths.extend((source.relative_to(repository).as_posix(), source) for source in sorted(repository.glob("*.py")))
    paths.extend((source.relative_to(repository).as_posix(), source)
                 for source in sorted((repository / "assets/tita_tower/calibration").rglob("*.json")))
    if vendor_root is not None:
        vendor_root = Path(vendor_root)
        paths.extend(("vendor/NeuPAN/" + source.relative_to(vendor_root).as_posix(), source)
                     for source in sorted((vendor_root / "neupan").rglob("*.py")))
    destination.parent.mkdir(parents=True, exist_ok=True)
    hashes = {}
    with destination.open("xb") as output:
        with tarfile.open(fileobj=output, mode="w:gz") as archive:
            for name, source in paths:
                content = source.read_bytes()
                hashes[name] = hashlib.sha256(content).hexdigest()
                member = tarfile.TarInfo(name)
                member.size = len(content)
                member.mode = 0o644
                archive.addfile(member, io.BytesIO(content))
    return {"schema": "tita.execution_source_snapshot.v1", "created_utc": datetime.now(timezone.utc).isoformat(),
            "archive": str(destination.resolve()), "archive_sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
            "files_sha256": hashes}


def input_hashes(paths):
    return {name: {"path": str(Path(path).resolve()), "sha256": hashlib.sha256(Path(path).read_bytes()).hexdigest()}
            for name, path in paths.items() if path is not None}
