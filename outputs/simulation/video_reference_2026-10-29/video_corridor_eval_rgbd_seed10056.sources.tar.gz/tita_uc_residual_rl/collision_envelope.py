from __future__ import annotations

from dataclasses import dataclass
import itertools
import math
from pathlib import Path
import xml.etree.ElementTree as element_tree

import numpy as np


def quaternion_matrix(quaternion_wxyz: np.ndarray) -> np.ndarray:
    quaternion = np.asarray(quaternion_wxyz, dtype=float)
    if quaternion.shape != (4,) or not np.isfinite(quaternion).all():
        raise ValueError("expected a finite wxyz quaternion")
    norm = float(np.linalg.norm(quaternion))
    if norm < 1e-8:
        raise ValueError("quaternion norm must be nonzero")
    scalar, first, second, third = quaternion / norm
    return np.array([
        [1 - 2 * (second * second + third * third), 2 * (first * second - third * scalar), 2 * (first * third + second * scalar)],
        [2 * (first * second + third * scalar), 1 - 2 * (first * first + third * third), 2 * (second * third - first * scalar)],
        [2 * (first * third - second * scalar), 2 * (second * third + first * scalar), 1 - 2 * (first * first + second * second)],
    ])


def _origin_matrix(roll_pitch_yaw: np.ndarray) -> np.ndarray:
    roll, pitch, yaw = roll_pitch_yaw
    roll_matrix = np.array([[1, 0, 0], [0, math.cos(roll), -math.sin(roll)], [0, math.sin(roll), math.cos(roll)]])
    pitch_matrix = np.array([[math.cos(pitch), 0, math.sin(pitch)], [0, 1, 0], [-math.sin(pitch), 0, math.cos(pitch)]])
    yaw_matrix = np.array([[math.cos(yaw), -math.sin(yaw), 0], [math.sin(yaw), math.cos(yaw), 0], [0, 0, 1]])
    return yaw_matrix @ pitch_matrix @ roll_matrix


def convex_hull_xy(points_xy: np.ndarray) -> np.ndarray:
    points = sorted(set(map(tuple, np.asarray(points_xy, dtype=float))))
    if len(points) < 3:
        raise ValueError("a collision envelope requires at least three distinct points")

    def cross(origin, first, second):
        return (first[0] - origin[0]) * (second[1] - origin[1]) - (first[1] - origin[1]) * (second[0] - origin[0])

    lower, upper = [], []
    for point in points:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], point) <= 0:
            lower.pop()
        lower.append(point)
    for point in reversed(points):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], point) <= 0:
            upper.pop()
        upper.append(point)
    return np.asarray(lower[:-1] + upper[:-1], dtype=float)


@dataclass(frozen=True)
class CollisionPrimitive:
    link_name: str
    vertices_link_m: np.ndarray


class UrdfCollisionEnvelope:
    def __init__(self, asset_path: str | Path, cylinder_samples: int = 32, include_visual_geometry: bool = False) -> None:
        if cylinder_samples < 8:
            raise ValueError("cylinder envelope requires at least eight samples")
        self.asset_path = Path(asset_path).resolve()
        self.primitives = []
        root = element_tree.parse(self.asset_path).getroot()
        for link in root.findall("link"):
            geometries = link.findall("collision") + (link.findall("visual") if include_visual_geometry else [])
            for collision in geometries:
                origin = collision.find("origin")
                translation = np.fromstring(origin.get("xyz", "0 0 0") if origin is not None else "0 0 0", sep=" ")
                rotation = _origin_matrix(np.fromstring(origin.get("rpy", "0 0 0") if origin is not None else "0 0 0", sep=" "))
                geometry = collision.find("geometry")
                if geometry is None or len(geometry) != 1:
                    raise ValueError(f"invalid collision geometry on {link.get('name')}")
                shape = geometry[0]
                if shape.tag == "box":
                    size = np.fromstring(shape.get("size", ""), sep=" ")
                    if size.shape != (3,) or np.any(size <= 0):
                        raise ValueError("box sizes must be positive")
                    vertices = np.array(list(itertools.product((-0.5, 0.5), repeat=3))) * size
                elif shape.tag == "cylinder":
                    radius, length = float(shape.get("radius", "nan")), float(shape.get("length", "nan"))
                    if not math.isfinite(radius + length) or min(radius, length) <= 0:
                        raise ValueError("cylinder dimensions must be finite and positive")
                    angles = np.linspace(0, 2 * math.pi, cylinder_samples, endpoint=False)
                    radius /= math.cos(math.pi / cylinder_samples)
                    ring = np.column_stack((radius * np.cos(angles), radius * np.sin(angles)))
                    vertices = np.vstack([np.column_stack((ring, np.full(cylinder_samples, height))) for height in (-length / 2, length / 2)])
                elif shape.tag == "sphere":
                    radius = float(shape.get("radius", "nan"))
                    if not math.isfinite(radius) or radius <= 0:
                        raise ValueError("sphere radius must be finite and positive")
                    vertices = np.array(list(itertools.product((-radius, radius), repeat=3)))
                elif shape.tag == "mesh" and include_visual_geometry:
                    import trimesh
                    filename = shape.get("filename", "")
                    if filename.startswith("package://"):
                        raise ValueError("package mesh requires an explicit resolved asset path")
                    mesh = trimesh.load(self.asset_path.parent / filename, force="mesh", process=False)
                    scale = np.fromstring(shape.get("scale", "1 1 1"), sep=" ")
                    if scale.shape != (3,) or not np.isfinite(scale).all() or np.any(scale <= 0):
                        raise ValueError("mesh scale must be finite and positive")
                    minimum, maximum = np.asarray(mesh.bounds) * scale
                    vertices = np.array(list(itertools.product(*zip(minimum, maximum))))
                else:
                    raise ValueError(f"unsupported collision geometry {shape.tag}; refusing incomplete envelope")
                if translation.shape != (3,) or not np.isfinite(translation).all():
                    raise ValueError("collision origin must be finite")
                self.primitives.append(CollisionPrimitive(link.get("name"), vertices @ rotation.T + translation))
        if not self.primitives:
            raise ValueError("URDF has no supported collision primitives")

    def points_world(self, body_names: list[str], positions_world: np.ndarray, quaternions_wxyz: np.ndarray) -> dict[str, np.ndarray]:
        positions = np.asarray(positions_world, dtype=float)
        orientations = np.asarray(quaternions_wxyz, dtype=float)
        if positions.shape != (len(body_names), 3) or orientations.shape != (len(body_names), 4):
            raise ValueError("collision measurement must use aligned body-link poses")
        indices = {name: index for index, name in enumerate(body_names)}
        result = {}
        for primitive in self.primitives:
            if primitive.link_name not in indices:
                raise ValueError(f"collision link {primitive.link_name} missing from articulation")
            index = indices[primitive.link_name]
            points = primitive.vertices_link_m @ quaternion_matrix(orientations[index]).T + positions[index]
            result.setdefault(primitive.link_name, []).append(points)
        return {name: np.vstack(points) for name, points in result.items()}

    def measure(self, body_names: list[str], positions_world: np.ndarray, quaternions_wxyz: np.ndarray,
                root_position_world: np.ndarray, root_quaternion_wxyz: np.ndarray, ground_height_m: float = 0.0) -> dict:
        points = self.points_world(body_names, positions_world, quaternions_wxyz)
        vertices = np.vstack(list(points.values()))
        root_position = np.asarray(root_position_world, dtype=float)
        rotation = quaternion_matrix(root_quaternion_wxyz)
        yaw = math.atan2(rotation[1, 0], rotation[0, 0])
        yaw_rotation = np.array([[math.cos(yaw), -math.sin(yaw)], [math.sin(yaw), math.cos(yaw)]])
        footprint_points = (vertices[:, :2] - root_position[:2]) @ yaw_rotation
        footprint = convex_hull_xy(footprint_points)
        if "base_link" not in points:
            raise ValueError("base_link collision is required for body clearance")
        return {
            "top_above_ground_m": float(vertices[:, 2].max() - ground_height_m),
            "base_clearance_m": float(points["base_link"][:, 2].min() - ground_height_m),
            "footprint_vertices_xy_m": footprint.tolist(),
            "footprint_min_xy_m": footprint.min(axis=0).tolist(),
            "footprint_max_xy_m": footprint.max(axis=0).tolist(),
            "collision_links": sorted(points),
        }
