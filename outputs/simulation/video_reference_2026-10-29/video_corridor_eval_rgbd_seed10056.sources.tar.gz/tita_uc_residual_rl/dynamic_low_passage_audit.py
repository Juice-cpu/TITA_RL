import math

import numpy as np
import torch

from .joint_navigation import JointSafetyConfig, PathCandidate, action_mask, path_mode_feasibility
from .joint_ppo import FEATURE_COUNT, MAX_ACTIONS
from .sustained_motion_audit import audit_sustained_mode_motion


def audit_dynamic_low_decisions(document, scene, posture_specs, policy):
    if document.get('upper_trained_here') is not False:
        return {'passed': False, 'failures': ['frozen_independent_policy_required'], 'witnesses': []}
    if document.get('terrain') != 'flat' or document.get('stair_config') is not None:
        return {'passed': False, 'failures': ['flat_dynamic_only_scene_required'], 'witnesses': []}
    failures, witnesses = [], []
    try:
        safety = JointSafetyConfig(**document['upper_safety_config'])
        timestep = document['elapsed_simulation_s'] / document['completed_steps']
        if not math.isfinite(timestep) or timestep <= 0.:
            raise ValueError('invalid_physical_clock')
        rows = {(row['episode'], row['step']): row for row in document['trajectory']}
        sensors = {(row['episode'], row['step']): row for row in document['sensor_records']}
        first_steps = {}
        for row in document['trajectory']:
            first_steps.setdefault(row['episode'], row['step'])
        events = document['decision_events']
        if policy.training:
            raise ValueError('training_policy_not_allowed')
        for index, event in enumerate(events):
            decision = event['decision']
            if not decision['valid'] or decision['posture'] != 'LOW':
                continue
            paths = tuple(PathCandidate(candidate['id'], np.asarray(candidate['points_xy_m'], dtype=float),
                candidate['length_m'], 1, .2, True) for candidate in event['candidates'])
            geometry = path_mode_feasibility(scene, paths[decision['path_index']], posture_specs,
                float('inf'))
            if not geometry[1]:
                continue
            key = event['episode'], first_steps[event['episode']] + round(event['time_s'] / timestep)
            row, sensor = rows[key], sensors[key]
            if not sensor['tracks']:
                continue
            if np.linalg.norm(np.subtract(row['root_position_before'][:2], event['pose_xy_m'])) > 1e-7:
                raise ValueError('decision_not_bound_to_actual_pose')
            features = np.asarray(event['action_features'], dtype=np.float32)
            recorded_mask = np.asarray(event['valid_actions'], dtype=bool)
            if (features.shape != (MAX_ACTIONS, FEATURE_COUNT)
                    or recorded_mask.shape != (len(paths) * 9 + 1,) or len(recorded_mask) > MAX_ACTIONS):
                raise ValueError('unsupported_feature_or_action_contract')
            mask = np.zeros(MAX_ACTIONS, dtype=bool)
            mask[:len(recorded_mask) - 1] = recorded_mask[:-1]
            mask[-1] = recorded_mask[-1]
            if not np.isfinite(features).all() or not mask[decision['action_id']]:
                raise ValueError('invalid_recorded_low_choice')
            with torch.no_grad():
                original, _ = policy.model.distribution(torch.from_numpy(features), torch.from_numpy(mask))
            if int(original.logits.argmax()) != decision['action_id']:
                raise ValueError('recorded_frozen_low_decision_not_replayed')
            clear_mask, _ = action_mask(scene, paths, (), ('LOW', 'MID', 'HIGH').index(event['actual_posture']),
                float(np.linalg.norm(row['measured_velocity_before'][:2])), row['roll_rad'], row['pitch_rad'],
                safety=safety, posture_specs=posture_specs, current_position_xy_m=event['pose_xy_m'])
            padded_clear_mask = np.zeros(MAX_ACTIONS, dtype=bool)
            padded_clear_mask[:len(clear_mask) - 1] = clear_mask[:-1]
            padded_clear_mask[-1] = True
            clear_features = features.copy()
            clear_features[:, 8] = 0.
            clear_features[:, 24:32] = 0.
            with torch.no_grad():
                clear, _ = policy.model.distribution(torch.from_numpy(clear_features), torch.from_numpy(padded_clear_mask))
            clear_action = int(clear.logits.argmax())
            clear_mode = None if clear_action == MAX_ACTIONS - 1 else (clear_action % 9) // 3
            if clear_mode != 1:
                continue
            following = next((value for value in events[index + 1:] if value['episode'] == event['episode']
                and (not value['decision']['valid'] or value['decision']['posture'] != 'LOW')), None)
            witnesses.append({'episode': event['episode'], 'decision_time_s': event['time_s'],
                'pose_xy_m': event['pose_xy_m'], 'actual_posture_before_decision': event['actual_posture'],
                'action_id': decision['action_id'], 'mid_geometrically_feasible': True,
                'recorded_low_choice_replayed': True, 'observed_tracks': len(sensor['tracks']),
                'clear_context_action_id': clear_action, 'clear_context_posture': 'MID',
                'recorded_selected_risk': float(features[decision['action_id'], 8]),
                'next_non_low_or_wait_decision_time_s': following['time_s'] if following else None,
                'counterfactual_new_physics': False})
    except (KeyError, TypeError, ValueError, IndexError, ZeroDivisionError, RuntimeError) as error:
        failures.append(str(error))
    return {'passed': not failures and bool(witnesses), 'failures': failures, 'witnesses': witnesses,
        'counterfactual_scope': 'Remove dynamic risk and track-history inputs, recalculate no-person mask on the SAME recorded candidates. Preserve terrain, route, speed and transition costs. No new physics or dynamic A* counterfactual.'}


def audit_dynamic_low_passage(document, scene, posture_specs, policy, verify_artifacts=True):
    decisions = audit_dynamic_low_decisions(document, scene, posture_specs, policy)
    motion = audit_sustained_mode_motion(document, verify_artifacts=verify_artifacts)
    matched = []
    for witness in decisions['witnesses']:
        for interval in motion['motion']['intervals']:
            deadline = witness['next_non_low_or_wait_decision_time_s']
            if (interval['sustained_motion_passed'] and interval['episode'] == witness['episode']
                    and interval['start_time_s'] >= witness['decision_time_s']
                    and (deadline is None or interval['end_time_s'] <= deadline + 1e-8)):
                matched.append({'decision_witness': witness, 'physical_motion_interval': interval})
    return {'schema': 'tita.dynamic_low_sustained_passage_audit.v1',
        'passed': decisions['passed'] and motion['passed'] and bool(matched),
        'decisions': decisions, 'motion': motion, 'matched_witnesses': matched,
        'new_counterfactual_physics': False, 'rl_superiority_proven': False, 'all_goals_complete': False,
        'scope': 'Frozen recorded policy choices with MID geometric feasibility, same-candidate dynamic-input ablation and actual sustained LOW motion in an independently passed flat scene. Not a controlled physical no-people pair or proof of a globally optimal policy.'}
