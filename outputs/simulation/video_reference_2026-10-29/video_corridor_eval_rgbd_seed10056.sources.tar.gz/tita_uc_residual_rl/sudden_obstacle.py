"""Physical sudden-obstacle probe with moving and appears-then-stops modes."""

from __future__ import annotations

import json
import math
from pathlib import Path
import time

import numpy as np

from tita_realtime_trace import trace_event


def load_sudden_obstacle(path):
    config = json.loads(Path(path).read_text())
    if config.get("schema") != "tita.sudden_obstacle_probe.v1" or config.get("simulation_only") is not True:
        raise ValueError("expected simulation-only sudden obstacle config")
    for name in ("center_m", "size_m"):
        if len(config[name]) != 3 or not np.isfinite(config[name]).all():
            raise ValueError("obstacle requires finite three-dimensional geometry")
    if min(config["size_m"]) <= 0 or config["center_m"][2] - config["size_m"][2] / 2 <= 0:
        raise ValueError("obstacle must have positive size and sit above the ground")
    for name in ("trigger_x_m", "trigger_y_max_m", "minimum_forward_speed_mps", "conservative_robot_radius_m"):
        if not math.isfinite(config[name]):
            raise ValueError("nonfinite probe configuration")
    if config["minimum_forward_speed_mps"] <= 0 or config["conservative_robot_radius_m"] <= 0:
        raise ValueError("probe speed and footprint radius must be positive")
    mode = config.get("motion_mode", "appears_then_stops")
    if mode not in ("moving_crossing", "appears_then_stops"):
        raise ValueError("motion_mode must be moving_crossing or appears_then_stops")
    velocity = config.get("velocity_mps", [0.0, 0.0, 0.0])
    if len(velocity) != 3 or not np.isfinite(velocity).all():
        raise ValueError("velocity_mps must contain three finite values")
    if mode == "moving_crossing" and np.linalg.norm(np.asarray(velocity)[:2]) <= 0.0:
        raise ValueError("moving_crossing requires nonzero planar velocity_mps")
    stop_after = float(config.get("stop_after_s", 0.0))
    if not math.isfinite(stop_after) or stop_after < 0.0:
        raise ValueError("stop_after_s must be finite and non-negative")
    return config


def trigger_satisfied(config, position_xy, forward_speed):
    return (position_xy[0] >= config["trigger_x_m"]
            and position_xy[1] <= config["trigger_y_max_m"]
            and forward_speed >= config["minimum_forward_speed_mps"])


def conservative_clearance(config, position_xy):
    offset = np.abs(np.asarray(position_xy) - np.asarray(config["center_m"][:2])) - np.asarray(config["size_m"][:2]) / 2
    distance = np.linalg.norm(np.maximum(offset, 0)) + min(float(np.max(offset)), 0)
    return float(distance - config["conservative_robot_radius_m"])


class SuddenObstacleProbe:
    def __init__(self, env, path, static_mesh):
        import torch
        import trimesh
        from isaaclab.assets import RigidObject, RigidObjectCfg
        import isaaclab.sim as sim_utils
        from isaaclab.sensors import ContactSensor, ContactSensorCfg

        if env.num_envs != 1:
            raise ValueError("sudden obstacle probe requires a single physical robot")
        self.config = load_sudden_obstacle(path)
        self.active = False
        self.detected_ns = None
        self.appeared_ns = None
        self.motion_started_ns = None
        self.motion_stopped_ns = None
        self.appearance_sim_time_s = None
        self.sim_time_s = 0.0
        self.control_step = 0
        self.last_update_step = None
        self.last_sample_step = None
        self.clearance_confirmed = False
        self.clearance_confirmed_ns = None
        self.clearance_consecutive_samples = 0
        self.origin = env.terrain.env_origins[0, :2].cpu().numpy()
        self.static_mesh = static_mesh
        self.spawn_center = np.asarray(self.config["center_m"], dtype=float)
        self.spawn_center[:2] += self.origin
        self.center = self.spawn_center.copy()
        self.config = {**self.config, "center_m": self.center.tolist()}
        rigid_config = RigidObjectCfg(
            prim_path="/World/sudden_obstacle",
            spawn=sim_utils.CuboidCfg(
                size=tuple(self.config["size_m"]),
                rigid_props=sim_utils.RigidBodyPropertiesCfg(kinematic_enabled=True, disable_gravity=True),
                collision_props=sim_utils.CollisionPropertiesCfg(),
                activate_contact_sensors=True,
                visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.9, 0.15, 0.1)),
            ),
            init_state=RigidObjectCfg.InitialStateCfg(pos=(float(self.center[0]), float(self.center[1]), -5.0)),
        )
        self.body = RigidObject(rigid_config)
        env.scene.rigid_objects["sudden_obstacle"] = self.body
        self.contacts = ContactSensor(ContactSensorCfg(
            prim_path="/World/sudden_obstacle", update_period=0.005, history_length=3,
        ))
        env.scene.sensors["sudden_obstacle_contacts"] = self.contacts
        self.pose = torch.tensor([[*self.center, 1.0, 0.0, 0.0, 0.0]], device=env.device, dtype=torch.float32)

    def _combined_mesh(self):
        import trimesh
        geometry = trimesh.creation.box(extents=self.config["size_m"])
        geometry.apply_translation(self.center)
        combined = trimesh.util.concatenate([self.static_mesh, geometry])
        return combined.vertices, combined.faces

    def _update_lidar_mesh(self, env):
        from isaaclab.utils.warp import convert_to_warp_mesh
        vertices, faces = self._combined_mesh()
        env._navigation_lidar.meshes[env.cfg.navigation_lidar.mesh_prim_paths[0]] = convert_to_warp_mesh(
            vertices, faces, device=env.device
        )

    @property
    def obstacle_moving(self):
        if not self.active or self.config.get("motion_mode", "appears_then_stops") != "moving_crossing":
            return False
        stop_after = float(self.config.get("stop_after_s", 0.0))
        return stop_after <= 0.0 or self.sim_time_s - float(self.appearance_sim_time_s) < stop_after

    def update(self, env, control_step):
        self.sim_time_s = control_step * float(env.step_dt)
        self.control_step = control_step
        if self.last_update_step == control_step:
            return
        self.last_update_step = control_step
        position = env.robot.data.root_pos_w[0, :2].cpu().tolist()
        local_position = np.asarray(position) - self.origin
        speed = float(env.robot.data.root_lin_vel_b[0, 0])
        if not self.active and trigger_satisfied(self.config, local_position, speed):
            self.active = True
            self.appearance_sim_time_s = self.sim_time_s
            self.appeared_ns = time.monotonic_ns()
            self.body.write_root_pose_to_sim(self.pose)
            self._update_lidar_mesh(env)
            trace_event("probe", "obstacle_appeared", at_ns=self.appeared_ns,
                        sim_time_s=self.sim_time_s, control_step=control_step,
                        position_xy=position, forward_speed_mps=speed,
                        center_m=self.center.tolist(), size_m=self.config["size_m"],
                        obstacle_moving=self.obstacle_moving,
                        clearance_m=conservative_clearance(self.config, position))
            if self.obstacle_moving:
                self.motion_started_ns = self.appeared_ns
                trace_event("probe", "obstacle_motion_started", at_ns=self.motion_started_ns,
                            sim_time_s=self.sim_time_s, velocity_mps=self.config["velocity_mps"])
            else:
                self.motion_stopped_ns = self.appeared_ns
                trace_event("probe", "obstacle_motion_stopped", at_ns=self.motion_stopped_ns,
                            sim_time_s=self.sim_time_s, obstacle_moving=False,
                            position_xy=self.center[:2].tolist())
            return
        if not self.active:
            return
        elapsed = self.sim_time_s - float(self.appearance_sim_time_s)
        stop_after = float(self.config.get("stop_after_s", 0.0))
        should_move = self.config.get("motion_mode") == "moving_crossing" and (stop_after <= 0.0 or elapsed < stop_after)
        if should_move:
            self.center = self.spawn_center + np.asarray(self.config["velocity_mps"], dtype=float) * elapsed
            self.config["center_m"] = self.center.tolist()
            pose = self.pose.clone()
            pose[0, :3] = pose.new_tensor(self.center)
            self.body.write_root_pose_to_sim(pose)
            self._update_lidar_mesh(env)
        elif self.motion_started_ns is not None and self.motion_stopped_ns is None:
            self.motion_stopped_ns = time.monotonic_ns()
            trace_event("probe", "obstacle_motion_stopped", at_ns=self.motion_stopped_ns,
                        sim_time_s=self.sim_time_s, obstacle_moving=False,
                        position_xy=self.center[:2].tolist())

    def observe_lidar(self, hits):
        if not self.active or self.detected_ns is not None:
            return
        center = hits.new_tensor(self.center)
        half_size = hits.new_tensor(self.config["size_m"]) / 2
        hit_mask = (abs(hits[0] - center) <= half_size + 1e-4).all(dim=-1)
        if bool(hit_mask.any()):
            self.detected_ns = time.monotonic_ns()
            trace_event("probe", "perception_first_hit", at_ns=self.detected_ns,
                        sim_time_s=self.sim_time_s, control_step=self.control_step,
                        hit_count=int(hit_mask.sum()), obstacle_moving=self.obstacle_moving)

    def state(self):
        return {
            "active": self.active, "lidar_detected": self.detected_ns is not None,
            "appeared_ns": self.appeared_ns, "detected_ns": self.detected_ns,
            "motion_started_ns": self.motion_started_ns, "motion_stopped_ns": self.motion_stopped_ns,
            "obstacle_moving": self.obstacle_moving, "center_m": self.center.tolist(),
            "size_m": list(self.config["size_m"]), "clearance_confirmed": self.clearance_confirmed,
            "clearance_confirmed_ns": self.clearance_confirmed_ns,
        }

    def hmap_points(self, sample_m=0.05):
        """Return obstacle boundary samples for the three complete HMAP layers."""
        half_x = float(self.config["size_m"][0]) / 2.0
        half_y = float(self.config["size_m"][1]) / 2.0
        count_x = max(1, int(math.ceil(2.0 * half_x / sample_m)))
        count_y = max(1, int(math.ceil(2.0 * half_y / sample_m)))
        xs = np.linspace(self.center[0] - half_x, self.center[0] + half_x, count_x + 1)
        ys = np.linspace(self.center[1] - half_y, self.center[1] + half_y, count_y + 1)
        boundary = []
        for x in xs:
            boundary.extend(((float(x), float(self.center[1] - half_y)), (float(x), float(self.center[1] + half_y))))
        for y in ys:
            boundary.extend(((float(self.center[0] - half_x), float(y)), (float(self.center[0] + half_x), float(y))))
        return [[round(x, 4), round(y, 4), height] for height in (0.20, 0.30, 0.40) for x, y in boundary]

    def sample(self, env, control_step):
        if not self.active:
            return
        if self.last_sample_step == control_step:
            return
        self.last_sample_step = control_step
        trace_event("probe", "physical_sample", control_step=control_step,
                    sim_time_s=control_step * float(env.step_dt),
                    position_xy=env.robot.data.root_pos_w[0, :2].cpu().tolist(),
                    body_velocity=env.robot.data.root_lin_vel_b[0, :2].cpu().tolist(),
                    quaternion_wxyz=env.robot.data.root_quat_w[0].cpu().tolist(),
                    obstacle_contact_force_n=float(self.contacts.data.net_forces_w.norm(dim=-1).max()))
        position_xy = env.robot.data.root_pos_w[0, :2].cpu().numpy()
        clearance = conservative_clearance(self.config, position_xy)
        rear_clear = position_xy[0] >= self.center[0] + self.config["size_m"][0] / 2.0 + self.config["conservative_robot_radius_m"]
        if clearance >= float(self.config.get("clearance_margin_m", 0.10)) and rear_clear:
            self.clearance_consecutive_samples += 1
        else:
            self.clearance_consecutive_samples = 0
        required = int(self.config.get("minimum_consecutive_clearance_samples", 10))
        if not self.clearance_confirmed and self.clearance_consecutive_samples >= required:
            self.clearance_confirmed = True
            self.clearance_confirmed_ns = time.monotonic_ns()
            trace_event("probe", "avoidance_confirmed", at_ns=self.clearance_confirmed_ns,
                        sim_time_s=self.sim_time_s, control_step=control_step,
                        position_xy=position_xy.tolist(), clearance_m=clearance,
                        consecutive_samples=self.clearance_consecutive_samples,
                        obstacle_moving=self.obstacle_moving)
