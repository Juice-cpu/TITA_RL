import numpy as np

from .dynamic_perception import PedestrianMotionContext
from .joint_navigation import Pedestrian
from .pedestrian_navigation_cost import OBSERVED_ASTAR_COST_CONTRACT, pedestrian_cost_summary, predicted_pedestrian_cost


def audit_observed_astar_cost(document, scene):
    configuration = document.get('astar_config', {})
    enabled = configuration.get('observed_shuttle_cost', False)
    invocation = '--observed-shuttle-astar-cost' in document.get('invocation', [])
    failures, checked, changed = [], 0, 0
    if enabled != invocation:
        failures.append('observed_astar_gate_not_bound_to_actual_invocation')
    if not enabled:
        if any(row.get('navigation_cost_summary') is not None for row in document.get('decision_events', [])):
            failures.append('disabled_astar_forecast_emitted_cost_summary')
        return {'passed': not failures, 'failures': failures, 'decisions_checked': 0, 'changed_decisions': 0,
            'exercised': False}
    contract = document.get('observed_shuttle_prediction', {})
    if (not contract.get('enabled') or not contract.get('global_astar_cost_enabled')
            or contract.get('global_astar_cost_contract') != OBSERVED_ASTAR_COST_CONTRACT):
        failures.append('observed_astar_contract_not_bound_to_observed_prediction')
    try:
        timestep = document['elapsed_simulation_s'] / document['completed_steps']
        first_steps = {}
        for row in document['trajectory']:
            first_steps.setdefault(row['episode'], row['step'])
        sensors = {(row['episode'], row['step']): row for row in document['sensor_records']}
        for event in document['decision_events']:
            key = event['episode'], first_steps[event['episode']] + round(event['time_s'] / timestep)
            sensor = sensors[key]
            people = tuple(Pedestrian(**person) for person in sensor['tracks'])
            contexts = tuple(PedestrianMotionContext(**context) for context in sensor['motion_context'])
            if not people or configuration['dynamic_cost_weight'] <= 0.:
                if event.get('navigation_cost_summary') is not None:
                    raise ValueError('unexpected_cost_summary_without_observed_people')
                continue
            options = {'horizon_s': configuration['dynamic_horizon_s'],
                'robot_radius_m': configuration['dynamic_robot_radius_m'], 'weight': configuration['dynamic_cost_weight']}
            cost = predicted_pedestrian_cost(scene, people, pedestrian_motion_context=contexts,
                observed_shuttle_prediction=True, **options)
            expected = pedestrian_cost_summary(scene, people, contexts, cost, **options)
            if expected != event.get('navigation_cost_summary'):
                raise ValueError('observed_astar_cost_not_reproduced_from_same_step_tracks')
            checked += 1
            changed += expected['changed_cells'] > 0
        if not checked:
            failures.append('no_observed_people_cost_decisions_checked')
    except (KeyError, TypeError, ValueError, IndexError, ZeroDivisionError) as error:
        failures.append(str(error))
    return {'schema': 'tita.observed_astar_cost_binding_audit.v1', 'passed': not failures,
        'failures': failures, 'decisions_checked': checked, 'changed_decisions': changed, 'exercised': changed > 0,
        'scope': 'Measured-track/forecast-to-A* input-cost binding only; not a newly executed physical route, a worst-case human bound or navigation acceptance.'}
