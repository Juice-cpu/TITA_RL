import math


def envelope_probe_commands(speeds_mps, combined_commands=False, yaw_rate_radps=.2):
    speeds = tuple(sorted(set(float(value) for value in speeds_mps)))
    if not speeds or any(not math.isfinite(value) or value <= 0. for value in speeds) or not math.isfinite(yaw_rate_radps) or yaw_rate_radps <= 0.:
        raise ValueError("envelope probe speeds and yaw rate must be finite and positive")
    commands = [(0., 0., 0.)]
    commands.extend((speed, 0., 0.) for speed in speeds)
    commands.extend((0., 0., yaw) for yaw in (yaw_rate_radps, -yaw_rate_radps))
    if combined_commands:
        commands.extend((speed, 0., yaw) for speed in speeds for yaw in (yaw_rate_radps, -yaw_rate_radps))
    return tuple(commands)
