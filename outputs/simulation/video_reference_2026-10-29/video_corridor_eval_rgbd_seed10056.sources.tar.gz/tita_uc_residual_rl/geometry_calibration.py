from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np

from .joint_navigation import PostureSpec, POSTURES


def load_geometry_calibration(path, asset_path, checkpoint_path, posture_joint_anchors, residual_path=None,
                              required_postures=POSTURES, required_support_height_m=0., velocity_calibration_path=None,
                              convex_cylinder_collisions=False):
    report = json.loads(Path(path).read_text())
    if report.get("schema") != "tita.full_body_envelope.v1":
        raise ValueError("unsupported full-body calibration schema")
    if report.get("convex_cylinder_collisions", False) != convex_cylinder_collisions:
        raise ValueError("full-body calibration cylinder collision backend mismatch")
    if required_support_height_m > report.get("support_height_m", 0.) + 1e-6:
        raise ValueError("full-body calibration does not cover elevated support in this scene")
    for key, source in (("asset_sha256", asset_path), ("checkpoint_sha256", checkpoint_path)):
        if report.get(key) != hashlib.sha256(Path(source).read_bytes()).hexdigest():
            raise ValueError(f"full-body calibration {key} mismatch")
    if not np.array_equal(report["posture_joint_anchors"], posture_joint_anchors):
        raise ValueError("full-body calibration posture anchors mismatch")
    residual_hash = hashlib.sha256(Path(residual_path).read_bytes()).hexdigest() if residual_path is not None else None
    if report.get("residual_sha256") != residual_hash:
        raise ValueError("full-body calibration residual mismatch")
    if velocity_calibration_path is not None:
        expected_governor = report.get("input_artifacts", {}).get("velocity_calibration", {}).get("sha256")
        actual_governor = hashlib.sha256(Path(velocity_calibration_path).read_bytes()).hexdigest()
        if expected_governor != actual_governor:
            raise ValueError("full-body calibration velocity governor mismatch")
    for name in required_postures:
        profile = report["profiles"][name]
        height = profile["body_height_envelope_m"]
        if not profile["valid"] or profile["hard_failures"] or not np.isfinite(height) or height <= 0:
            raise ValueError(f"unsafe geometry calibration for {name}")
        if "validated_linear_speed_mps" in profile:
            speed = profile["validated_linear_speed_mps"]
            if not np.isfinite(speed) or speed <= 0.:
                raise ValueError(f"invalid calibrated speed for {name}")
    return report


def validate_planner_enclosure(report, vertices_xy_m):
    vertices = np.asarray(vertices_xy_m, dtype=float)
    if vertices.ndim != 2 or vertices.shape[1] != 2 or len(vertices) < 3 or not np.isfinite(vertices).all():
        raise ValueError("planner footprint must be a finite polygon")
    edges = np.roll(vertices, -1, axis=0) - vertices
    lengths = np.linalg.norm(edges, axis=1)
    orientation = np.sign(np.sum(vertices[:, 0] * np.roll(vertices[:, 1], -1) - vertices[:, 1] * np.roll(vertices[:, 0], -1)))
    if not orientation or (lengths <= 1e-9).any():
        raise ValueError("planner polygon is degenerate")
    polygon_cross = edges[:, 0] * np.roll(edges[:, 1], -1) - edges[:, 1] * np.roll(edges[:, 0], -1)
    if (orientation * polygon_cross < -1e-9).any():
        raise ValueError("planner footprint must be convex")
    minimum_margin = float("inf")
    for profile in report["profiles"].values():
        points = np.asarray(profile["footprint_vertices_xy_m"], dtype=float)
        differences = points[:, None, :] - vertices[None, :, :]
        margins = orientation * (edges[None, :, 0] * differences[:, :, 1] - edges[None, :, 1] * differences[:, :, 0]) / lengths
        if not np.isfinite(margins).all() or margins.min() < -1e-6:
            raise ValueError("NeuPAN footprint does not enclose every calibrated body envelope")
        minimum_margin = min(minimum_margin, float(margins.min()))
    return minimum_margin


def validate_dune_audit(path, checkpoint_path, vertices_xy_m):
    audit = json.loads(Path(path).read_text())
    if audit.get("schema") != "tita.full_tower_dune_audit.v1":
        raise ValueError("unsupported DUNE audit schema")
    if audit["checkpoint_sha256"] != hashlib.sha256(Path(checkpoint_path).read_bytes()).hexdigest():
        raise ValueError("DUNE audit checkpoint mismatch")
    if not np.array_equal(audit["robot_vertices_xy_m"], vertices_xy_m):
        raise ValueError("DUNE audit polygon mismatch")
    for name, maximum in (("outside_p95_absolute_error_m", .015), ("maximum_distance_overestimate_m", .025)):
        value = audit.get(name, float("nan"))
        if not np.isfinite(value) or value < 0. or value > maximum:
            raise ValueError(f"DUNE sampled quality screen failed for {name}")
    return audit


def calibrated_posture_specs(report, step_capabilities_m=(0.0, 0.0, 0.0), speed_limits_mps=(0.15, 0.30, 0.20)):
    return tuple(PostureSpec(name, report["profiles"][name]["body_height_envelope_m"],
                            report["profiles"][name]["minimum_base_clearance_m"], step,
                            min(speed, report["profiles"][name].get("validated_linear_speed_mps", speed)))
                 for name, step, speed in zip(POSTURES, step_capabilities_m, speed_limits_mps))
