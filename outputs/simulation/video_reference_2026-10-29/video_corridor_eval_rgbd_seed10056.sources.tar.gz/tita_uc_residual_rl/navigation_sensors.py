"""Isaac Lab sensor configurations for the TITA navigation experiment.

The factories are intentionally lazy: importing this module does not require
Isaac Lab, which keeps the simulator-independent unit tests usable. The URDF
supplies the ``radar_link`` and camera frames; these factories add the actual
simulated sensor objects.
"""

from __future__ import annotations

import math


# The official RL URDF has no radar_link; base_link is the calibrated sensor
# anchor used by this Isaac-only bridge.  A real tower extrinsic is still
# required before transferring this scan model to hardware.
RADAR_PRIM_PATH = "/World/envs/env_.*/Robot/base_link"
LEFT_CAMERA_PRIM_PATH = "/World/envs/env_.*/Robot/left_camera/camera"
RIGHT_CAMERA_PRIM_PATH = "/World/envs/env_.*/Robot/right_camara/camera"
RADAR_MOUNT_PITCH_RAD = 0.34907


def make_navigation_lidar_cfg(
    mesh_prim_path: str,
    *,
    update_period: float = 0.05,
    horizontal_resolution_deg: float = 2.0,
    max_distance_m: float = 12.0,
    debug_vis: bool = False,
):
    """Build a compact ray-cast LiDAR attached to the modeled radar frame.

    ``mesh_prim_path`` must identify one static scene mesh. Isaac Lab's
    RayCaster currently accepts one mesh, so callers should merge route walls
    and obstacles into a single mesh before creating this sensor.
    """

    from isaaclab.sensors import RayCasterCfg, patterns

    if horizontal_resolution_deg <= 0.0:
        raise ValueError("horizontal_resolution_deg must be positive")
    if max_distance_m <= 0.0:
        raise ValueError("max_distance_m must be positive")
    inverse_pitch = (
        math.cos(RADAR_MOUNT_PITCH_RAD / 2.0),
        0.0,
        -math.sin(RADAR_MOUNT_PITCH_RAD / 2.0),
        0.0,
    )
    return RayCasterCfg(
        prim_path=RADAR_PRIM_PATH,
        update_period=update_period,
        # Cancel the modeled housing's fixed +20 degree pitch so the scan is
        # level in the nominal pose while still following robot orientation.
        offset=RayCasterCfg.OffsetCfg(pos=(0.0, 0.0, 0.0), rot=inverse_pitch),
        attach_yaw_only=False,
        pattern_cfg=patterns.LidarPatternCfg(
            channels=1,
            vertical_fov_range=(0.0, 0.0),
            horizontal_fov_range=(-180.0, 180.0),
            horizontal_res=horizontal_resolution_deg,
        ),
        max_distance=max_distance_m,
        debug_vis=debug_vis,
        mesh_prim_paths=[mesh_prim_path],
    )


def make_navigation_camera_cfg(
    side: str,
    *,
    update_period: float = 0.10,
    width: int = 320,
    height: int = 240,
):
    """Build a camera below one of the existing fixed camera frames.

    The camera is created as a child named ``camera``. This avoids replacing
    the URDF's fixed ``left_camera``/``right_camara`` Xform links.
    """

    from isaaclab.sensors import CameraCfg
    from isaaclab.sim import PinholeCameraCfg

    frame_paths = {
        "left": LEFT_CAMERA_PRIM_PATH,
        "right": RIGHT_CAMERA_PRIM_PATH,
    }
    try:
        prim_path = frame_paths[side.lower()]
    except KeyError as exc:
        raise ValueError("side must be 'left' or 'right'") from exc
    if width <= 0 or height <= 0:
        raise ValueError("camera width and height must be positive")
    return CameraCfg(
        prim_path=prim_path,
        update_period=update_period,
        height=height,
        width=width,
        data_types=["rgb", "distance_to_image_plane"],
        spawn=PinholeCameraCfg(
            focal_length=24.0,
            focus_distance=400.0,
            horizontal_aperture=20.955,
            clipping_range=(0.05, 50.0),
        ),
        offset=CameraCfg.OffsetCfg(
            pos=(0.0, 0.0, 0.0),
            rot=(1.0, 0.0, 0.0, 0.0),
            convention="ros",
        ),
    )
