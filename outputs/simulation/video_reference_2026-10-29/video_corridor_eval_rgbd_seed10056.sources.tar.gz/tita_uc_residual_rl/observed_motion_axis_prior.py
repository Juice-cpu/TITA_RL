import math

import numpy as np


class ObservedMotionAxisPrior:
    def __init__(self, window_s=30., minimum_speed_mps=.08, dominant_axis_fraction=.85):
        if (not all(math.isfinite(value) for value in (window_s, minimum_speed_mps, dominant_axis_fraction))
                or min(window_s, minimum_speed_mps) <= 0. or not .5 < dominant_axis_fraction <= 1.):
            raise ValueError('observed axis prior requires positive history window, motion threshold and a dominant-axis fraction')
        self.window_s = window_s
        self.minimum_speed_mps = minimum_speed_mps
        self.dominant_axis_fraction = dominant_axis_fraction
        self.reset()

    def reset(self):
        self.samples = []
        self.last_time_s = None

    def update(self, timestamp_s, observations):
        if not math.isfinite(timestamp_s) or self.last_time_s is not None and timestamp_s <= self.last_time_s:
            raise ValueError('observed motion prior timestamps must increase strictly')
        self.last_time_s = timestamp_s
        self.samples = [sample for sample in self.samples if timestamp_s - sample[0] <= self.window_s]
        for identifier, velocity_x, velocity_y in observations:
            if not isinstance(identifier, int) or identifier < 0 or not np.isfinite([velocity_x, velocity_y]).all():
                raise ValueError('observed motion prior requires identified finite velocities')
            velocity = np.asarray([velocity_x, velocity_y], dtype=float)
            if np.linalg.norm(velocity) >= self.minimum_speed_mps:
                self.samples.append((timestamp_s, identifier, velocity))

    def for_track(self, identifier):
        own = [sample[2] for sample in self.samples if sample[1] == identifier]
        if own:
            return max(own, key=np.linalg.norm).copy(), 'track_observed_peak'
        if not self.samples:
            return np.zeros(2), 'unavailable'
        velocities = np.vstack([sample[2] for sample in self.samples])
        eigenvalues, eigenvectors = np.linalg.eigh(velocities.T @ velocities)
        if eigenvalues[-1] / eigenvalues.sum() < self.dominant_axis_fraction:
            return np.zeros(2), 'unavailable'
        return eigenvectors[:, -1] * np.linalg.norm(velocities, axis=1).max(), 'scene_observed_dominant_axis'
