import math

import numpy as np


def signed_path_tracking_error(points_xy_m, position_xy_m, yaw_rad, heading_lookahead_m=0.):
    points = np.asarray(points_xy_m, dtype=float)
    position = np.asarray(position_xy_m, dtype=float)
    if (points.ndim != 2 or points.shape[1] != 2 or len(points) < 2 or position.shape != (2,)
            or not np.isfinite(points).all() or not np.isfinite(position).all() or not math.isfinite(yaw_rad)
            or not math.isfinite(heading_lookahead_m) or heading_lookahead_m < 0.):
        raise ValueError("path tracking requires a finite polyline and robot pose")
    segments = np.diff(points, axis=0)
    squared_length = np.sum(segments ** 2, axis=1)
    valid = squared_length > 1e-12
    if not valid.any():
        raise ValueError("path tracking requires a nonzero path segment")
    starts, segments, squared_length = points[:-1][valid], segments[valid], squared_length[valid]
    fraction = np.clip(np.sum((position - starts) * segments, axis=1) / squared_length, 0., 1.)
    projections = starts + fraction[:, None] * segments
    nearest = int(np.argmin(np.sum((position - projections) ** 2, axis=1)))
    tangent = segments[nearest] / math.sqrt(float(squared_length[nearest]))
    delta = position - projections[nearest]
    cross_track = tangent[0] * delta[1] - tangent[1] * delta[0]
    if heading_lookahead_m > 0.:
        lengths = np.sqrt(squared_length)
        cumulative = np.r_[0., np.cumsum(lengths)]
        progress = cumulative[nearest] + fraction[nearest] * lengths[nearest]
        target_progress = min(progress + heading_lookahead_m, cumulative[-1])
        target_segment = min(int(np.searchsorted(cumulative, target_progress, side="right")) - 1, len(segments) - 1)
        target_fraction = (target_progress - cumulative[target_segment]) / lengths[target_segment]
        target = starts[target_segment] + target_fraction * segments[target_segment]
        heading_vector = target - projections[nearest]
        if np.linalg.norm(heading_vector) > 1e-6:
            tangent = heading_vector / np.linalg.norm(heading_vector)
    heading_error = math.atan2(math.sin(yaw_rad - math.atan2(tangent[1], tangent[0])),
                               math.cos(yaw_rad - math.atan2(tangent[1], tangent[0])))
    return float(cross_track), heading_error
