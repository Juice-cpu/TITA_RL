import torch


def symmetric_posture_logit_bias(parameters):
    if parameters.ndim != 2 or parameters.shape[1] != 2 or not torch.isfinite(parameters).all():
        raise ValueError('posture bias search requires finite hip/knee parameter pairs')
    offsets = parameters.new_zeros((len(parameters), 8))
    offsets[:, 1] = offsets[:, 5] = parameters[:, 0]
    offsets[:, 2] = offsets[:, 6] = parameters[:, 1]
    return offsets


def robust_posture_candidate_scores(hold_s, pitch_error, height_error, speed_error, failures):
    if (hold_s.ndim != 2 or any(value.shape != hold_s.shape for value in
            (pitch_error, height_error, speed_error, failures)) or failures.dtype != torch.bool
            or any(not torch.isfinite(value).all() for value in
                   (hold_s, pitch_error, height_error, speed_error))):
        raise ValueError('posture scores require aligned finite candidate-by-scenario feedback')
    scenario_score = (hold_s.clamp(max=3.) * 10. - 1000. * pitch_error
                      - 1000. * height_error - 100. * speed_error)
    return scenario_score.min(1).values - 1e6 * failures.any(1)


def robust_riser_candidate_scores(hold_s, traversed, pitch_error, height_error, speed_error, failures):
    scores = robust_posture_candidate_scores(hold_s, pitch_error, height_error, speed_error, failures)
    if traversed.shape != hold_s.shape or traversed.dtype != torch.bool:
        raise ValueError('riser scores require aligned boolean traversal feedback')
    acceptance_gap = (1. - hold_s.clamp(max=1.)).max(1).values
    return scores - 100. * (~traversed).sum(1) - 50. * acceptance_gap
