"""Versioned, discrete upper-level model from TITA-RL函数.docx.

Inputs are complete per-action predictions, not the legacy three-layer summary
features. Calibration provenance is mandatory by default. This module never
publishes commands and does not estimate missing geometry or electrical power.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import math
from numbers import Integral
from typing import Mapping

import numpy as np


FORMULA_VERSION = "tita-navigation-formula-v2"
POSTURES = ("LOW", "MID", "HIGH")
SPEED_RATIOS = (0.4, 0.7, 1.0)
ACTIONS_PER_PATH = len(POSTURES) * len(SPEED_RATIOS)


def _index(value: int, count: int, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral) or not 0 <= value < count:
        raise ValueError(f"{name} must be an integer in [0, {count})")
    return int(value)


def encode_action(path_index: int, posture_index: int, speed_index: int, path_count: int) -> int:
    _positive_integer(path_count, "path_count")
    return (ACTIONS_PER_PATH * _index(path_index, path_count, "path_index")
            + 3 * _index(posture_index, 3, "posture_index")
            + _index(speed_index, 3, "speed_index"))


def decode_action(action_id: int, path_count: int) -> tuple[int, int, int]:
    _positive_integer(path_count, "path_count")
    path_index, remainder = divmod(_index(action_id, ACTIONS_PER_PATH * path_count, "action_id"),
                                    ACTIONS_PER_PATH)
    posture_index, speed_index = divmod(remainder, 3)
    return path_index, posture_index, speed_index


def _positive_integer(value: int, name: str) -> None:
    if isinstance(value, bool) or not isinstance(value, Integral) or value <= 0:
        raise ValueError(f"{name} must be a positive integer")


def _finite(value: float, name: str, *, minimum: float | None = None, positive: bool = False) -> None:
    if not math.isfinite(float(value)) or (minimum is not None and value < minimum) or (positive and value <= 0):
        raise ValueError(f"invalid {name}")


def _array(value, name: str, shape: tuple[int, ...], *, nonnegative: bool = False) -> np.ndarray:
    result = np.array(value, dtype=np.float64, copy=True)
    if result.shape != shape or not np.isfinite(result).all() or (nonnegative and np.any(result < 0)):
        raise ValueError(f"{name} must have finite shape {shape}" + (" and be nonnegative" if nonnegative else ""))
    result.setflags(write=False)
    return result


@dataclass(frozen=True)
class PowerModel:
    idle_w: float
    velocity_w: float
    acceleration_w: float
    curvature_w: float
    slope_w: float
    roughness_w: float

    def __post_init__(self) -> None:
        for name, value in vars(self).items():
            _finite(value, name, minimum=0.0)


@dataclass(frozen=True)
class PostureModel:
    body_height_m: float
    vmax_mps: float
    braking_mps2: float
    base_clearance_m: float
    roll_max_rad: float
    pitch_max_rad: float
    power: PowerModel

    def __post_init__(self) -> None:
        for name in ("body_height_m", "vmax_mps", "braking_mps2", "roll_max_rad", "pitch_max_rad"):
            _finite(getattr(self, name), name, positive=True)
        _finite(self.base_clearance_m, "base_clearance_m", minimum=0.0)
        if max(self.roll_max_rad, self.pitch_max_rad) >= math.pi / 2:
            raise ValueError("posture limits must be below pi/2")


@dataclass(frozen=True)
class FormulaWeights:
    energy: float = 0.30
    time: float = 0.25
    length: float = 0.15
    clearance: float = 0.25
    switch: float = 0.05

    def __post_init__(self) -> None:
        for name, value in vars(self).items():
            _finite(value, name, minimum=0.0)
        if not math.isclose(sum(vars(self).values()), 1.0, rel_tol=0.0, abs_tol=1e-9):
            raise ValueError("the five objective weights must sum to one")


@dataclass(frozen=True)
class FormulaConfig:
    postures: tuple[PostureModel, PostureModel, PostureModel]
    energy_ref_j: float
    time_ref_s: float
    length_ref_m: float
    distance_ref_m: float
    height_ref_m: float
    roll_ref_rad: float
    pitch_ref_rad: float
    clearance_sigma_m: float
    dt_s: float
    reaction_time_s: float
    distance_margin_m: float
    height_margin_m: float
    goal_tolerance_m: float
    switch_speed_max_mps: float
    switch_roll_max_rad: float
    switch_pitch_max_rad: float
    switch_times_s: tuple[tuple[float, float, float], ...]
    weights: FormulaWeights = field(default_factory=FormulaWeights)
    penalty_clearance: float = 2.0
    penalty_height: float = 2.0
    penalty_attitude: float = 1.0
    roll_bias_rad: float = 0.0
    gravity_mps2: float = 9.81
    calibration: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if len(self.postures) != 3:
            raise ValueError("exactly LOW/MID/HIGH posture models are required")
        for name in ("energy_ref_j", "time_ref_s", "length_ref_m", "distance_ref_m", "height_ref_m",
                     "roll_ref_rad", "pitch_ref_rad", "clearance_sigma_m", "dt_s", "gravity_mps2"):
            _finite(getattr(self, name), name, positive=True)
        for name in ("reaction_time_s", "distance_margin_m", "height_margin_m", "goal_tolerance_m",
                     "switch_speed_max_mps", "switch_roll_max_rad", "switch_pitch_max_rad",
                     "penalty_clearance", "penalty_height", "penalty_attitude", "roll_bias_rad"):
            _finite(getattr(self, name), name, minimum=0.0)
        times = _array(self.switch_times_s, "switch_times_s", (3, 3), nonnegative=True)
        if np.any(np.diag(times) != 0):
            raise ValueError("switch time diagonal must be zero")
        object.__setattr__(self, "switch_times_s", tuple(tuple(float(value) for value in row) for row in times))
        object.__setattr__(self, "calibration", dict(self.calibration))

    @property
    def calibrated(self) -> bool:
        return all(isinstance(self.calibration.get(key), str) and self.calibration[key].strip()
                   for key in ("geometry", "power", "speed", "braking", "switch", "attitude", "normalization"))

    @classmethod
    def from_dict(cls, values: Mapping[str, object]) -> "FormulaConfig":
        data = dict(values)
        data["postures"] = tuple(PostureModel(**{**item, "power": PowerModel(**item["power"])})
                                 for item in data["postures"])
        data["weights"] = FormulaWeights(**data.get("weights", {}))
        return cls(**data)


@dataclass(frozen=True)
class PathPrediction:
    path_id: str
    points_xy_m: np.ndarray
    elevation_m: np.ndarray
    ceiling_height_m: np.ndarray
    curvature_per_m: np.ndarray
    terrain_roll_rad: np.ndarray
    roughness_rms_m: np.ndarray
    path_version: int = 0
    goal_version: int = 0

    def __post_init__(self) -> None:
        points = np.asarray(self.points_xy_m)
        if points.ndim != 2 or points.shape[1] != 2 or len(points) < 2 or not self.path_id:
            raise ValueError("path requires an id and at least two XY points")
        count = len(points)
        for name, shape, nonnegative in (
            ("points_xy_m", (count, 2), False), ("elevation_m", (count,), False),
            ("ceiling_height_m", (count,), True), ("curvature_per_m", (count - 1,), False),
            ("terrain_roll_rad", (count - 1,), False), ("roughness_rms_m", (count - 1,), True),
        ):
            object.__setattr__(self, name, _array(getattr(self, name), name, shape, nonnegative=nonnegative))
        if np.any(self.segment_lengths_m <= 0):
            raise ValueError("zero-length path segments are not supported")
        for name in ("path_version", "goal_version"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, Integral) or value < 0:
                raise ValueError(f"{name} must be a nonnegative integer")

    @property
    def segment_lengths_m(self) -> np.ndarray:
        return np.linalg.norm(np.diff(self.points_xy_m, axis=0), axis=1)


@dataclass(frozen=True)
class ActionPrediction:
    action_id: int
    speed_mps: np.ndarray
    acceleration_mps2: np.ndarray
    segment_indices: np.ndarray
    point_speed_mps: np.ndarray
    point_clearance_m: np.ndarray
    roll_error_rad: np.ndarray
    pitch_error_rad: np.ndarray
    roll_limits_rad: np.ndarray | None = None
    pitch_limits_rad: np.ndarray | None = None

    def __post_init__(self) -> None:
        if isinstance(self.action_id, bool) or not isinstance(self.action_id, Integral) or self.action_id < 0:
            raise ValueError("action_id must be a nonnegative integer")
        speed = np.asarray(self.speed_mps)
        points = np.asarray(self.point_speed_mps)
        if speed.ndim != 1 or len(speed) < 1 or points.ndim != 1 or len(points) < 2:
            raise ValueError("prediction needs control steps and path point speeds")
        for name, count, nonnegative in (
            ("speed_mps", len(speed), True), ("acceleration_mps2", len(speed), False),
            ("point_speed_mps", len(points), True), ("point_clearance_m", len(points), False),
            ("roll_error_rad", len(speed), True), ("pitch_error_rad", len(speed), True),
        ):
            object.__setattr__(self, name, _array(getattr(self, name), name, (count,), nonnegative=nonnegative))
        indices = np.asarray(self.segment_indices)
        if indices.shape != speed.shape or not np.issubdtype(indices.dtype, np.integer) or np.any(indices < 0):
            raise ValueError("segment_indices must be nonnegative integers, one per control step")
        indices = np.array(indices, dtype=np.int64, copy=True)
        indices.setflags(write=False)
        object.__setattr__(self, "segment_indices", indices)
        for name in ("roll_limits_rad", "pitch_limits_rad"):
            if getattr(self, name) is not None:
                limits = _array(getattr(self, name), name, speed.shape, nonnegative=True)
                if np.any(limits <= 0):
                    raise ValueError("attitude limits must be positive")
                object.__setattr__(self, name, limits)


@dataclass(frozen=True)
class DecisionContext:
    goal_xy_m: tuple[float, float]
    current_posture: int
    speed_mps: float
    roll_rad: float
    pitch_rad: float
    goal_version: int
    path_version: int

    def __post_init__(self) -> None:
        _array(self.goal_xy_m, "goal_xy_m", (2,))
        _index(self.current_posture, 3, "current_posture")
        for name in ("speed_mps", "roll_rad", "pitch_rad"):
            _finite(getattr(self, name), name)
        for name in ("goal_version", "path_version"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, Integral) or value < 0:
                raise ValueError(f"{name} must be a nonnegative integer")


@dataclass(frozen=True)
class FormulaEvaluation:
    action_id: int
    path_index: int
    posture_index: int
    speed_index: int
    feasible: bool
    reasons: tuple[str, ...]
    energy_j: float = 0.0
    time_s: float = 0.0
    length_m: float = 0.0
    clearance_cost: float = 0.0
    switch_cost: float = 0.0
    penalty_clearance: float = 0.0
    penalty_height: float = 0.0
    penalty_attitude: float = 0.0
    objective: float | None = None
    reward: float | None = None


def safe_distance(speed_mps, posture: PostureModel, config: FormulaConfig):
    speed = np.asarray(speed_mps, dtype=np.float64)
    if not np.isfinite(speed).all() or np.any(speed < 0):
        raise ValueError("speed must be finite and nonnegative")
    return (posture.base_clearance_m + config.reaction_time_s * speed
            + speed ** 2 / (2 * posture.braking_mps2) + config.distance_margin_m)


def evaluate_action(path: PathPrediction, prediction: ActionPrediction, context: DecisionContext,
                    config: FormulaConfig, path_count: int, *, require_calibration: bool = True) -> FormulaEvaluation:
    path_index, posture_index, speed_index = decode_action(prediction.action_id, path_count)
    posture = config.postures[posture_index]
    indices = prediction.segment_indices
    if len(prediction.point_speed_mps) != len(path.points_xy_m) or np.any(indices >= len(path.segment_lengths_m)):
        raise ValueError("prediction does not align with path points/segments")
    if np.any(np.diff(indices) < 0) or not np.array_equal(np.unique(indices), np.arange(len(path.segment_lengths_m))):
        raise ValueError("whole-route prediction must visit all path segments in order")
    lengths = path.segment_lengths_m
    slopes = np.arctan2(np.diff(path.elevation_m), lengths)
    pitch = slopes[indices] + np.arctan2(-prediction.acceleration_mps2, config.gravity_mps2)
    roll = (np.arctan2(prediction.speed_mps ** 2 * path.curvature_per_m[indices],
                       config.gravity_mps2 * np.cos(pitch))
            + path.terrain_roll_rad[indices] + config.roll_bias_rad)
    roll_limits = np.full(len(indices), posture.roll_max_rad)
    pitch_limits = np.full(len(indices), posture.pitch_max_rad)
    if prediction.roll_limits_rad is not None:
        roll_limits = np.minimum(roll_limits, prediction.roll_limits_rad)
    if prediction.pitch_limits_rad is not None:
        pitch_limits = np.minimum(pitch_limits, prediction.pitch_limits_rad)
    roll_excess = np.maximum(np.abs(roll) + prediction.roll_error_rad - roll_limits, 0)
    pitch_excess = np.maximum(np.abs(pitch) + prediction.pitch_error_rad - pitch_limits, 0)
    clearance_margin = prediction.point_clearance_m - safe_distance(prediction.point_speed_mps, posture, config)
    height_margin = path.ceiling_height_m - posture.body_height_m - config.height_margin_m
    power = posture.power
    predicted_power = (power.idle_w + power.velocity_w * prediction.speed_mps ** 2
                       + power.acceleration_w * np.abs(prediction.acceleration_mps2)
                       + power.curvature_w * prediction.speed_mps ** 2 * np.abs(path.curvature_per_m[indices])
                       + power.slope_w * np.abs(np.sin(slopes[indices]))
                       + power.roughness_w * path.roughness_rms_m[indices])
    switched = posture_index != context.current_posture
    energy = float(np.sum(predicted_power) * config.dt_s)
    time = len(indices) * config.dt_s + config.switch_times_s[context.current_posture][posture_index] * switched
    length = float(np.sum(lengths))
    with np.errstate(over="ignore"):
        clearance_cost = float(np.sum(lengths * np.exp(-clearance_margin[:-1] / config.clearance_sigma_m)) / length)
    penalty_clearance = float(np.mean(np.maximum(-clearance_margin, 0)) / config.distance_ref_m)
    penalty_height = float(np.mean(np.maximum(-height_margin, 0)) / config.height_ref_m)
    penalty_attitude = float(np.mean(roll_excess / config.roll_ref_rad + pitch_excess / config.pitch_ref_rad))
    weights = config.weights
    objective = (weights.energy * energy / config.energy_ref_j + weights.time * time / config.time_ref_s
                 + weights.length * length / config.length_ref_m + weights.clearance * clearance_cost
                 + weights.switch * switched)
    reward = (-objective - config.penalty_clearance * penalty_clearance
              - config.penalty_height * penalty_height - config.penalty_attitude * penalty_attitude)
    reasons = []
    if require_calibration and not config.calibrated:
        reasons.append("missing_calibration")
    if (path.path_version, path.goal_version) != (context.path_version, context.goal_version):
        reasons.append("stale_path_or_goal_version")
    if np.linalg.norm(path.points_xy_m[-1] - context.goal_xy_m) > config.goal_tolerance_m:
        reasons.append("goal_mismatch")
    if np.any(clearance_margin < 0):
        reasons.append("obstacle_clearance")
    if np.any(height_margin < 0):
        reasons.append("overhead_clearance")
    if max(float(np.max(prediction.speed_mps)), float(np.max(prediction.point_speed_mps))) > posture.vmax_mps:
        reasons.append("speed_limit")
    if switched and (abs(context.speed_mps) > config.switch_speed_max_mps
                     or abs(context.roll_rad) > config.switch_roll_max_rad
                     or abs(context.pitch_rad) > config.switch_pitch_max_rad):
        reasons.append("unsafe_posture_switch")
    if np.any(roll_excess > 0) or np.any(pitch_excess > 0):
        reasons.append("predicted_attitude")
    if not np.isfinite((energy, time, length, clearance_cost, objective, reward)).all():
        reasons.append("nonfinite_objective")
        objective, reward, clearance_cost = None, None, 0.0
    return FormulaEvaluation(prediction.action_id, path_index, posture_index, speed_index, not reasons,
                             tuple(reasons), energy, time, length, clearance_cost, float(switched),
                             penalty_clearance, penalty_height, penalty_attitude, objective, reward)


def evaluate_candidates(paths: tuple[PathPrediction, ...], predictions: tuple[ActionPrediction, ...],
                        context: DecisionContext, config: FormulaConfig, *,
                        require_calibration: bool = True) -> tuple[FormulaEvaluation, ...]:
    _positive_integer(len(paths), "path_count")
    if len({path.path_id for path in paths}) != len(paths):
        raise ValueError("path identifiers must be unique")
    by_action = {}
    for prediction in predictions:
        decode_action(prediction.action_id, len(paths))
        if prediction.action_id in by_action:
            raise ValueError("duplicate action prediction")
        by_action[prediction.action_id] = prediction
    evaluations = []
    for action_id in range(ACTIONS_PER_PATH * len(paths)):
        path_index, posture_index, speed_index = decode_action(action_id, len(paths))
        if action_id not in by_action:
            evaluations.append(FormulaEvaluation(action_id, path_index, posture_index, speed_index,
                                                 False, ("missing_prediction",)))
        else:
            evaluations.append(evaluate_action(paths[path_index], by_action[action_id], context, config,
                                               len(paths), require_calibration=require_calibration))
    return tuple(evaluations)


def enumerate_best(evaluations: tuple[FormulaEvaluation, ...]) -> FormulaEvaluation | None:
    feasible = [item for item in evaluations if item.feasible and item.objective is not None]
    return min(feasible, key=lambda item: (item.objective, item.action_id)) if feasible else None
