"""Small vectorized three-route environment for upper-policy feasibility tests.

This environment is intentionally not a replacement for Isaac Sim.  It is a
fast first-stage model that exercises the exact action contract, objective,
route locking, masks, metrics, and PPO implementation before an expensive
closed-loop Isaac/MPPI run.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np

from .upper_level_objective import (
    action_mask,
    braking_clearance,
    incremental_terms,
    scalar_cost,
)
from .upper_level_types import (
    ROUTE_HEIGHTS_CM,
    SPEED_RATIOS,
    EpisodeMetrics,
    RouteCandidate,
    UpperNormalization,
    UpperObjectiveWeights,
    UpperObservation,
    UpperSafetyConfig,
    decode_action,
)


@dataclass(frozen=True)
class ToyScenario:
    route_length_m: np.ndarray
    lateral_clearance_m: np.ndarray
    overhead_margin_m: np.ndarray
    mean_slope_rad: np.ndarray
    max_slope_rad: np.ndarray
    roughness_rms_m: np.ndarray
    curvature_integral: np.ndarray

    def __post_init__(self) -> None:
        for name in self.__dataclass_fields__:
            value = np.asarray(getattr(self, name))
            if value.shape != (3,) or not np.isfinite(value).all():
                raise ValueError(f"{name} must be a finite three-vector")


def sample_scenario(generator: np.random.Generator, split: str) -> ToyScenario:
    """Generate a reproducible short/mid/open scenario without shared samples."""

    split_offsets = {
        "train": 0.0,
        "validation": 0.012,
        "test": -0.008,
        "gate": 0.0,
    }
    if split not in split_offsets:
        raise ValueError("split must be train, validation, test, or gate")
    if split == "gate":
        return ToyScenario(
            route_length_m=np.asarray((3.2, 3.7, 4.2)),
            lateral_clearance_m=np.asarray((0.45, 0.45, 0.45)),
            overhead_margin_m=np.asarray((0.08, 0.10, 0.15)),
            mean_slope_rad=np.asarray((0.01, 0.01, 0.01)),
            max_slope_rad=np.asarray((0.02, 0.02, 0.02)),
            roughness_rms_m=np.asarray((0.002, 0.002, 0.002)),
            curvature_integral=np.asarray((0.04, 0.04, 0.04)),
        )
    offset = split_offsets[split]
    lengths = np.asarray((3.35, 4.0, 4.6)) + generator.normal(0.0, 0.52, 3)
    # Occasionally make terrain cost more important than geometric length.
    difficulty = generator.permutation(np.asarray((0.0, 0.5, 1.0)))
    slope = 0.015 + 0.075 * difficulty + generator.uniform(0.0, 0.018, 3)
    roughness = 0.004 + 0.018 * difficulty + generator.uniform(0.0, 0.004, 3)
    curvature = 0.05 + 0.28 * generator.random(3)
    overhead = np.asarray((0.025, 0.070, 0.14)) + offset
    overhead += generator.uniform(-0.022, 0.030, 3)
    overhead = np.maximum(overhead, 0.005)
    # Balance the three speed actions through the actual braking-envelope
    # mask.  Every route admits rho=0.4; a sampled class admits either one,
    # two, or all three speed ratios.
    safety = UpperSafetyConfig()
    maximum_speed_class = generator.integers(0, 3, size=3)
    lateral = np.zeros(3)
    for route_index, speed_class in enumerate(maximum_speed_class):
        thresholds = [
            braking_clearance(
                ratio * safety.posture_vmax_mps[route_index], route_index, safety
            )
            for ratio in SPEED_RATIOS
        ]
        if speed_class == 0:
            lateral[route_index] = 0.5 * (thresholds[0] + thresholds[1])
        elif speed_class == 1:
            lateral[route_index] = 0.5 * (thresholds[1] + thresholds[2])
        else:
            lateral[route_index] = thresholds[2] + generator.uniform(0.012, 0.055)
    return ToyScenario(
        route_length_m=np.maximum(lengths, 2.8),
        lateral_clearance_m=lateral,
        overhead_margin_m=overhead,
        mean_slope_rad=slope,
        max_slope_rad=slope + generator.uniform(0.015, 0.045, 3),
        roughness_rms_m=roughness,
        curvature_integral=curvature,
    )


class UpperLevelToyEnv:
    """Numpy-vectorized episodic environment with 0.5 s upper decisions."""

    def __init__(
        self,
        num_envs: int = 16,
        seed: int = 11,
        split: str = "train",
        normalization: UpperNormalization | None = None,
        weights: UpperObjectiveWeights | None = None,
        safety: UpperSafetyConfig | None = None,
        maximum_steps: int = 320,
    ) -> None:
        if num_envs <= 0 or maximum_steps <= 0:
            raise ValueError("num_envs and maximum_steps must be positive")
        self.num_envs = int(num_envs)
        self.seed = int(seed)
        self.split = split
        self.normalization = normalization or UpperNormalization()
        self.weights = weights or UpperObjectiveWeights()
        self.safety = safety or UpperSafetyConfig()
        self.maximum_steps = int(maximum_steps)
        self._episode_counter = np.zeros(self.num_envs, dtype=np.int64)
        self._scenarios: list[ToyScenario] = []
        self._progress = np.zeros(self.num_envs)
        self._speed = np.zeros(self.num_envs)
        self._roll = np.zeros(self.num_envs)
        self._pitch = np.zeros(self.num_envs)
        self._current_route = np.ones(self.num_envs, dtype=np.int64)
        self._previous_speed = np.ones(self.num_envs, dtype=np.int64)
        self._transition_phase = np.zeros(self.num_envs)
        self._stable_elapsed = np.full(self.num_envs, self.safety.switch_hold_time_s)
        self._route_locked = np.zeros(self.num_envs, dtype=np.bool_)
        self._energy = np.zeros(self.num_envs)
        self._elapsed = np.zeros(self.num_envs)
        self._distance = np.zeros(self.num_envs)
        self._reward = np.zeros(self.num_envs)
        self._cost = np.zeros(self.num_envs)
        self._switches = np.zeros(self.num_envs, dtype=np.int64)
        self._steps = np.zeros(self.num_envs, dtype=np.int64)
        self._minimum_overhead = np.full(self.num_envs, np.inf)
        self._minimum_lateral = np.full(self.num_envs, np.inf)
        self._maximum_roll = np.zeros(self.num_envs)
        self._maximum_pitch = np.zeros(self.num_envs)
        self._collision = np.zeros(self.num_envs, dtype=np.bool_)
        self._hard_violation = np.zeros(self.num_envs, dtype=np.bool_)
        self._latencies: list[list[float]] = [[] for _ in range(self.num_envs)]
        self.reset()

    def _reset_index(self, index: int) -> None:
        episode_number = int(self._episode_counter[index]) + 1
        split_offset = {
            "train": 0,
            "validation": 10_000_019,
            "test": 20_000_033,
            "gate": 30_000_041,
        }[self.split]
        scenario_generator = np.random.default_rng(
            self.seed + split_offset + 104_729 * episode_number + 9_176 * index
        )
        scenario = sample_scenario(scenario_generator, self.split)
        if index < len(self._scenarios):
            self._scenarios[index] = scenario
        else:
            self._scenarios.append(scenario)
        self._episode_counter[index] += 1
        self._progress[index] = 0.0
        self._speed[index] = 0.0
        self._roll[index] = 0.0
        self._pitch[index] = 0.0
        self._current_route[index] = 1
        self._previous_speed[index] = 1
        self._transition_phase[index] = 0.0
        self._stable_elapsed[index] = self.safety.switch_hold_time_s
        self._route_locked[index] = False
        self._energy[index] = 0.0
        self._elapsed[index] = 0.0
        self._distance[index] = 0.0
        self._reward[index] = 0.0
        self._cost[index] = 0.0
        self._switches[index] = 0
        self._steps[index] = 0
        self._minimum_overhead[index] = np.inf
        self._minimum_lateral[index] = np.inf
        self._maximum_roll[index] = 0.0
        self._maximum_pitch[index] = 0.0
        self._collision[index] = False
        self._hard_violation[index] = False
        self._latencies[index] = []

    def reset(self, indices: Iterable[int] | None = None) -> tuple[np.ndarray, np.ndarray]:
        target = range(self.num_envs) if indices is None else tuple(int(i) for i in indices)
        for index in target:
            self._reset_index(index)
        return self.observation_matrix(), self.action_masks()

    def observation(self, index: int) -> UpperObservation:
        scenario = self._scenarios[index]
        remaining_fraction = max(0.0, 1.0 - self._progress[index])
        version = int(self._episode_counter[index])
        routes = tuple(
            RouteCandidate(
                height_cm=ROUTE_HEIGHTS_CM[route_index],
                valid=True,
                remaining_length_m=float(
                    scenario.route_length_m[route_index] * remaining_fraction
                ),
                lateral_clearance_m=float(scenario.lateral_clearance_m[route_index]),
                overhead_margin_m=float(scenario.overhead_margin_m[route_index]),
                mean_slope_rad=float(scenario.mean_slope_rad[route_index]),
                max_slope_rad=float(scenario.max_slope_rad[route_index]),
                roughness_rms_m=float(scenario.roughness_rms_m[route_index]),
                curvature_integral=float(scenario.curvature_integral[route_index]),
                path_version=version,
                goal_version=version,
            )
            for route_index in range(3)
        )
        route = self._current_route[index]
        return UpperObservation(
            routes=routes,  # type: ignore[arg-type]
            speed_mps=float(self._speed[index]),
            roll_rad=float(self._roll[index]),
            pitch_rad=float(self._pitch[index]),
            current_route=int(route),
            previous_speed_index=int(self._previous_speed[index]),
            transition_phase=float(self._transition_phase[index]),
            energy_accumulator_j=float(self._energy[index]),
            remaining_goal_distance_m=float(routes[route].remaining_length_m),
            path_age_s=0.05,
            goal_age_s=0.05,
            stable_elapsed_s=float(self._stable_elapsed[index]),
            route_locked=bool(self._route_locked[index]),
            sensor_valid=True,
        )

    def observation_matrix(self) -> np.ndarray:
        return np.stack([self.observation(i).vector() for i in range(self.num_envs)])

    def action_masks(self) -> np.ndarray:
        return np.stack(
            [action_mask(self.observation(i), self.safety) for i in range(self.num_envs)]
        )

    def add_decision_latency(self, index: int, latency_ms: float) -> None:
        self._latencies[index].append(float(latency_ms))

    def episode_metrics(self, index: int, method: str, success: bool) -> EpisodeMetrics:
        distance = float(self._distance[index])
        energy = float(self._energy[index])
        cot = 0.0 if distance <= 0.0 else energy / (29.0254 * 9.81 * distance)
        return EpisodeMetrics(
            method=method,
            seed=self.seed,
            episode=int(self._episode_counter[index]),
            success=bool(success),
            collision=bool(self._collision[index]),
            hard_violation=bool(self._hard_violation[index]),
            total_cost=float(self._cost[index]),
            total_reward=float(self._reward[index]),
            elapsed_s=float(self._elapsed[index]),
            distance_m=distance,
            mechanical_energy_j=energy,
            mechanical_cot=cot,
            switches=int(self._switches[index]),
            minimum_overhead_margin_m=float(self._minimum_overhead[index]),
            minimum_lateral_clearance_m=float(self._minimum_lateral[index]),
            maximum_abs_roll_rad=float(self._maximum_roll[index]),
            maximum_abs_pitch_rad=float(self._maximum_pitch[index]),
            decision_latency_ms=list(self._latencies[index]),
        )

    def step(
        self, actions: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, list[dict[str, object]], np.ndarray]:
        actions = np.asarray(actions, dtype=np.int64)
        if actions.shape != (self.num_envs,):
            raise ValueError(f"actions must have shape ({self.num_envs},)")
        rewards = np.zeros(self.num_envs, dtype=np.float32)
        done = np.zeros(self.num_envs, dtype=np.bool_)
        information: list[dict[str, object]] = []
        for index, action_id in enumerate(actions):
            observation = self.observation(index)
            mask = action_mask(observation, self.safety)
            if action_id < 0 or action_id >= 9 or not mask[action_id]:
                rewards[index] = -5.0
                self._reward[index] += rewards[index]
                self._cost[index] += 5.0
                self._hard_violation[index] = True
                done[index] = True
                information.append(
                    {"success": False, "hard_violation": True, "reason": "invalid_action"}
                )
                continue

            route_index, speed_index = decode_action(int(action_id))
            scenario = self._scenarios[index]
            switched = route_index != self._current_route[index]
            if switched:
                self._switches[index] += 1
                self._current_route[index] = route_index
                self._transition_phase[index] = 1.0
                self._stable_elapsed[index] = 0.0
            else:
                self._transition_phase[index] = max(
                    0.0,
                    self._transition_phase[index]
                    - self.safety.decision_dt_s / 1.5,
                )

            ratio = SPEED_RATIOS[speed_index]
            target_speed = ratio * self.safety.posture_vmax_mps[route_index]
            terrain_factor = max(
                0.40,
                1.0
                - 1.4 * scenario.mean_slope_rad[route_index]
                - 3.0 * scenario.roughness_rms_m[route_index]
                - 0.15 * scenario.curvature_integral[route_index],
            )
            transition_factor = 0.55 if switched else 1.0
            speed = target_speed * terrain_factor * transition_factor
            dt = self.safety.decision_dt_s
            distance = speed * dt
            route_length = scenario.route_length_m[route_index]
            self._progress[index] = min(1.0, self._progress[index] + distance / route_length)
            self._speed[index] = speed
            self._previous_speed[index] = speed_index
            self._stable_elapsed[index] = (
                0.0
                if switched
                else self._stable_elapsed[index] + self.safety.decision_dt_s
            )
            self._route_locked[index] = self._progress[index] >= 0.25

            slope_load = 1.0 + 3.0 * abs(scenario.mean_slope_rad[route_index])
            terrain_load = (
                1.0
                + 8.0 * scenario.roughness_rms_m[route_index]
                + scenario.curvature_integral[route_index]
            )
            posture_power = (0.24, 0.20, 0.22)[route_index]
            power = posture_power + 5.0 * speed * speed * slope_load * terrain_load
            energy = power * dt
            noise_generator = np.random.default_rng(
                self.seed
                + 1_000_003 * int(self._episode_counter[index])
                + 9_176 * index
                + 101 * int(self._steps[index])
            )
            noise = noise_generator.normal(0.0, 0.003, 2)
            roll = (
                3.5 * scenario.roughness_rms_m[route_index]
                + 0.10 * scenario.curvature_integral[route_index]
                + noise[0]
            )
            pitch = scenario.mean_slope_rad[route_index] + noise[1]
            self._roll[index] = roll
            self._pitch[index] = pitch
            overhead = scenario.overhead_margin_m[route_index]
            lateral = scenario.lateral_clearance_m[route_index]
            clearance_violation = lateral < braking_clearance(speed, route_index, self.safety)
            height_violation = overhead < 0.0
            attitude_violation = (
                abs(roll) >= self.safety.attitude_hard_rad
                or abs(pitch) >= self.safety.attitude_hard_rad
            )
            collision = clearance_violation or height_violation
            terms = incremental_terms(
                energy_j=energy,
                elapsed_s=dt,
                distance_m=distance,
                overhead_margin_m=float(overhead),
                switched=switched,
                roll_rad=roll,
                pitch_rad=pitch,
                normalization=self.normalization,
                safety=self.safety,
                clearance_violation=clearance_violation,
                height_violation=height_violation,
            )
            cost = scalar_cost(terms, self.weights)
            reward = -cost
            success = self._progress[index] >= 1.0
            self._steps[index] += 1
            timeout = self._steps[index] >= self.maximum_steps
            hard_violation = collision or attitude_violation
            if hard_violation:
                reward -= 5.0
                cost += 5.0
            done[index] = success or timeout or hard_violation
            rewards[index] = reward
            self._energy[index] += energy
            self._elapsed[index] += dt
            self._distance[index] += distance
            self._reward[index] += reward
            self._cost[index] += cost
            self._minimum_overhead[index] = min(self._minimum_overhead[index], overhead)
            self._minimum_lateral[index] = min(self._minimum_lateral[index], lateral)
            self._maximum_roll[index] = max(self._maximum_roll[index], abs(roll))
            self._maximum_pitch[index] = max(self._maximum_pitch[index], abs(pitch))
            self._collision[index] |= collision
            self._hard_violation[index] |= hard_violation
            information.append(
                {
                    "success": bool(success),
                    "timeout": bool(timeout),
                    "collision": bool(collision),
                    "hard_violation": bool(hard_violation),
                    "terms": terms.as_dict(),
                }
            )
        return self.observation_matrix(), rewards, done, information, self.action_masks()
