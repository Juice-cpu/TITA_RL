"""Deterministic left/right phase prior for TITA stair negotiation."""

from __future__ import annotations

from dataclasses import dataclass

import torch


STAIR_PHASE_COUNT = 7
STAIR_PHASE_APPROACH = 0
STAIR_PHASE_SHIFT_TO_TRAIL = 1
STAIR_PHASE_LEAD_RETRACT = 2
STAIR_PHASE_LEAD_PLACE = 3
STAIR_PHASE_TRAIL_RETRACT = 4
STAIR_PHASE_TRAIL_PLACE = 5
STAIR_PHASE_SETTLE = 6


def ground_relative_wheel_reference(wheel_axis_z, support_height):
    if wheel_axis_z.ndim != 2 or wheel_axis_z.shape[1] != 2 or support_height.shape != wheel_axis_z.shape[:1]:
        raise ValueError("ground reference requires two wheel axes and one support height per robot")
    return wheel_axis_z - support_height[:, None]


def fully_supported_stair_traversal(wheel_local_x, verified_level, final_edge_x, platform_end_x,
                                   total_levels, wheel_radius_m, edge_margin_m=.03):
    count = wheel_local_x.shape[0]
    if wheel_local_x.shape != (count, 2) or any(value.shape != (count,) for value in
                                               (verified_level, final_edge_x, platform_end_x)):
        raise ValueError("stair traversal requires two wheels and aligned support geometry")
    if total_levels < 1 or wheel_radius_m <= 0. or edge_margin_m < 0.:
        raise ValueError("invalid stair support limits")
    clearance = wheel_radius_m + edge_margin_m
    fully_on_tread = ((wheel_local_x >= final_edge_x[:, None] + clearance)
                      & (wheel_local_x <= platform_end_x[:, None] - clearance)).all(1)
    return fully_on_tread & (verified_level >= total_levels)


def gate_stair_residual(
    actions: torch.Tensor, phase: torch.Tensor, enabled: bool
) -> torch.Tensor:
    """Enable full residual control only during the rolling-contact window."""
    if actions.ndim != 2 or actions.shape[1] != 8:
        raise ValueError("actions must have shape (N, 8)")
    if phase.shape != (actions.shape[0],):
        raise ValueError("phase must have shape (N,)")
    if not enabled:
        return actions
    active = (phase >= STAIR_PHASE_SHIFT_TO_TRAIL) & (
        phase <= STAIR_PHASE_TRAIL_PLACE
    )
    return torch.where(active[:, None], actions, 0.0)


def lead_place_residual_prior(
    phase: torch.Tensor,
    lead_is_left: torch.Tensor,
    lead_hip: float,
    lead_knee: float,
    support_hip: float,
    support_knee: float,
) -> torch.Tensor:
    """Build a filtered-action prior used only while placing the first wheel."""
    if phase.ndim != 1 or lead_is_left.shape != phase.shape:
        raise ValueError("phase and lead_is_left must be matching vectors")
    if lead_is_left.dtype != torch.bool:
        raise ValueError("lead_is_left must be boolean")
    values = torch.tensor(
        (lead_hip, lead_knee, support_hip, support_knee),
        dtype=torch.float32,
        device=phase.device,
    )
    if not torch.isfinite(values).all():
        raise ValueError("lead-place residual prior must be finite")
    prior = torch.zeros(phase.shape[0], 8, dtype=torch.float32, device=phase.device)
    active = phase == STAIR_PHASE_LEAD_PLACE
    left_lead = active & lead_is_left
    right_lead = active & ~lead_is_left
    prior[left_lead, 1] = values[0]
    prior[left_lead, 2] = values[1]
    prior[left_lead, 5] = values[2]
    prior[left_lead, 6] = values[3]
    prior[right_lead, 5] = values[0]
    prior[right_lead, 6] = values[1]
    prior[right_lead, 1] = values[2]
    prior[right_lead, 2] = values[3]
    return prior


@dataclass(frozen=True)
class StairStepSequenceConfig:
    shift_steps: int
    retract_steps: int
    place_steps: int
    settle_steps: int
    hip_retract_rad: float
    hip_place_rad: float
    knee_retract_rad: float
    knee_place_rad: float
    support_hip_rad: float = 0.25
    support_knee_rad: float = 0.30
    lateral_shift_rad: float = 0.0
    support_lateral_scale: float = 0.0
    inward_hold_rad: float = 0.0
    wheel_drive: float = 0.0
    wheel_impulse_scale: float = 1.0
    event_driven: bool = False
    drive_from_shift: bool = False

    def validate(self) -> None:
        if (
            self.shift_steps <= 0
            or self.retract_steps <= 0
            or self.place_steps <= 0
            or self.settle_steps <= 0
        ):
            raise ValueError("stair phase durations must be positive")
        amplitudes = (
            self.hip_retract_rad,
            self.hip_place_rad,
            self.knee_retract_rad,
            self.knee_place_rad,
            self.support_hip_rad,
            self.support_knee_rad,
            self.inward_hold_rad,
        )
        if any(value < 0.0 for value in amplitudes):
            raise ValueError("stair leg amplitudes must be non-negative")
        if not 0.0 <= self.support_lateral_scale <= 1.0:
            raise ValueError("support_lateral_scale must be in [0, 1]")
        if not isinstance(self.event_driven, bool) or not isinstance(
            self.drive_from_shift, bool
        ):
            raise ValueError("stair sequence mode flags must be boolean")
        if self.wheel_impulse_scale < 1.0:
            raise ValueError("wheel_impulse_scale must be at least 1")
        if not torch.isfinite(
            torch.tensor(
                (
                    *amplitudes,
                    self.lateral_shift_rad,
                    self.support_lateral_scale,
                    self.wheel_drive,
                    self.wheel_impulse_scale,
                )
            )
        ).all():
            raise ValueError("stair sequence values must be finite")

    @property
    def total_steps(self) -> int:
        return (
            self.shift_steps
            + 2 * (self.retract_steps + self.place_steps)
            + self.settle_steps
        )

    @property
    def trail_place_start(self) -> int:
        return self.shift_steps + 2 * self.retract_steps + self.place_steps


def _smoothstep(value: torch.Tensor) -> torch.Tensor:
    value = value.clamp(0.0, 1.0)
    return value * value * (3.0 - 2.0 * value)


def stair_phase(
    sequence_step: torch.Tensor, config: StairStepSequenceConfig
) -> tuple[torch.Tensor, torch.Tensor]:
    """Return phase id and within-phase progress for each environment."""
    config.validate()
    if sequence_step.ndim != 1:
        raise ValueError("sequence_step must be one-dimensional")
    phase = torch.zeros_like(sequence_step)
    progress = torch.zeros_like(sequence_step, dtype=torch.float32)
    starts = (
        0,
        config.shift_steps,
        config.shift_steps + config.retract_steps,
        config.shift_steps + config.retract_steps + config.place_steps,
        config.shift_steps + 2 * config.retract_steps + config.place_steps,
        config.shift_steps + 2 * (config.retract_steps + config.place_steps),
    )
    durations = (
        config.shift_steps,
        config.retract_steps,
        config.place_steps,
        config.retract_steps,
        config.place_steps,
        config.settle_steps,
    )
    for phase_id, (start, duration) in enumerate(zip(starts, durations), start=1):
        active = (sequence_step >= start) & (sequence_step < start + duration)
        phase[active] = phase_id
        progress[active] = (
            (sequence_step[active] - start).to(torch.float32) + 1.0
        ) / float(duration)
    return phase, progress.clamp(0.0, 1.0)


def advance_stair_sequence(
    sequence_step: torch.Tensor,
    lead_reached: torch.Tensor,
    trail_reached: torch.Tensor,
    config: StairStepSequenceConfig,
) -> torch.Tensor:
    """Advance a rolling step, using wheel-on-tread events when available.

    Weight transfer keeps a short fixed duration.  Once either commanded wheel
    reaches the tread, the next side starts immediately.  Without that event,
    the nominal ramp completes and holds its edge-contact target.
    """
    if sequence_step.ndim != 1:
        raise ValueError("sequence_step must be one-dimensional")
    if lead_reached.shape != sequence_step.shape or lead_reached.dtype != torch.bool:
        raise ValueError("lead_reached must be a matching boolean tensor")
    if trail_reached.shape != sequence_step.shape or trail_reached.dtype != torch.bool:
        raise ValueError("trail_reached must be a matching boolean tensor")
    config.validate()

    next_step = sequence_step.clone()
    lead_place_end = config.shift_steps + config.retract_steps + config.place_steps - 1
    trail_retract_start = lead_place_end + 1
    trail_place_end = (
        config.shift_steps + 2 * (config.retract_steps + config.place_steps) - 1
    )
    settle_start = trail_place_end + 1

    active = (next_step >= 0) & (next_step < config.total_steps)
    wait_for_lead = (next_step == lead_place_end) & ~lead_reached
    wait_for_trail = (next_step == trail_place_end) & ~trail_reached
    next_step[active & ~wait_for_lead & ~wait_for_trail] += 1
    if config.event_driven:
        lead_motion = (sequence_step >= config.shift_steps) & (
            sequence_step <= lead_place_end
        )
        trail_motion = (sequence_step >= trail_retract_start) & (
            sequence_step <= trail_place_end
        )
        next_step[lead_motion & lead_reached] = trail_retract_start
        next_step[trail_motion & trail_reached] = settle_start
    else:
        next_step[(sequence_step == lead_place_end) & lead_reached] = trail_retract_start
        next_step[(sequence_step == trail_place_end) & trail_reached] = settle_start
    return next_step


def transition_sequence_on_level_advance(
    sequence_step: torch.Tensor,
    previous_level: torch.Tensor,
    current_level: torch.Tensor,
    total_levels: int,
    config: StairStepSequenceConfig,
) -> torch.Tensor:
    """Re-arm intermediate steps and settle permanently on the final tread."""
    if sequence_step.ndim != 1:
        raise ValueError("sequence_step must be one-dimensional")
    if previous_level.shape != sequence_step.shape:
        raise ValueError("previous_level must match sequence_step")
    if current_level.shape != sequence_step.shape:
        raise ValueError("current_level must match sequence_step")
    if total_levels <= 0:
        raise ValueError("total_levels must be positive")
    config.validate()

    result = sequence_step.clone()
    advanced = current_level > previous_level
    reached_final = advanced & (current_level >= total_levels)
    result[advanced & ~reached_final] = -1
    result[reached_final] = config.total_steps - config.settle_steps
    return result


def stair_stable_state(
    completed: torch.Tensor,
    collision: torch.Tensor,
    root_linear_velocity_w: torch.Tensor,
    projected_gravity_b: torch.Tensor,
    planar_speed_limit: float = 0.20,
    vertical_speed_limit: float = 0.15,
    attitude_limit: float = 0.25,
) -> torch.Tensor:
    """Return the strict post-stair stability predicate used for reward shaping."""
    if completed.ndim != 1 or collision.shape != completed.shape:
        raise ValueError("completed and collision must be matching vectors")
    if completed.dtype != torch.bool or collision.dtype != torch.bool:
        raise ValueError("completed and collision must be boolean")
    expected = (completed.shape[0], 3)
    if root_linear_velocity_w.shape != expected:
        raise ValueError("root_linear_velocity_w must have shape (N, 3)")
    if projected_gravity_b.shape != expected:
        raise ValueError("projected_gravity_b must have shape (N, 3)")
    if min(planar_speed_limit, vertical_speed_limit, attitude_limit) <= 0.0:
        raise ValueError("stability limits must be positive")

    planar_speed = torch.linalg.vector_norm(root_linear_velocity_w[:, :2], dim=1)
    gravity = projected_gravity_b
    roll = torch.atan2(gravity[:, 1], -gravity[:, 2])
    pitch = torch.atan2(
        -gravity[:, 0],
        torch.sqrt(torch.square(gravity[:, 1]) + torch.square(gravity[:, 2])),
    )
    return (
        completed
        & ~collision
        & (planar_speed <= planar_speed_limit)
        & (root_linear_velocity_w[:, 2].abs() <= vertical_speed_limit)
        & (roll.abs() <= attitude_limit)
        & (pitch.abs() <= attitude_limit)
    )


def stair_stationary_state(completed, collision, root_linear_velocity_w, projected_gravity_b,
                           wheel_contacts, posture_height_error_m):
    if wheel_contacts.shape != (completed.shape[0], 2) or wheel_contacts.dtype != torch.bool:
        raise ValueError("stationary stair acceptance requires two boolean wheel contacts")
    if posture_height_error_m.shape != completed.shape:
        raise ValueError("posture height errors must match the environment count")
    return (stair_stable_state(completed, collision, root_linear_velocity_w, projected_gravity_b,
                               planar_speed_limit=.08, vertical_speed_limit=.10, attitude_limit=.12)
            & wheel_contacts.all(1) & (posture_height_error_m.abs() <= .025))


def select_reached_wheel_as_lead(
    lead_is_left: torch.Tensor,
    wheel_levels: torch.Tensor,
    current_level: torch.Tensor,
    phase: torch.Tensor,
    event_driven: bool = False,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Relabel the first wheel on the tread while the first placement is active."""
    if lead_is_left.ndim != 1 or lead_is_left.dtype != torch.bool:
        raise ValueError("lead_is_left must be a one-dimensional boolean tensor")
    if wheel_levels.shape != (lead_is_left.shape[0], 2):
        raise ValueError("wheel_levels must have shape (N, 2)")
    if current_level.shape != lead_is_left.shape or phase.shape != lead_is_left.shape:
        raise ValueError("current_level and phase must match lead_is_left")

    left_reached = wheel_levels[:, 0] > current_level
    right_reached = wheel_levels[:, 1] > current_level
    exactly_one_reached = left_reached ^ right_reached
    # The first wheel that geometrically clears the edge owns the lead role.
    # The caller immediately advances to trailing-wheel motion after a
    # reassignment, so the newly selected support wheel is never retracted.
    placement_active = phase == STAIR_PHASE_LEAD_PLACE
    if event_driven:
        placement_active |= phase == STAIR_PHASE_LEAD_RETRACT
    should_select = exactly_one_reached & placement_active
    selected = torch.where(should_select, left_reached, lead_is_left)
    return selected, should_select & (selected != lead_is_left)


def alternating_stair_assist(
    sequence_step: torch.Tensor,
    lead_is_left: torch.Tensor,
    config: StairStepSequenceConfig,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Build an 8-D lead-leg then trail-leg target offset.

    The support leg is never retracted at the same time as the swing leg.  A
    smooth transition avoids the simultaneous crouch/extend impulse used by
    the rejected jump prior.
    """
    if lead_is_left.shape != sequence_step.shape or lead_is_left.dtype != torch.bool:
        raise ValueError("lead_is_left must be a boolean tensor matching sequence_step")
    phase, progress = stair_phase(sequence_step, config)
    blend = _smoothstep(progress).to(sequence_step.device)
    assist = torch.zeros(sequence_step.shape[0], 8, device=sequence_step.device)

    left_leg = torch.tensor((1, 2, 3), device=sequence_step.device)
    right_leg = torch.tensor((5, 6, 7), device=sequence_step.device)
    lead_leg = torch.where(lead_is_left[:, None], left_leg, right_leg)
    trail_leg = torch.where(lead_is_left[:, None], right_leg, left_leg)
    lead_abduction = torch.where(
        lead_is_left,
        torch.zeros_like(sequence_step),
        torch.full_like(sequence_step, 4),
    )
    trail_abduction = torch.where(
        lead_is_left,
        torch.full_like(sequence_step, 4),
        torch.zeros_like(sequence_step),
    )

    # TITA FK around the HIGH pose: +hip with -knee moves the wheel forward
    # and upward.  The former -hip/-knee combination moved it forward about
    # 6 cm but lifted it less than 1 mm, effectively driving into the riser.
    hip_retract = float(config.hip_retract_rad)
    knee_retract = -float(config.knee_retract_rad)
    hip_place = float(config.hip_place_rad)
    knee_place = -float(config.knee_place_rad)
    support_hip = -float(config.support_hip_rad)
    support_knee = float(config.support_knee_rad)

    def assign(indices: torch.Tensor, column: int, values: torch.Tensor) -> None:
        assist.scatter_(1, indices[:, column : column + 1], values[:, None])

    shift_to_trail = phase == STAIR_PHASE_SHIFT_TO_TRAIL
    lead_retract = phase == STAIR_PHASE_LEAD_RETRACT
    lead_place = phase == STAIR_PHASE_LEAD_PLACE
    trail_retract = phase == STAIR_PHASE_TRAIL_RETRACT
    trail_place = phase == STAIR_PHASE_TRAIL_PLACE
    settle = phase == STAIR_PHASE_SETTLE

    lead_hip = torch.zeros_like(blend)
    lead_knee = torch.zeros_like(blend)
    trail_hip = torch.zeros_like(blend)
    trail_knee = torch.zeros_like(blend)
    lead_wheel = torch.zeros_like(blend)
    trail_wheel = torch.zeros_like(blend)
    lead_lateral = torch.zeros_like(blend)
    trail_lateral = torch.zeros_like(blend)
    shift_direction = torch.where(
        lead_is_left, torch.ones_like(blend), -torch.ones_like(blend)
    )
    # DDT_Lab drives both TITA wheels through equal-sign velocity actions
    # (scale 5 rad/s).  Build wheel speed before edge contact: ramp during the
    # weight-transfer phase, then hold the peak only until the geometric
    # wheel-on-tread event advances the state machine.
    # In the official TITA URDF used here, negative wheel velocity advances
    # the robot along +X.  Both wheel joints share that sign convention.
    lead_drive = torch.full_like(blend, -float(config.wheel_drive))
    trail_drive = torch.full_like(blend, -float(config.wheel_drive))
    precontact_gain = 1.0 + (
        float(config.wheel_impulse_scale) - 1.0
    ) * blend
    lead_drive_ramp = lead_drive * precontact_gain
    lead_drive_peak = lead_drive * float(config.wheel_impulse_scale)
    trail_drive_peak = trail_drive * float(config.wheel_impulse_scale)
    full_shift = shift_direction * float(config.lateral_shift_rad)
    support_shift = full_shift * float(config.support_lateral_scale)
    lead_lateral[shift_to_trail] = (
        shift_direction[shift_to_trail]
        * float(config.lateral_shift_rad)
        * blend[shift_to_trail]
    )
    trail_lateral[shift_to_trail] = support_shift[shift_to_trail] * blend[
        shift_to_trail
    ]
    lead_lateral[lead_retract | lead_place] = full_shift[
        lead_retract | lead_place
    ]
    trail_lateral[lead_retract | lead_place] = support_shift[
        lead_retract | lead_place
    ]
    lead_lateral[trail_retract] = full_shift[trail_retract] * (
        1.0 - blend[trail_retract]
    )
    trail_lateral[trail_retract] = torch.lerp(
        support_shift[trail_retract],
        -full_shift[trail_retract],
        blend[trail_retract],
    )
    trail_lateral[trail_place] = -full_shift[trail_place]
    trail_lateral[settle] = -full_shift[settle] * (1.0 - blend[settle])

    # Keep sagittal joints unchanged during weight transfer.  Moving the hip
    # and knee while both wheels are planted translates the base toward the
    # riser instead of lifting a wheel.
    trail_hip[lead_retract] = support_hip * blend[lead_retract]
    trail_knee[lead_retract] = support_knee * blend[lead_retract]
    trail_hip[lead_place] = support_hip
    trail_knee[lead_place] = support_knee

    lead_hip[lead_retract] = hip_retract * blend[lead_retract]
    lead_knee[lead_retract] = knee_retract * blend[lead_retract]
    lead_hip[lead_place] = hip_retract + (hip_place - hip_retract) * blend[lead_place]
    lead_knee[lead_place] = knee_retract + (knee_place - knee_retract) * blend[lead_place]
    if config.drive_from_shift:
        # The video-like maneuver loads and rolls the lead wheel first.  The
        # trailing wheel is kept passive until the lead wheel has cleared the
        # riser and the trail-retract phase begins; driving both wheels during
        # the weight-transfer phase creates a symmetric shove that pitches the
        # base into the riser.
        lead_wheel[shift_to_trail] = lead_drive_ramp[shift_to_trail]
        lead_wheel[lead_retract | lead_place] = lead_drive_peak[
            lead_retract | lead_place
        ]
        trail_wheel[shift_to_trail] = lead_drive_ramp[shift_to_trail]
        trail_wheel[lead_retract | lead_place] = lead_drive_peak[
            lead_retract | lead_place
        ]
        trail_wheel[trail_retract | trail_place] = trail_drive_peak[
            trail_retract | trail_place
        ]
    else:
        lead_wheel[lead_place] = lead_drive[lead_place]
        trail_wheel[trail_retract | trail_place] = trail_drive[
            trail_retract | trail_place
        ]

    lead_hip[trail_retract] = hip_place + (support_hip - hip_place) * blend[
        trail_retract
    ]
    lead_knee[trail_retract] = knee_place + (support_knee - knee_place) * blend[
        trail_retract
    ]
    lead_hip[trail_place] = support_hip
    lead_knee[trail_place] = support_knee
    trail_hip[trail_retract] = hip_retract * blend[trail_retract]
    trail_knee[trail_retract] = knee_retract * blend[trail_retract]
    trail_hip[trail_place] = hip_retract + (hip_place - hip_retract) * blend[trail_place]
    trail_knee[trail_place] = knee_retract + (knee_place - knee_retract) * blend[trail_place]

    release = 1.0 - blend[settle]
    lead_hip[settle] = support_hip * release
    lead_knee[settle] = support_knee * release
    trail_hip[settle] = support_hip * release
    trail_knee[settle] = support_knee * release

    assign(lead_leg, 0, lead_hip)
    assign(lead_leg, 1, lead_knee)
    assign(lead_leg, 2, lead_wheel)
    assign(trail_leg, 0, trail_hip)
    assign(trail_leg, 1, trail_knee)
    assign(trail_leg, 2, trail_wheel)
    assist.scatter_(1, lead_abduction[:, None], lead_lateral[:, None])
    assist.scatter_(1, trail_abduction[:, None], trail_lateral[:, None])

    # URDF FK gives mirrored adduction signs: left negative, right positive.
    # Hold both wheels inward through edge contact, then release after the
    # trailing wheel reaches the tread.
    inward = torch.zeros_like(blend)
    # Do not alter stance geometry during the acceleration approach.  Ramp the
    # inward force only while the lead wheel is being lifted at the edge.
    inward[lead_retract] = float(config.inward_hold_rad) * blend[lead_retract]
    inward[lead_place | trail_retract | trail_place] = float(
        config.inward_hold_rad
    )
    inward[settle] = float(config.inward_hold_rad) * (1.0 - blend[settle])
    assist[:, 0] -= inward
    assist[:, 4] += inward
    return assist, phase, progress
