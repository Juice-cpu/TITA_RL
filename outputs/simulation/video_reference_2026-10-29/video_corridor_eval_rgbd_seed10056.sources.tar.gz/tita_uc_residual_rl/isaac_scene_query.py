from __future__ import annotations

from dataclasses import dataclass
import math

import numpy as np


@dataclass(frozen=True)
class DepthScan:
    timestamp_s: float
    points_world_m: np.ndarray
    ranges_m: np.ndarray
    body_paths: tuple[str, ...]
    source: str = "physx_collision_surface_ray_sensor"
    normals_world: np.ndarray | None = None


class PhysicsDepthSensors:
    def __init__(self, query_interface=None, ignored_path: str = "/World/envs/env_0/Robot", max_range_m: float = 8.0) -> None:
        if query_interface is None:
            from omni.physx import get_physx_scene_query_interface
            query_interface = get_physx_scene_query_interface()
        self.query = query_interface
        self.ignored_path = ignored_path
        self.max_range_m = max_range_m

    def scan(self, origin_world_m: np.ndarray, directions_world: np.ndarray, timestamp_s: float) -> DepthScan:
        origin = np.asarray(origin_world_m, dtype=float)
        directions = np.asarray(directions_world, dtype=float)
        if origin.shape != (3,) or directions.ndim != 2 or directions.shape[1] != 3 or not np.isfinite(origin).all() or not np.isfinite(directions).all():
            raise ValueError("depth rays must have finite world coordinates")
        norms = np.linalg.norm(directions, axis=1)
        if np.any(norms <= 0) or not math.isfinite(timestamp_s):
            raise ValueError("ray directions must be nonzero and timestamp finite")
        ranges = np.full(len(directions), self.max_range_m)
        points, paths, normals = [], [], []
        for index, direction in enumerate(directions / norms[:, None]):
            hits = []

            def report(hit):
                body = str(hit.rigid_body)
                if self.ignored_path not in body:
                    hits.append((float(hit.distance), np.asarray(hit.position, dtype=float), body,
                                 np.asarray(getattr(hit, "normal", [0., 0., 0.]), dtype=float)))
                return True

            self.query.raycast_all(tuple(origin), tuple(direction), self.max_range_m, report)
            if hits:
                distance, point, body, normal = min(hits, key=lambda item: item[0])
                ranges[index] = distance
                points.append(point)
                paths.append(body)
                normals.append(normal)
        return DepthScan(timestamp_s, np.asarray(points, dtype=float).reshape(-1, 3), ranges, tuple(paths),
                         normals_world=np.asarray(normals, dtype=float).reshape(-1, 3))

    def lidar(self, origin_world_m: np.ndarray, yaw_rad: float, timestamp_s: float, rays: int = 180) -> DepthScan:
        angles = np.linspace(-math.pi, math.pi, rays, endpoint=False) + yaw_rad
        directions = np.column_stack((np.cos(angles), np.sin(angles), np.zeros(rays)))
        return self.scan(origin_world_m, directions, timestamp_s)

    def gimbal_depth(self, origin_world_m: np.ndarray, yaw_rad: float, pitch_rad: float, timestamp_s: float,
                     horizontal_rays: int = 24, vertical_rays: int = 12) -> DepthScan:
        yaw, pitch = np.meshgrid(np.linspace(-0.7, 0.7, horizontal_rays) + yaw_rad,
                                 np.linspace(-0.6, 0.6, vertical_rays) + pitch_rad)
        directions = np.column_stack((np.cos(pitch).ravel() * np.cos(yaw).ravel(),
                                      np.cos(pitch).ravel() * np.sin(yaw).ravel(), np.sin(pitch).ravel()))
        return self.scan(origin_world_m, directions, timestamp_s)
