from __future__ import annotations

from dataclasses import dataclass
import math

import numpy as np


def swept_ceiling_height(scene, position_xy, velocity_xy, reaction_s=.20, braking_acceleration_mps2=.30):
    position = np.asarray(position_xy, dtype=float)
    velocity = np.asarray(velocity_xy, dtype=float)
    if position.shape != (2,) or velocity.shape != (2,) or not np.isfinite([position, velocity]).all():
        raise ValueError("live clearance requires finite planar position and velocity")
    if reaction_s < 0. or braking_acceleration_mps2 <= 0.:
        raise ValueError("invalid live-clearance braking parameters")
    speed = float(np.linalg.norm(velocity))
    distance = reaction_s * speed + speed * speed / (2. * braking_acceleration_mps2)
    direction = velocity / speed if speed > 1e-6 else np.zeros(2)
    minimum = float("inf")
    for travel in np.linspace(0., distance, max(2, int(math.ceil(distance / (scene.resolution_m / 2.))) + 1)):
        cell = scene.world_to_cell(position + direction * travel)
        if not scene.in_bounds(cell):
            return 0.
        minimum = min(minimum, float(scene.ceiling_height_m[cell[1], cell[0]]))
    return minimum


@dataclass
class LiveClearanceGuard:
    minimum_margin_m: float = .02
    release_margin_m: float = .035
    release_hold_s: float = .30
    braking: bool = False
    safe_since_s: float | None = None

    def update(self, time_s, measured_body_height_m, swept_ceiling_height_m):
        if not all(math.isfinite(value) for value in (time_s, measured_body_height_m, swept_ceiling_height_m)):
            raise ValueError("live body clearance must be finite")
        margin = swept_ceiling_height_m - measured_body_height_m
        if margin < self.minimum_margin_m:
            self.braking = True
            self.safe_since_s = None
        elif self.braking:
            if margin >= self.release_margin_m:
                if self.safe_since_s is None:
                    self.safe_since_s = time_s
                if time_s - self.safe_since_s >= self.release_hold_s:
                    self.braking = False
                    self.safe_since_s = None
            else:
                self.safe_since_s = None
        return self.braking
