import numpy as np

from .joint_navigation import NeuPANBridge, POSTURES
from .navigation_command_limiter import MODE_COMMAND_LIMITS


def mode_solver_limits(posture_specs, geometry_profiles, maximum_yaw_radps):
    result = {}
    for spec in posture_specs:
        yaw = min(maximum_yaw_radps, geometry_profiles[spec.name]['validated_yaw_rate_radps'])
        linear_acceleration, angular_acceleration, _ = MODE_COMMAND_LIMITS[spec.name]
        limits = {'max_speed': [spec.vmax_mps, yaw],
                  'max_acce': [linear_acceleration, angular_acceleration]}
        if not np.isfinite(list(limits.values())).all() or (np.asarray(list(limits.values())) <= 0.).any():
            raise ValueError('mode-specific solver limits require positive finite calibrated bounds')
        result[spec.name] = limits
    if set(result) != set(POSTURES):
        raise ValueError('mode-specific solver requires all three calibrated postures')
    return result


class ModeConditionedNeuPANBridge:
    def __init__(self, yaml_path, vendor_root, limits, bridge_factory=NeuPANBridge):
        if set(limits) != set(POSTURES):
            raise ValueError('all mode-specific vendor solvers are required')
        self.limits = limits
        self.controllers = {name: bridge_factory(yaml_path, vendor_root, robot_limits=limits[name]) for name in POSTURES}
        self.mode = 'MID'
        if any(controller.backend != 'vendor' or controller.init_error for controller in self.controllers.values()):
            raise RuntimeError('mode-specific NeuPAN cannot fall back: ' + self.init_error)
        vertices = [controller.planner.robot.vertices for controller in self.controllers.values()]
        if any(not np.array_equal(vertices[0], value) for value in vertices[1:]):
            raise ValueError('mode conditioning must not change the audited DUNE robot polygon')

    @property
    def backend(self):
        return 'vendor'

    @property
    def init_error(self):
        return '; '.join(f'{mode}: {controller.init_error}' for mode, controller in self.controllers.items() if controller.init_error)

    @property
    def planner(self):
        return self.controllers[self.mode].planner

    @property
    def last_latency_ms(self):
        return self.controllers[self.mode].last_latency_ms

    @property
    def last_status(self):
        return self.controllers[self.mode].last_status

    def select_execution_mode(self, mode):
        if mode not in range(3):
            raise ValueError('solver mode must be LOW/MID/HIGH index')
        selected = POSTURES[mode]
        if selected != self.mode:
            self.controllers[selected].reset()
        self.mode = selected

    def command(self, *args, **kwargs):
        return self.controllers[self.mode].command(*args, **kwargs)

    def reset(self):
        for controller in self.controllers.values():
            controller.reset()
        self.mode = 'MID'
