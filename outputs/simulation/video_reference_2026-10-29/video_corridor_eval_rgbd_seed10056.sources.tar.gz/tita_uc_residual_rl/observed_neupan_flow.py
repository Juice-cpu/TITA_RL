from copy import deepcopy
from dataclasses import asdict
import hashlib
import json
import math

import numpy as np
import torch

from .observed_shuttle_prediction import validate_observed_shuttle_forecast


OBSERVED_NEUPAN_FLOW_CONTRACT = 'tita.observed_shuttle_neupan_additive_flow.v1'


def _flow_hash(points):
    values = torch.stack(points).detach().cpu().numpy()
    return hashlib.sha256(np.asarray(values, dtype='<f4').tobytes()).hexdigest()


def install_observed_neupan_flow(controller):
    bridges = getattr(controller, 'controllers', {'single': controller})
    if not bridges or any(bridge.backend != 'vendor' or bridge.planner is None for bridge in bridges.values()):
        raise ValueError('observed local flow requires actual original vendor execution')
    if any(hasattr(bridge.planner.pan, '_tita_observed_shuttle_flow') for bridge in bridges.values()):
        raise ValueError('observed local flow already attached to a vendor instance')
    return {mode: ObservedShuttlePointFlow(bridge.planner.pan) for mode, bridge in bridges.items()}


class ObservedShuttlePointFlow:
    def __init__(self, pan, boundary_samples=16, maximum_observation_age_s=.2):
        if (not isinstance(boundary_samples, int) or boundary_samples < 8
                or not math.isfinite(maximum_observation_age_s) or maximum_observation_age_s <= 0.
                or not isinstance(pan.T, int) or pan.T < 1 or not math.isfinite(pan.dt) or pan.dt <= 0.):
            raise ValueError('observed local flow requires valid MPC and boundary dimensions')
        if hasattr(pan, '_tita_observed_shuttle_flow'):
            raise ValueError('observed local flow already attached to this vendor instance')
        self.pan = pan
        self.original = pan.generate_point_flow
        self.boundary_samples = boundary_samples
        self.maximum_age_s = maximum_observation_age_s
        self.observations = []
        self.current_time_s = None
        self.calls = 0
        self.last_summary = None
        pan.generate_point_flow = self.generate_point_flow
        pan._tita_observed_shuttle_flow = self

    def update(self, pedestrians, contexts, current_time_s):
        if not math.isfinite(current_time_s) or current_time_s < 0. or len(pedestrians) != len(contexts):
            raise ValueError('observed local flow requires aligned causal pedestrian context')
        observations = []
        for person, context in zip(pedestrians, contexts):
            forecast = getattr(context, 'shuttle_prediction', None)
            if forecast is None:
                continue
            validate_observed_shuttle_forecast(forecast)
            age = current_time_s - forecast['computed_at_s']
            if age < -1e-8:
                raise ValueError('future local-flow observation is forbidden')
            if np.linalg.norm(np.subtract(forecast['points_xy_m'][0], [person.x, person.y])) > .05:
                raise ValueError('local shuttle forecast must anchor to the current measured track')
            if age > self.maximum_age_s:
                continue
            if age + self.pan.T * self.pan.dt > forecast['times_s'][-1] + 1e-9:
                continue
            observations.append({'pedestrian': asdict(person), 'forecast': deepcopy(forecast), 'age_s': max(age, 0.)})
        self.observations = observations
        self.current_time_s = current_time_s

    def generate_point_flow(self, nominal_state, obstacle_points, point_velocities=None):
        original = self.original(nominal_state, obstacle_points, point_velocities)
        self.calls += 1
        if not self.observations:
            self.last_summary = {'contract': OBSERVED_NEUPAN_FLOW_CONTRACT, 'call_index': self.calls,
                'control_time_s': self.current_time_s, 'forecast_tracks': 0, 'added_columns': 0,
                'mpc_relative_times_s': (np.arange(self.pan.T + 1) * self.pan.dt).tolist(),
                'boundary_samples': self.boundary_samples,
                'original_flow_returned_without_modification': True}
            return original
        point_flow, rotations, world_flow = original
        frames = self.pan.T + 1
        if (len(point_flow) != frames or len(rotations) != frames or len(world_flow) != frames
                or nominal_state.shape != (3, frames) or not torch.isfinite(nominal_state).all()):
            raise ValueError('vendor flow dimensions do not match the actual MPC horizon')
        columns = world_flow[0].shape[1]
        if any(points.shape != (2, columns) or not torch.isfinite(points).all() for points in (*point_flow, *world_flow)):
            raise ValueError('original vendor point flow must remain finite and aligned')
        times = np.arange(frames) * self.pan.dt
        angles = np.linspace(0., 2. * np.pi, self.boundary_samples, endpoint=False)
        directions = np.column_stack((np.cos(angles), np.sin(angles)))
        additions = []
        for observation in self.observations:
            forecast = observation['forecast']
            points = np.asarray(forecast['points_xy_m'], dtype=float)
            centers = np.column_stack([np.interp(times + observation['age_s'], forecast['times_s'], points[:, axis]) for axis in range(2)])
            radius = observation['pedestrian']['radius_m'] + forecast['uncertainty_radius_m']
            boundaries = centers[:, None, :] + radius * directions[None, :, :]
            additions.append(np.concatenate((centers[:, None, :], boundaries), axis=1))
        values = np.concatenate(additions, axis=1)
        extras = [world_flow[0].new_tensor(value.T) for value in values]
        extended_world, extended_robot = [], []
        for index, extra in enumerate(extras):
            if rotations[index].shape != (2, 2) or not torch.isfinite(rotations[index]).all():
                raise ValueError('vendor frame transform must remain finite and planar')
            extended_world.append(torch.cat((world_flow[index], extra), dim=1))
            relative = rotations[index].T @ (extra - nominal_state[:2, index:index + 1])
            extended_robot.append(torch.cat((point_flow[index], relative), dim=1))
        prefix = [points[:, :columns] for points in extended_world]
        forecasts = [{'pedestrian': observation['pedestrian'], 'age_s': observation['age_s'],
            'forecast_sha256': hashlib.sha256(json.dumps(observation['forecast'], sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
            'forecast': observation['forecast']} for observation in self.observations]
        self.last_summary = {'contract': OBSERVED_NEUPAN_FLOW_CONTRACT, 'call_index': self.calls,
            'control_time_s': self.current_time_s, 'mpc_relative_times_s': times.tolist(),
            'forecast_tracks': len(self.observations), 'boundary_samples': self.boundary_samples,
            'original_columns': columns, 'added_columns': extras[0].shape[1],
            'original_world_flow_sha256': _flow_hash(world_flow), 'extended_original_prefix_sha256': _flow_hash(prefix),
            'added_world_flow_sha256': _flow_hash(extras), 'extended_world_flow_sha256': _flow_hash(extended_world),
            'original_input_flow_retained_bitwise': all(torch.equal(before, after) for before, after in zip(world_flow, prefix)),
            'forecast_observations': forecasts, 'future_actor_waypoints_or_labels_used': False,
            'vendor_DUNE_NRMP_weights_and_solver_not_replaced': True,
            'scope': 'Add observed uncertain forecast point flow AFTER original vendor raw-cloud decimation. Original CV flow remains; finite point boundaries and unchanged NRMP top-k are not a worst-case collision certificate.'}
        return extended_robot, rotations, extended_world
