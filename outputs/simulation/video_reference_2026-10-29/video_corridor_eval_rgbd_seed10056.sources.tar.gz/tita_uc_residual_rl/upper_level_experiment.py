"""Reusable calibration, evaluation, and reporting helpers for upper RL."""

from __future__ import annotations

from dataclasses import asdict, replace
import json
from pathlib import Path
from typing import Iterable

import numpy as np

from .upper_level_objective import ShortestRoutePolicy, action_mask, timed_decision
from .upper_level_toy_env import UpperLevelToyEnv
from .upper_level_types import (
    EpisodeMetrics,
    UpperDecision,
    UpperNormalization,
    UpperObjectiveWeights,
    UpperObservation,
    UpperSafetyConfig,
)


class FixedActionPolicy:
    def __init__(self, action_id: int, safety: UpperSafetyConfig | None = None) -> None:
        if action_id not in range(9):
            raise ValueError("fixed action must be in [0, 8]")
        self.action_id = int(action_id)
        self.safety = safety or UpperSafetyConfig()

    def decide(self, observation: UpperObservation) -> UpperDecision:
        if not action_mask(observation, self.safety)[self.action_id]:
            return UpperDecision.stop("fixed_action_infeasible")
        return UpperDecision.from_action(self.action_id, observation, "fixed_action")


def evaluate_policy(
    policy,
    *,
    method: str,
    seed: int,
    episodes: int,
    normalization: UpperNormalization,
    weights: UpperObjectiveWeights | None = None,
    safety: UpperSafetyConfig | None = None,
    split: str = "test",
) -> list[EpisodeMetrics]:
    if episodes <= 0:
        raise ValueError("episodes must be positive")
    env = UpperLevelToyEnv(
        num_envs=1,
        seed=seed,
        split=split,
        normalization=normalization,
        weights=weights,
        safety=safety,
    )
    results: list[EpisodeMetrics] = []
    while len(results) < episodes:
        observation = env.observation(0)
        decision, latency_ms = timed_decision(policy, observation)
        env.add_decision_latency(0, latency_ms)
        _, _, done, information, _ = env.step(np.asarray([decision.action_id]))
        if done[0]:
            success = bool(information[0].get("success", False))
            results.append(env.episode_metrics(0, method, success))
            env.reset((0,))
    return results


def calibrate_rule_references(
    *, seed: int = 20261009, episodes: int = 128
) -> UpperNormalization:
    provisional = UpperNormalization()
    results = evaluate_policy(
        ShortestRoutePolicy(),
        method="rule_calibration",
        seed=seed,
        episodes=episodes,
        normalization=provisional,
        split="train",
    )
    energy = np.asarray([item.mechanical_energy_j for item in results])
    elapsed = np.asarray([item.elapsed_s for item in results])
    distance = np.asarray([item.distance_m for item in results])
    return UpperNormalization(
        energy_ref_j=max(1e-6, float(np.percentile(energy, 95))),
        time_ref_s=max(1e-6, float(np.percentile(elapsed, 95))),
        length_ref_m=max(1e-6, float(np.percentile(distance, 95))),
    )


def manual_action_gate(
    *,
    seed: int,
    rollouts_per_action: int,
    normalization: UpperNormalization,
) -> dict[str, object]:
    actions: dict[str, object] = {}
    passed = True
    required = int(np.ceil(0.8 * rollouts_per_action))
    for action_id in range(9):
        results = evaluate_policy(
            FixedActionPolicy(action_id),
            method=f"fixed_action_{action_id}",
            seed=seed + 10_000 * action_id,
            episodes=rollouts_per_action,
            normalization=normalization,
            split="gate",
        )
        successes = sum(item.success and not item.hard_violation for item in results)
        action_passed = successes >= required
        passed &= action_passed
        actions[str(action_id)] = {
            "successes": successes,
            "rollouts": rollouts_per_action,
            "required": required,
            "passed": action_passed,
        }
    return {"passed": passed, "actions": actions}


def summarize_metrics(results: Iterable[EpisodeMetrics]) -> dict[str, object]:
    items = list(results)
    if not items:
        raise ValueError("cannot summarize an empty result set")
    latencies = np.asarray(
        [latency for item in items for latency in item.decision_latency_ms],
        dtype=np.float64,
    )
    numeric_names = (
        "total_cost",
        "total_reward",
        "elapsed_s",
        "distance_m",
        "mechanical_energy_j",
        "mechanical_cot",
        "switches",
        "minimum_overhead_margin_m",
        "minimum_lateral_clearance_m",
        "maximum_abs_roll_rad",
        "maximum_abs_pitch_rad",
    )
    summary: dict[str, object] = {
        "method": items[0].method,
        "episodes": len(items),
        "success_rate": float(np.mean([item.success for item in items])),
        "collision_rate": float(np.mean([item.collision for item in items])),
        "hard_violation_rate": float(np.mean([item.hard_violation for item in items])),
    }
    for name in numeric_names:
        values = np.asarray([getattr(item, name) for item in items], dtype=np.float64)
        summary[name] = {
            "mean": float(np.mean(values)),
            "median": float(np.median(values)),
            "p95": float(np.percentile(values, 95)),
        }
    summary["decision_latency_ms"] = {
        "p50": float(np.percentile(latencies, 50)) if latencies.size else 0.0,
        "p95": float(np.percentile(latencies, 95)) if latencies.size else 0.0,
        "max": float(np.max(latencies)) if latencies.size else 0.0,
    }
    return summary


def paired_bootstrap_cost_difference(
    proposed: Iterable[EpisodeMetrics],
    baseline: Iterable[EpisodeMetrics],
    *,
    seed: int = 20261009,
    samples: int = 10_000,
) -> dict[str, float]:
    proposed_values = np.asarray([item.total_cost for item in proposed], dtype=np.float64)
    baseline_values = np.asarray([item.total_cost for item in baseline], dtype=np.float64)
    if proposed_values.shape != baseline_values.shape or proposed_values.size == 0:
        raise ValueError("paired bootstrap inputs must have equal non-empty lengths")
    difference = proposed_values - baseline_values
    generator = np.random.default_rng(seed)
    indices = generator.integers(0, difference.size, size=(samples, difference.size))
    means = difference[indices].mean(axis=1)
    return {
        "mean_difference": float(difference.mean()),
        "ci95_low": float(np.percentile(means, 2.5)),
        "ci95_high": float(np.percentile(means, 97.5)),
    }


def objective_weight_variants(
    base: UpperObjectiveWeights | None = None,
) -> dict[str, UpperObjectiveWeights]:
    weights = base or UpperObjectiveWeights()
    output = {"nominal": weights}
    for term in ("energy", "time", "length", "clearance", "switch"):
        output[f"{term}_minus50"] = replace(
            weights, **{term: 0.5 * getattr(weights, term)}
        )
        output[f"{term}_plus50"] = replace(
            weights, **{term: 1.5 * getattr(weights, term)}
        )
    for term in ("energy", "clearance", "switch", "attitude"):
        output[f"ablate_{term}"] = replace(weights, **{term: 0.0})
    return output


def write_json(path: str | Path, value: object) -> None:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def metrics_as_dicts(results: Iterable[EpisodeMetrics]) -> list[dict[str, object]]:
    return [asdict(item) for item in results]
