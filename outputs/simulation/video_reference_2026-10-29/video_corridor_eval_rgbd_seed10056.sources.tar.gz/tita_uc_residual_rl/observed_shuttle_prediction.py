from copy import copy

import math

import numpy as np


class _ObservedShuttleTrack:
    def __init__(self):
        self.last_time_s = None
        self.phase = None
        self.phase_start_s = None
        self.phase_fully_observed = False
        self.stationary_points = []
        self.completed_dwells_s = []
        self.endpoint_samples = []
        self.moving_velocities = []
        self.current_motion_observations = []
        self.completed_motion_profiles = []
        self.position = None
        self.velocity = None

    def update(self, timestamp_s, position_xy_m, velocity_xy_mps):
        position = np.asarray(position_xy_m, dtype=float)
        velocity = np.asarray(velocity_xy_mps, dtype=float)
        if (not math.isfinite(timestamp_s) or position.shape != (2,) or velocity.shape != (2,)
                or not np.isfinite([position, velocity]).all()
                or self.last_time_s is not None and timestamp_s <= self.last_time_s):
            raise ValueError('hypothesis requires increasing times and finite planar observations')
        if self.last_time_s is not None and timestamp_s - self.last_time_s > .25:
            self.__init__()
        speed = float(np.linalg.norm(velocity))
        phase = 'moving' if speed >= .08 else 'stationary' if speed <= .04 else self.phase
        if phase is not None and phase != self.phase:
            if self.phase == 'moving' and self.current_motion_observations:
                self.completed_motion_profiles.append(tuple(self.current_motion_observations))
            if self.phase == 'stationary' and self.stationary_points:
                duration = timestamp_s - self.phase_start_s
                if duration >= 1.:
                    self.endpoint_samples.append(np.median(self.stationary_points, axis=0))
                    if self.phase_fully_observed:
                        self.completed_dwells_s.append(duration)
            self.phase_fully_observed = self.phase is not None
            self.phase = phase
            self.phase_start_s = timestamp_s
            self.stationary_points = []
            self.current_motion_observations = []
        if phase == 'stationary':
            self.stationary_points.append(position.copy())
        elif phase == 'moving':
            self.moving_velocities.append(velocity.copy())
            self.current_motion_observations.append((timestamp_s, velocity.copy()))
        self.last_time_s = timestamp_s
        self.position = position.copy()
        self.velocity = velocity.copy()

    def parameters(self):
        if len(self.completed_dwells_s) < 2 or len(self.moving_velocities) < 30:
            return None
        dwell = float(np.median(self.completed_dwells_s))
        if dwell < 1. or max(abs(value - dwell) for value in self.completed_dwells_s) > .2 * dwell:
            return None
        endpoints = list(self.endpoint_samples)
        if self.phase == 'stationary' and self.last_time_s - self.phase_start_s >= 1.:
            endpoints.append(np.median(self.stationary_points, axis=0))
        if len(endpoints) < 2:
            return None
        points = np.asarray(endpoints)
        difference = points[:, None, :] - points[None, :, :]
        first, second = np.unravel_index(np.linalg.norm(difference, axis=2).argmax(), difference.shape[:2])
        lower, upper = points[first], points[second]
        distance = float(np.linalg.norm(upper - lower))
        if distance < .8:
            return None
        axis = (upper - lower) / distance
        projected = (points - lower) @ axis
        if np.max(np.minimum(abs(projected), abs(projected - distance))) > .2:
            return None
        lateral = points - lower - projected[:, None] * axis
        if np.linalg.norm(lateral, axis=1).max() > .15:
            return None
        velocities = np.asarray(self.moving_velocities)
        speeds = np.abs(velocities @ axis)
        speed = float(np.median(speeds))
        if speed < .08 or np.quantile(np.linalg.norm(velocities - (velocities @ axis)[:, None] * axis, axis=1), .95) > .05:
            return None
        return {'lower': lower, 'axis': axis, 'distance_m': distance,
            'speed_mps': speed, 'dwell_s': dwell, 'complete_dwell_observations': len(self.completed_dwells_s)}

    def predict(self, horizons_s):
        horizons = np.asarray(horizons_s, dtype=float)
        if horizons.ndim != 1 or not np.isfinite(horizons).all() or (horizons < 0.).any() or (horizons > 15.).any():
            raise ValueError('prediction horizons must be finite times within fifteen seconds')
        model = self.parameters()
        if model is None:
            return None
        axis, lower = model['axis'], model['lower']
        distance, speed, dwell = model['distance_m'], model['speed_mps'], model['dwell_s']
        coordinate = float(np.clip((self.position - lower) @ axis, 0., distance))
        lateral = self.position - lower - coordinate * axis
        if self.phase == 'moving':
            direction = 1. if self.velocity @ axis > 0. else -1.
            remaining = (distance - coordinate if direction > 0. else coordinate) / speed
            moving = True
        else:
            direction = -1. if coordinate > distance / 2. else 1.
            remaining = max(0., dwell - (self.last_time_s - self.phase_start_s))
            moving = False
        predictions = []
        for horizon in horizons:
            current, pending, sign, travel = coordinate, remaining, direction, moving
            while horizon > pending:
                if travel:
                    current = distance if sign > 0. else 0.
                    sign = -sign
                horizon -= pending
                travel = not travel
                pending = distance / speed if travel else dwell
            if travel:
                current += sign * speed * horizon
            predictions.append(lower + np.clip(current, 0., distance) * axis + lateral)
        return np.asarray(predictions)


class ObservedShuttleForecaster:
    def __init__(self, motion_plateau_gate=False):
        self.models = {}
        self.motion_plateau_gate = bool(motion_plateau_gate)

    def update(self, identifier, timestamp_s, position_xy_m, velocity_xy_mps):
        if not isinstance(identifier, int) or identifier < 0:
            raise ValueError('observed shuttle history requires a nonnegative integer track identifier')
        self.models.setdefault(identifier, _ObservedShuttleTrack()).update(
            timestamp_s, position_xy_m, velocity_xy_mps)

    def forecast(self, identifier, timestamp_s):
        model = self.models.get(identifier)
        if model is None or model.last_time_s != timestamp_s:
            return None
        times = np.linspace(0., 15., 151)
        positions, provenance = self.prediction(identifier, times)
        if positions is None:
            return None
        parameters = provenance['parameters']
        axis = parameters['axis']
        speed = parameters['speed_mps']
        normal_speed = np.linalg.norm(model.velocity - (model.velocity @ axis) * axis)
        if normal_speed > .05 or np.linalg.norm(positions[0] - model.position) > .05:
            return None
        if model.phase == 'moving' and abs(abs(model.velocity @ axis) - speed) > max(.05, .25 * speed):
            return None
        coordinate = (model.position - parameters['lower']) @ axis
        if model.phase == 'stationary' and min(abs(coordinate), abs(coordinate - parameters['distance_m'])) > .2:
            return None
        contributors = [self.models[value] for value in provenance['contributor_ids']]
        plateau_evidence = []
        if self.motion_plateau_gate:
            plateaus = []
            for other_identifier, other in zip(provenance['contributor_ids'], contributors):
                profiles = [(profile, 'observed_phase_change') for profile in other.completed_motion_profiles]
                if other.phase == 'moving' and timestamp_s - other.last_time_s > .25 and other.current_motion_observations:
                    profiles.append((other.current_motion_observations, 'observation_gap'))
                for profile, closure in profiles:
                    first_time, last_time = profile[0][0], profile[-1][0]
                    duration = last_time - first_time
                    middle = np.asarray([velocity for timestamp, velocity in profile
                        if first_time + .2 * duration <= timestamp <= last_time - .2 * duration])
                    if duration < 2. or len(middle) < 10:
                        continue
                    projected = np.abs(middle @ axis)
                    if np.quantile(projected, .9) - np.quantile(projected, .1) > .3 * speed:
                        return None
                    plateaus.append(float(np.median(projected)))
                    plateau_evidence.append({'identifier': other_identifier, 'first_observation_s': first_time,
                        'last_observation_s': last_time, 'closure': closure, 'observations': len(profile),
                        'middle_observations': len(middle), 'median_speed_mps': plateaus[-1]})
            if (len(plateaus) < 2 or max(plateaus) - min(plateaus) > .3 * speed
                    or max(abs(value - speed) for value in plateaus) > .3 * speed):
                return None
        else:
            velocities = np.asarray([velocity for other in contributors for velocity in other.moving_velocities])
            projected_speeds = np.abs(velocities @ axis)
            if np.quantile(projected_speeds, .9) - np.quantile(projected_speeds, .1) > .3 * speed:
                return None
        dwells = [duration for other in contributors for duration in other.completed_dwells_s]
        phase_variation = max(abs(duration - parameters['dwell_s']) for duration in dwells)
        cycles = 1 + math.ceil(15. / (parameters['dwell_s'] + parameters['distance_m'] / speed))
        uncertainty = .35 + speed * .1 / 2. + speed * phase_variation * cycles
        forecast = {'schema': 'tita.observed_shuttle_forecast.v1', 'times_s': times.tolist(),
            'points_xy_m': positions.tolist(), 'uncertainty_radius_m': uncertainty,
            'computed_at_s': timestamp_s, 'source': provenance['source'],
            'contributor_ids': provenance['contributor_ids'], 'identity_reidentification_claimed': False,
            'future_actor_waypoints_or_labels_used': False}
        if self.motion_plateau_gate:
            forecast['motion_plateau_evidence'] = plateau_evidence
        validate_observed_shuttle_forecast(forecast)
        return forecast

    def observed_axis(self, model):
        if len(model.moving_velocities) < 5:
            return None
        velocities = np.asarray(model.moving_velocities)
        eigenvalues, eigenvectors = np.linalg.eigh(velocities.T @ velocities)
        if eigenvalues[-1] <= 0. or eigenvalues[-1] / eigenvalues.sum() < .95:
            return None
        return eigenvectors[:, -1]

    def prediction(self, identifier, horizons_s):
        model = self.models[identifier]
        own = model.predict(horizons_s)
        if own is not None:
            return own, {'source': 'same_track_only', 'contributor_ids': [identifier], 'parameters': model.parameters()}
        axis = self.observed_axis(model)
        if axis is None:
            return None, {'source': 'unavailable', 'contributor_ids': []}
        normal = np.asarray([-axis[1], axis[0]])
        contributors = []
        for other_identifier, other in self.models.items():
            other_axis = self.observed_axis(other)
            if (other_axis is None or model.last_time_s - other.last_time_s > 120.
                    or abs(axis @ other_axis) < .95
                    or abs((model.position - other.position) @ normal) > .2):
                continue
            contributors.append((other_identifier, other))
        combined = copy(model)
        combined.completed_dwells_s = [value for _, other in contributors for value in other.completed_dwells_s]
        combined.endpoint_samples = [value for _, other in contributors for value in other.endpoint_samples]
        combined.moving_velocities = [value for _, other in contributors for value in other.moving_velocities]
        prediction = combined.predict(horizons_s)
        return prediction, {'source': 'observed_spatial_shuttle_prior' if prediction is not None else 'unavailable',
            'contributor_ids': [other_identifier for other_identifier, _ in contributors],
            'identity_continuity_across_contributors_not_claimed': True,
            'parameters': combined.parameters()}


def validate_observed_shuttle_forecast(forecast):
    try:
        times = np.asarray(forecast['times_s'], dtype=float)
        points = np.asarray(forecast['points_xy_m'], dtype=float)
        uncertainty = forecast['uncertainty_radius_m']
        timestamp = forecast['computed_at_s']
        valid = (forecast['schema'] == 'tita.observed_shuttle_forecast.v1'
            and times.ndim == 1 and len(times) >= 2 and points.shape == (len(times), 2)
            and np.isfinite(times).all() and np.isfinite(points).all()
            and times[0] == 0. and 0. < times[-1] <= 15.
            and (np.diff(times) > 0.).all() and (np.diff(times) <= .100000001).all()
            and math.isfinite(uncertainty) and uncertainty >= .35 and math.isfinite(timestamp)
            and forecast['source'] in ('same_track_only', 'observed_spatial_shuttle_prior')
            and bool(forecast['contributor_ids'])
            and all(isinstance(value, int) and value >= 0 for value in forecast['contributor_ids'])
            and forecast['identity_reidentification_claimed'] is False
            and forecast['future_actor_waypoints_or_labels_used'] is False)
    except (KeyError, TypeError, ValueError, OverflowError):
        valid = False
    if not valid:
        raise ValueError('invalid observed shuttle forecast contract')


def observed_shuttle_minimum_distance(times_s, robot_positions_xy_m, forecast):
    validate_observed_shuttle_forecast(forecast)
    times = np.asarray(times_s, dtype=float)
    robot = np.asarray(robot_positions_xy_m, dtype=float)
    if (times.ndim != 1 or len(times) < 2 or robot.shape != (len(times), 2)
            or not np.isfinite(times).all() or not np.isfinite(robot).all()
            or times[0] < 0. or (np.diff(times) <= 0.).any()):
        raise ValueError('observed shuttle distance requires aligned finite trajectories')
    forecast_times = np.asarray(forecast['times_s'])
    if times[-1] > forecast_times[-1]:
        return None
    points = np.asarray(forecast['points_xy_m'])
    evaluation_times = np.unique(np.r_[times, forecast_times[(forecast_times >= times[0]) & (forecast_times <= times[-1])]])
    relative = np.column_stack([np.interp(evaluation_times, times, robot[:, axis])
        - np.interp(evaluation_times, forecast_times, points[:, axis]) for axis in range(2)])
    movement = np.diff(relative, axis=0)
    squared = np.sum(movement * movement, axis=1)
    fraction = np.divide(-np.sum(relative[:-1] * movement, axis=1), squared,
        out=np.zeros_like(squared), where=squared > 0.)
    closest = relative[:-1] + np.clip(fraction, 0., 1.)[:, None] * movement
    return float(np.linalg.norm(closest, axis=1).min()) - forecast['uncertainty_radius_m']
