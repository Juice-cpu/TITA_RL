import math

import numpy as np

from .joint_navigation import Pedestrian, Pose2D, nominal_pedestrian_clearance


ACTUAL_ACTOR_CLEARANCE_CONTRACT = 'tita.actual_actor_nominal_clearance.v1'


def audit_nominal_actor_clearance(document, geometry, allow_legacy_null_rows=False):
    failures, minimum, overlaps, legacy_nulls, checked = [], float('inf'), 0, 0, 0
    try:
        actors = document['pedestrian_track']['actors']
        if not actors or not all(math.isfinite(actor['radius_m']) and actor['radius_m'] > 0. for actor in actors):
            raise ValueError('declared_physical_capsule_radii_required')
        trajectory = document['trajectory']
        if not trajectory or len(trajectory) != document['completed_steps']:
            raise ValueError('complete_actual_trajectory_required')
        if trajectory[0]['step'] != 0:
            raise ValueError('actual_clearance_trajectory_must_start_at_zero')
        contract = document.get('nominal_clearance_logging_contract')
        if contract not in (None, ACTUAL_ACTOR_CLEARANCE_CONTRACT):
            raise ValueError('unsupported_nominal_clearance_logging_contract')
        first_steps = {}
        for row in trajectory:
            first_steps.setdefault(row['episode'], row['step'])
        decision_modes = {}
        for event in document.get('decision_events', []):
            timestep = document['elapsed_simulation_s'] / document['completed_steps']
            if not math.isfinite(timestep) or timestep <= 0.:
                raise ValueError('invalid_actual_clearance_clock')
            key = event['episode'], first_steps[event['episode']] + round(event['time_s'] / timestep)
            if key in decision_modes:
                raise ValueError('duplicate_actual_clearance_decision')
            decision_modes[key] = event
        previous_step = None
        for row in trajectory:
            if previous_step is not None and row['step'] != previous_step + 1:
                raise ValueError('actual_clearance_trajectory_step_gap')
            previous_step = row['step']
            positions = np.asarray(row['pedestrian_actor_xy_m'], dtype=float)
            root = np.asarray(row['root_position_before'], dtype=float)
            yaw = row['yaw_before_rad']
            if (positions.shape != (len(actors), 2) or root.shape != (3,)
                    or not np.isfinite(positions).all() or not np.isfinite(root).all() or not math.isfinite(yaw)):
                raise ValueError('all_actual_actor_positions_and_robot_pose_required')
            people = tuple(Pedestrian(*position, 0., 0., actor['radius_m']) for position, actor in zip(positions, actors))
            event = decision_modes.get((row['episode'], row['step']))
            if event is not None and math.dist(event['pose_xy_m'], root[:2]) > 1e-7:
                raise ValueError('clearance_decision_not_bound_to_same_pre_step_pose')
            clearance_posture = event['actual_posture'] if event is not None else row['posture']
            footprint = np.asarray(geometry['profiles'][clearance_posture]['footprint_vertices_xy_m'], dtype=float)
            clearance = nominal_pedestrian_clearance(Pose2D(*root[:2], yaw), footprint, people)
            reported = row['nominal_pedestrian_clearance_m']
            if reported is None:
                legacy_nulls += 1
                if not allow_legacy_null_rows or contract == ACTUAL_ACTOR_CLEARANCE_CONTRACT:
                    raise ValueError('actual_actor_clearance_missing_despite_physical_actors')
            elif not math.isfinite(reported) or not math.isclose(reported, clearance, rel_tol=0., abs_tol=1e-9):
                raise ValueError('nominal_clearance_does_not_match_all_actual_actor_poses')
            minimum = min(minimum, clearance)
            overlaps += clearance < 0.
            checked += 1
        aggregate = document['minimum_nominal_pedestrian_clearance_m']
        if not math.isfinite(aggregate) or not math.isclose(aggregate, minimum, rel_tol=0., abs_tol=1e-9):
            failures.append('minimum_nominal_clearance_aggregate_mismatch')
        if document['nominal_pedestrian_overlap_steps'] != overlaps:
            failures.append('nominal_overlap_count_mismatch')
    except (KeyError, TypeError, ValueError, IndexError, OverflowError) as error:
        failures.append(str(error))
    return {'schema': 'tita.actual_actor_nominal_clearance_audit.v1', 'passed': not failures,
        'failures': failures, 'physical_frames_checked': checked, 'recomputed_minimum_clearance_m': minimum if checked else None,
        'recomputed_overlap_steps': int(overlaps), 'legacy_null_rows_reconstructed': legacy_nulls,
        'legacy_reconstruction_explicitly_enabled': allow_legacy_null_rows,
        'nominally_collision_free': not failures and overlaps == 0,
        'scope': 'Replay all measured physical capsule poses against the executed full-body footprint, including actors absent from lidar tracks; not new physics, a future collision guarantee or complete navigation acceptance.'}
