from dataclasses import dataclass
import math


@dataclass
class GoalArrivalGuard:
    tolerance_m: float = .3
    hold_s: float = 1.
    maximum_speed_mps: float = .03
    maximum_yaw_rate_radps: float = .05
    maximum_attitude_rad: float = .2
    braking_entry_margin_m: float = 0.
    braking: bool = False
    stable_since_s: float | None = None
    last_time_s: float | None = None

    def __post_init__(self):
        limits = (self.tolerance_m, self.hold_s, self.maximum_speed_mps,
                  self.maximum_yaw_rate_radps, self.maximum_attitude_rad)
        if not all(math.isfinite(value) and value > 0. for value in limits):
            raise ValueError("goal arrival limits must be finite and positive")
        if not math.isfinite(self.braking_entry_margin_m) or not 0. <= self.braking_entry_margin_m < self.tolerance_m:
            raise ValueError("goal braking entry margin must be nonnegative and smaller than acceptance radius")

    def observe(self, time_s, distance_m, speed_mps, yaw_rate_radps, roll_rad, pitch_rad,
                both_wheels_contact, posture_settled):
        values = (time_s, distance_m, speed_mps, yaw_rate_radps, roll_rad, pitch_rad)
        if (not all(math.isfinite(value) for value in values) or min(distance_m, speed_mps) < 0.
                or self.last_time_s is not None and time_s < self.last_time_s):
            raise ValueError("goal arrival requires finite monotonic physical feedback")
        self.last_time_s = time_s
        braking_radius = self.tolerance_m if self.braking else self.tolerance_m - self.braking_entry_margin_m
        self.braking = distance_m <= braking_radius
        stable = (self.braking and speed_mps <= self.maximum_speed_mps
                  and abs(yaw_rate_radps) <= self.maximum_yaw_rate_radps
                  and max(abs(roll_rad), abs(pitch_rad)) <= self.maximum_attitude_rad
                  and both_wheels_contact and posture_settled)
        if not stable:
            self.stable_since_s = None
        elif self.stable_since_s is None:
            self.stable_since_s = time_s
        return stable and time_s - self.stable_since_s >= self.hold_s - 1e-9
