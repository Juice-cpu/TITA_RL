from dataclasses import dataclass
import json
import math
from pathlib import Path

import numpy as np

from .joint_navigation import Pedestrian
from .pedestrian_scenario import load_pedestrian_scenario


@dataclass(frozen=True)
class PedestrianTrack:
    initial: Pedestrian
    waypoints: tuple = ()
    repeat: bool = False

    def __post_init__(self):
        if not isinstance(self.repeat, bool):
            raise ValueError('pedestrian repeat must be boolean')
        if not self.waypoints:
            if self.repeat:
                raise ValueError('constant-velocity tracks cannot repeat without waypoints')
            return
        points = np.asarray(self.waypoints, dtype=float)
        if (points.ndim != 2 or points.shape[1] != 3 or len(points) < 2
                or not np.isfinite(points).all() or points[0, 0] != 0.
                or (np.diff(points[:, 0]) < .02).any()
                or not np.allclose(points[0, 1:], [self.initial.x, self.initial.y], atol=1e-9, rtol=0.)):
            raise ValueError('pedestrian waypoints need finite time/x/y rows starting at zero, positive segment durations, and matching initial position')
        if self.repeat and not np.allclose(points[0, 1:], points[-1, 1:], atol=1e-9, rtol=0.):
            raise ValueError('repeating pedestrian tracks must close without teleporting')

    def state_at(self, time_s):
        if not math.isfinite(time_s) or time_s < 0.:
            raise ValueError('pedestrian track time must be finite and nonnegative')
        if not self.waypoints:
            person = self.initial
            return Pedestrian(person.x + person.vx * time_s, person.y + person.vy * time_s,
                              person.vx, person.vy, person.radius_m)
        points = np.asarray(self.waypoints, dtype=float)
        if self.repeat:
            time_s %= points[-1, 0]
        elif time_s >= points[-1, 0]:
            return Pedestrian(*points[-1, 1:], 0., 0., self.initial.radius_m)
        index = min(int(np.searchsorted(points[:, 0], time_s, side='right')) - 1, len(points) - 2)
        velocity = (points[index + 1, 1:] - points[index, 1:]) / (points[index + 1, 0] - points[index, 0])
        position = points[index, 1:] + velocity * (time_s - points[index, 0])
        return Pedestrian(*position, *velocity, self.initial.radius_m)

    def breakpoints(self, duration_s):
        if not math.isfinite(duration_s) or duration_s <= 0.:
            raise ValueError('pedestrian track duration must be finite and positive')
        if not self.waypoints:
            return np.array([0., duration_s])
        times = np.asarray(self.waypoints, dtype=float)[:, 0]
        periods = int(math.ceil(duration_s / times[-1])) if self.repeat else 1
        if periods * len(times) > 100000:
            raise ValueError('pedestrian track has too many segments for complete validation')
        values = np.concatenate([times + period * times[-1] for period in range(periods)])
        return np.unique(np.r_[0., values[(values > 0.) & (values < duration_s)], duration_s])


def load_pedestrian_tracks(path):
    path = Path(path)
    document = json.loads(path.read_text())
    if document.get('version') == 1:
        return tuple(PedestrianTrack(person) for person in load_pedestrian_scenario(path))
    entries = document.get('pedestrians')
    if document.get('version') != 2 or not isinstance(entries, list) or not 1 <= len(entries) <= 16:
        raise ValueError('waypoint scenarios require version 2 and one to sixteen pedestrians')
    tracks = []
    for entry in entries:
        if float(entry.get('radius_m', .3)) != .3:
            raise ValueError('waypoint scenario radius must match the physical capsule radius .30 m')
        points = np.asarray(entry.get('waypoints'), dtype=float)
        if points.ndim != 2 or points.shape[1] != 3 or len(points) < 2:
            raise ValueError('waypoints require time/x/y rows')
        initial = Pedestrian(*points[0, 1:], 0., 0., .3)
        track = PedestrianTrack(initial, tuple(tuple(float(value) for value in row) for row in points),
                                entry.get('repeat', False))
        tracks.append(track)
    return tuple(tracks)
