import hashlib
import json
from pathlib import Path

import numpy as np


DEFAULT_TRANSITION_COSTS_S = ((0., 6., 6.), (6., 0., 6.), (6., 6., 0.))


def transition_cost_matrix(values=None):
    matrix = np.asarray(DEFAULT_TRANSITION_COSTS_S if values is None else values, dtype=float)
    if (matrix.shape != (3, 3) or not np.isfinite(matrix).all()
            or (matrix < 0.).any() or not (np.diag(matrix) == 0.).all()
            or (matrix[~np.eye(3, dtype=bool)] <= 0.).any()):
        raise ValueError('transition costs must be a finite positive off-diagonal LOW/MID/HIGH matrix')
    return matrix


def load_transition_costs(report_path, artifacts, convex_cylinder_collisions, physics_device,
                          margin_s=.5):
    report = json.loads(Path(report_path).read_text())
    if (report.get('passed') is not True or report.get('guarded_schedule') is not True
            or report.get('strict_goal_speed_and_yaw_thresholds') is not True
            or report.get('contact_processing_enabled') is not True
            or report.get('convex_cylinder_collisions') != convex_cylinder_collisions
            or report.get('physics_device') != physics_device
            or not np.isfinite(margin_s) or margin_s < 0.):
        raise ValueError('transition costs require a passing guarded physical probe with matching backend')
    for key, path in artifacts.items():
        expected = report.get('input_artifacts', {}).get(key, {}).get('sha256')
        if path is None or expected != hashlib.sha256(Path(path).read_bytes()).hexdigest():
            raise ValueError(f'transition probe input mismatch: {key}')
    required = {'asset', 'checkpoint', 'residual', 'high_residual', 'velocity_calibration'}
    if set(artifacts) != required:
        raise ValueError('transition costs require all five execution inputs')
    modes = ('LOW', 'MID', 'HIGH')
    schedule = report.get('mode_schedule', [])
    times = np.asarray(report.get('first_continuous_one_second_hold_after_command_s'), dtype=float)
    accepted = np.asarray(report.get('one_second_stationary_accepted_at_stage_end'))
    if (len(schedule) < 2 or any(mode not in modes for mode in schedule)
            or times.ndim != 2 or times.shape[0] != len(schedule) or times.shape[1] < 1
            or not np.isfinite(times).all() or (times < 6. - 1e-4).any()
            or accepted.shape != times.shape or accepted.dtype != np.bool_ or not accepted.all()):
        raise ValueError('transition probe must contain accepted finite durations for every environment')
    for key in ('hard_failure_per_env', 'simulator_truncated_per_env',
                'guarded_stage_timeout_per_env'):
        failures = np.asarray(report.get(key))
        if failures.shape != (times.shape[1],) or failures.dtype != np.bool_ or failures.any():
            raise ValueError(f'transition probe has missing or failed execution evidence: {key}')
    matrix = np.zeros((3, 3))
    observed = set()
    for stage, (origin, destination) in enumerate(zip(schedule, schedule[1:]), 1):
        if origin == destination:
            continue
        pair = (modes.index(origin), modes.index(destination))
        matrix[pair] = max(matrix[pair], 6., float(times[stage].max()) + margin_s)
        observed.add(pair)
    if len(observed) != 6:
        raise ValueError('transition probe must cover all six directed mode pairs')
    return tuple(tuple(float(value) for value in row) for row in transition_cost_matrix(matrix))
