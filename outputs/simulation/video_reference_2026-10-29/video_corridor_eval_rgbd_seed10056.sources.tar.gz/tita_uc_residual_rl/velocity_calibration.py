"""Validate and fit simulation-only posture-specific velocity inverse maps."""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path


POSTURES = ("LOW", "MID", "HIGH")
GOVERNOR_FIELDS = (
    "linear_bias", "linear_scale", "linear_kp", "angular_kp",
    "max_linear_command", "max_angular_command",
)
ANGULAR_FIELDS = ("angular_bias", "angular_scale", "lateral_kp")


def blend_governor_parameters(current: dict, target: dict, alpha: float) -> dict[str, float]:
    if not math.isfinite(alpha) or not 0.0 <= alpha <= 1.0:
        raise ValueError("governor transition blend must be in [0, 1]")
    if set(current) != set(target):
        raise ValueError("governor transition profiles must have matching fields")
    return {name: (1.0 - alpha) * current[name] + alpha * target[name] for name in current}


def validate_governor_profiles(profiles: dict) -> dict[str, dict[str, float]]:
    if set(profiles) != set(POSTURES):
        raise ValueError("velocity calibration requires exactly LOW, MID, and HIGH")
    validated = {}
    for posture in POSTURES:
        profile = profiles[posture]
        if not set(GOVERNOR_FIELDS) <= set(profile) or set(profile) - set(GOVERNOR_FIELDS + ANGULAR_FIELDS):
            raise ValueError(f"{posture} has missing or unknown governor parameters")
        values = {name: float(profile[name]) for name in GOVERNOR_FIELDS}
        values.update(angular_bias=float(profile.get("angular_bias", 0.0)),
                      angular_scale=float(profile.get("angular_scale", 1.0)),
                      lateral_kp=float(profile.get("lateral_kp", profile['linear_kp'])))
        if not all(math.isfinite(value) for value in values.values()):
            raise ValueError("velocity calibration parameters must be finite")
        if values["linear_scale"] <= 0.0 or values["angular_scale"] <= 0.0:
            raise ValueError("velocity inverse-map scale must be positive")
        if any(values[name] < 0.0 for name in GOVERNOR_FIELDS[2:]):
            raise ValueError("velocity gains and command limits must be non-negative")
        if values['lateral_kp'] < 0.0:
            raise ValueError('lateral velocity gain must be non-negative')
        validated[posture] = values
    return validated


def load_velocity_calibration(
    path: str | Path, *, posture_joint_anchors, checkpoint_path: str | Path,
    asset_path: str | Path,
) -> dict:
    payload = json.loads(Path(path).read_text())
    if payload.get("schema") != "tita.isaac_velocity_calibration.v1" or payload.get("simulation_only") is not True:
        raise ValueError("expected a simulation-only velocity calibration v1")
    actual_anchors = [[float(value) for value in row] for row in posture_joint_anchors]
    if payload.get("posture_joint_anchors") != actual_anchors:
        raise ValueError("velocity calibration does not match the active posture anchors")
    for name, source in (("checkpoint", checkpoint_path), ("asset", asset_path)):
        digest = hashlib.sha256(Path(source).read_bytes()).hexdigest()
        if payload.get(f"{name}_sha256") != digest:
            raise ValueError(f"velocity calibration does not match the active {name}")
    payload["profiles"] = validate_governor_profiles(payload["profiles"])
    return payload


def fit_velocity_calibration(report: dict, *, max_abs_velocity: float = 0.4) -> dict:
    if not math.isfinite(max_abs_velocity) or max_abs_velocity <= 0.0:
        raise ValueError("fit velocity bound must be finite and positive")
    profiles = {}
    diagnostics = {}
    for posture in POSTURES:
        points = []
        for result in report["results"]:
            specification = result["specification"]
            command = specification["command"]
            velocity = result["velocity_mean"][0]
            if (specification["posture"] == posture and "governor" not in specification
                    and result["all_valid"] and command[1:] == [0, 0]
                    and abs(velocity) <= max_abs_velocity):
                if not all(math.isfinite(value) for value in (command[0], velocity)):
                    raise ValueError("cannot fit non-finite response measurements")
                points.append((velocity, command[0]))
        if len(points) < 3 or not min(point[0] for point in points) < 0.0 < max(point[0] for point in points):
            raise ValueError(f"{posture} requires at least three valid points bracketing zero velocity")
        velocity_mean = sum(point[0] for point in points) / len(points)
        command_mean = sum(point[1] for point in points) / len(points)
        denominator = sum((point[0] - velocity_mean) ** 2 for point in points)
        scale = sum((velocity - velocity_mean) * (command - command_mean)
                    for velocity, command in points) / denominator
        bias = command_mean - scale * velocity_mean
        if scale <= 0.0:
            raise ValueError(f"{posture} has a non-positive command response")
        residuals = [abs((command - bias) / scale - velocity) for velocity, command in points]
        profiles[posture] = {
            "linear_bias": bias, "linear_scale": scale,
            "linear_kp": 0.8, "angular_kp": 0.5,
            "max_linear_command": 0.90, "max_angular_command": 1.0,
        }
        diagnostics[posture] = {
            "points_velocity_command": points,
            "fit_velocity_max_abs_error_mps": max(residuals),
            "fit_velocity_rmse_mps": math.sqrt(sum(value ** 2 for value in residuals) / len(points)),
        }
    return {
        "schema": "tita.isaac_velocity_calibration.v1", "simulation_only": True,
        "scope": "frozen actor, explicit Isaac posture anchors, flat-terrain low-speed calibration",
        "checkpoint_sha256": report["checkpoint_sha256"],
        "asset_sha256": report["asset_sha256"],
        "posture_joint_anchors": report["posture_joint_anchors"],
        "fit_max_abs_velocity_mps": max_abs_velocity,
        "profiles": validate_governor_profiles(profiles), "fit_diagnostics": diagnostics,
    }


def fit_angular_calibration(calibration: dict, report: dict) -> dict:
    if any(report[key] != calibration[key] for key in
           ("posture_joint_anchors", "checkpoint_sha256", "asset_sha256")):
        raise ValueError("yaw response must use the same frozen controller and posture anchors")
    result = json.loads(json.dumps(calibration))
    diagnostics = {}
    for posture in POSTURES:
        points = []
        for measurement in report["results"]:
            specification = measurement["specification"]
            if (specification["posture"] == posture and measurement["all_valid"]
                    and specification.get("governor", {}).get("angular_kp") == 0.0):
                measured = measurement["velocity_mean"][2]
                command = measurement["policy_command_mean"][2]
                if not all(math.isfinite(value) for value in (measured, command)):
                    raise ValueError("yaw response must be finite")
                points.append((measured, command))
        if len(points) < 3 or not min(point[0] for point in points) < 0.0 < max(point[0] for point in points):
            raise ValueError(f"{posture} requires yaw measurements bracketing zero")
        measured_mean = sum(point[0] for point in points) / len(points)
        command_mean = sum(point[1] for point in points) / len(points)
        denominator = sum((point[0] - measured_mean) ** 2 for point in points)
        scale = sum((measured - measured_mean) * (command - command_mean)
                    for measured, command in points) / denominator
        if scale <= 0.0:
            raise ValueError("yaw inverse-map scale must be positive")
        bias = command_mean - scale * measured_mean
        result["profiles"][posture].update(angular_bias=bias, angular_scale=scale)
        diagnostics[posture] = {
            "points_yaw_command": points,
            "fit_yaw_max_abs_error_radps": max(abs((command - bias) / scale - measured)
                                               for measured, command in points),
        }
    result["profiles"] = validate_governor_profiles(result["profiles"])
    result["angular_fit_diagnostics"] = diagnostics
    return result
