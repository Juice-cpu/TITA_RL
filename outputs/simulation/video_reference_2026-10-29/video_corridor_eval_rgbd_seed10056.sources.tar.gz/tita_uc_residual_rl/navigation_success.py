import math

import torch


def validate_navigation_goal(goal_xy, tolerance_m):
    if len(goal_xy) != 2 or not all(math.isfinite(value) for value in goal_xy):
        raise ValueError('navigation goal must contain two finite coordinates')
    if not math.isfinite(tolerance_m) or tolerance_m <= 0.0:
        raise ValueError('navigation goal tolerance must be finite and positive')
    return tuple(float(value) for value in goal_xy)


def navigation_goal_reached(local_xy, goal_xy, tolerance_m):
    goal_xy = validate_navigation_goal(goal_xy, tolerance_m)
    goal = local_xy.new_tensor(goal_xy)
    return torch.linalg.vector_norm(local_xy - goal, dim=-1) <= tolerance_m
