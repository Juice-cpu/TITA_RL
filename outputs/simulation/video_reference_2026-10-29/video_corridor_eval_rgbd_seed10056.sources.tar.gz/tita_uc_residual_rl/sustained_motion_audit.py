import math

from .navigation_acceptance_audit import audit_navigation_execution


def mode_motion_intervals(document, posture='LOW', minimum_duration_s=5., minimum_displacement_m=.5):
    if posture not in ('LOW', 'MID', 'HIGH'):
        raise ValueError('unknown execution posture')
    if not all(math.isfinite(value) and value > 0. for value in (minimum_duration_s, minimum_displacement_m)):
        raise ValueError('motion acceptance thresholds must be finite and positive')
    completed = document.get('completed_steps', 0)
    elapsed = document.get('elapsed_simulation_s', 0.)
    if not isinstance(completed, int) or isinstance(completed, bool) or completed <= 0 or not math.isfinite(elapsed) or elapsed <= 0.:
        return {'passed': False, 'failures': ['missing_positive_simulation_clock'], 'intervals': []}
    timestep = elapsed / completed
    rows = document.get('trajectory', [])
    failures, intervals = [], []
    interval = None
    previous = None

    def finish():
        nonlocal interval
        if interval is None:
            return
        start, end = interval.pop('start_xy_m'), interval.pop('end_xy_m')
        interval['displacement_m'] = math.dist(start, end)
        interval['start_xy_m'], interval['end_xy_m'] = start, end
        interval['sustained_motion_passed'] = (interval['duration_s'] >= minimum_duration_s - 1e-8
            and interval['displacement_m'] >= minimum_displacement_m
            and interval['goal_progress_m'] >= minimum_displacement_m)
        intervals.append(interval)
        interval = None

    try:
        goal = document['goal_xy_m']
        if len(goal) != 2 or not all(math.isfinite(value) for value in goal):
            raise ValueError('invalid_goal')
        if len(rows) != completed:
            raise ValueError('trajectory_not_complete')
        seen_episodes = set()
        for row in rows:
            episode, step = row['episode'], row['step']
            feedback = row['goal_feedback_after']
            before, after = row['root_position_before'], feedback['root_position_world_m']
            command = row['command']
            timestamp = feedback['time_s']
            speed = feedback['planar_speed_mps']
            values = (*before, *after, *command, timestamp, speed, feedback['roll_rad'], feedback['pitch_rad'],
                feedback['posture_height_m'], feedback['posture_target_height_m'])
            if (len(before) != 3 or len(after) != 3 or len(command) != 2
                    or not all(math.isfinite(value) for value in values) or speed < 0.
                    or not isinstance(step, int) or not isinstance(episode, int)):
                raise ValueError('invalid_physical_motion_feedback')
            if previous is not None:
                if step != previous['step'] + 1:
                    raise ValueError('global_step_gap')
                if episode == previous['episode']:
                    if abs(timestamp - previous['time_s'] - timestep) > 1e-6:
                        raise ValueError('physical_clock_gap')
                    if math.dist(before, previous['after']) > 1e-6 and not previous['auto_reset']:
                        raise ValueError('discontinuous_measured_position')
                else:
                    finish()
                    if episode in seen_episodes or episode != previous['episode'] + 1:
                        raise ValueError('nonsequential_episode')
            seen_episodes.add(episode)
            active = (row['posture'] == posture and row['mode_execution_ready'] is True
                and row['pending_posture'] is None and row['safe_wait'] is False
                and command[0] > .02 and speed > .02
                and row['wheel_contacts_before'] == [True, True] and feedback['wheel_contacts'] == [True, True]
                and abs(feedback['posture_height_m'] - feedback['posture_target_height_m']) <= .025
                and max(abs(feedback['roll_rad']), abs(feedback['pitch_rad'])) <= .2
                and not row['terminated'] and not row['truncated'] and row['execution_timeout_reason'] is None
                and not row.get('live_clearance_brake', False) and not row.get('overspeed_brake', False))
            if active:
                if interval is None:
                    interval = {'episode': episode, 'start_step': step, 'end_step': step,
                        'start_time_s': timestamp, 'end_time_s': timestamp + timestep, 'duration_s': 0.,
                        'frames': 0, 'start_xy_m': list(before[:2]), 'end_xy_m': list(after[:2]),
                        'goal_progress_m': 0., 'minimum_measured_speed_mps': speed}
                interval['end_step'] = step
                interval['end_time_s'] = timestamp + timestep
                interval['duration_s'] += timestep
                interval['frames'] += 1
                interval['end_xy_m'] = list(after[:2])
                interval['goal_progress_m'] += math.dist(before[:2], goal) - math.dist(after[:2], goal)
                interval['minimum_measured_speed_mps'] = min(interval['minimum_measured_speed_mps'], speed)
            else:
                finish()
            previous = {'step': step, 'episode': episode, 'time_s': timestamp,
                'after': after, 'auto_reset': bool(row['terminated'] or row['truncated'])}
        finish()
    except (KeyError, TypeError, ValueError, IndexError, OverflowError) as error:
        failures.append(str(error))
        interval = None
    return {'passed': not failures and any(row['sustained_motion_passed'] for row in intervals),
        'failures': failures, 'posture': posture, 'minimum_duration_s': minimum_duration_s,
        'minimum_displacement_m': minimum_displacement_m, 'minimum_goal_progress_m': minimum_displacement_m,
        'intervals': intervals, 'dynamic_risk_causality_proven': False,
        'scope': 'Consecutive ready, contacted, commanded physical motion, not a mode-selection or dynamic-causality certificate.'}


def audit_sustained_mode_motion(document, posture='LOW', minimum_duration_s=5., minimum_displacement_m=.5,
                               verify_artifacts=True):
    navigation = audit_navigation_execution(document, verify_artifacts=verify_artifacts)
    motion = mode_motion_intervals(document, posture, minimum_duration_s, minimum_displacement_m)
    return {'schema': 'tita.sustained_mode_physical_motion_audit.v1',
        'passed': navigation['status'] == 'passed' and motion['passed'], 'navigation': navigation, 'motion': motion,
        'dynamic_risk_causality_proven': False, 'all_goals_complete': False,
        'scope': 'Logged physical passage and independent navigation replay only; terrain or people causality needs separate policy/geometry evidence.'}
