"""Masked categorical PPO for the independent upper-level route policy."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import nn

from .upper_level_objective import action_mask
from .upper_level_types import (
    UPPER_ACTION_COUNT,
    UPPER_OBSERVATION_DIM,
    UpperDecision,
    UpperObservation,
    UpperSafetyConfig,
)


def observation_scale(device: torch.device | str = "cpu") -> torch.Tensor:
    """Frozen, interpretable scales for the 38 raw observation fields."""

    route_scale = [1.0, 5.0, 0.5, 0.10, 0.20, 0.20, 0.03, 1.0] * 3
    global_scale = [
        0.15,
        0.25,
        0.25,
        1.0,
        1.0,
        1.0,
        1.0,
        1.0,
        1.0,
        1.0,
        20.0,
        5.0,
        0.75,
        0.75,
    ]
    scale = torch.tensor(route_scale + global_scale, dtype=torch.float32, device=device)
    if scale.shape != (UPPER_OBSERVATION_DIM,):
        raise RuntimeError(f"invalid observation scale shape {scale.shape}")
    return scale


def normalize_observation(observation: torch.Tensor) -> torch.Tensor:
    return observation / observation_scale(observation.device).clamp_min(1e-6)


@dataclass(frozen=True)
class CategoricalPPOConfig:
    gamma: float = 0.99
    gae_lambda: float = 0.95
    clip_ratio: float = 0.20
    learning_rate: float = 3e-4
    entropy_coefficient: float = 0.01
    value_coefficient: float = 0.5
    epochs: int = 4
    mini_batches: int = 4
    maximum_gradient_norm: float = 1.0


@dataclass(frozen=True)
class CategoricalPPOStats:
    policy_loss: float
    value_loss: float
    entropy: float
    approximate_kl: float
    clip_fraction: float


class UpperActorCritic(nn.Module):
    """Two-layer actor/critic with masked categorical route actions."""

    def __init__(
        self,
        observation_dim: int = UPPER_OBSERVATION_DIM,
        action_count: int = UPPER_ACTION_COUNT,
    ) -> None:
        super().__init__()
        self.observation_dim = int(observation_dim)
        self.action_count = int(action_count)
        self.encoder = nn.Sequential(
            nn.Linear(self.observation_dim, 256),
            nn.ELU(),
            nn.Linear(256, 128),
            nn.ELU(),
        )
        self.actor = nn.Linear(128, self.action_count)
        self.critic = nn.Linear(128, 1)

    def forward(self, observation: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        if observation.shape[-1] != self.observation_dim:
            raise ValueError(
                f"expected observation dim {self.observation_dim}, got {observation.shape[-1]}"
            )
        hidden = self.encoder(normalize_observation(observation))
        return self.actor(hidden), self.critic(hidden).squeeze(-1)

    def distribution(
        self, observation: torch.Tensor, valid_actions: torch.Tensor
    ) -> tuple[torch.distributions.Categorical, torch.Tensor]:
        logits, value = self(observation)
        valid_actions = valid_actions.to(dtype=torch.bool, device=logits.device)
        if valid_actions.shape != logits.shape:
            raise ValueError("action mask must have the same shape as actor logits")
        if torch.any(~valid_actions.any(dim=-1)):
            raise ValueError("categorical distribution requires at least one feasible action")
        masked_logits = logits.masked_fill(~valid_actions, torch.finfo(logits.dtype).min)
        return torch.distributions.Categorical(logits=masked_logits), value

    @torch.no_grad()
    def act(
        self,
        observation: torch.Tensor,
        valid_actions: torch.Tensor,
        deterministic: bool = False,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        distribution, value = self.distribution(observation, valid_actions)
        action = torch.argmax(distribution.logits, dim=-1) if deterministic else distribution.sample()
        return action, distribution.log_prob(action), value, distribution.entropy()


def generalized_advantage(
    rewards: torch.Tensor,
    values: torch.Tensor,
    last_value: torch.Tensor,
    done: torch.Tensor,
    gamma: float,
    gae_lambda: float,
) -> tuple[torch.Tensor, torch.Tensor]:
    advantages = torch.zeros_like(rewards)
    running = torch.zeros_like(last_value)
    for index in reversed(range(rewards.shape[0])):
        next_value = last_value if index == rewards.shape[0] - 1 else values[index + 1]
        not_done = 1.0 - done[index].to(rewards.dtype)
        delta = rewards[index] + gamma * not_done * next_value - values[index]
        running = delta + gamma * gae_lambda * not_done * running
        advantages[index] = running
    return advantages, advantages + values


class MaskedCategoricalPPO:
    def __init__(
        self,
        model: UpperActorCritic,
        config: CategoricalPPOConfig | None = None,
    ) -> None:
        self.model = model
        self.config = config or CategoricalPPOConfig()
        self.optimizer = torch.optim.Adam(model.parameters(), lr=self.config.learning_rate)

    def update(
        self,
        observations: torch.Tensor,
        action_masks: torch.Tensor,
        actions: torch.Tensor,
        old_log_probabilities: torch.Tensor,
        advantages: torch.Tensor,
        returns: torch.Tensor,
    ) -> CategoricalPPOStats:
        flat_observations = observations.flatten(0, 1)
        flat_masks = action_masks.flatten(0, 1)
        flat_actions = actions.flatten()
        flat_old_log_probabilities = old_log_probabilities.flatten()
        flat_advantages = advantages.flatten()
        flat_returns = returns.flatten()
        flat_advantages = (flat_advantages - flat_advantages.mean()) / (
            flat_advantages.std(unbiased=False) + 1e-8
        )
        count = flat_observations.shape[0]
        batch_size = max(1, count // self.config.mini_batches)
        totals = torch.zeros(5, device=flat_observations.device)
        update_count = 0
        for _ in range(self.config.epochs):
            permutation = torch.randperm(count, device=flat_observations.device)
            for start in range(0, count, batch_size):
                indices = permutation[start : start + batch_size]
                distribution, value = self.model.distribution(
                    flat_observations[indices], flat_masks[indices]
                )
                log_probability = distribution.log_prob(flat_actions[indices])
                ratio = torch.exp(log_probability - flat_old_log_probabilities[indices])
                unclipped = ratio * flat_advantages[indices]
                clipped = ratio.clamp(
                    1.0 - self.config.clip_ratio, 1.0 + self.config.clip_ratio
                ) * flat_advantages[indices]
                policy_loss = -torch.minimum(unclipped, clipped).mean()
                value_loss = 0.5 * torch.square(value - flat_returns[indices]).mean()
                entropy = distribution.entropy().mean()
                loss = (
                    policy_loss
                    + self.config.value_coefficient * value_loss
                    - self.config.entropy_coefficient * entropy
                )
                self.optimizer.zero_grad(set_to_none=True)
                loss.backward()
                nn.utils.clip_grad_norm_(
                    self.model.parameters(), self.config.maximum_gradient_norm
                )
                self.optimizer.step()
                approximate_kl = (
                    flat_old_log_probabilities[indices] - log_probability
                ).mean().abs()
                clip_fraction = (
                    torch.abs(ratio - 1.0) > self.config.clip_ratio
                ).to(torch.float32).mean()
                totals += torch.stack(
                    (
                        policy_loss.detach(),
                        value_loss.detach(),
                        entropy.detach(),
                        approximate_kl.detach(),
                        clip_fraction.detach(),
                    )
                )
                update_count += 1
        means = totals / max(1, update_count)
        return CategoricalPPOStats(*(float(value) for value in means))


class LearnedUpperPolicy:
    """Adapter exposing the common deterministic baseline policy interface."""

    def __init__(
        self,
        model: UpperActorCritic,
        safety: UpperSafetyConfig | None = None,
        deterministic: bool = True,
        device: torch.device | str = "cpu",
    ) -> None:
        self.model = model.to(device)
        self.safety = safety or UpperSafetyConfig()
        self.deterministic = bool(deterministic)
        self.device = torch.device(device)
        self.model.eval()

    def decide(self, observation: UpperObservation) -> UpperDecision:
        mask = action_mask(observation, self.safety)
        if not mask.any():
            return UpperDecision.stop("no_feasible_action")
        observation_tensor = torch.as_tensor(
            observation.vector(), dtype=torch.float32, device=self.device
        ).unsqueeze(0)
        mask_tensor = torch.as_tensor(mask, dtype=torch.bool, device=self.device).unsqueeze(0)
        action, _, _, _ = self.model.act(
            observation_tensor, mask_tensor, deterministic=self.deterministic
        )
        return UpperDecision.from_action(int(action.item()), observation, "categorical_ppo")


def save_upper_checkpoint(
    path: str | Path,
    model: UpperActorCritic,
    *,
    normalization: dict[str, float],
    config: CategoricalPPOConfig,
    metadata: dict[str, Any] | None = None,
) -> None:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "format_version": 1,
            "model_state_dict": model.state_dict(),
            "observation_dim": model.observation_dim,
            "action_count": model.action_count,
            "normalization": dict(normalization),
            "ppo_config": asdict(config),
            "metadata": dict(metadata or {}),
        },
        destination,
    )


def load_upper_checkpoint(
    path: str | Path, device: torch.device | str = "cpu"
) -> tuple[UpperActorCritic, dict[str, Any]]:
    payload = torch.load(Path(path), map_location=device, weights_only=False)
    if payload.get("format_version") != 1:
        raise ValueError("unsupported upper-level checkpoint format")
    model = UpperActorCritic(
        observation_dim=int(payload["observation_dim"]),
        action_count=int(payload["action_count"]),
    ).to(device)
    model.load_state_dict(payload["model_state_dict"])
    model.eval()
    return model, payload

