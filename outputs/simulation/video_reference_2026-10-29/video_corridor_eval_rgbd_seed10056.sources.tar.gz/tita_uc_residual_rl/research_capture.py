import json
from pathlib import Path
import subprocess

import numpy as np


class ResearchVideo:
    def __init__(self, env, output, ffmpeg_path, label, fps=10):
        import omni.replicator.core as rep
        import omni.usd
        from pxr import Gf, UsdGeom
        from PIL import ImageFont

        self.env = env
        self.output = Path(output)
        if self.output.exists():
            raise FileExistsError('never overwrite an existing research video')
        self.output.parent.mkdir(parents=True, exist_ok=True)
        self.label = label
        self.follow_side = 1.0 if env.cfg.navigation_goal_xy_m[1] >= 0.0 else -1.0
        self.frames = 0
        self.frame_log = self.output.with_suffix('.frames.jsonl').open('x')
        self.font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 20)
        self.camera_paths = ['/World/ResearchFollowCamera', '/World/ResearchOverviewCamera']
        self.transforms = []
        self.annotators = []
        stage = omni.usd.get_context().get_stage()
        marker = UsdGeom.Cylinder.Define(stage, '/World/ResearchGoalMarker')
        marker.CreateRadiusAttr(0.35)
        marker.CreateHeightAttr(0.004)
        marker.CreateDisplayColorAttr([Gf.Vec3f(0.05, 0.75, 0.55)])
        UsdGeom.Xformable(marker).AddTranslateOp().Set(Gf.Vec3d(*env.cfg.navigation_goal_xy_m, 0.01))
        for path, resolution in zip(self.camera_paths, [(1280, 720), (480, 270)]):
            camera = UsdGeom.Camera.Define(stage, path)
            camera.GetFocalLengthAttr().Set(18.0)
            self.transforms.append(UsdGeom.Xformable(camera).AddTransformOp())
            product = rep.create.render_product(path, resolution)
            annotator = rep.AnnotatorRegistry.get_annotator('rgb')
            annotator.attach([product])
            self.annotators.append(annotator)
        self._set_views()
        for _ in range(10):
            env.sim.render()
        self.encoder_log = self.output.with_suffix('.encoder.log').open('x')
        self.encoder = subprocess.Popen([
            str(ffmpeg_path), '-hide_banner', '-loglevel', 'warning', '-n',
            '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', '1280x720', '-r', str(fps),
            '-i', '-', '-an', '-c:v', 'libx264', '-preset', 'fast', '-crf', '20',
            '-pix_fmt', 'yuv420p', '-movflags', '+faststart', str(self.output),
        ], stdin=subprocess.PIPE, stderr=self.encoder_log)

    def _set_views(self):
        from pxr import Gf

        position = self.env.robot.data.root_pos_w[0].tolist()
        eye = Gf.Vec3d(position[0] - 1.5, position[1] + self.follow_side * 0.18, position[2] + 0.04)
        target = Gf.Vec3d(position[0] + 0.15, position[1], position[2])
        if getattr(self.env.cfg, 'navigation_scene_file', ''):
            eye = Gf.Vec3d(position[0] - 2.0, position[1] - 1.8, position[2] + 2.3)
            target = Gf.Vec3d(position[0] + 0.3, position[1], position[2])
        self.transforms[0].Set(Gf.Matrix4d().SetLookAt(eye, target, Gf.Vec3d(0, 0, 1)).GetInverse())
        self.transforms[1].Set(Gf.Matrix4d().SetLookAt(
            Gf.Vec3d(4, -8.5, 8.5), Gf.Vec3d(4, -0.4, 0.15), Gf.Vec3d(0, 0, 1)).GetInverse())

    def capture(self, metadata):
        from PIL import Image, ImageDraw

        self._set_views()
        self.env.sim.render()
        images = [annotator.get_data() for annotator in self.annotators]
        if images[0].shape[:2] != (720, 1280) or images[1].shape[:2] != (270, 480):
            raise RuntimeError('Isaac renderer returned an invalid camera frame')
        image = Image.fromarray(np.asarray(images[0][..., :3], dtype=np.uint8))
        image.paste(Image.fromarray(np.asarray(images[1][..., :3], dtype=np.uint8)).resize((384, 216)), (880, 16))
        draw = ImageDraw.Draw(image)
        draw.rectangle((0, 0, 870, 70), fill=(12, 18, 26))
        draw.rectangle((0, 650, 1280, 720), fill=(12, 18, 26))
        draw.text((16, 10), 'TITA | Isaac physical simulation | ' + self.label, font=self.font, fill='white')
        draw.text((16, 38), 'Actual simulator render; no hardware; no trajectory animation', font=self.font, fill=(168, 198, 220))
        details = (f"sim t={metadata['sim_time_s']:.2f}s | episode={metadata['episode_id']} | "
                   f"action={metadata['action_id']} | physics status={metadata['status']}")
        draw.text((16, 660), details, font=self.font, fill='white')
        draw.text((16, 688), f"goal distance={metadata['goal_distance_m']:.3f} m | 1x simulation time | 10 fps", font=self.font, fill=(168, 198, 220))
        self.encoder.stdin.write(np.asarray(image, dtype=np.uint8).tobytes())
        if self.frames == 0:
            image.save(self.output.with_suffix('.preview.jpg'))
        self.frame_log.write(json.dumps(dict(frame=self.frames, **metadata)) + '\n')
        self.frame_log.flush()
        self.frames += 1

    def close(self):
        self.encoder.stdin.close()
        result = self.encoder.wait(timeout=120)
        self.encoder_log.close()
        self.frame_log.close()
        if result or self.frames == 0:
            raise RuntimeError('research video encoding failed or recorded no frames')
