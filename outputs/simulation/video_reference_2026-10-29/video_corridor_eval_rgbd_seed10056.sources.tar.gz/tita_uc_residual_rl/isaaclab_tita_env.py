"""Isaac Lab 2.0 DirectRLEnv for an 8-DOF TITA residual controller.

The file is intentionally not imported by the simulator-independent package
tests.  Launch it through ``isaaclab.sh -p`` after supplying an 8-DOF USD or
URDF asset with ``TITA_USD_PATH``/``TITA_URDF_PATH``.  The local ROS URDF is
not silently accepted because it exposes a different joint contract.
"""

from __future__ import annotations

import os
import math
from pathlib import Path

import gymnasium as gym
import carb
import numpy as np
import torch
import trimesh

import isaaclab.envs.mdp as mdp
import isaaclab.sim as sim_utils
from isaaclab.assets import Articulation, ArticulationCfg, RigidObject, RigidObjectCfg
from isaaclab.envs import DirectRLEnv, DirectRLEnvCfg
from isaaclab.managers import EventTermCfg as EventTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.scene import InteractiveSceneCfg
from isaaclab.sensors import Camera, CameraCfg, ContactSensor, ContactSensorCfg, RayCaster, RayCasterCfg, patterns
from isaaclab.sim import SimulationCfg
from isaaclab.terrains import TerrainImporterCfg
from isaaclab.terrains.utils import create_prim_from_mesh
from isaaclab.utils import configclass
from isaaclab.utils.math import quat_from_euler_xyz
from isaaclab.actuators import ImplicitActuatorCfg
from omni.physx.bindings._physx import SETTING_COLLISION_APPROXIMATE_CYLINDERS

from .asset_check import require_official_tita_urdf
from .config import TITA_JOINT_NAMES
from .posture_calibration import load_posture_calibration, posture_anchors
from .runtime_asset_directory import create_runtime_asset_directory
from .official_policy import build_official_proprioception
from .navigation_sensors import make_navigation_lidar_cfg
from .navigation_success import navigation_goal_reached
from .navigation_command_curriculum import navigation_tracking_penalty
from .route_choice_scene import RouteChoiceConfig, route_choice_boxes
from .three_route_scene import ThreeRouteSceneConfig, three_route_boxes
from .safety_actuation import (
    apply_velocity_torque_guard,
    filter_residual_action,
    project_joint_velocity,
)
from .stair_curriculum import StairCurriculumConfig, sample_stair_dimensions, stair_box_vertical_geometry
from .stair_step_sequence import (
    STAIR_PHASE_COUNT,
    STAIR_PHASE_SHIFT_TO_TRAIL,
    STAIR_PHASE_LEAD_PLACE,
    STAIR_PHASE_SETTLE,
    StairStepSequenceConfig,
    advance_stair_sequence,
    alternating_stair_assist,
    gate_stair_residual,
    ground_relative_wheel_reference,
    fully_supported_stair_traversal,
    lead_place_residual_prior,
    select_reached_wheel_as_lead,
    stair_phase,
    stair_stable_state,
    stair_stationary_state,
    transition_sequence_on_level_advance,
)
from .tunnel_curriculum import TunnelCurriculumConfig, sample_tunnel_dimensions


HARD_REASON_NAMES = (
    "infeasible_projection",
    "velocity",
    "acceleration",
    "torque",
    "collision",
    "height",
    "attitude",
    "clearance",
)


@configclass
class TitaDomainRandomizationCfg:
    """Conservative simulation-only Phase B2 randomization defaults."""

    physics_material = EventTerm(
        func=mdp.randomize_rigid_body_material,
        mode="startup",
        params={
            "asset_cfg": SceneEntityCfg("robot", body_names=".*"),
            "static_friction_range": (0.7, 1.2),
            "dynamic_friction_range": (0.5, 1.0),
            "restitution_range": (0.0, 0.05),
            "num_buckets": 32,
        },
    )
    base_mass = EventTerm(
        func=mdp.randomize_rigid_body_mass,
        mode="startup",
        params={
            "asset_cfg": SceneEntityCfg("robot", body_names="base_link"),
            "mass_distribution_params": (-2.0, 2.0),
            "operation": "add",
        },
    )


@configclass
class TitaResidualEnvCfg(DirectRLEnvCfg):
    """Configuration preserving the official 8-D joint-target interface."""

    episode_length_s = 20.0
    decimation = 4
    action_scale = 1.0
    action_space = 8
    convex_cylinder_collisions = False
    # The original 51 values are followed by 11 stair-sequence values: phase,
    # progress, lead side, per-wheel contact, x/z relative to the next tread,
    # and independently verified wheel levels.
    observation_space = 62
    state_space = 0
    sim: SimulationCfg = SimulationCfg(
        dt=1.0 / 200.0,
        render_interval=decimation,
        device="cuda:0",
        disable_contact_processing=True,
    )
    scene: InteractiveSceneCfg = InteractiveSceneCfg(num_envs=1024, env_spacing=3.0, replicate_physics=True)
    terrain = TerrainImporterCfg(prim_path="/World/ground", terrain_type="plane")
    contact_sensor = ContactSensorCfg(
        prim_path="/World/envs/env_.*/Robot/.*",
        history_length=3,
        update_period=0.005,
        track_air_time=False,
    )
    height_scanner: RayCasterCfg | None = None
    navigation_lidar: RayCasterCfg | None = None
    physical_pedestrian_enabled = False
    physical_pedestrian_initial_xyz_m = (2.0, -1.0, 0.9)
    physical_pedestrian_positions_xyz_m = ()
    physical_pedestrian_radius_m = 0.30
    rendered_inspection_camera_enabled = False
    rendered_external_camera_enabled = False
    perception_preview_mesh = False
    route_choice_enabled = False
    route_choice_wall_start_x_m = 0.50
    route_choice_wall_end_x_m = 6.00
    route_choice_obstacle_start_x_m = 2.00
    route_choice_obstacle_length_m = 2.00
    route_choice_obstacle_half_width_m = 0.40
    route_choice_narrow_width_m = 0.65
    route_choice_wide_width_m = 1.60
    route_choice_wall_height_m = 0.80
    route_choice_wall_thickness_m = 0.10
    route_choice_goal_x_m = 5.50
    three_route_enabled = False
    navigation_scene_file = ""
    sudden_obstacle_file = ""
    navigation_goal_tolerance_m = 0.30
    navigation_terminate_on_goal = True
    navigation_goal_xy_m = (8.0, 0.0)
    tunnel_enabled = False
    tunnel_height_range_m = (0.34, 0.44)
    tunnel_width_range_m = (0.40, 0.65)
    tunnel_length_range_m = (0.60, 1.50)
    tunnel_start_x_m = 0.75
    tunnel_wall_thickness_m = 0.10
    tunnel_preview_distance_m = 1.50
    tunnel_clearance_buffer_m = 0.01
    tunnel_success_reward = 10.0
    tunnel_terminate_on_success = True
    stair_enabled = False
    stair_step_height_range_m = (0.025, 0.045)
    stair_tread_range_m = (0.55, 0.67)
    stair_width_range_m = (0.90, 1.20)
    stair_num_steps = 3
    stair_start_x_m = 0.75
    stair_landing_length_m = 0.80
    stair_foundation_depth_m = 0.0
    stair_mesh_collider_enabled = False
    stair_handrail_enabled = False
    stair_training_corridor_enabled = False
    stair_support_augmentation_enabled = False
    stair_support_augmentation_offset_m = 12.0
    stair_handrail_height_m = 0.90
    stair_handrail_thickness_m = 0.05
    stair_handrail_side_offset_m = 0.06
    stair_handrail_post_spacing_m = 0.90
    stair_handrail_follow_slope = True
    stair_preview_distance_m = 1.50
    stair_success_reward = 12.0
    stair_success_stable_hold_s = 0.0
    stair_terminate_on_success = True
    stair_height_progress_reward_scale = 4.0
    stair_step_progress_reward = 3.0
    stair_level_hold_reward_scale = 0.5
    stair_stable_hold_reward_scale = 0.5
    stair_approach_lift_reward_scale = 1.0
    stair_approach_lift_distance_m = 0.30
    stair_collision_penalty = 2.0
    stair_collision_terminates = True
    stair_step_assist_enabled = False
    stair_approach_yaw_rad = 0.0
    stair_approach_lead_side = "random"
    stair_step_assist_trigger_distance_m = 0.18
    stair_step_assist_shift_steps = 10
    stair_step_assist_retract_steps = 10
    stair_step_assist_place_steps = 14
    stair_step_assist_settle_steps = 12
    stair_step_assist_hip_retract_rad = 0.25
    stair_step_assist_hip_place_rad = 0.45
    stair_step_assist_knee_retract_rad = 0.80
    stair_step_assist_knee_place_rad = 0.70
    stair_step_assist_support_hip_rad = 0.25
    stair_step_assist_support_knee_rad = 0.30
    stair_step_assist_lateral_shift_rad = 0.18
    stair_step_assist_support_lateral_scale = 0.0
    stair_step_assist_inward_hold_rad = 0.0
    stair_step_assist_wheel_drive = 0.0
    stair_step_assist_wheel_impulse_scale = 1.0
    stair_step_assist_event_driven = False
    stair_step_assist_drive_from_shift = False
    stair_step_assist_brake_torque = 10.0
    stair_residual_phase_gating = False
    stair_lead_place_hip_residual = 0.0
    stair_lead_place_knee_residual = 0.0
    stair_support_place_hip_residual = 0.0
    stair_support_place_knee_residual = 0.0
    stair_lead_wheel_reward = 12.0
    stair_trail_wheel_reward = 24.0
    stair_lead_lift_progress_reward = 20.0
    stair_lead_unload_reward = 10.0
    stair_rolling_contact_reward_scale = 0.25
    stair_single_wheel_lag_penalty = 0.5
    stair_single_wheel_grace_steps = 30
    stair_completion_height_tolerance_m = 0.005
    stair_start_delay_steps = 75
    stair_height_preview_reference_m = 0.10
    base_collision_half_length_m = 0.235
    base_collision_half_width_m = 0.15
    base_collision_half_height_m = 0.095
    base_collision_center_z_m = 0.017

    residual_limit = 0.20
    posture_scale = 0.75
    residual_filter_alpha = 0.25
    joint_target_change_reference = 0.50
    tracking_reward_scale = 2.0
    route_reward_scale = 0.40
    energy_cost_scale = 0.35
    mode_cost_scale = 0.25
    smooth_cost_scale = 0.05
    route_length_weight = 0.40
    route_clearance_weight = 0.35
    route_curvature_weight = 0.25
    dynamic_obstacle_risk_weight = 0.20
    route_reference_length = 5.0
    clearance_sigma = 0.30
    corridor_half_width = 0.50
    posture_heights = (0.10, 0.20, 0.30)
    # Read-only real-robot posture seed. This supplies initial posture
    # anchors only; geometry, vmax, braking P5, and energy remain uncalibrated.
    posture_calibration_path = ""
    # Simulation-only pose anchors calibrated by scripts/calibrate_posture_poses.py
    # with the frozen official balancing policy, including a 0.20 m/s stability gate.
    posture_joint_anchors = (
        (0.0, 0.76, -2.150, 0.0, 0.0, 0.76, -2.150, 0.0),
        (0.0, 0.90, -1.800, 0.0, 0.0, 0.90, -1.800, 0.0),
        (0.0, 0.90, -1.100, 0.0, 0.0, 0.90, -1.100, 0.0),
    )
    posture_feedforward_transition_s = 1.5
    enable_posture_feedforward = True
    wheel_radius = 0.0925
    height_rate_reference = 0.10
    mode_height_rate_weight = 0.50
    mode_hold_weight = 0.50
    mode_switch_cost_weight = 0.35
    rapid_mode_switch_cost_weight = 0.75
    rapid_mode_switch_window_s = 2.0
    # Frozen offline P95 values. Keep at one only while collecting the
    # baseline calibration set, then write the measured values to config.
    objective_p95 = (0.0007925402, 1.9832050, 0.6782783, 0.06604067)
    normalized_cost_clip = float("inf")
    hard_failure_cost = 10.0
    clearance_default = 1.0
    safe_clearance = 0.20
    clearance_hold_margin = 0.0
    clearance_release_hysteresis = 0.10
    terrain_step_threshold = 0.055
    terrain_drop_threshold = 0.075
    terrain_preview_threshold = 0.002
    hard_clearance_half_width = 0.25
    navigation_linear_tracking_penalty = 0.0
    navigation_stationary_hold_reward_scale = 0.0
    navigation_stationary_interruption_penalty = 0.0
    navigation_yaw_tracking_penalty = 0.0
    navigation_tilt_penalty = 0.0
    navigation_lateral_deviation_penalty = 0.0
    navigation_posture_height_penalty = 0.0
    navigation_pose_observations = False
    collision_force_threshold = 20.0
    soft_contact_cost_weight = 0.10
    reset_stabilization_steps = 10
    # Asset limits from the official TITA URDF.
    leg_torque_limit = 60.0
    wheel_torque_limit = 15.0
    leg_velocity_limit = 25.0
    wheel_velocity_limit = 20.0
    velocity_safety_margin = 1.0
    # This remains disabled until an official-policy simulation baseline is
    # measured. The URDF does not define an acceleration limit.
    acceleration_limit = 80.0
    acceleration_filter_time_constant = 0.10
    enforce_acceleration_limit = False
    enable_safety_projector = True
    project_target_kinematics = False
    # Official leg PD and wheel torque-proxy gains.
    leg_kp = 40.0
    leg_kd = 1.0
    wheel_target_gain = 10.0
    wheel_damping = 0.5
    wheel_hold_brake_torque = 3.0

    robot: ArticulationCfg = None  # type: ignore[assignment]


def build_tita_cfg(
    asset_path: str | None = None,
    *,
    num_envs: int = 1024,
    terrain: str = "flat",
    domain_randomization: bool = False,
) -> TitaResidualEnvCfg:
    """Build a task configuration from an explicit 8-DOF USD/URDF path."""
    asset = asset_path or os.environ.get("TITA_USD_PATH")
    if not asset:
        raise ValueError("set TITA_USD_PATH to the converted official 8-DOF TITA USD")
    asset_path_obj = Path(asset).expanduser()
    if not asset_path_obj.exists():
        raise FileNotFoundError(asset_path_obj)
    cfg = TitaResidualEnvCfg()
    calibration_path = os.environ.get(
        "TITA_POSTURE_CALIBRATION",
        str(Path(__file__).resolve().parents[1] / "assets" / "tita_tower" / "calibration" / "real_posture_seeds_20261011.json"),
    )
    calibration = load_posture_calibration(calibration_path)
    cfg.posture_calibration_path = str(Path(calibration_path).expanduser().resolve())
    cfg.posture_heights = tuple(
        float(calibration["profiles"][name]["command_height_m"])
        for name in ("LOW", "MID", "HIGH")
    )
    cfg.posture_joint_anchors = posture_anchors(calibration)
    # Isaac Lab normally runs on CUDA, but keeping this overridable makes
    # diagnostics reproducible on machines where only the CPU backend is
    # available (for example CI or a driver-recovery session).
    cfg.sim.device = os.environ.get("TITA_SIM_DEVICE", cfg.sim.device)
    cfg.scene.num_envs = int(num_envs)
    if terrain not in (
        "flat", "rough_warmup", "route_choice", "three_route", "tunnel", "stairs"
    ):
        raise ValueError(
            "terrain must be 'flat', 'rough_warmup', 'route_choice', "
            "'three_route', 'tunnel', or 'stairs'"
        )
    if terrain == "rough_warmup":
        cfg.perception_preview_mesh = True
        cfg.clearance_hold_margin = 0.35
        cfg.height_scanner = RayCasterCfg(
            prim_path="/World/envs/env_.*/Robot/base_link",
            offset=RayCasterCfg.OffsetCfg(pos=(0.0, 0.0, 1.0)),
            attach_yaw_only=True,
            pattern_cfg=patterns.GridPatternCfg(resolution=0.1, size=(1.6, 2.2)),
            max_distance=3.0,
            debug_vis=False,
            mesh_prim_paths=["/World/perception_preview/terrain"],
        )
    elif terrain == "route_choice":
        cfg.route_choice_enabled = True
        cfg.scene.env_spacing = 9.0
        cfg.navigation_lidar = make_navigation_lidar_cfg(
            "/World/route_choice/mesh",
            update_period=0.05,
            horizontal_resolution_deg=2.0,
            max_distance_m=12.0,
        )
    elif terrain == "three_route":
        cfg.three_route_enabled = True
        cfg.scene.env_spacing = 12.0
        cfg.navigation_lidar = make_navigation_lidar_cfg(
            "/World/three_route/mesh",
            update_period=0.05,
            horizontal_resolution_deg=2.0,
            max_distance_m=12.0,
        )
    elif terrain == "tunnel":
        cfg.tunnel_enabled = True
        cfg.scene.env_spacing = 4.5
    elif terrain == "stairs":
        cfg.stair_enabled = True
        cfg.scene.env_spacing = 6.0
    if domain_randomization:
        cfg.events = TitaDomainRandomizationCfg()
    if asset_path_obj.suffix.lower() == ".urdf":
        require_official_tita_urdf(asset_path_obj)
        spawn = sim_utils.UrdfFileCfg(
            asset_path=str(asset_path_obj),
            usd_dir=create_runtime_asset_directory(),
            activate_contact_sensors=True,
            fix_base=False,
            merge_fixed_joints=False,
            make_instanceable=True,
            joint_drive=sim_utils.UrdfConverterCfg.JointDriveCfg(
                gains=sim_utils.UrdfConverterCfg.JointDriveCfg.PDGainsCfg(
                    stiffness=0.0, damping=0.0
                )
            ),
            articulation_props=sim_utils.ArticulationRootPropertiesCfg(
                enabled_self_collisions=False,
                solver_position_iteration_count=8,
                solver_velocity_iteration_count=4,
            ),
        )
    else:
        spawn = sim_utils.UsdFileCfg(
            usd_path=str(asset_path_obj), activate_contact_sensors=True
        )
    cfg.robot = ArticulationCfg(
        prim_path="/World/envs/env_.*/Robot",
        spawn=spawn,
        # Match the official TITA RL default pose.  In particular, leg_3 has
        # a negative range in the URDF and cannot be initialized at zero.
        init_state=ArticulationCfg.InitialStateCfg(
            pos=(0.0, 0.0, 0.30),
            joint_pos={
                "joint_left_leg_1": 0.0,
                "joint_left_leg_2": 0.8,
                "joint_left_leg_3": -1.5,
                "joint_left_leg_4": 0.0,
                "joint_right_leg_1": 0.0,
                "joint_right_leg_2": 0.8,
                "joint_right_leg_3": -1.5,
                "joint_right_leg_4": 0.0,
            },
        ),
        actuators={
            "tita_legs": ImplicitActuatorCfg(
                joint_names_expr=["joint_.*_leg_[123]"], stiffness=0.0, damping=0.0,
                effort_limit=cfg.leg_torque_limit,
                velocity_limit=cfg.leg_velocity_limit - cfg.velocity_safety_margin,
            ),
            "tita_wheels": ImplicitActuatorCfg(
                joint_names_expr=["joint_.*_leg_4"], stiffness=0.0, damping=0.0,
                effort_limit=cfg.wheel_torque_limit,
                velocity_limit=cfg.wheel_velocity_limit - cfg.velocity_safety_margin,
            ),
        },
    )
    return cfg


class TitaResidualEnv(DirectRLEnv):
    """Vectorized Isaac Lab task with target-space residual and hard gating."""

    cfg: TitaResidualEnvCfg

    def __init__(self, cfg: TitaResidualEnvCfg, render_mode: str | None = None, **kwargs):
        if cfg.robot is None:
            raise ValueError("cfg.robot is not configured; call build_tita_cfg first")
        super().__init__(cfg, render_mode, **kwargs)
        sampled_tunnels = getattr(
            self,
            "_sampled_tunnel_dimensions",
            np.zeros((self.num_envs, 3), dtype=np.float32),
        )
        self._tunnel_dimensions = torch.as_tensor(
            sampled_tunnels, dtype=torch.float32, device=self.device
        )
        sampled_stairs = getattr(
            self,
            "_sampled_stair_dimensions",
            np.zeros((self.num_envs, 3), dtype=np.float32),
        )
        self._stair_dimensions = torch.as_tensor(
            sampled_stairs, dtype=torch.float32, device=self.device
        )
        self._joint_ids, resolved_names = self.robot.find_joints(list(TITA_JOINT_NAMES), preserve_order=True)
        if tuple(resolved_names) != TITA_JOINT_NAMES:
            raise ValueError(f"Isaac Lab joint order mismatch: expected {TITA_JOINT_NAMES}, got {resolved_names}")
        self._actions = torch.zeros(self.num_envs, 8, device=self.device)
        self._previous_actions = torch.zeros_like(self._actions)
        self._base_target = self.robot.data.default_joint_pos[:, self._joint_ids].clone()
        self._q_cmd = self._base_target.clone()
        self._previous_q_cmd = self._q_cmd.clone()
        self._hard_failure = torch.zeros(self.num_envs, dtype=torch.bool, device=self.device)
        self._tunnel_success_step = torch.zeros(
            self.num_envs, dtype=torch.bool, device=self.device
        )
        self._tunnel_success_count = torch.zeros(
            self.num_envs, dtype=torch.long, device=self.device
        )
        self._tunnel_completed_latched = torch.zeros(self.num_envs, dtype=torch.bool, device=self.device)
        self._last_transition_root_position = self.robot.data.root_pos_w.clone()
        self._last_transition_posture_height = torch.zeros(self.num_envs, device=self.device)
        self._last_transition_wheel_contacts = torch.zeros(self.num_envs, 2, dtype=torch.bool, device=self.device)
        self._stair_success_step = torch.zeros(
            self.num_envs, dtype=torch.bool, device=self.device
        )
        self._stair_success_count = torch.zeros(
            self.num_envs, dtype=torch.long, device=self.device
        )
        self._stair_success_stable_steps = torch.zeros(self.num_envs, dtype=torch.long, device=self.device)
        self._navigation_success_step = torch.zeros(
            self.num_envs, dtype=torch.bool, device=self.device
        )
        self._navigation_success_count = torch.zeros(
            self.num_envs, dtype=torch.long, device=self.device
        )
        self._distance = torch.zeros(self.num_envs, device=self.device)
        self._last_step_distance = torch.zeros_like(self._distance)
        self._energy = torch.zeros_like(self._distance)
        self._last_step_energy = torch.zeros_like(self._distance)
        self._previous_xy = torch.zeros(self.num_envs, 2, device=self.device)
        self._previous_root_height = self.robot.data.root_pos_w[:, 2].clone()
        self._velocity_command = torch.zeros(self.num_envs, 3, device=self.device)
        self._navigation_stationary_hold_s = torch.zeros(self.num_envs, device=self.device)
        self._soft_costs = torch.zeros(self.num_envs, 4, device=self.device)
        self._raw_soft_costs = torch.zeros_like(self._soft_costs)
        self._smooth_components = torch.zeros(self.num_envs, 4, device=self.device)
        self._projected = torch.zeros(self.num_envs, dtype=torch.bool, device=self.device)
        self._safety_hold = torch.zeros(
            self.num_envs, dtype=torch.bool, device=self.device
        )
        self._posture_command = torch.tensor([0.0, 1.0, 0.0], device=self.device).repeat(self.num_envs, 1)
        self._posture_mode = torch.ones(self.num_envs, dtype=torch.long, device=self.device)
        self._posture_mode_age = torch.full((self.num_envs,), 1.0e6, device=self.device)
        self._posture_switch_event = torch.zeros(self.num_envs, dtype=torch.bool, device=self.device)
        self._rapid_posture_switch_event = torch.zeros_like(self._posture_switch_event)
        self._posture_switch_count = torch.zeros(self.num_envs, dtype=torch.long, device=self.device)
        self._rapid_posture_switch_count = torch.zeros_like(self._posture_switch_count)
        self._posture_phase = torch.zeros(self.num_envs, 1, device=self.device)
        self._posture_offset = torch.zeros(self.num_envs, 8, device=self.device)
        self._path_version = torch.zeros(self.num_envs, 1, device=self.device)
        self._goal_age = torch.zeros(self.num_envs, 1, device=self.device)
        self._path_pose_error = torch.zeros(self.num_envs, 2, device=self.device)
        self._path_pose_override = torch.zeros(self.num_envs, dtype=torch.bool, device=self.device)
        self._hard_reason_flags = torch.zeros(
            self.num_envs, len(HARD_REASON_NAMES), dtype=torch.bool, device=self.device
        )
        self._last_hard_reason_flags = torch.zeros_like(self._hard_reason_flags)
        self._last_physical_pedestrian_contact_force = torch.zeros(self.num_envs, device=self.device)
        self._last_velocity_violation_flags = torch.zeros(self.num_envs, 8, dtype=torch.bool, device=self.device)
        self._last_velocity_state_projection_flags = torch.zeros_like(
            self._last_velocity_violation_flags
        )
        self._last_joint_velocity_abs = torch.zeros(self.num_envs, 8, device=self.device)
        self._last_preprojection_joint_velocity_abs = torch.zeros_like(
            self._last_joint_velocity_abs
        )
        self._last_joint_acceleration_abs = torch.zeros(self.num_envs, 8, device=self.device)
        self._filtered_joint_acceleration = torch.zeros(
            self.num_envs, 8, device=self.device
        )
        self._previous_joint_velocity = self.robot.data.joint_vel[
            :, self._joint_ids
        ].clone()
        self._last_infeasible_joint_flags = torch.zeros(
            self.num_envs, 8, dtype=torch.bool, device=self.device
        )
        self._last_infeasible_cause_flags = torch.zeros(
            self.num_envs, 8, 4, dtype=torch.bool, device=self.device
        )
        self._last_projection_joint_flags = torch.zeros(
            self.num_envs, 8, dtype=torch.bool, device=self.device
        )
        self._last_projection_cause_flags = torch.zeros(
            self.num_envs, 8, 4, dtype=torch.bool, device=self.device
        )
        self._previous_posture_height = (
            self.robot.data.root_pos_w[:, 2] - self.cfg.wheel_radius
        ).clone()
        self._collision = torch.zeros(self.num_envs, dtype=torch.bool, device=self.device)
        self._collision_event = torch.zeros(
            self.num_envs, dtype=torch.bool, device=self.device
        )
        self._last_collision_event = torch.zeros_like(self._collision_event)
        self._collision_event_count = torch.zeros(
            self.num_envs, dtype=torch.long, device=self.device
        )
        self._collision_peak_force = torch.zeros(self.num_envs, device=self.device)
        self._collision_body_index = torch.zeros(self.num_envs, dtype=torch.long, device=self.device)
        self._collision_local_x = torch.zeros(self.num_envs, device=self.device)
        self._collision_local_y = torch.zeros(self.num_envs, device=self.device)
        self._collision_root_z = torch.zeros(self.num_envs, device=self.device)
        self._collision_speed = torch.zeros(self.num_envs, device=self.device)
        self._collision_roll = torch.zeros(self.num_envs, device=self.device)
        self._collision_pitch = torch.zeros(self.num_envs, device=self.device)
        self._collision_yaw_rate = torch.zeros(self.num_envs, device=self.device)
        self._collision_vertical_margin = torch.full(
            (self.num_envs,), self.cfg.clearance_default, device=self.device
        )
        self._collision_lateral_margin = torch.full_like(
            self._collision_vertical_margin, self.cfg.clearance_default
        )
        self._collision_navigation_clearance = torch.full_like(
            self._collision_vertical_margin, self.cfg.clearance_default
        )
        self._collision_in_tunnel = torch.zeros(
            self.num_envs, dtype=torch.bool, device=self.device
        )
        self._last_collision_context = {
            "peak_force": torch.zeros(self.num_envs, device=self.device),
            "peak_body_index": torch.zeros(self.num_envs, dtype=torch.long, device=self.device),
            "local_x": torch.zeros(self.num_envs, device=self.device),
            "local_y": torch.zeros(self.num_envs, device=self.device),
            "root_z": torch.zeros(self.num_envs, device=self.device),
            "speed": torch.zeros(self.num_envs, device=self.device),
            "roll": torch.zeros(self.num_envs, device=self.device),
            "pitch": torch.zeros(self.num_envs, device=self.device),
            "yaw_rate": torch.zeros(self.num_envs, device=self.device),
            "vertical_margin": torch.full(
                (self.num_envs,), self.cfg.clearance_default, device=self.device
            ),
            "lateral_margin": torch.full(
                (self.num_envs,), self.cfg.clearance_default, device=self.device
            ),
            "navigation_clearance": torch.full(
                (self.num_envs,), self.cfg.clearance_default, device=self.device
            ),
            "in_tunnel": torch.zeros(
                self.num_envs, dtype=torch.bool, device=self.device
            ),
        }
        self._soft_contact_force = torch.zeros(self.num_envs, device=self.device)
        self._clearance = torch.full(
            (self.num_envs,), self.cfg.clearance_default, device=self.device
        )
        self._hard_clearance = torch.full_like(
            self._clearance, self.cfg.clearance_default
        )
        self._navigation_clearance = torch.full_like(
            self._clearance, self.cfg.clearance_default
        )
        self._dynamic_obstacle_risk = torch.zeros_like(self._clearance)
        self._stair_height_preview = torch.zeros(self.num_envs, device=self.device)
        self._stair_approach_root_height = self.robot.data.root_pos_w[:, 2].clone()
        self._stair_approach_height_frozen = torch.zeros(
            self.num_envs, dtype=torch.bool, device=self.device
        )
        self._previous_verified_stair_level = torch.zeros(
            self.num_envs, device=self.device
        )
        self._previous_lead_wheel_level = torch.zeros(
            self.num_envs, device=self.device
        )
        self._previous_trail_wheel_level = torch.zeros(
            self.num_envs, device=self.device
        )
        self._single_wheel_steps = torch.zeros(
            self.num_envs, dtype=torch.long, device=self.device
        )
        self._stair_step_step = torch.full(
            (self.num_envs,), -1, dtype=torch.long, device=self.device
        )
        self._stair_step_level = torch.zeros(
            self.num_envs, dtype=torch.long, device=self.device
        )
        self._stair_lead_is_left = torch.zeros(
            self.num_envs, dtype=torch.bool, device=self.device
        )
        self._stair_lead_reassigned = torch.zeros(
            self.num_envs, dtype=torch.bool, device=self.device
        )
        self._stair_phase = torch.zeros(
            self.num_envs, dtype=torch.long, device=self.device
        )
        self._stair_phase_progress = torch.zeros(self.num_envs, device=self.device)
        self._stair_completed_latched = torch.zeros(
            self.num_envs, dtype=torch.bool, device=self.device
        )
        hard_body_pattern = "base_link"
        if "tower_base_link" in self.robot.body_names:
            hard_body_pattern = "base_link|tower_base_link|radar_link|.*leg_[12]"
        self._hard_contact_body_ids, hard_names = self._contact_sensor.find_bodies(hard_body_pattern)
        self._soft_contact_body_ids, soft_names = self._contact_sensor.find_bodies(
            ".*leg_3"
        )
        self._wheel_body_ids, wheel_names = self.robot.find_bodies(
            ["left_leg_4", "right_leg_4"], preserve_order=True
        )
        self._wheel_contact_body_ids, wheel_contact_names = self._contact_sensor.find_bodies(
            ["left_leg_4", "right_leg_4"], preserve_order=True
        )
        if not self._hard_contact_body_ids or "base_link" not in hard_names:
            raise RuntimeError("failed to resolve the TITA base and payload hard-contact bodies")
        if len(self._soft_contact_body_ids) != 2:
            raise RuntimeError("failed to resolve the two TITA leg_3 soft-contact bodies")
        if len(self._wheel_body_ids) != 2 or len(self._wheel_contact_body_ids) != 2:
            raise RuntimeError("failed to resolve the left/right TITA wheel bodies")
        if wheel_names != wheel_contact_names:
            raise RuntimeError(
                f"wheel body order mismatch: articulation={wheel_names}, sensor={wheel_contact_names}"
            )
        self._wheel_contact = torch.zeros(
            self.num_envs, 2, dtype=torch.bool, device=self.device
        )
        self._stair_wheel_axis_reference_z = self.robot.data.body_pos_w[
            :, self._wheel_body_ids, 2
        ].clone()
        self._previous_lead_wheel_axis_z = torch.where(
            self._stair_lead_is_left,
            self._stair_wheel_axis_reference_z[:, 0],
            self._stair_wheel_axis_reference_z[:, 1],
        )
        print(f"[TITA-UC] hard contact bodies: {hard_names}")
        print(f"[TITA-UC] soft contact bodies: {soft_names}")
        print(f"[TITA-UC] ordered wheel bodies: {wheel_names}")
        if self.cfg.tunnel_enabled:
            minimum = self._tunnel_dimensions.amin(dim=0).tolist()
            maximum = self._tunnel_dimensions.amax(dim=0).tolist()
            print(
                "[TITA-UC] tunnel dimensions height/width/length "
                f"min={minimum} max={maximum}"
            )
        if self.cfg.stair_enabled:
            minimum = self._stair_dimensions.amin(dim=0).tolist()
            maximum = self._stair_dimensions.amax(dim=0).tolist()
            print(
                "[TITA-UC] stair dimensions height/tread/width "
                f"min={minimum} max={maximum} steps={self.cfg.stair_num_steps}"
            )

    def _setup_scene(self):
        carb.settings.get_settings().set_bool(SETTING_COLLISION_APPROXIMATE_CYLINDERS, self.cfg.convex_cylinder_collisions)
        self.robot = Articulation(self.cfg.robot)
        self.scene.articulations["robot"] = self.robot
        self._contact_sensor = ContactSensor(self.cfg.contact_sensor)
        self.scene.sensors["contact_sensor"] = self._contact_sensor
        self.cfg.terrain.num_envs = self.scene.cfg.num_envs
        self.cfg.terrain.env_spacing = self.scene.cfg.env_spacing
        self.terrain = self.cfg.terrain.class_type(self.cfg.terrain)
        if self.cfg.perception_preview_mesh:
            self._create_perception_preview_mesh()
        if self.cfg.height_scanner is not None:
            self._height_scanner = RayCaster(self.cfg.height_scanner)
            self.scene.sensors["height_scanner"] = self._height_scanner
        if self.cfg.navigation_lidar is not None:
            self._navigation_lidar = RayCaster(self.cfg.navigation_lidar)
            self.scene.sensors["navigation_lidar"] = self._navigation_lidar
        if self.cfg.rendered_inspection_camera_enabled:
            camera_cfg = CameraCfg(prim_path="/World/envs/env_0/Robot/base_link/InspectionCamera", update_period=.1,
                                   height=120, width=160, data_types=["rgb", "distance_to_image_plane"],
                                   spawn=sim_utils.PinholeCameraCfg(focal_length=12., horizontal_aperture=20.955, clipping_range=(.05, 8.)),
                                   offset=CameraCfg.OffsetCfg(pos=(.23416, .075001, .04036), rot=(.5, -.5, .5, -.5), convention="ros"))
            self.inspection_camera = Camera(camera_cfg)
            self.scene.sensors["inspection_camera"] = self.inspection_camera
        if self.cfg.rendered_external_camera_enabled:
            if self.scene.cfg.num_envs != 1:
                raise ValueError("external execution video requires one physical environment")
            external_cfg = CameraCfg(prim_path="/World/ExternalExecutionCamera", update_period=.1,
                                     height=480, width=640, data_types=["rgb"],
                                     spawn=sim_utils.PinholeCameraCfg(focal_length=18., horizontal_aperture=20.955, clipping_range=(.05, 30.)))
            self.external_execution_camera = Camera(external_cfg)
            self.scene.sensors["external_execution_camera"] = self.external_execution_camera
        if self.cfg.physical_pedestrian_enabled:
            if self.scene.cfg.num_envs != 1:
                raise ValueError("physical pedestrian integration currently requires one environment")
            if str(self.cfg.sim.device).startswith("cuda"):
                raise ValueError("installed PhysX GPU backend does not implement kinematic targets; use CPU physics")
            positions = self.cfg.physical_pedestrian_positions_xyz_m or (self.cfg.physical_pedestrian_initial_xyz_m,)
            self.physical_pedestrians = []
            pedestrian_paths = []
            for index, position in enumerate(positions):
                pedestrian_path = "/World/envs/env_0/Pedestrian" + (f"_{index}" if index else "")
                pedestrian_cfg = RigidObjectCfg(
                    prim_path=pedestrian_path,
                    spawn=sim_utils.CapsuleCfg(
                        radius=float(self.cfg.physical_pedestrian_radius_m), height=1.20,
                        rigid_props=sim_utils.RigidBodyPropertiesCfg(kinematic_enabled=True, disable_gravity=True),
                        collision_props=sim_utils.CollisionPropertiesCfg(),
                        mass_props=sim_utils.MassPropertiesCfg(mass=70.0),
                        visual_material=sim_utils.PreviewSurfaceCfg(diffuse_color=(0.85, 0.25, 0.15)),
                    ),
                    init_state=RigidObjectCfg.InitialStateCfg(pos=tuple(position)),
                )
                pedestrian_actor = RigidObject(pedestrian_cfg)
                self.scene.rigid_objects[f"pedestrian_{index}"] = pedestrian_actor
                self.physical_pedestrians.append(pedestrian_actor)
                pedestrian_paths.append(pedestrian_path)
            self.physical_pedestrian = self.physical_pedestrians[0]
            self._pedestrian_contact_sensors = []
            for name in ("base_link", "left_leg_1", "left_leg_2", "left_leg_3", "left_leg_4",
                         "right_leg_1", "right_leg_2", "right_leg_3", "right_leg_4", "tower_base_link", "radar_link"):
                sensor = ContactSensor(ContactSensorCfg(
                    prim_path=f"/World/envs/env_0/Robot/{name}",
                    filter_prim_paths_expr=pedestrian_paths,
                    history_length=1, update_period=.005,
                ))
                self.scene.sensors[f"pedestrian_contact_{name}"] = sensor
                self._pedestrian_contact_sensors.append(sensor)
        self.scene.clone_environments(copy_from_source=False)
        if self.cfg.route_choice_enabled:
            self._create_route_choice_scene()
        if self.cfg.three_route_enabled:
            self._create_three_route_scene()
        if self.cfg.tunnel_enabled:
            self._create_tunnel_curriculum()
        if self.cfg.stair_enabled:
            self._create_stair_curriculum()
        light_cfg = sim_utils.DomeLightCfg(intensity=1800.0, color=(0.75, 0.75, 0.75))
        light_cfg.func("/World/Light", light_cfg)

    def set_physical_pedestrian_target(self, position_xyz_m, actor_index: int = 0) -> None:
        if not self.cfg.physical_pedestrian_enabled:
            raise RuntimeError("physical pedestrian is disabled")
        position = torch.as_tensor(position_xyz_m, dtype=torch.float32, device=self.device)
        if position.shape != (3,) or not torch.isfinite(position).all():
            raise ValueError("pedestrian position must contain three finite values")
        target = torch.zeros((1, 7), dtype=torch.float32, device=self.device)
        target[0, :3] = position
        target[0, 6] = 1.0
        if actor_index not in range(len(self.physical_pedestrians)):
            raise ValueError("invalid physical pedestrian index")
        self.physical_pedestrians[actor_index].root_physx_view.set_kinematic_targets(
            target, torch.zeros(1, dtype=torch.int32, device=self.device)
        )

    @property
    def physical_pedestrian_contact_force(self):
        if not self.cfg.physical_pedestrian_enabled:
            return torch.zeros(self.num_envs, device=self.device)
        return torch.stack([torch.linalg.vector_norm(sensor.data.force_matrix_w, dim=-1).flatten(1).amax(1)
                            for sensor in self._pedestrian_contact_sensors]).amax(0)

    @property
    def last_step_pedestrian_contact_force(self):
        return self._last_physical_pedestrian_contact_force

    @property
    def last_transition_root_position(self):
        return self._last_transition_root_position

    def _create_route_choice_scene(self) -> None:
        """Create one combined collision/ray-cast mesh for all route environments."""

        route_cfg = RouteChoiceConfig(
            wall_start_x_m=float(self.cfg.route_choice_wall_start_x_m),
            wall_end_x_m=float(self.cfg.route_choice_wall_end_x_m),
            obstacle_start_x_m=float(self.cfg.route_choice_obstacle_start_x_m),
            obstacle_length_m=float(self.cfg.route_choice_obstacle_length_m),
            obstacle_half_width_m=float(self.cfg.route_choice_obstacle_half_width_m),
            narrow_width_m=float(self.cfg.route_choice_narrow_width_m),
            wide_width_m=float(self.cfg.route_choice_wide_width_m),
            wall_height_m=float(self.cfg.route_choice_wall_height_m),
            wall_thickness_m=float(self.cfg.route_choice_wall_thickness_m),
            goal_x_m=float(self.cfg.route_choice_goal_x_m),
        )
        meshes: list[trimesh.Trimesh] = []
        origins = self.terrain.env_origins[:, :2].cpu().numpy()
        colors = {
            "central_obstacle": (88, 96, 102, 255),
            "narrow_outer_wall": (181, 87, 58, 255),
            "wide_outer_wall": (55, 116, 126, 255),
        }
        for origin in origins:
            for box in route_choice_boxes((float(origin[0]), float(origin[1])), route_cfg):
                mesh = trimesh.creation.box(extents=box.size)
                mesh.apply_translation(box.center)
                mesh.visual.face_colors = colors[box.name]
                meshes.append(mesh)
        route_mesh = trimesh.util.concatenate(meshes)
        create_prim_from_mesh("/World/route_choice", route_mesh)
        print(
            "[TITA-UC] route-choice scene "
            f"narrow_width={route_cfg.narrow_width_m:.3f}m "
            f"wide_width={route_cfg.wide_width_m:.3f}m "
            f"nominal_lengths=({route_cfg.nominal_route_length_m('narrow'):.3f},"
            f"{route_cfg.nominal_route_length_m('wide'):.3f})m"
        )

    def _create_three_route_scene(self) -> None:
        """Create the deterministic LOW/open/MID three-route scene."""

        route_cfg = ThreeRouteSceneConfig()
        maze = None
        if self.cfg.navigation_scene_file:
            from .navigation_maze import load_maze
            maze = load_maze(self.cfg.navigation_scene_file)
        meshes: list[trimesh.Trimesh] = []
        origins = self.terrain.env_origins[:, :2].cpu().numpy()
        for origin in origins:
            if maze is not None:
                from .navigation_maze import maze_boxes
                boxes = maze_boxes(maze, (float(origin[0]), float(origin[1])))
            else:
                boxes = three_route_boxes((float(origin[0]), float(origin[1])), route_cfg)
            for box in boxes:
                mesh = trimesh.creation.box(extents=box.size)
                mesh.apply_translation(box.center)
                mesh.visual.face_colors = box.color
                meshes.append(mesh)
        route_mesh = trimesh.util.concatenate(meshes)
        create_prim_from_mesh("/World/three_route", route_mesh)
        if self.cfg.sudden_obstacle_file:
            from .sudden_obstacle import SuddenObstacleProbe
            self.sudden_obstacle_probe = SuddenObstacleProbe(self, self.cfg.sudden_obstacle_file, route_mesh)
        route_summary = ", ".join(
            f"{route.name}: length={route.length_m:.3f}m "
            f"postures={'/'.join(route.allowed_postures)}"
            for route in route_cfg.routes()
        )
        if maze is not None:
            print(f"[TITA-UC] oracle navigation maze {maze['name']}, boxes={len(maze['boxes'])}; not sensor mapping")
        else:
            print(f"[TITA-UC] three-route scene {route_summary}")

    def _create_tunnel_curriculum(self) -> None:
        tunnel_cfg = TunnelCurriculumConfig(
            height_range_m=tuple(self.cfg.tunnel_height_range_m),
            width_range_m=tuple(self.cfg.tunnel_width_range_m),
            length_range_m=tuple(self.cfg.tunnel_length_range_m),
            start_x_m=self.cfg.tunnel_start_x_m,
            wall_thickness_m=self.cfg.tunnel_wall_thickness_m,
        )
        seed = int(self.cfg.seed if self.cfg.seed is not None else 0) + 4100
        dimensions = sample_tunnel_dimensions(self.cfg.scene.num_envs, seed, tunnel_cfg)
        self._sampled_tunnel_dimensions = dimensions
        thickness = tunnel_cfg.wall_thickness_m
        wall_material = sim_utils.PreviewSurfaceCfg(diffuse_color=(0.24, 0.27, 0.29))
        ceiling_material = sim_utils.PreviewSurfaceCfg(diffuse_color=(0.46, 0.49, 0.50))
        for env_index, (height, width, length) in enumerate(dimensions):
            # Children authored below env_0 are inherited by Isaac Lab's
            # cloned env prims even when the shape spawner itself is not
            # cloned.  Put each static tunnel in an independent world-space
            # namespace and offset it by the corresponding environment origin.
            env_origin = self.terrain.env_origins[env_index].cpu().tolist()
            center_x = env_origin[0] + tunnel_cfg.start_x_m + float(length) / 2.0
            center_y = env_origin[1]
            wall_size = (float(length), thickness, float(height) + thickness)
            for side_name, side in (("Left", 1.0), ("Right", -1.0)):
                wall = sim_utils.CuboidCfg(
                    size=wall_size,
                    collision_props=sim_utils.CollisionPropertiesCfg(),
                    visual_material=wall_material,
                )
                # The public spawner is decorated with Isaac Lab's ``clone``
                # helper.  Even a literal env_0 path is expanded across the
                # cloned environment hierarchy, which would give every env
                # env_0's dimensions and collide with the following loop
                # iteration.  Call the wrapped single-prim spawner so each
                # vectorized environment keeps its own sampled geometry.
                wall.func.__wrapped__(
                    f"/World/tunnels/env_{env_index}/{side_name}Wall",
                    wall,
                    translation=(
                        center_x,
                        center_y + side * (float(width) + thickness) / 2.0,
                        (float(height) + thickness) / 2.0,
                    ),
                )
            ceiling = sim_utils.CuboidCfg(
                size=(float(length), float(width) + 2.0 * thickness, thickness),
                collision_props=sim_utils.CollisionPropertiesCfg(),
                visual_material=ceiling_material,
            )
            ceiling.func.__wrapped__(
                f"/World/tunnels/env_{env_index}/Ceiling",
                ceiling,
                translation=(
                    center_x,
                    center_y,
                    float(height) + thickness / 2.0,
                ),
            )

    def _create_stair_curriculum(self) -> None:
        stair_cfg = StairCurriculumConfig(
            step_height_range_m=tuple(self.cfg.stair_step_height_range_m),
            tread_range_m=tuple(self.cfg.stair_tread_range_m),
            width_range_m=tuple(self.cfg.stair_width_range_m),
            num_steps=self.cfg.stair_num_steps,
            start_x_m=self.cfg.stair_start_x_m,
            landing_length_m=self.cfg.stair_landing_length_m,
        )
        seed = int(self.cfg.seed if self.cfg.seed is not None else 0) + 5100
        dimensions = sample_stair_dimensions(self.cfg.scene.num_envs, seed, stair_cfg)
        self._sampled_stair_dimensions = dimensions
        materials = (
            sim_utils.PreviewSurfaceCfg(diffuse_color=(0.34, 0.36, 0.38)),
            sim_utils.PreviewSurfaceCfg(diffuse_color=(0.48, 0.50, 0.52)),
        )
        for env_index, (step_height, tread, width) in enumerate(dimensions):
            env_origin = self.terrain.env_origins[env_index].cpu().tolist()
            if self.cfg.stair_training_corridor_enabled:
                corridor_length = stair_cfg.start_x_m + stair_cfg.num_steps * float(tread) + stair_cfg.landing_length_m
                for side_name, side in (("Right", -1.), ("Left", 1.)):
                    wall = sim_utils.CuboidCfg(size=(corridor_length, .10, .8),
                                              collision_props=sim_utils.CollisionPropertiesCfg())
                    wall.func.__wrapped__(f"/World/stair_corridors/env_{env_index}/{side_name}", wall,
                                          translation=(env_origin[0] + corridor_length / 2., env_origin[1] + side * (float(width) + .10) / 2., .4))
            for step_index in range(stair_cfg.num_steps):
                segment_length = float(tread)
                if step_index == stair_cfg.num_steps - 1:
                    segment_length += stair_cfg.landing_length_m
                top_height = float(step_height) * (step_index + 1)
                box_height, box_center_z = stair_box_vertical_geometry(top_height, self.cfg.stair_foundation_depth_m)
                center_x = (
                    env_origin[0]
                    + stair_cfg.start_x_m
                    + step_index * float(tread)
                    + segment_length / 2.0
                )
                shape_config = sim_utils.MeshCuboidCfg if self.cfg.stair_mesh_collider_enabled else sim_utils.CuboidCfg
                step = shape_config(
                    size=(segment_length, float(width), box_height),
                    collision_props=sim_utils.CollisionPropertiesCfg(),
                    visual_material=materials[step_index % len(materials)],
                )
                step.func.__wrapped__(
                    f"/World/stairs/env_{env_index}/Step_{step_index + 1}",
                    step,
                    translation=(
                        center_x,
                        env_origin[1],
                        box_center_z,
                    ),
                )
            if self.cfg.stair_handrail_enabled:
                self._create_stair_handrails(
                    env_index,
                    env_origin,
                    float(step_height),
                    float(tread),
                    float(width),
                    stair_cfg,
                )

    def _create_stair_handrails(
        self,
        env_index: int,
        env_origin: list[float],
        step_height: float,
        tread: float,
        width: float,
        stair_cfg: StairCurriculumConfig,
    ) -> None:
        """Create side handrails as static collision geometry for one stairway."""
        thickness = float(self.cfg.stair_handrail_thickness_m)
        side_y = float(width) / 2.0 + float(self.cfg.stair_handrail_side_offset_m)
        rail_height = float(self.cfg.stair_handrail_height_m)
        total_run = stair_cfg.num_steps * tread
        post_spacing = max(float(self.cfg.stair_handrail_post_spacing_m), thickness)
        material = sim_utils.PreviewSurfaceCfg(diffuse_color=(0.16, 0.17, 0.18))
        for side_name, side in (("Left", 1.0), ("Right", -1.0)):
            # Posts are placed on the first riser, at each step boundary, and
            # at the end landing.  They remain outside the clear stair width.
            post_count = max(2, int(math.ceil(total_run / post_spacing)) + 1)
            for post_index in range(post_count):
                along = min(total_run, post_index * total_run / (post_count - 1))
                level = min(stair_cfg.num_steps, int(math.floor(along / tread)) + 1)
                base_z = step_height * level
                post = sim_utils.CuboidCfg(
                    size=(thickness, thickness, rail_height),
                    collision_props=sim_utils.CollisionPropertiesCfg(),
                    visual_material=material,
                )
                post.func.__wrapped__(
                    f"/World/stairs/env_{env_index}/{side_name}RailPost_{post_index + 1}",
                    post,
                    translation=(
                        env_origin[0] + stair_cfg.start_x_m + along,
                        env_origin[1] + side * side_y,
                        base_z + rail_height / 2.0,
                    ),
                )
            # The measured staircase has a continuous rail following the
            # stair slope, then a level segment over the top landing.  A
            # single sloped cuboid avoids artificial horizontal ledges at
            # every riser while retaining a collidable rail envelope.
            total_run = stair_cfg.num_steps * tread
            total_rise = stair_cfg.num_steps * step_height
            slope_length = math.hypot(total_run, total_rise)
            slope_angle = math.atan2(total_rise, total_run)
            if self.cfg.stair_handrail_follow_slope:
                rail = sim_utils.CuboidCfg(
                    size=(slope_length, thickness, thickness),
                    collision_props=sim_utils.CollisionPropertiesCfg(),
                    visual_material=material,
                )
                rail.func.__wrapped__(
                    f"/World/stairs/env_{env_index}/{side_name}RailSlope",
                    rail,
                    translation=(
                        env_origin[0] + stair_cfg.start_x_m + total_run / 2.0,
                        env_origin[1] + side * side_y,
                        step_height + rail_height + total_rise / 2.0,
                    ),
                    # Isaac uses (w, x, y, z); negative Y rotates +X toward +Z.
                    orientation=(
                        math.cos(slope_angle / 2.0),
                        0.0,
                        -math.sin(slope_angle / 2.0),
                        0.0,
                    ),
                )
                landing = sim_utils.CuboidCfg(
                    size=(stair_cfg.landing_length_m, thickness, thickness),
                    collision_props=sim_utils.CollisionPropertiesCfg(),
                    visual_material=material,
                )
                landing.func.__wrapped__(
                    f"/World/stairs/env_{env_index}/{side_name}RailLanding",
                    landing,
                    translation=(
                        env_origin[0]
                        + stair_cfg.start_x_m
                        + total_run
                        + stair_cfg.landing_length_m / 2.0,
                        env_origin[1] + side * side_y,
                        total_rise + rail_height,
                    ),
                )
            else:
                # Compatibility mode for old checkpoints and geometry tests.
                for step_index in range(stair_cfg.num_steps):
                    segment_length = tread
                    if step_index == stair_cfg.num_steps - 1:
                        segment_length += stair_cfg.landing_length_m
                    top_height = step_height * (step_index + 1)
                    rail = sim_utils.CuboidCfg(
                        size=(segment_length, thickness, thickness),
                        collision_props=sim_utils.CollisionPropertiesCfg(),
                        visual_material=material,
                    )
                    rail.func.__wrapped__(
                        f"/World/stairs/env_{env_index}/{side_name}Rail_{step_index + 1}",
                        rail,
                        translation=(
                            env_origin[0]
                            + stair_cfg.start_x_m
                            + step_index * tread
                            + segment_length / 2.0,
                            env_origin[1] + side * side_y,
                            top_height + rail_height,
                        ),
                    )

    def _create_perception_preview_mesh(self) -> None:
        """Create a collision-free geometry layer for the first perception curriculum."""
        origins = self.terrain.env_origins[:, :2].cpu().numpy()
        xy_min = origins.min(axis=0) - 2.0
        xy_max = origins.max(axis=0) + 2.0
        center = 0.5 * (xy_min + xy_max)
        extent = xy_max - xy_min
        meshes = [trimesh.creation.box(extents=(extent[0], extent[1], 0.002))]
        meshes[0].apply_translation((center[0], center[1], -0.001))
        for index, origin in enumerate(origins):
            obstacle = trimesh.creation.box(extents=(0.12, 0.12, 0.08))
            lateral = 1.00 if index % 2 == 0 else -1.00
            forward = 0.75 + 0.10 * (index % 3)
            obstacle.apply_translation((origin[0] + forward, origin[1] + lateral, 0.04))
            meshes.append(obstacle)
        preview_mesh = trimesh.util.concatenate(meshes)
        create_prim_from_mesh("/World/perception_preview/terrain", preview_mesh)
        sim_utils.define_collision_properties(
            "/World/perception_preview/terrain/mesh",
            sim_utils.CollisionPropertiesCfg(collision_enabled=False),
        )

    def _pre_physics_step(self, actions: torch.Tensor):
        self._previous_q_cmd.copy_(self._q_cmd)
        self._previous_actions = self._actions.clone()
        residual_limit = self.cfg.residual_limit * self.cfg.posture_scale
        desired_actions = actions.clamp(-residual_limit, residual_limit)
        if self.cfg.stair_enabled and self.cfg.stair_step_assist_enabled:
            desired_actions = gate_stair_residual(
                desired_actions,
                self._stair_phase,
                self.cfg.stair_residual_phase_gating,
            )
            desired_actions = desired_actions + lead_place_residual_prior(
                self._stair_phase,
                self._stair_lead_is_left,
                self.cfg.stair_lead_place_hip_residual,
                self.cfg.stair_lead_place_knee_residual,
                self.cfg.stair_support_place_hip_residual,
                self.cfg.stair_support_place_knee_residual,
            )
            desired_actions.clamp_(-residual_limit, residual_limit)
        self._actions = filter_residual_action(
            self._previous_actions, desired_actions, self.cfg.residual_filter_alpha
        )
        if self.cfg.stair_enabled and self.cfg.stair_step_assist_enabled:
            self._actions = gate_stair_residual(
                self._actions,
                self._stair_phase,
                self.cfg.stair_residual_phase_gating,
            )
        if self.cfg.enable_posture_feedforward:
            anchors = self._base_target.new_tensor(self.cfg.posture_joint_anchors)
            desired_anchor = self._posture_command @ anchors
            default_anchor = self.robot.data.default_joint_pos[:, self._joint_ids]
            feedforward_alpha = min(
                self.step_dt / self.cfg.posture_feedforward_transition_s, 1.0
            )
            self._posture_offset.lerp_(
                desired_anchor - default_anchor, feedforward_alpha
            )
        else:
            self._posture_offset.zero_()
        raw = self._base_target + self._posture_offset + self._actions
        if self.cfg.stair_enabled and self.cfg.stair_step_assist_enabled:
            base_raw = raw
            stair_assist = self._stair_step_assist()
            raw = raw + stair_assist
            default_target = self.robot.data.default_joint_pos[:, self._joint_ids]
            stair_reference = (
                default_target + self._posture_offset + self._actions + stair_assist
            )
            sagittal_leg_mask = raw.new_tensor(
                (False, True, True, False, False, True, True, False),
                dtype=torch.bool,
            )
            takeover_blend = self._stair_phase_progress.clamp(0.0, 1.0)
            takeover_blend = takeover_blend * takeover_blend * (
                3.0 - 2.0 * takeover_blend
            )
            retracting_lead = self._stair_phase == 2
            stair_reference = torch.where(
                retracting_lead[:, None],
                torch.lerp(base_raw, stair_reference, takeover_blend[:, None]),
                stair_reference,
            )
            use_stair_reference = (
                (self._stair_phase >= 2)[:, None]
                & sagittal_leg_mask[None, :]
            )
            raw = torch.where(use_stair_reference, stair_reference, raw)
        q = self.robot.data.joint_pos[:, self._joint_ids]
        qd = self.robot.data.joint_vel[:, self._joint_ids]
        if (
            self.cfg.stair_enabled
            and self.cfg.stair_step_assist_enabled
            and self.cfg.stair_step_assist_brake_torque > 0.0
        ):
            # Do not brake during the preload: the lead wheel needs a short
            # high-torque impulse to climb the riser.  Once its axis clears
            # the next tread, reverse torque is applied to that wheel only so
            # the base can settle before the trailing wheel is released.
            wheel_levels, _, _ = self._wheel_stair_state()
            lead_level = torch.where(
                self._stair_lead_is_left, wheel_levels[:, 0], wheel_levels[:, 1]
            )
            lead_contact_event = lead_level > self._stair_step_level
            post_contact_phase = lead_contact_event & (self._stair_phase >= 3)
            wheel_velocity = qd[:, (3, 7)]
            brake_target = (
                -torch.sign(wheel_velocity)
                * float(self.cfg.stair_step_assist_brake_torque)
                + self.cfg.wheel_damping * wheel_velocity
            ) / self.cfg.wheel_target_gain
            brake_target = torch.where(
                wheel_velocity.abs() > 0.20,
                brake_target,
                torch.zeros_like(brake_target),
            )
            lead_wheel_index = torch.where(
                self._stair_lead_is_left,
                torch.zeros_like(self._stair_phase),
                torch.ones_like(self._stair_phase),
            )
            lead_wheel_mask = torch.zeros_like(wheel_velocity).scatter_(
                1, lead_wheel_index[:, None], 1.0
            )
            raw[:, (3, 7)] = torch.where(
                post_contact_phase[:, None] & (lead_wheel_mask > 0.0),
                brake_target,
                raw[:, (3, 7)],
            )
        qmin = self.robot.data.soft_joint_pos_limits[:, self._joint_ids, 0]
        qmax = self.robot.data.soft_joint_pos_limits[:, self._joint_ids, 1]
        qdmax = q.new_tensor(
            (
                self.cfg.leg_velocity_limit, self.cfg.leg_velocity_limit,
                self.cfg.leg_velocity_limit, self.cfg.wheel_velocity_limit,
                self.cfg.leg_velocity_limit, self.cfg.leg_velocity_limit,
                self.cfg.leg_velocity_limit, self.cfg.wheel_velocity_limit,
            )
        ).expand_as(q)
        taumax = q.new_tensor(
            (
                self.cfg.leg_torque_limit, self.cfg.leg_torque_limit,
                self.cfg.leg_torque_limit, self.cfg.wheel_torque_limit,
                self.cfg.leg_torque_limit, self.cfg.leg_torque_limit,
                self.cfg.leg_torque_limit, self.cfg.wheel_torque_limit,
            )
        ).expand_as(q)
        target_gain = q.new_tensor(
            (
                self.cfg.leg_kp, self.cfg.leg_kp, self.cfg.leg_kp, self.cfg.wheel_target_gain,
                self.cfg.leg_kp, self.cfg.leg_kp, self.cfg.leg_kp, self.cfg.wheel_target_gain,
            )
        ).expand_as(q)
        position_gain = q.new_tensor(
            (self.cfg.leg_kp, self.cfg.leg_kp, self.cfg.leg_kp, 0.0,
             self.cfg.leg_kp, self.cfg.leg_kp, self.cfg.leg_kp, 0.0)
        ).expand_as(q)
        damping = q.new_tensor(
            (self.cfg.leg_kd, self.cfg.leg_kd, self.cfg.leg_kd, self.cfg.wheel_damping,
             self.cfg.leg_kd, self.cfg.leg_kd, self.cfg.leg_kd, self.cfg.wheel_damping)
        ).expand_as(q)
        position_controlled = position_gain > 0.0
        infinity = torch.full_like(q, torch.inf)

        # Deterministic vectorized equivalent of SafetyProjector for Isaac Lab.
        lower = qmin.clone()
        upper = qmax.clone()
        causes = torch.zeros(self.num_envs, 8, 4, dtype=torch.bool, device=self.device)
        projection_causes = torch.zeros_like(causes)
        causes[:, :, 0] = lower > upper
        projection_causes[:, :, 0] = (raw < lower) | (raw > upper)

        if self.cfg.project_target_kinematics:
            velocity_lower = torch.where(position_controlled, q - qdmax * self.step_dt, -infinity)
            velocity_upper = torch.where(position_controlled, q + qdmax * self.step_dt, infinity)
            projection_causes[:, :, 1] = (raw < velocity_lower) | (raw > velocity_upper)
            lower = torch.maximum(lower, velocity_lower)
            upper = torch.minimum(upper, velocity_upper)
            causes[:, :, 1] = (lower > upper) & ~causes.any(dim=2)

        torque_lower = (-taumax + position_gain * q + damping * qd) / target_gain
        torque_upper = (taumax + position_gain * q + damping * qd) / target_gain
        projection_causes[:, :, 2] = (raw < torque_lower) | (raw > torque_upper)
        lower = torch.maximum(lower, torque_lower)
        upper = torch.minimum(upper, torque_upper)
        causes[:, :, 2] = (lower > upper) & ~causes.any(dim=2)

        if self.cfg.project_target_kinematics and self.cfg.enforce_acceleration_limit:
            qd_lower = qd - self.cfg.acceleration_limit * self.step_dt
            qd_upper = qd + self.cfg.acceleration_limit * self.step_dt
            acceleration_lower = torch.where(
                position_controlled, q + qd_lower * self.step_dt, -infinity
            )
            acceleration_upper = torch.where(
                position_controlled, q + qd_upper * self.step_dt, infinity
            )
            projection_causes[:, :, 3] = (
                (raw < acceleration_lower) | (raw > acceleration_upper)
            )
            lower = torch.maximum(lower, acceleration_lower)
            upper = torch.minimum(upper, acceleration_upper)
            causes[:, :, 3] = (lower > upper) & ~causes.any(dim=2)

        infeasible_joints = lower > upper
        self._hard_failure = torch.any(infeasible_joints, dim=1)
        projected_cmd = torch.minimum(torch.maximum(raw, lower), upper)
        zero_torque_hold = (position_gain * q + damping * qd) / target_gain
        zero_torque_hold = torch.minimum(torch.maximum(zero_torque_hold, qmin), qmax)
        if self.cfg.enable_safety_projector:
            self._q_cmd = torch.where(self._hard_failure[:, None], zero_torque_hold, projected_cmd)
        else:
            self._q_cmd = raw
            self._hard_failure.zero_()
        speed = torch.linalg.vector_norm(self.robot.data.root_lin_vel_b[:, :2], dim=1)
        braking_clearance = 0.08 + 0.15 * speed + torch.square(speed) / 3.0 + 0.03
        hold_threshold = braking_clearance + self.cfg.clearance_hold_margin
        release_threshold = hold_threshold + self.cfg.clearance_release_hysteresis
        activate_hold = self._hard_clearance <= hold_threshold
        keep_hold = self._safety_hold & (self._hard_clearance <= release_threshold)
        self._safety_hold.copy_(activate_hold | keep_hold)
        if self.cfg.enable_safety_projector:
            hold_command = self._q_cmd.clone()
            wheel_velocity = qd[:, (3, 7)]
            brake_torque = -torch.sign(wheel_velocity) * self.cfg.wheel_hold_brake_torque
            hold_command[:, (3, 7)] = (
                brake_torque + self.cfg.wheel_damping * wheel_velocity
            ) / self.cfg.wheel_target_gain
            self._q_cmd = torch.where(
                self._safety_hold[:, None], hold_command, self._q_cmd
            )
        projection_joints = torch.abs(self._q_cmd - raw) > 1e-7
        self._projected = torch.any(projection_joints, dim=1)
        self._last_projection_joint_flags.copy_(projection_joints)
        self._last_projection_cause_flags.copy_(projection_causes)
        self._last_infeasible_joint_flags.copy_(infeasible_joints)
        self._last_infeasible_cause_flags.copy_(causes)

    def _apply_action(self):
        q = self.robot.data.joint_pos[:, self._joint_ids]
        qd = self.robot.data.joint_vel[:, self._joint_ids]
        tau = torch.empty_like(q)
        leg_ids = (0, 1, 2, 4, 5, 6)
        wheel_ids = (3, 7)
        tau[:, leg_ids] = (
            self.cfg.leg_kp * (self._q_cmd[:, leg_ids] - q[:, leg_ids])
            - self.cfg.leg_kd * qd[:, leg_ids]
        )
        tau[:, wheel_ids] = (
            self.cfg.wheel_target_gain * self._q_cmd[:, wheel_ids]
            - self.cfg.wheel_damping * qd[:, wheel_ids]
        )
        limits = tau.new_tensor(
            (self.cfg.leg_torque_limit, self.cfg.leg_torque_limit, self.cfg.leg_torque_limit,
             self.cfg.wheel_torque_limit, self.cfg.leg_torque_limit, self.cfg.leg_torque_limit,
             self.cfg.leg_torque_limit, self.cfg.wheel_torque_limit)
        ).expand_as(tau)
        velocity_limits = tau.new_tensor(
            (self.cfg.leg_velocity_limit, self.cfg.leg_velocity_limit,
             self.cfg.leg_velocity_limit, self.cfg.wheel_velocity_limit,
             self.cfg.leg_velocity_limit, self.cfg.leg_velocity_limit,
             self.cfg.leg_velocity_limit, self.cfg.wheel_velocity_limit)
        ).expand_as(tau)
        tau = apply_velocity_torque_guard(
            tau, qd, limits, velocity_limits, self.cfg.velocity_safety_margin
        )
        self.robot.set_joint_effort_target(
            torch.clamp(tau, -limits, limits), joint_ids=self._joint_ids
        )

    def _stair_sequence_config(self) -> StairStepSequenceConfig:
        return StairStepSequenceConfig(
            shift_steps=int(self.cfg.stair_step_assist_shift_steps),
            retract_steps=int(self.cfg.stair_step_assist_retract_steps),
            place_steps=int(self.cfg.stair_step_assist_place_steps),
            settle_steps=int(self.cfg.stair_step_assist_settle_steps),
            hip_retract_rad=float(self.cfg.stair_step_assist_hip_retract_rad),
            hip_place_rad=float(self.cfg.stair_step_assist_hip_place_rad),
            knee_retract_rad=float(self.cfg.stair_step_assist_knee_retract_rad),
            knee_place_rad=float(self.cfg.stair_step_assist_knee_place_rad),
            support_hip_rad=float(self.cfg.stair_step_assist_support_hip_rad),
            support_knee_rad=float(self.cfg.stair_step_assist_support_knee_rad),
            lateral_shift_rad=float(self.cfg.stair_step_assist_lateral_shift_rad),
            support_lateral_scale=float(
                self.cfg.stair_step_assist_support_lateral_scale
            ),
            inward_hold_rad=float(self.cfg.stair_step_assist_inward_hold_rad),
            wheel_drive=float(self.cfg.stair_step_assist_wheel_drive),
            wheel_impulse_scale=float(self.cfg.stair_step_assist_wheel_impulse_scale),
            event_driven=bool(self.cfg.stair_step_assist_event_driven),
            drive_from_shift=bool(self.cfg.stair_step_assist_drive_from_shift),
        )

    def _stair_step_assist(self) -> torch.Tensor:
        """Move one wheel onto the tread before commanding the other side."""
        level = self._verified_stair_level().long()
        sequence_cfg = self._stair_sequence_config()
        self._stair_step_step.copy_(
            transition_sequence_on_level_advance(
                self._stair_step_step,
                self._stair_step_level,
                level,
                int(self.cfg.stair_num_steps),
                sequence_cfg,
            )
        )
        self._stair_step_level.copy_(level)

        commanded_forward = self._velocity_command[:, 0] > 1e-5
        newly_triggered = (
            (self._stair_step_step < 0)
            & commanded_forward
            & (self._clearance <= float(self.cfg.stair_step_assist_trigger_distance_m))
        )
        self._stair_step_step[newly_triggered] = 0
        wheel_levels, _, _ = self._wheel_stair_state()
        selected_lead, reassigned = select_reached_wheel_as_lead(
            self._stair_lead_is_left,
            wheel_levels,
            self._stair_step_level,
            self._stair_phase,
            event_driven=sequence_cfg.event_driven,
        )
        self._stair_lead_reassigned.copy_(reassigned)
        if reassigned.any():
            previous_lead = self._previous_lead_wheel_level[reassigned].clone()
            self._previous_lead_wheel_level[reassigned] = (
                self._previous_trail_wheel_level[reassigned]
            )
            self._previous_trail_wheel_level[reassigned] = previous_lead
            self._previous_lead_wheel_axis_z[reassigned] = torch.where(
                selected_lead[reassigned],
                self.robot.data.body_pos_w[reassigned, self._wheel_body_ids[0], 2],
                self.robot.data.body_pos_w[reassigned, self._wheel_body_ids[1], 2],
            )
            # The old lead is already retracted.  Once the other wheel reaches
            # the tread, make it the support and place the old lead directly;
            # replaying lead retract/place swaps the loaded and swing legs.
            self._stair_step_step[reassigned] = sequence_cfg.trail_place_start
        self._stair_lead_is_left.copy_(selected_lead)
        lead_level = torch.where(
            self._stair_lead_is_left, wheel_levels[:, 0], wheel_levels[:, 1]
        )
        trail_level = torch.where(
            self._stair_lead_is_left, wheel_levels[:, 1], wheel_levels[:, 0]
        )
        lead_reached = lead_level > self._stair_step_level
        trail_reached = trail_level > self._stair_step_level
        assist, phase, progress = alternating_stair_assist(
            self._stair_step_step,
            self._stair_lead_is_left,
            sequence_cfg,
        )
        final_settle_complete = (
            (level >= int(self.cfg.stair_num_steps))
            & (self._stair_step_step >= sequence_cfg.total_steps)
        )
        phase[final_settle_complete] = STAIR_PHASE_SETTLE
        progress[final_settle_complete] = 1.0
        self._stair_phase.copy_(phase)
        self._stair_phase_progress.copy_(progress)

        self._stair_step_step.copy_(
            advance_stair_sequence(
                self._stair_step_step,
                lead_reached,
                trail_reached,
                sequence_cfg,
            )
        )
        return assist

    def set_base_target(self, target: torch.Tensor) -> None:
        """Set the frozen official policy target in URDF joint order."""
        if target.shape != (self.num_envs, 8) or not torch.isfinite(target).all():
            raise ValueError(f"base target must be finite with shape ({self.num_envs}, 8)")
        self._base_target.copy_(target)

    def default_joint_target(self) -> torch.Tensor:
        return self.robot.data.default_joint_pos[:, self._joint_ids]

    @property
    def soft_costs(self) -> torch.Tensor:
        """Route, mechanical-energy, mode, and smooth costs for NP3O."""
        return self._soft_costs

    @property
    def raw_soft_costs(self) -> torch.Tensor:
        return self._raw_soft_costs

    @property
    def smooth_components(self) -> torch.Tensor:
        """Target-change, residual-rate, acceleration, and contact terms."""
        return self._smooth_components

    @property
    def energy_mech(self) -> torch.Tensor:
        return self._energy

    @property
    def last_step_energy(self) -> torch.Tensor:
        """Mechanical-energy proxy for the transition returned by ``step``.

        Unlike the episode accumulator this value intentionally survives an
        automatic reset, so an external trainer can account for the terminal
        transition.
        """

        return self._last_step_energy

    @property
    def distance(self) -> torch.Tensor:
        return self._distance

    @property
    def last_step_distance(self) -> torch.Tensor:
        return self._last_step_distance

    @property
    def hard_failure(self) -> torch.Tensor:
        return self._hard_failure

    @property
    def projected(self) -> torch.Tensor:
        return self._projected

    @property
    def safety_hold(self) -> torch.Tensor:
        return self._safety_hold

    @property
    def navigation_lidar_ranges(self) -> torch.Tensor | None:
        """Horizontal navigation scan in meters, clipped to sensor max range."""

        if self.cfg.navigation_lidar is None:
            return None
        delta = (
            self._navigation_lidar.data.ray_hits_w
            - self._navigation_lidar.data.pos_w.unsqueeze(1)
        )
        ranges = torch.linalg.vector_norm(delta, dim=-1)
        if hasattr(self, "sudden_obstacle_probe"):
            control_step = int(self.episode_length_buf[0].item())
            self.sudden_obstacle_probe.update(self, control_step)
            self.sudden_obstacle_probe.observe_lidar(self._navigation_lidar.data.ray_hits_w)
            self.sudden_obstacle_probe.sample(self, control_step)
        return torch.nan_to_num(
            ranges,
            nan=float(self.cfg.navigation_lidar.max_distance),
            posinf=float(self.cfg.navigation_lidar.max_distance),
            neginf=float(self.cfg.navigation_lidar.max_distance),
        ).clamp(0.0, float(self.cfg.navigation_lidar.max_distance))

    @property
    def tunnel_dimensions(self) -> torch.Tensor:
        """Per-environment net height, net width, and length in meters."""
        return self._tunnel_dimensions

    @property
    def tunnel_exited(self) -> torch.Tensor:
        if not self.cfg.tunnel_enabled:
            return torch.zeros(self.num_envs, dtype=torch.bool, device=self.device)
        local_x = self.robot.data.root_pos_w[:, 0] - self._environment_origins()[:, 0]
        return local_x > self.cfg.tunnel_start_x_m + self._tunnel_dimensions[:, 2]

    @property
    def tunnel_success_count(self) -> torch.Tensor:
        """Cumulative successful exits per environment; preserved across resets."""
        return self._tunnel_success_count

    @property
    def navigation_success_step(self) -> torch.Tensor:
        """Goal completion flag for the transition most recently returned by ``step``."""

        return self._navigation_success_step

    @property
    def navigation_success_count(self) -> torch.Tensor:
        return self._navigation_success_count

    @property
    def stair_dimensions(self) -> torch.Tensor:
        """Per-environment step height, tread length, and width in meters."""
        return self._stair_dimensions

    @property
    def stair_completed(self) -> torch.Tensor:
        if not self.cfg.stair_enabled:
            return torch.zeros(self.num_envs, dtype=torch.bool, device=self.device)
        local_x = self.robot.data.root_pos_w[:, 0] - self._environment_origins()[:, 0]
        tread = self._stair_dimensions[:, 1]
        completion_x = (
            self.cfg.stair_start_x_m
            + max(self.cfg.stair_num_steps - 1, 0) * tread
            + self.cfg.base_collision_half_length_m
        )
        platform_end_x = (
            self.cfg.stair_start_x_m
            + self.cfg.stair_num_steps * tread
            + self.cfg.stair_landing_length_m
            - self.cfg.base_collision_half_length_m
        )
        return (local_x > completion_x) & (local_x <= platform_end_x) & (
            self._verified_stair_level() >= self.cfg.stair_num_steps
        )

    @property
    def stair_stable(self) -> torch.Tensor:
        if not self.cfg.stair_enabled:
            return torch.zeros(self.num_envs, dtype=torch.bool, device=self.device)
        return stair_stable_state(
            self.stair_completed,
            self._collision,
            self.robot.data.root_lin_vel_w,
            self.robot.data.projected_gravity_b,
        )

    @property
    def stair_stationary_accepted(self) -> torch.Tensor:
        return stair_stationary_state(self.stair_traversed, self._collision,
                                      self.robot.data.root_lin_vel_w, self.robot.data.projected_gravity_b,
                                      self._wheel_contact, self.posture_height - self.posture_target_height)

    @property
    def stair_traversed(self) -> torch.Tensor:
        wheel_local_x = self.robot.data.body_pos_w[:, self._wheel_body_ids, 0] - self._environment_origins()[:, 0:1]
        final_edge = self.cfg.stair_start_x_m + (self.cfg.stair_num_steps - 1) * self._stair_dimensions[:, 1]
        platform_end = self.cfg.stair_start_x_m + self.cfg.stair_num_steps * self._stair_dimensions[:, 1] + self.cfg.stair_landing_length_m
        return fully_supported_stair_traversal(wheel_local_x, self._verified_stair_level(), final_edge,
                                              platform_end, self.cfg.stair_num_steps, self.cfg.wheel_radius)

    def _stair_support_height(self) -> torch.Tensor:
        """Height of the stair surface supporting the robot base center."""
        if not self.cfg.stair_enabled:
            return torch.zeros(self.num_envs, device=self.device)
        origins = self._environment_origins()
        local_x = self.robot.data.root_pos_w[:, 0] - origins[:, 0]
        local_y = self.robot.data.root_pos_w[:, 1] - origins[:, 1]
        height, tread, width = self._stair_dimensions.unbind(dim=1)
        level = (torch.floor((local_x - self.cfg.stair_start_x_m) / tread) + 1.0).clamp(
            min=0.0, max=float(self.cfg.stair_num_steps)
        )
        on_stair = (
            (local_x >= self.cfg.stair_start_x_m)
            & (
                local_x
                <= self.cfg.stair_start_x_m
                + self.cfg.stair_num_steps * tread
                + self.cfg.stair_landing_length_m
            )
            & (torch.abs(local_y) <= width / 2.0)
        )
        return torch.where(on_stair, level * height, torch.zeros_like(level))

    def _wheel_stair_state(
        self,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Return left/right levels and wheel position relative to the next tread."""
        if not self.cfg.stair_enabled:
            zeros = torch.zeros(self.num_envs, 2, device=self.device)
            return zeros, zeros, zeros
        origins = self._environment_origins()
        wheel_pos = self.robot.data.body_pos_w[:, self._wheel_body_ids]
        local_x = wheel_pos[:, :, 0] - origins[:, None, 0]
        local_y = wheel_pos[:, :, 1] - origins[:, None, 1]
        height, tread, width = self._stair_dimensions.unbind(dim=1)
        geometric_level = (
            torch.floor((local_x - self.cfg.stair_start_x_m) / tread[:, None]) + 1.0
        ).clamp(min=0.0, max=float(self.cfg.stair_num_steps))
        required_axis_z = (
            self._stair_wheel_axis_reference_z
            + geometric_level * height[:, None]
            - self.cfg.stair_completion_height_tolerance_m
        )
        stair_end = (
            self.cfg.stair_start_x_m
            + self.cfg.stair_num_steps * tread
            + self.cfg.stair_landing_length_m
        )
        on_stair = (
            (local_x >= self.cfg.stair_start_x_m)
            & (local_x <= stair_end[:, None])
            & (torch.abs(local_y) <= width[:, None] / 2.0)
        )
        height_ok = wheel_pos[:, :, 2] >= required_axis_z
        levels = torch.where(
            on_stair & height_ok, geometric_level, torch.zeros_like(geometric_level)
        )

        next_level = levels.amin(dim=1).long().clamp(
            min=0, max=max(self.cfg.stair_num_steps - 1, 0)
        )
        next_riser_x = self.cfg.stair_start_x_m + next_level.to(torch.float32) * tread
        next_axis_z = (
            self._stair_wheel_axis_reference_z
            + (next_level.to(torch.float32) + 1.0)[:, None] * height[:, None]
        )
        x_relative = (local_x - next_riser_x[:, None]) / self.cfg.wheel_radius
        z_relative = (wheel_pos[:, :, 2] - next_axis_z) / self.cfg.wheel_radius
        return levels, x_relative.clamp(-4.0, 4.0), z_relative.clamp(-4.0, 4.0)

    def _verified_stair_level(self) -> torch.Tensor:
        if not self.cfg.stair_enabled:
            return torch.zeros(self.num_envs, device=self.device)
        wheel_levels, _, _ = self._wheel_stair_state()
        origins = self._environment_origins()
        local_y = self.robot.data.root_pos_w[:, 1] - origins[:, 1]
        width = self._stair_dimensions[:, 2]
        lateral_ok = torch.abs(local_y) <= (
            width / 2.0 - self.cfg.base_collision_half_width_m
        ).clamp_min(0.0)
        return torch.where(
            lateral_ok, wheel_levels.amin(dim=1), torch.zeros_like(local_y)
        )

    @property
    def stair_success_count(self) -> torch.Tensor:
        """Cumulative successful stair completions; preserved across resets."""
        return self._stair_success_count

    @property
    def clearance(self) -> torch.Tensor:
        """Nearest terrain feature from the local ray-cast preview."""
        return self._clearance

    @property
    def hard_clearance(self) -> torch.Tensor:
        """Nearest non-traversable feature used by the braking constraint."""
        return self._hard_clearance

    @property
    def posture_height(self) -> torch.Tensor:
        """Wheel-axis to body-center height used by the official command interface."""
        return (
            self.robot.data.root_pos_w[:, 2]
            - self.cfg.wheel_radius
            - self._stair_support_height()
        )

    @property
    def posture_target_height(self) -> torch.Tensor:
        levels = self._posture_command.new_tensor(self.cfg.posture_heights)
        return torch.sum(self._posture_command * levels, dim=1)

    @property
    def soft_contact_force(self) -> torch.Tensor:
        """Peak leg_3 contact force; diagnostic and soft-cost input only."""
        return self._soft_contact_force

    @property
    def collision_event(self) -> torch.Tensor:
        """New base-link collision event observed on the last physics step."""
        return self._last_collision_event

    @property
    def collision_event_count(self) -> torch.Tensor:
        return self._collision_event_count

    @property
    def collision_context(self) -> dict[str, torch.Tensor]:
        """Context captured when the most recent base-link collision occurred."""
        return self._last_collision_context

    @property
    def hard_reason_flags(self) -> torch.Tensor:
        """Flags ordered according to :data:`HARD_REASON_NAMES`."""
        return self._last_hard_reason_flags

    @property
    def velocity_violation_flags(self) -> torch.Tensor:
        return self._last_velocity_violation_flags

    def joint_velocity_absmax(self) -> torch.Tensor:
        return self._last_joint_velocity_abs.amax(0)

    @property
    def velocity_state_projection_flags(self) -> torch.Tensor:
        return self._last_velocity_state_projection_flags

    def preprojection_joint_velocity_absmax(self) -> torch.Tensor:
        return self._last_preprojection_joint_velocity_abs.amax(0)

    def joint_acceleration_absmax(self) -> torch.Tensor:
        return self._last_joint_acceleration_abs.amax(0)

    @property
    def infeasible_joint_flags(self) -> torch.Tensor:
        return self._last_infeasible_joint_flags

    @property
    def infeasible_cause_flags(self) -> torch.Tensor:
        """Per-joint position, velocity, torque, acceleration conflict flags."""
        return self._last_infeasible_cause_flags

    @property
    def projection_joint_flags(self) -> torch.Tensor:
        return self._last_projection_joint_flags

    @property
    def projection_cause_flags(self) -> torch.Tensor:
        """Per-joint position, velocity, torque, acceleration activation flags."""
        return self._last_projection_cause_flags

    def set_velocity_command(self, command: torch.Tensor) -> None:
        if command.shape != (self.num_envs, 3) or not torch.isfinite(command).all():
            raise ValueError(f"velocity command must be finite with shape ({self.num_envs}, 3)")
        if self.cfg.stair_enabled:
            starts_moving = torch.linalg.vector_norm(command[:, :2], dim=1) > 1e-5
            freeze = starts_moving & ~self._stair_approach_height_frozen
            self._stair_approach_root_height[freeze] = torch.maximum(
                self._stair_approach_root_height[freeze],
                self.robot.data.root_pos_w[freeze, 2],
            )
            self._stair_wheel_axis_reference_z[freeze] = ground_relative_wheel_reference(
                self.robot.data.body_pos_w[freeze][:, self._wheel_body_ids, 2], self._stair_support_height()[freeze])
            self._stair_approach_height_frozen[freeze] = True
        self._velocity_command.copy_(command)

    def set_posture_command(self, command: torch.Tensor, phase: torch.Tensor | None = None) -> None:
        """Set an upper-level one-hot LOW/MID/HIGH command without selecting it in-policy."""
        if command.shape != (self.num_envs, 3) or not torch.isfinite(command).all():
            raise ValueError(f"posture command must be finite with shape ({self.num_envs}, 3)")
        if not torch.allclose(command.sum(dim=1), torch.ones(self.num_envs, device=self.device), atol=1e-5):
            raise ValueError("posture command rows must sum to one")
        if torch.any((command < 0.0) | (command > 1.0)):
            raise ValueError("posture command must be a one-hot probability vector")
        self._posture_command.copy_(command)
        if phase is not None:
            if phase.shape != (self.num_envs, 1) or not torch.isfinite(phase).all():
                raise ValueError(f"posture phase must have shape ({self.num_envs}, 1)")
            self._posture_phase.copy_(phase.clamp(0.0, 1.0))

    @property
    def posture_switch_event(self) -> torch.Tensor:
        return self._posture_switch_event

    @property
    def rapid_posture_switch_event(self) -> torch.Tensor:
        return self._rapid_posture_switch_event

    @property
    def posture_switch_count(self) -> torch.Tensor:
        return self._posture_switch_count

    @property
    def rapid_posture_switch_count(self) -> torch.Tensor:
        return self._rapid_posture_switch_count

    @property
    def dynamic_obstacle_risk(self) -> torch.Tensor:
        return self._dynamic_obstacle_risk

    def _environment_origins(self) -> torch.Tensor:
        if self.cfg.terrain.terrain_type == "generator":
            return self.terrain.env_origins
        return self.scene.env_origins

    def _effective_base_half_width(self) -> torch.Tensor:
        """World-Y half extent of the rectangular base after yaw rotation."""
        quat = self.robot.data.root_quat_w
        yaw = torch.atan2(
            2.0 * (quat[:, 0] * quat[:, 3] + quat[:, 1] * quat[:, 2]),
            1.0 - 2.0 * (torch.square(quat[:, 2]) + torch.square(quat[:, 3])),
        )
        return (
            self.cfg.base_collision_half_length_m * torch.abs(torch.sin(yaw))
            + self.cfg.base_collision_half_width_m * torch.abs(torch.cos(yaw))
        )

    def _update_perception(self) -> None:
        origins = self._environment_origins()
        local_x = self.robot.data.root_pos_w[:, 0] - origins[:, 0]
        local_y = self.robot.data.root_pos_w[:, 1] - origins[:, 1]
        root_z = self.robot.data.root_pos_w[:, 2]
        speed = torch.linalg.vector_norm(self.robot.data.root_lin_vel_b[:, :2], dim=1)
        gravity = self.robot.data.projected_gravity_b
        roll = torch.atan2(gravity[:, 1], -gravity[:, 2])
        pitch = torch.atan2(
            -gravity[:, 0],
            torch.sqrt(torch.square(gravity[:, 1]) + torch.square(gravity[:, 2])),
        )
        yaw_rate = self.robot.data.root_ang_vel_b[:, 2]
        tunnel_vertical_margin = torch.full_like(local_x, self.cfg.clearance_default)
        tunnel_lateral_margin = torch.full_like(local_x, self.cfg.clearance_default)
        in_tunnel = torch.zeros(self.num_envs, dtype=torch.bool, device=self.device)
        if self.cfg.height_scanner is None:
            self._clearance.fill_(self.cfg.clearance_default)
            self._hard_clearance.fill_(self.cfg.clearance_default)
        else:
            hits_z = self._height_scanner.data.ray_hits_w[..., 2]
            ray_xy = self._height_scanner.ray_starts[0, :, :2]
            center = (torch.abs(ray_xy[:, 0]) <= 0.10) & (torch.abs(ray_xy[:, 1]) <= 0.15)
            reference_height = torch.median(hits_z[:, center], dim=1).values
            elevation = hits_z - reference_height[:, None]
            forward = ray_xy[:, 0] > 0.05
            valid_hit = torch.isfinite(hits_z) & torch.isfinite(elevation)
            swept_corridor = torch.abs(ray_xy[:, 1]) <= self.cfg.hard_clearance_half_width
            hard_hazard = valid_hit & forward[None, :] & swept_corridor[None, :] & (
                (elevation > self.cfg.terrain_step_threshold)
                | (elevation < -self.cfg.terrain_drop_threshold)
            )
            preview_hazard = valid_hit & forward[None, :] & (
                torch.abs(elevation) > self.cfg.terrain_preview_threshold
            )
            forward_distance = ray_xy[:, 0].expand(self.num_envs, -1)
            fallback = torch.full_like(forward_distance, self.cfg.clearance_default)
            preview_candidates = torch.where(preview_hazard, forward_distance, fallback)
            hard_candidates = torch.where(hard_hazard, forward_distance, fallback)
            preview_clearance = preview_candidates.amin(dim=1).clamp_min(0.0)
            hard_clearance = hard_candidates.amin(dim=1).clamp_min(0.0)
            self._clearance.copy_(preview_clearance)
            self._hard_clearance.copy_(hard_clearance)

        if self.cfg.tunnel_enabled:
            height, width, length = self._tunnel_dimensions.unbind(dim=1)
            start = self.cfg.tunnel_start_x_m
            end = start + length
            in_tunnel = (local_x >= start) & (local_x <= end)
            near_tunnel = (
                (local_x >= start - self.cfg.tunnel_preview_distance_m)
                & (local_x <= end)
            )
            body_top = (
                self.robot.data.root_pos_w[:, 2]
                + self.cfg.base_collision_center_z_m
                + self.cfg.base_collision_half_height_m
            )
            vertical_margin = height - body_top
            lateral_margin = (
                width / 2.0
                - torch.abs(local_y)
                - self._effective_base_half_width()
            )
            tunnel_vertical_margin.copy_(vertical_margin)
            tunnel_lateral_margin.copy_(lateral_margin)
            envelope_margin = torch.minimum(vertical_margin, lateral_margin)
            preview_clearance = envelope_margin.clamp_min(0.0)
            self._clearance.copy_(
                torch.where(
                    near_tunnel,
                    preview_clearance,
                    torch.full_like(preview_clearance, self.cfg.clearance_default),
                )
            )
            unsafe_envelope = envelope_margin < self.cfg.tunnel_clearance_buffer_m
            distance_to_entry = (start - local_x).clamp_min(0.0)
            hard_clearance = torch.where(
                near_tunnel & unsafe_envelope,
                distance_to_entry,
                torch.full_like(distance_to_entry, self.cfg.clearance_default),
            )
            self._hard_clearance.copy_(hard_clearance)

        if self.cfg.stair_enabled:
            origins = self._environment_origins()
            local_x = self.robot.data.root_pos_w[:, 0] - origins[:, 0]
            tread = self._stair_dimensions[:, 1]
            relative_x = local_x - self.cfg.stair_start_x_m
            step_index = torch.floor(relative_x / tread).clamp(
                min=-1, max=self.cfg.stair_num_steps - 1
            )
            next_riser = self.cfg.stair_start_x_m + (step_index + 1.0) * tread
            before_first = local_x < self.cfg.stair_start_x_m
            approach_height = torch.maximum(
                self._stair_approach_root_height,
                self.robot.data.root_pos_w[:, 2],
            )
            update_reference = before_first & ~self._stair_approach_height_frozen
            self._stair_approach_root_height.copy_(
                torch.where(
                    update_reference,
                    approach_height,
                    self._stair_approach_root_height,
                )
            )
            next_riser = torch.where(
                before_first,
                torch.full_like(next_riser, self.cfg.stair_start_x_m),
                next_riser,
            )
            before_landing = step_index < self.cfg.stair_num_steps - 1
            near_stairs = (
                (local_x >= self.cfg.stair_start_x_m - self.cfg.stair_preview_distance_m)
                & before_landing
            )
            preview_clearance = (next_riser - local_x).clamp_min(0.0)
            stair_clearance = torch.where(near_stairs, preview_clearance,
                                          torch.full_like(preview_clearance, self.cfg.clearance_default))
            self._clearance.copy_(torch.minimum(self._clearance, stair_clearance))
            # Stair risers are traversable features. They affect route preview,
            # but must not trigger the non-traversable braking-distance HOLD.
            if not self.cfg.tunnel_enabled:
                self._hard_clearance.fill_(self.cfg.clearance_default)
            self._stair_height_preview.copy_(
                self._stair_dimensions[:, 0] / self.cfg.stair_height_preview_reference_m
            )
        else:
            self._stair_height_preview.zero_()

        if self.cfg.navigation_lidar is None:
            self._navigation_clearance.fill_(self.cfg.clearance_default)
            self._dynamic_obstacle_risk.zero_()
        else:
            sensor_position = self._navigation_lidar.data.pos_w.unsqueeze(1)
            delta = self._navigation_lidar.data.ray_hits_w - sensor_position
            valid = torch.isfinite(delta).all(dim=-1)
            forward = delta[..., 0] > 0.05
            corridor = torch.abs(delta[..., 1]) <= self.cfg.hard_clearance_half_width
            candidate = torch.where(
                valid & forward & corridor,
                delta[..., 0],
                torch.full_like(delta[..., 0], self.cfg.clearance_default),
            )
            self._navigation_clearance.copy_(candidate.amin(dim=1).clamp_min(0.0))
            self._clearance.minimum_(self._navigation_clearance)
            self._hard_clearance.minimum_(self._navigation_clearance)
            self._dynamic_obstacle_risk.copy_(
                torch.exp(-self._navigation_clearance / 0.50).clamp(0.0, 1.0)
            )
        self._collision_navigation_clearance.copy_(self._navigation_clearance)

        net_forces = self._contact_sensor.data.net_forces_w_history
        hard_contact = net_forces[:, :, self._hard_contact_body_ids]
        peak_force = torch.linalg.vector_norm(hard_contact, dim=-1).amax(dim=(1, 2))
        detected_collision = peak_force > self.cfg.collision_force_threshold
        self._collision_event.copy_(detected_collision & ~self._collision)
        self._collision.copy_(detected_collision)
        self._collision_peak_force.copy_(peak_force)
        body_peak_forces = torch.linalg.vector_norm(hard_contact, dim=-1).amax(dim=1)
        contact_body_indices = torch.as_tensor(self._hard_contact_body_ids, device=self.device)
        self._collision_body_index.copy_(contact_body_indices[body_peak_forces.argmax(dim=1)])
        self._collision_local_x.copy_(local_x)
        self._collision_local_y.copy_(local_y)
        self._collision_root_z.copy_(root_z)
        self._collision_speed.copy_(speed)
        self._collision_roll.copy_(roll)
        self._collision_pitch.copy_(pitch)
        self._collision_yaw_rate.copy_(yaw_rate)
        self._collision_vertical_margin.copy_(tunnel_vertical_margin)
        self._collision_lateral_margin.copy_(tunnel_lateral_margin)
        self._collision_in_tunnel.copy_(in_tunnel)
        soft_contact = net_forces[:, :, self._soft_contact_body_ids]
        self._soft_contact_force.copy_(
            torch.linalg.vector_norm(soft_contact, dim=-1).amax(dim=(1, 2))
        )
        wheel_contact = net_forces[:, :, self._wheel_contact_body_ids]
        wheel_peak_force = torch.linalg.vector_norm(wheel_contact, dim=-1).amax(dim=1)
        self._wheel_contact.copy_(wheel_peak_force > 1.0)

    def official_proprioception(self, previous_policy_action: torch.Tensor) -> torch.Tensor:
        return build_official_proprioception(
            self.robot.data.root_ang_vel_b,
            self.robot.data.projected_gravity_b,
            self._velocity_command,
            self.robot.data.joint_pos[:, self._joint_ids],
            self.robot.data.joint_vel[:, self._joint_ids],
            self.robot.data.default_joint_pos[:, self._joint_ids],
            previous_policy_action,
        )

    def set_path_pose_error(self, error: torch.Tensor) -> None:
        if error.shape != (self.num_envs, 2) or not torch.isfinite(error).all():
            raise ValueError("path pose feedback must contain signed cross-track and heading error")
        self._path_pose_error.copy_(error)
        self._path_pose_override.fill_(True)

    def _get_observations(self) -> dict[str, torch.Tensor]:
        self._update_perception()
        q = self.robot.data.joint_pos[:, self._joint_ids]
        qd = self.robot.data.joint_vel[:, self._joint_ids]
        root_lin = self.robot.data.root_lin_vel_b
        root_ang = self.robot.data.root_ang_vel_b
        gravity = self.robot.data.projected_gravity_b
        speed = torch.linalg.vector_norm(root_lin[:, :2], dim=1)
        braking_distance = 0.08 + 0.15 * speed + torch.square(speed) / 3.0 + 0.03
        corridor_deviation = torch.abs(
            self.robot.data.root_pos_w[:, 1] - self._environment_origins()[:, 1]
        )
        curvature = (torch.abs(root_ang[:, 2]) / (speed + 0.10)).clamp(max=5.0)
        clearance = self._clearance
        preview = torch.stack((clearance, corridor_deviation, curvature, clearance - braking_distance), dim=1)
        roll = torch.atan2(gravity[:, 1], -gravity[:, 2])
        pitch = torch.atan2(-gravity[:, 0], torch.sqrt(torch.square(gravity[:, 1]) + torch.square(gravity[:, 2])))
        posture_height = self.posture_height
        posture_actual = torch.stack((posture_height, roll, pitch), dim=1)
        wheel_levels, wheel_x_relative, wheel_z_relative = self._wheel_stair_state()
        if self.cfg.stair_step_assist_enabled:
            phase, phase_progress = stair_phase(
                self._stair_step_step, self._stair_sequence_config()
            )
        else:
            phase = torch.zeros(self.num_envs, dtype=torch.long, device=self.device)
            phase_progress = torch.zeros(self.num_envs, device=self.device)
        lead_side = torch.where(
            self._stair_lead_is_left,
            torch.ones(self.num_envs, device=self.device),
            -torch.ones(self.num_envs, device=self.device),
        )
        stair_sequence_obs = torch.cat(
            (
                phase[:, None].to(torch.float32) / float(STAIR_PHASE_COUNT - 1),
                phase_progress[:, None],
                lead_side[:, None],
                self._wheel_contact.to(torch.float32),
                wheel_x_relative,
                wheel_z_relative,
                wheel_levels / max(float(self.cfg.stair_num_steps), 1.0),
            ),
            dim=1,
        )
        obs = torch.cat(
            (
                root_lin, root_ang, gravity, q, qd, self._actions, self._velocity_command,
                preview, self._posture_command, posture_actual, self._posture_phase,
                self._energy[:, None], self._path_version, self._goal_age,
                self._stair_height_preview[:, None],
                stair_sequence_obs,
            ),
            dim=-1,
        )
        if self.cfg.navigation_pose_observations:
            quaternion = self.robot.data.root_quat_w
            yaw = torch.atan2(2. * (quaternion[:, 0] * quaternion[:, 3] + quaternion[:, 1] * quaternion[:, 2]),
                              1. - 2. * (quaternion[:, 2].square() + quaternion[:, 3].square()))
            straight_error = torch.stack((self.robot.data.root_pos_w[:, 1] - self._environment_origins()[:, 1], yaw), 1)
            path_error = torch.where(self._path_pose_override[:, None], self._path_pose_error, straight_error)
            obs = torch.cat((obs, path_error), dim=1)
        return {"policy": obs}

    def _get_rewards(self) -> torch.Tensor:
        q = self.robot.data.joint_pos[:, self._joint_ids]
        qd = self.robot.data.joint_vel[:, self._joint_ids]
        tau = self.robot.data.applied_torque[:, self._joint_ids]
        xy = self.robot.data.root_pos_w[:, :2]
        delta_xy = xy - self._previous_xy
        local_length = torch.linalg.vector_norm(delta_xy, dim=1).clamp(max=0.1)
        self._last_step_distance.copy_(local_length.detach())
        progress = delta_xy[:, 0].clamp(-0.1, 0.1)
        self._previous_xy = xy.detach().clone()
        root_height = self.robot.data.root_pos_w[:, 2]
        height_progress = (root_height - self._previous_root_height).clamp(-0.05, 0.05)
        self._previous_root_height.copy_(root_height.detach())
        self._distance += local_length
        energy_step = torch.sum(torch.abs(tau * qd), dim=1) * self.step_dt
        self._last_step_energy.copy_(energy_step.detach())
        self._energy += energy_step
        speed = torch.linalg.vector_norm(self.robot.data.root_lin_vel_b[:, :2], dim=1)
        corridor_deviation = torch.abs(xy[:, 1] - self._environment_origins()[:, 1])
        clearance = self._clearance
        clearance_risk = torch.exp(-clearance / self.cfg.clearance_sigma)
        curvature = (torch.abs(self.robot.data.root_ang_vel_b[:, 2]) / (speed + 0.10)).clamp(max=5.0)
        corridor_half_width = torch.full_like(
            corridor_deviation, self.cfg.corridor_half_width
        )
        if self.cfg.tunnel_enabled:
            corridor_half_width = (
                self._tunnel_dimensions[:, 1] / 2.0
                - self._effective_base_half_width()
            ).clamp_min(0.0)
        elif self.cfg.stair_enabled:
            corridor_half_width = (
                self._stair_dimensions[:, 2] / 2.0
                - self.cfg.base_collision_half_width_m
            ).clamp_min(0.0)
        corridor_violation = torch.relu(corridor_deviation - corridor_half_width)
        forward_progress = progress.clamp_min(0.0)
        detour_length = torch.relu(local_length - forward_progress)
        commanded_progress = torch.linalg.vector_norm(self._velocity_command[:, :2], dim=1) * self.step_dt
        progress_deficit = torch.relu(commanded_progress - forward_progress)
        route_cost = (
            self.cfg.route_length_weight
            * (detour_length + progress_deficit) / self.cfg.route_reference_length
            + self.cfg.route_clearance_weight * clearance_risk * local_length / self.cfg.route_reference_length
            + self.cfg.route_curvature_weight * self.cfg.route_reference_length
            * torch.square(curvature) * local_length
            + corridor_violation
            + self.cfg.dynamic_obstacle_risk_weight
            * self._dynamic_obstacle_risk
            * local_length / self.cfg.route_reference_length
        )
        posture_height = self.posture_height
        height_rate = (posture_height - self._previous_posture_height) / self.step_dt
        self._previous_posture_height.copy_(posture_height.detach())
        posture_levels = posture_height.new_tensor(self.cfg.posture_heights)
        target_height = torch.sum(self._posture_command * posture_levels, dim=1)
        commanded_mode = torch.argmax(self._posture_command, dim=1)
        self._posture_switch_event.copy_(commanded_mode != self._posture_mode)
        self._rapid_posture_switch_event.copy_(
            self._posture_switch_event
            & (self._posture_mode_age < self.cfg.rapid_mode_switch_window_s)
        )
        self._posture_switch_count += self._posture_switch_event.long()
        self._rapid_posture_switch_count += self._rapid_posture_switch_event.long()
        self._posture_mode_age += self.step_dt
        self._posture_mode_age[self._posture_switch_event] = 0.0
        self._posture_mode.copy_(commanded_mode)
        mode_cost = (
            self.cfg.mode_height_rate_weight
            * torch.square(height_rate / self.cfg.height_rate_reference)
            + self.cfg.mode_hold_weight
            * torch.square((posture_height - target_height) / self.cfg.height_rate_reference)
            + self.cfg.mode_switch_cost_weight * self._posture_switch_event.float()
            + self.cfg.rapid_mode_switch_cost_weight
            * self._rapid_posture_switch_event.float()
        )
        residual_rate = torch.mean(
            torch.abs(self._actions - self._previous_actions), dim=1
        ) / max(self.cfg.residual_limit * self.cfg.posture_scale, 1e-6)
        joint_target_change = torch.mean(
            torch.abs(self._q_cmd - self._previous_q_cmd), dim=1
        ) / self.cfg.joint_target_change_reference
        acceleration_ratio = torch.mean(
            self._last_joint_acceleration_abs / self.cfg.acceleration_limit, dim=1
        )
        soft_contact_ratio = (
            self._soft_contact_force / self.cfg.collision_force_threshold
        ).clamp(max=5.0)
        soft_contact_term = self.cfg.soft_contact_cost_weight * soft_contact_ratio
        self._smooth_components = torch.stack(
            (
                joint_target_change,
                residual_rate,
                acceleration_ratio,
                soft_contact_term,
            ),
            dim=1,
        )
        smooth_cost = self._smooth_components.sum(dim=1)
        self._raw_soft_costs = torch.stack(
            (route_cost, energy_step, mode_cost, smooth_cost), dim=1
        )
        p95 = self._raw_soft_costs.new_tensor(self.cfg.objective_p95).clamp_min(1e-8)
        self._soft_costs = (self._raw_soft_costs / p95).clamp(
            min=0.0, max=self.cfg.normalized_cost_clip
        )
        linear_error = torch.sum(
            torch.square(self.robot.data.root_lin_vel_b[:, :2] - self._velocity_command[:, :2]), dim=1
        )
        yaw_error = torch.square(self.robot.data.root_ang_vel_b[:, 2] - self._velocity_command[:, 2])
        tracking_reward = torch.exp(-linear_error / 0.25) + 0.5 * torch.exp(-yaw_error / 0.25)
        normalized_route, normalized_energy, normalized_mode, normalized_smooth = self._soft_costs.unbind(1)
        stair_step_progress = torch.zeros(self.num_envs, device=self.device)
        stair_approach_lift = torch.zeros(self.num_envs, device=self.device)
        stair_lead_progress = torch.zeros(self.num_envs, device=self.device)
        stair_trail_progress = torch.zeros(self.num_envs, device=self.device)
        stair_lead_lift_progress = torch.zeros(self.num_envs, device=self.device)
        stair_lead_unloaded = torch.zeros(self.num_envs, device=self.device)
        stair_rolling_contact = torch.zeros(self.num_envs, device=self.device)
        single_wheel_lag = torch.zeros(self.num_envs, device=self.device)
        if self.cfg.stair_enabled:
            wheel_levels, wheel_x_relative, wheel_z_relative = self._wheel_stair_state()
            lead_level = torch.where(
                self._stair_lead_is_left, wheel_levels[:, 0], wheel_levels[:, 1]
            )
            trail_level = torch.where(
                self._stair_lead_is_left, wheel_levels[:, 1], wheel_levels[:, 0]
            )
            wheel_axis_z = self.robot.data.body_pos_w[:, self._wheel_body_ids, 2]
            lead_axis_z = torch.where(
                self._stair_lead_is_left, wheel_axis_z[:, 0], wheel_axis_z[:, 1]
            )
            stair_lead_lift_progress = (
                (lead_axis_z - self._previous_lead_wheel_axis_z).clamp_min(0.0)
                / self._stair_dimensions[:, 0].clamp_min(1e-6)
            ).clamp(max=0.25)
            self._previous_lead_wheel_axis_z.copy_(lead_axis_z.detach())
            lead_contact = torch.where(
                self._stair_lead_is_left,
                self._wheel_contact[:, 0],
                self._wheel_contact[:, 1],
            )
            stair_lead_unloaded = (
                (self._stair_phase == 1) & ~lead_contact & ~self._collision
            ).to(torch.float32)
            lead_x_relative = torch.where(
                self._stair_lead_is_left,
                wheel_x_relative[:, 0],
                wheel_x_relative[:, 1],
            )
            lead_z_relative = torch.where(
                self._stair_lead_is_left,
                wheel_z_relative[:, 0],
                wheel_z_relative[:, 1],
            )
            lead_wheel_velocity = torch.where(
                self._stair_lead_is_left, -qd[:, 3], -qd[:, 7]
            )
            rolling_near_edge = (
                (self._stair_phase >= STAIR_PHASE_SHIFT_TO_TRAIL)
                & (self._stair_phase <= STAIR_PHASE_LEAD_PLACE)
                & (lead_x_relative >= -1.25)
                & (lead_x_relative <= 0.25)
                & (lead_z_relative >= -1.50)
                & (lead_z_relative <= 0.25)
            )
            stair_rolling_contact = (
                lead_contact
                & rolling_near_edge
                & ~self._collision
            ).to(torch.float32) * (lead_wheel_velocity / 10.0).clamp(0.0, 1.0)
            lead_max = torch.maximum(lead_level, self._previous_lead_wheel_level)
            trail_max = torch.maximum(trail_level, self._previous_trail_wheel_level)
            stair_lead_progress = lead_max - self._previous_lead_wheel_level
            stair_trail_progress = trail_max - self._previous_trail_wheel_level
            self._previous_lead_wheel_level.copy_(lead_max)
            self._previous_trail_wheel_level.copy_(trail_max)
            one_wheel_ahead = torch.abs(wheel_levels[:, 0] - wheel_levels[:, 1]) > 0.5
            self._single_wheel_steps.copy_(
                torch.where(
                    one_wheel_ahead,
                    self._single_wheel_steps + 1,
                    torch.zeros_like(self._single_wheel_steps),
                )
            )
            grace = max(int(self.cfg.stair_single_wheel_grace_steps), 1)
            single_wheel_lag = (
                (self._single_wheel_steps - grace).clamp_min(0).to(torch.float32)
                / float(grace)
            ).clamp(max=2.0)
            verified_level = self._verified_stair_level()
            verified_max = torch.maximum(
                verified_level, self._previous_verified_stair_level
            )
            stair_step_progress = verified_max - self._previous_verified_stair_level
            self._previous_verified_stair_level.copy_(verified_max)
            near_next_riser = (
                (self._clearance <= self.cfg.stair_approach_lift_distance_m)
                & (verified_max < self.cfg.stair_num_steps)
            )
            stair_approach_lift = (
                height_progress.clamp_min(0.0) * near_next_riser.float()
            )
        reward = (
            self.cfg.tracking_reward_scale * tracking_reward
            + self.cfg.tracking_reward_scale * progress
            - self.cfg.route_reward_scale * normalized_route
            - self.cfg.energy_cost_scale * normalized_energy
            - self.cfg.mode_cost_scale * normalized_mode
            - self.cfg.smooth_cost_scale * normalized_smooth
            - self.cfg.hard_failure_cost * self._hard_failure.float()
            + self.cfg.tunnel_success_reward * self._tunnel_success_step.float()
            + self.cfg.stair_success_reward * self._stair_success_step.float()
            + self.cfg.stair_height_progress_reward_scale
            * height_progress.clamp_min(0.0)
            * float(self.cfg.stair_enabled)
            + self.cfg.stair_approach_lift_reward_scale * stair_approach_lift
            + self.cfg.stair_step_progress_reward * stair_step_progress
            + self.cfg.stair_lead_wheel_reward * stair_lead_progress
            + self.cfg.stair_trail_wheel_reward * stair_trail_progress
            + self.cfg.stair_lead_lift_progress_reward * stair_lead_lift_progress
            + self.cfg.stair_lead_unload_reward * stair_lead_unloaded
            + self.cfg.stair_rolling_contact_reward_scale * stair_rolling_contact
            + self.cfg.stair_level_hold_reward_scale
            * (self._previous_verified_stair_level / max(self.cfg.stair_num_steps, 1))
            * float(self.cfg.stair_enabled)
            + self.cfg.stair_stable_hold_reward_scale
            * (self.stair_stationary_accepted if self.cfg.stair_success_stable_hold_s > 0. else self.stair_stable).float()
            * float(self.cfg.stair_enabled)
            - self.cfg.stair_collision_penalty
            * self._collision.float()
            * float(self.cfg.stair_enabled)
            - self.cfg.stair_single_wheel_lag_penalty * single_wheel_lag
            * float(self.cfg.stair_enabled)
        )
        reward -= self.cfg.navigation_lateral_deviation_penalty * corridor_deviation.square()
        reward -= self.cfg.navigation_posture_height_penalty * (posture_height - target_height).square()
        reward -= navigation_tracking_penalty(
            self.robot.data.root_lin_vel_b,
            self.robot.data.root_ang_vel_b,
            self.robot.data.projected_gravity_b,
            self._velocity_command,
            self.cfg.navigation_linear_tracking_penalty,
            self.cfg.navigation_yaw_tracking_penalty,
            self.cfg.navigation_tilt_penalty,
        )
        if self.cfg.navigation_stationary_hold_reward_scale or self.cfg.navigation_stationary_interruption_penalty:
            from .stationary_execution_reward import stationary_execution_reward
            hold_s, stationary_reward = stationary_execution_reward(
                self._navigation_stationary_hold_s, self._velocity_command, self.robot.data.root_lin_vel_w,
                self.robot.data.root_ang_vel_b, self.robot.data.projected_gravity_b, self._wheel_contact,
                posture_height - target_height, self._posture_phase[:, 0], self._hard_failure, self.step_dt,
                self.cfg.navigation_stationary_hold_reward_scale, self.cfg.navigation_stationary_interruption_penalty)
            self._navigation_stationary_hold_s.copy_(hold_s)
            reward += stationary_reward
        return reward

    def _get_dones(self) -> tuple[torch.Tensor, torch.Tensor]:
        self._last_transition_root_position.copy_(self.robot.data.root_pos_w)
        self._last_transition_posture_height.copy_(self.posture_height)
        self._update_perception()
        self._last_transition_wheel_contacts.copy_(self._wheel_contact)
        self._last_physical_pedestrian_contact_force.copy_(self.physical_pedestrian_contact_force)
        self._last_collision_event.copy_(self._collision_event)
        self._collision_event_count += self._last_collision_event.long()
        current_collision_context = {
            "peak_force": self._collision_peak_force,
            "peak_body_index": self._collision_body_index,
            "local_x": self._collision_local_x,
            "local_y": self._collision_local_y,
            "root_z": self._collision_root_z,
            "speed": self._collision_speed,
            "roll": self._collision_roll,
            "pitch": self._collision_pitch,
            "yaw_rate": self._collision_yaw_rate,
            "vertical_margin": self._collision_vertical_margin,
            "lateral_margin": self._collision_lateral_margin,
            "navigation_clearance": self._collision_navigation_clearance,
            "in_tunnel": self._collision_in_tunnel,
        }
        for name, value in current_collision_context.items():
            self._last_collision_context[name].copy_(
                torch.where(
                    self._last_collision_event,
                    value,
                    self._last_collision_context[name],
                )
            )
        q = self.robot.data.joint_pos[:, self._joint_ids]
        measured_qd = self.robot.data.joint_vel[:, self._joint_ids]
        tau = self.robot.data.applied_torque[:, self._joint_ids]
        limits = q.new_tensor(
            (self.cfg.leg_torque_limit, self.cfg.leg_torque_limit, self.cfg.leg_torque_limit,
             self.cfg.wheel_torque_limit, self.cfg.leg_torque_limit, self.cfg.leg_torque_limit,
             self.cfg.leg_torque_limit, self.cfg.wheel_torque_limit)
        ).expand_as(q)
        velocity_limits = q.new_tensor(
            (
                self.cfg.leg_velocity_limit, self.cfg.leg_velocity_limit,
                self.cfg.leg_velocity_limit, self.cfg.wheel_velocity_limit,
                self.cfg.leg_velocity_limit, self.cfg.leg_velocity_limit,
                self.cfg.leg_velocity_limit, self.cfg.wheel_velocity_limit,
            )
        ).expand_as(q)
        self._last_preprojection_joint_velocity_abs.copy_(torch.abs(measured_qd))
        qd, velocity_state_projection = project_joint_velocity(
            measured_qd, velocity_limits
        )
        if self.cfg.enable_safety_projector and velocity_state_projection.any():
            affected_envs = torch.any(velocity_state_projection, dim=1).nonzero().flatten()
            self.robot.write_joint_state_to_sim(
                q[affected_envs], qd[affected_envs],
                joint_ids=self._joint_ids, env_ids=affected_envs
            )
        else:
            qd = measured_qd
            velocity_state_projection.zero_()
        self._last_velocity_state_projection_flags.copy_(velocity_state_projection)
        velocity_by_joint = torch.abs(qd) > velocity_limits
        self._last_joint_velocity_abs.copy_(torch.abs(qd))
        measured_acceleration = (qd - self._previous_joint_velocity) / self.step_dt
        filter_alpha = self.step_dt / (
            self.cfg.acceleration_filter_time_constant + self.step_dt
        )
        self._filtered_joint_acceleration.lerp_(measured_acceleration, filter_alpha)
        self._previous_joint_velocity.copy_(qd)
        self._last_joint_acceleration_abs.copy_(
            torch.abs(self._filtered_joint_acceleration)
        )
        self._last_velocity_violation_flags.copy_(velocity_by_joint)
        velocity = torch.any(velocity_by_joint, dim=1)
        acceleration = (
            torch.any(self._last_joint_acceleration_abs > self.cfg.acceleration_limit, dim=1)
            if self.cfg.enforce_acceleration_limit
            else torch.zeros(self.num_envs, dtype=torch.bool, device=self.device)
        )
        torque = torch.any(torch.abs(tau) > limits, dim=1)
        height = self.robot.data.root_pos_w[:, 2] < 0.15
        attitude = self.robot.data.projected_gravity_b[:, 2] > -0.3
        speed = torch.linalg.vector_norm(self.robot.data.root_lin_vel_b[:, :2], dim=1)
        braking_clearance = (
            0.10 + 0.15 * speed + torch.square(speed) / 3.0 + 0.03
        )
        # Reaching the braking envelope activates HOLD in the projector.  It is
        # only a hard violation if the robot still crosses the zero-speed
        # clearance floor after that intervention.
        clearance = self._hard_clearance < (0.08 + 0.03)
        stabilized = self.episode_length_buf >= self.cfg.reset_stabilization_steps
        velocity &= stabilized
        acceleration &= stabilized
        torque &= stabilized
        collision = (self._collision | (self._last_physical_pedestrian_contact_force > 1.0)) & stabilized
        if self.cfg.stair_enabled and not self.cfg.stair_collision_terminates:
            collision = (self._last_physical_pedestrian_contact_force > 1.0) & stabilized
        height &= stabilized
        attitude &= stabilized
        clearance &= stabilized
        self._hard_reason_flags = torch.stack(
            (
                self._hard_failure,
                velocity,
                acceleration,
                torque,
                collision,
                height,
                attitude,
                clearance,
            ),
            dim=1,
        )
        self._last_hard_reason_flags.copy_(self._hard_reason_flags)
        hard = torch.any(self._hard_reason_flags, dim=1)
        self._hard_failure |= hard
        timeout = self.episode_length_buf >= self.max_episode_length - 1
        if self.cfg.three_route_enabled:
            local_xy = (
                self.robot.data.root_pos_w[:, :2]
                - self._environment_origins()[:, :2]
            )
            reached = navigation_goal_reached(
                local_xy, self.cfg.navigation_goal_xy_m,
                float(self.cfg.navigation_goal_tolerance_m))
            self._navigation_success_step.copy_(reached & ~hard)
            self._navigation_success_count += self._navigation_success_step.long()
            if self.cfg.navigation_terminate_on_goal:
                timeout |= self._navigation_success_step
        else:
            self._navigation_success_step.zero_()
        if self.cfg.tunnel_enabled:
            self._tunnel_success_step.copy_(self.tunnel_exited & ~hard & ~self._tunnel_completed_latched)
            self._tunnel_completed_latched |= self._tunnel_success_step
            self._tunnel_success_count += self._tunnel_success_step.long()
            if self.cfg.tunnel_terminate_on_success:
                timeout |= self._tunnel_success_step
        else:
            self._tunnel_success_step.zero_()
        if self.cfg.stair_enabled:
            completed = self.stair_completed & ~hard
            if self.cfg.stair_success_stable_hold_s > 0.:
                stable = self.stair_stationary_accepted & ~hard
                self._stair_success_stable_steps = torch.where(stable, self._stair_success_stable_steps + 1,
                                                              torch.zeros_like(self._stair_success_stable_steps))
                completed &= self._stair_success_stable_steps * self.step_dt >= self.cfg.stair_success_stable_hold_s
            self._stair_success_step.copy_(completed & ~self._stair_completed_latched)
            self._stair_completed_latched |= completed
            self._stair_success_count += self._stair_success_step.long()
            if self.cfg.stair_terminate_on_success:
                timeout |= self._stair_success_step
        else:
            self._stair_success_step.zero_()
        return hard, timeout

    def _reset_idx(self, env_ids: torch.Tensor | None):
        if getattr(self, "_defer_navigation_reset", False) and env_ids is not None:
            return
        if env_ids is None or len(env_ids) == self.num_envs:
            env_ids = self.robot._ALL_INDICES
        self.robot.reset(env_ids)
        super()._reset_idx(env_ids)
        default_q = self.robot.data.default_joint_pos[env_ids][:, self._joint_ids]
        default_root = self.robot.data.default_root_state[env_ids].clone()
        default_root[:, :3] += self._environment_origins()[env_ids]
        if self.cfg.stair_support_augmentation_enabled:
            on_support = env_ids.remainder(2) == 1
            default_root[on_support, 0] += self.cfg.stair_start_x_m + self.cfg.stair_support_augmentation_offset_m
            default_root[on_support, 2] += self._stair_dimensions[env_ids[on_support], 0] * self.cfg.stair_num_steps
        approach_yaw = torch.zeros(env_ids.numel(), device=self.device)
        approach_lead_is_left = torch.rand(
            env_ids.numel(), device=self.device
        ) < 0.5
        if self.cfg.stair_enabled:
            if self.cfg.stair_approach_lead_side == "left":
                approach_lead_is_left.fill_(True)
            elif self.cfg.stair_approach_lead_side == "right":
                approach_lead_is_left.fill_(False)
            elif self.cfg.stair_approach_lead_side == "random":
                pass
            else:
                raise ValueError(
                    "stair_approach_lead_side must be left, right, or random"
                )
        if self.cfg.stair_enabled and self.cfg.stair_approach_yaw_rad > 0.0:
            yaw_sign = torch.where(
                approach_lead_is_left,
                -torch.ones_like(approach_yaw),
                torch.ones_like(approach_yaw),
            )
            approach_yaw = yaw_sign * float(self.cfg.stair_approach_yaw_rad)
            default_root[:, 3:7] = quat_from_euler_xyz(
                torch.zeros_like(approach_yaw),
                torch.zeros_like(approach_yaw),
                approach_yaw,
            )
        self.robot.write_root_pose_to_sim(default_root[:, :7], env_ids)
        self.robot.write_root_velocity_to_sim(default_root[:, 7:], env_ids)
        self.robot.write_joint_state_to_sim(
            default_q, torch.zeros_like(default_q), joint_ids=self._joint_ids, env_ids=env_ids
        )
        self._actions[env_ids] = 0.0
        self._previous_actions[env_ids] = 0.0
        self._base_target[env_ids] = default_q
        self._q_cmd[env_ids] = default_q
        self._previous_q_cmd[env_ids] = default_q
        self._hard_failure[env_ids] = False
        self._tunnel_success_step[env_ids] = False
        self._stair_success_step[env_ids] = False
        self._stair_success_stable_steps[env_ids] = 0
        self._projected[env_ids] = False
        self._safety_hold[env_ids] = False
        self._hard_reason_flags[env_ids] = False
        self._last_infeasible_joint_flags[env_ids] = False
        self._last_infeasible_cause_flags[env_ids] = False
        self._last_projection_joint_flags[env_ids] = False
        self._last_projection_cause_flags[env_ids] = False
        self._last_joint_acceleration_abs[env_ids] = 0.0
        self._last_velocity_state_projection_flags[env_ids] = False
        self._last_preprojection_joint_velocity_abs[env_ids] = 0.0
        self._filtered_joint_acceleration[env_ids] = 0.0
        self._previous_joint_velocity[env_ids] = 0.0
        self._distance[env_ids] = 0.0
        self._energy[env_ids] = 0.0
        self._soft_costs[env_ids] = 0.0
        self._raw_soft_costs[env_ids] = 0.0
        self._smooth_components[env_ids] = 0.0
        self._previous_xy[env_ids] = default_root[:, :2]
        self._previous_root_height[env_ids] = default_root[:, 2]
        self._velocity_command[env_ids] = 0.0
        self._navigation_stationary_hold_s[env_ids] = 0.0
        reset_posture_command = self._posture_command[env_ids].clone()
        reset_posture_mode = torch.argmax(reset_posture_command, dim=1)
        self._posture_command[env_ids] = reset_posture_command
        self._posture_mode[env_ids] = reset_posture_mode
        self._posture_mode_age[env_ids] = 1.0e6
        self._posture_switch_event[env_ids] = False
        self._rapid_posture_switch_event[env_ids] = False
        self._posture_switch_count[env_ids] = 0
        self._rapid_posture_switch_count[env_ids] = 0
        self._posture_phase[env_ids] = 0.0
        self._posture_offset[env_ids] = 0.0
        self._path_version[env_ids] = 0.0
        self._goal_age[env_ids] = 0.0
        self._path_pose_error[env_ids] = 0.0
        self._path_pose_override[env_ids] = False
        self._previous_posture_height[env_ids] = default_root[:, 2] - self.cfg.wheel_radius - self._stair_support_height()[env_ids]
        self._collision[env_ids] = False
        self._soft_contact_force[env_ids] = 0.0
        self._clearance[env_ids] = self.cfg.clearance_default
        self._hard_clearance[env_ids] = self.cfg.clearance_default
        self._navigation_clearance[env_ids] = self.cfg.clearance_default
        self._dynamic_obstacle_risk[env_ids] = 0.0
        self._stair_height_preview[env_ids] = 0.0
        self._stair_approach_root_height[env_ids] = default_root[:, 2]
        self._stair_approach_height_frozen[env_ids] = False
        self._previous_verified_stair_level[env_ids] = 0.0
        self._previous_lead_wheel_level[env_ids] = 0.0
        self._previous_trail_wheel_level[env_ids] = 0.0
        self._single_wheel_steps[env_ids] = 0
        self._stair_step_step[env_ids] = -1
        self._stair_step_level[env_ids] = 0
        self._stair_lead_is_left[env_ids] = approach_lead_is_left
        self._stair_lead_reassigned[env_ids] = False
        self._stair_phase[env_ids] = 0
        self._stair_phase_progress[env_ids] = 0.0
        self._stair_completed_latched[env_ids] = False
        self._tunnel_completed_latched[env_ids] = False
        self._wheel_contact[env_ids] = False
        self._stair_wheel_axis_reference_z[env_ids] = ground_relative_wheel_reference(
            self.robot.data.body_pos_w[env_ids][:, self._wheel_body_ids, 2], self._stair_support_height()[env_ids])
        self._previous_lead_wheel_axis_z[env_ids] = torch.where(
            self._stair_lead_is_left[env_ids],
            self._stair_wheel_axis_reference_z[env_ids, 0],
            self._stair_wheel_axis_reference_z[env_ids, 1],
        )
