"""Synthetic upper-level training scenarios for independent path/mode choice.

The generator is a fast proxy for the expensive Isaac/NeuPAN loop.  It keeps
the same independent action contract as ``navigation_formula`` while making
the three intended behaviors explicit: low-clearance traversal, ordinary
flat travel, and high-posture stair traversal.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np

from .navigation_formula import (
    ActionPrediction,
    DecisionContext,
    FormulaConfig,
    FormulaEvaluation,
    FormulaWeights,
    PathPrediction,
    PostureModel,
    PowerModel,
    enumerate_best,
    evaluate_candidates,
    encode_action,
)
from .navigation_formula_policy import candidate_features


PATH_CAPACITY = 3
SCENARIO_FAMILIES = ("low_tunnel", "flat", "stairs")


@dataclass(frozen=True)
class FormulaEpisode:
    family: str
    paths: tuple[PathPrediction, ...]
    predictions: tuple[ActionPrediction, ...]
    context: DecisionContext
    evaluations: tuple[FormulaEvaluation, ...]
    features: np.ndarray
    action_mask: np.ndarray
    oracle_action: int


def default_formula_config() -> FormulaConfig:
    """Return the frozen proxy contract used for this training run."""

    def power(idle: float, velocity: float, roughness: float) -> PowerModel:
        return PowerModel(
            idle_w=idle,
            velocity_w=velocity,
            acceleration_w=1.5,
            curvature_w=1.8,
            slope_w=5.0,
            roughness_w=roughness,
        )

    postures = (
        PostureModel(
            body_height_m=0.45,
            vmax_mps=0.40,
            braking_mps2=0.65,
            base_clearance_m=0.34,
            roll_max_rad=0.22,
            pitch_max_rad=0.22,
            power=power(10.0, 2.6, 7.0),
        ),
        PostureModel(
            body_height_m=0.58,
            vmax_mps=0.60,
            braking_mps2=0.65,
            base_clearance_m=0.34,
            roll_max_rad=0.32,
            pitch_max_rad=0.32,
            power=power(8.5, 2.1, 5.0),
        ),
        PostureModel(
            body_height_m=0.70,
            vmax_mps=0.45,
            braking_mps2=0.65,
            base_clearance_m=0.36,
            roll_max_rad=0.58,
            pitch_max_rad=0.58,
            power=power(9.2, 2.3, 2.4),
        ),
    )
    return FormulaConfig(
        postures=postures,
        energy_ref_j=240.0,
        time_ref_s=8.0,
        length_ref_m=11.0,
        distance_ref_m=0.20,
        height_ref_m=0.10,
        roll_ref_rad=0.10,
        pitch_ref_rad=0.10,
        clearance_sigma_m=0.20,
        dt_s=0.25,
        reaction_time_s=0.15,
        distance_margin_m=0.03,
        height_margin_m=0.03,
        goal_tolerance_m=0.15,
        switch_speed_max_mps=0.20,
        switch_roll_max_rad=0.12,
        switch_pitch_max_rad=0.12,
        switch_times_s=(
            (0.0, 0.45, 0.75),
            (0.45, 0.0, 0.55),
            (0.75, 0.55, 0.0),
        ),
        weights=FormulaWeights(energy=0.25, time=0.30, length=0.15, clearance=0.25, switch=0.05),
        penalty_clearance=3.0,
        penalty_height=4.0,
        penalty_attitude=3.0,
        calibration={},
    )


def _polyline(
    *,
    y_waypoints: Iterable[float],
    elevation: Iterable[float],
    ceiling: Iterable[float],
    curvature: Iterable[float],
    terrain_roll: Iterable[float],
    roughness: Iterable[float],
    path_id: str,
) -> PathPrediction:
    y = np.asarray(tuple(y_waypoints), dtype=np.float64)
    z = np.asarray(tuple(elevation), dtype=np.float64)
    ceiling_values = np.asarray(tuple(ceiling), dtype=np.float64)
    curvature_values = np.asarray(tuple(curvature), dtype=np.float64)
    roll_values = np.asarray(tuple(terrain_roll), dtype=np.float64)
    roughness_values = np.asarray(tuple(roughness), dtype=np.float64)
    if len(y) < 2 or len(z) != len(y) or len(ceiling_values) != len(y):
        raise ValueError("proxy paths require aligned point features")
    if any(len(values) != len(y) - 1 for values in (curvature_values, roll_values, roughness_values)):
        raise ValueError("proxy paths require one feature per segment")
    x = np.linspace(0.0, 8.0, len(y))
    return PathPrediction(
        path_id=path_id,
        points_xy_m=np.column_stack((x, y)),
        elevation_m=z,
        ceiling_height_m=ceiling_values,
        curvature_per_m=curvature_values,
        terrain_roll_rad=roll_values,
        roughness_rms_m=roughness_values,
        path_version=1,
        goal_version=1,
    )


def _path_set(family: str, generator: np.random.Generator) -> tuple[PathPrediction, ...]:
    """Create three spatial candidates with one family-specific advantage."""

    jitter = generator.normal(0.0, 0.035, size=3)
    open_ceiling = np.full(9, 1.60)
    flat_curvature = np.full(8, 0.015)
    flat_roll = np.zeros(8)
    flat_roughness = np.full(8, 0.004)

    def longer(values: Iterable[float], count: int = 13) -> np.ndarray:
        values_array = np.asarray(tuple(values), dtype=np.float64)
        return np.interp(
            np.linspace(0.0, len(values_array) - 1, count),
            np.arange(len(values_array)),
            values_array,
        )

    def longer_segments(value: float, count: int = 12) -> np.ndarray:
        return np.full(count, value, dtype=np.float64)

    if family == "low_tunnel":
        return (
            _polyline(
                y_waypoints=0.04 * np.sin(np.linspace(0.0, 2.0 * np.pi, 9)) + jitter[0],
                elevation=np.zeros(9),
                ceiling=np.full(9, 0.54),
                curvature=flat_curvature,
                terrain_roll=flat_roll,
                roughness=flat_roughness,
                path_id="low_tunnel_direct",
            ),
            _polyline(
                y_waypoints=longer(np.asarray((0.0, 3.0, 5.5, 6.5, 6.5, 5.5, 3.0, 1.0, 0.0)) + jitter[1]),
                elevation=longer(np.zeros(9)),
                ceiling=longer(open_ceiling),
                curvature=longer_segments(0.035),
                terrain_roll=longer_segments(0.0),
                roughness=longer_segments(0.008),
                path_id="mid_detour",
            ),
            _polyline(
                y_waypoints=longer(np.asarray((0.0, -2.8, -5.0, -6.0, -6.0, -5.0, -2.8, -0.9, 0.0)) + jitter[2]),
                elevation=longer(np.zeros(9)),
                ceiling=longer(open_ceiling),
                curvature=longer_segments(0.045),
                terrain_roll=longer_segments(0.0),
                roughness=longer_segments(0.012),
                path_id="high_detour",
            ),
        )
    if family == "stairs":
        stair_height = np.asarray((0.0, 0.46, 0.46, 0.92, 0.92, 0.46, 0.46, 0.0, 0.0))
        return (
            _polyline(
                y_waypoints=longer(np.asarray((0.0, 1.8, 3.1, 3.6, 3.6, 3.1, 1.8, 0.6, 0.0)) + jitter[0]),
                elevation=longer(stair_height),
                ceiling=longer(open_ceiling),
                curvature=longer_segments(0.04),
                terrain_roll=longer_segments(0.0),
                roughness=longer_segments(0.010),
                path_id="flat_detour",
            ),
            _polyline(
                y_waypoints=longer(np.asarray((0.0, -1.6, -2.8, -3.4, -3.4, -2.8, -1.6, -0.5, 0.0)) + jitter[1]),
                elevation=longer(stair_height),
                ceiling=longer(open_ceiling),
                curvature=longer_segments(0.05),
                terrain_roll=longer_segments(0.0),
                roughness=longer_segments(0.014),
                path_id="rough_detour",
            ),
            _polyline(
                y_waypoints=0.05 * np.sin(np.linspace(0.0, 2.0 * np.pi, 9)) + jitter[2],
                elevation=stair_height,
                ceiling=open_ceiling,
                curvature=np.full(8, 0.025),
                terrain_roll=np.full(8, 0.035),
                roughness=np.full(8, 0.030),
                path_id="high_stairs",
            ),
        )
    if family == "flat":
        return (
            _polyline(
                y_waypoints=np.asarray((0.0, 0.65, 1.1, 1.3, 1.3, 1.1, 0.65, 0.25, 0.0)) + jitter[0],
                elevation=np.zeros(9),
                ceiling=open_ceiling,
                curvature=np.full(8, 0.035),
                terrain_roll=flat_roll,
                roughness=np.full(8, 0.008),
                path_id="flat_short",
            ),
            _polyline(
                y_waypoints=0.03 * np.sin(np.linspace(0.0, 2.0 * np.pi, 9)) + jitter[1],
                elevation=np.zeros(9),
                ceiling=open_ceiling,
                curvature=flat_curvature,
                terrain_roll=flat_roll,
                roughness=flat_roughness,
                path_id="flat_direct",
            ),
            _polyline(
                y_waypoints=np.asarray((0.0, -0.9, -1.55, -1.85, -1.85, -1.55, -0.9, -0.3, 0.0)) + jitter[2],
                elevation=np.zeros(9),
                ceiling=open_ceiling,
                curvature=np.full(8, 0.05),
                terrain_roll=flat_roll,
                roughness=np.full(8, 0.014),
                path_id="flat_long",
            ),
        )
    raise ValueError(f"unknown scenario family {family!r}")


def _predictions(
    paths: tuple[PathPrediction, ...],
    config: FormulaConfig,
    generator: np.random.Generator,
) -> tuple[ActionPrediction, ...]:
    predictions: list[ActionPrediction] = []
    for path_index, path in enumerate(paths):
        segments = len(path.segment_lengths_m)
        point_clearance = np.full(len(path.points_xy_m), 1.60, dtype=np.float64)
        if path.path_id == "low_tunnel_direct":
            point_clearance[:] = generator.uniform(0.60, 0.68, size=len(point_clearance))
        elif path.path_id == "high_stairs":
            point_clearance[2:-2] = generator.uniform(0.58, 0.94, size=len(point_clearance) - 4)
        else:
            obstacle_count = int(generator.integers(1, 4))
            obstacle_points = generator.choice(
                np.arange(1, len(point_clearance) - 1), size=obstacle_count, replace=False
            )
            point_clearance[obstacle_points] = generator.uniform(0.48, 1.05, size=obstacle_count)
        for posture_index, posture in enumerate(config.postures):
            for speed_index, ratio in enumerate((0.4, 0.7, 1.0)):
                action_id = encode_action(path_index, posture_index, speed_index, len(paths))
                target_speed = ratio * posture.vmax_mps
                repeats = np.maximum(
                    1,
                    np.ceil(path.segment_lengths_m / max(target_speed * config.dt_s, 1e-6)).astype(np.int64),
                )
                segment_indices = np.repeat(np.arange(segments, dtype=np.int64), repeats)
                speed = np.full(len(segment_indices), target_speed)
                point_speed = np.full(len(path.points_xy_m), target_speed)
                prediction = ActionPrediction(
                    action_id=action_id,
                    speed_mps=speed,
                    acceleration_mps2=np.zeros(len(segment_indices)),
                    segment_indices=segment_indices,
                    point_speed_mps=point_speed,
                    point_clearance_m=point_clearance,
                    roll_error_rad=np.full(len(segment_indices), 0.012),
                    pitch_error_rad=np.full(len(segment_indices), 0.012),
                )
                predictions.append(prediction)
    return tuple(predictions)


def sample_formula_episode(
    generator: np.random.Generator,
    config: FormulaConfig | None = None,
    *,
    family: str | None = None,
    path_capacity: int = PATH_CAPACITY,
) -> FormulaEpisode:
    config = config or default_formula_config()
    selected_family = family or SCENARIO_FAMILIES[int(generator.integers(0, len(SCENARIO_FAMILIES)))]
    paths = _path_set(selected_family, generator)
    if len(paths) > path_capacity:
        raise ValueError("path capacity is smaller than the generated candidate set")
    context = DecisionContext(
        goal_xy_m=(8.0, 0.0),
        current_posture=1,
        speed_mps=0.0,
        roll_rad=0.0,
        pitch_rad=0.0,
        goal_version=1,
        path_version=1,
    )
    predictions = _predictions(paths, config, generator)
    evaluations = evaluate_candidates(paths, predictions, context, config, require_calibration=False)
    features, action_mask = candidate_features(evaluations, config, path_capacity)
    oracle = enumerate_best(evaluations)
    if oracle is None:
        raise RuntimeError(f"generated scenario {selected_family!r} has no feasible action")
    return FormulaEpisode(
        family=selected_family,
        paths=paths,
        predictions=predictions,
        context=context,
        evaluations=evaluations,
        features=features,
        action_mask=action_mask,
        oracle_action=oracle.action_id,
    )


def sample_formula_batch(
    generator: np.random.Generator,
    count: int,
    config: FormulaConfig | None = None,
    *,
    split: str = "train",
    path_capacity: int = PATH_CAPACITY,
) -> list[FormulaEpisode]:
    if count <= 0:
        raise ValueError("batch count must be positive")
    config = config or default_formula_config()
    episodes: list[FormulaEpisode] = []
    for index in range(count):
        if split in ("train", "validation", "test"):
            family = SCENARIO_FAMILIES[index % len(SCENARIO_FAMILIES)] if split != "train" else None
        else:
            raise ValueError("split must be train, validation, or test")
        episodes.append(
            sample_formula_episode(
                generator,
                config,
                family=family,
                path_capacity=path_capacity,
            )
        )
    return episodes
