import math

import torch


class TrainingContactContract:
    def __init__(self, count, device, contact_processing_enabled, stationary_reward_active,
                 observation_window_s=20.):
        if count < 1 or not math.isfinite(observation_window_s) or observation_window_s <= 0.:
            raise ValueError('contact contract requires a positive count and finite observation window')
        if stationary_reward_active and not contact_processing_enabled:
            raise ValueError('stationary reward requires enabled physical contact processing')
        self.active = bool(stationary_reward_active)
        self.observation_window_s = observation_window_s
        self.seen = torch.zeros(count, 2, device=device, dtype=torch.bool)
        self.elapsed_s = 0.
        self.completed_windows = 0

    def observe(self, contacts, dt_s):
        if contacts.shape != self.seen.shape or contacts.dtype != torch.bool:
            raise ValueError('contact contract requires aligned boolean wheel feedback')
        if not math.isfinite(dt_s) or dt_s <= 0.:
            raise ValueError('contact contract requires positive finite physics time')
        if not self.active:
            return
        self.seen |= contacts
        self.elapsed_s += dt_s
        if self.elapsed_s < self.observation_window_s - 1e-8:
            return
        missing = torch.nonzero(~self.seen, as_tuple=False).tolist()
        if missing:
            raise RuntimeError(f'physical wheel contact feedback absent over {self.elapsed_s:.3f}s: {missing}')
        self.completed_windows += 1
        self.elapsed_s = 0.
        self.seen.zero_()

    def metadata(self):
        return {'active': self.active, 'observation_window_s': self.observation_window_s,
                'completed_windows': self.completed_windows,
                'current_window_elapsed_s': self.elapsed_s,
                'current_window_seen_per_wheel': self.seen.tolist()}
