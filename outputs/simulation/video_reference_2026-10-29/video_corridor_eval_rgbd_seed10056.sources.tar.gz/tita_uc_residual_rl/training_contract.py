"""Simulation-only upper-action windows and explicit episode handshakes."""

from __future__ import annotations

import math


def boundary_attitude_exceeded(quaternion_wxyz, limit_rad: float) -> bool:
    if not math.isfinite(limit_rad) or not 0.0 < limit_rad < math.pi / 2:
        raise ValueError("boundary attitude limit must be in (0, pi/2)")
    if len(quaternion_wxyz) != 4 or not all(math.isfinite(value) for value in quaternion_wxyz):
        raise ValueError("boundary attitude requires a finite quaternion")
    quat_w, quat_x, quat_y, quat_z = quaternion_wxyz
    roll = math.atan2(2.0 * (quat_w * quat_x + quat_y * quat_z),
                      1.0 - 2.0 * (quat_x * quat_x + quat_y * quat_y))
    pitch = math.asin(max(-1.0, min(1.0, 2.0 * (quat_w * quat_y - quat_z * quat_x))))
    return abs(roll) >= limit_rad or abs(pitch) >= limit_rad


class TrainingActionWindow:
    def __init__(self, steps_per_action: int = 25) -> None:
        if steps_per_action < 1:
            raise ValueError("steps_per_action must be positive")
        self.steps_per_action = int(steps_per_action)
        self.episode_id = 0
        self.sequence = 0
        self.decision_id = 0
        self.policy_version = 0
        self.action_id = -1
        self.start_sequence = 0
        self.steps = 0
        self.energy_j = 0.0
        self.distance_m = 0.0
        self.elapsed_s = 0.0
        self.terminated = False
        self.truncated = False
        self.success = False
        self.hard_reasons: list[bool] = []
        self.ready = True
        self.reset_requested = False
        self.complete = False
        self.rejected_commands = 0
        self.nonzero_command_steps = 0
        self.desired_velocity_sum = [0.0, 0.0, 0.0]
        self.measured_velocity_sum = [0.0, 0.0, 0.0]

    def accept(self, metadata: dict, action_id: int) -> bool:
        if not isinstance(metadata, dict):
            self.rejected_commands += 1
            return False
        try:
            decision_id = int(metadata["decision_id"])
            episode_id = int(metadata["episode_id"])
            start_sequence = int(metadata["start_sequence"])
            policy_version = int(metadata["policy_version"])
            kind = metadata.get("kind", "action")
            matching_boundary = (
                episode_id == self.episode_id and start_sequence == self.sequence
            )
            if kind in ("reset", "complete"):
                if not (self.ready and matching_boundary
                        and decision_id == self.decision_id):
                    raise ValueError("control does not acknowledge the current boundary")
                if kind == "reset":
                    if not (self.terminated or self.truncated):
                        raise ValueError("reset requires a completed episode")
                    self.reset_requested = True
                else:
                    self.complete = True
                return False
            if kind != "action" or action_id not in range(9) or self.complete:
                raise ValueError("invalid training action")
            if not self.ready:
                if (decision_id == self.decision_id and episode_id == self.episode_id
                        and start_sequence == self.start_sequence
                        and policy_version == self.policy_version
                        and action_id == self.action_id):
                    return True
                raise ValueError("cannot change an executing action")
            if (not matching_boundary or decision_id <= self.decision_id
                    or policy_version < self.policy_version
                    or self.terminated or self.truncated):
                raise ValueError("action does not follow the acknowledged boundary")
            self.decision_id = decision_id
            self.policy_version = policy_version
            self.action_id = int(action_id)
            self.start_sequence = self.sequence
            self.steps = 0
            self.energy_j = self.distance_m = self.elapsed_s = 0.0
            self.terminated = self.truncated = self.success = False
            self.hard_reasons = []
            self.ready = False
            self.nonzero_command_steps = 0
            self.desired_velocity_sum = [0.0, 0.0, 0.0]
            self.measured_velocity_sum = [0.0, 0.0, 0.0]
            return True
        except (KeyError, TypeError, ValueError, OverflowError):
            self.rejected_commands += 1
            return False

    def record(self, *, energy_j: float, distance_m: float, elapsed_s: float,
               terminated: bool, truncated: bool, success: bool,
               hard_reasons: list[bool], desired_velocity=None,
               measured_velocity=None) -> None:
        if self.ready or self.complete:
            raise RuntimeError("physics advanced without an acknowledged upper action")
        increments = (energy_j, distance_m, elapsed_s)
        if not all(math.isfinite(value) and value >= 0.0 for value in increments):
            raise ValueError("training increments must be finite and non-negative")
        if self.hard_reasons and len(hard_reasons) != len(self.hard_reasons):
            raise ValueError("hard-reason schema changed within an action")
        if desired_velocity is not None and measured_velocity is not None:
            if (len(desired_velocity) != 3 or len(measured_velocity) != 3
                    or not all(math.isfinite(value) for value in
                               (*desired_velocity, *measured_velocity))):
                raise ValueError("execution velocities must be finite three-vectors")
        self.sequence += 1
        self.steps += 1
        self.energy_j += energy_j
        self.distance_m += distance_m
        self.elapsed_s += elapsed_s
        if desired_velocity is not None and measured_velocity is not None:
            self.nonzero_command_steps += int(any(abs(value) > 1e-6 for value in desired_velocity))
            self.desired_velocity_sum = [old + value for old, value in
                                         zip(self.desired_velocity_sum, desired_velocity)]
            self.measured_velocity_sum = [old + value for old, value in
                                          zip(self.measured_velocity_sum, measured_velocity)]
        self.success = bool(success)
        self.terminated = bool(terminated or success)
        self.truncated = bool(truncated and not self.terminated)
        if not self.hard_reasons:
            self.hard_reasons = [False] * len(hard_reasons)
        self.hard_reasons = [old or bool(new) for old, new in
                             zip(self.hard_reasons, hard_reasons)]
        self.ready = (self.steps >= self.steps_per_action
                      or self.terminated or self.truncated)

    def finish_reset(self) -> None:
        if not self.reset_requested:
            raise RuntimeError("episode reset was not acknowledged")
        self.episode_id += 1
        self.reset_requested = False
        self.start_sequence = self.sequence
        self.action_id = -1
        self.steps = 0
        self.energy_j = self.distance_m = self.elapsed_s = 0.0
        self.terminated = self.truncated = self.success = False
        self.hard_reasons = []
        self.ready = True
        self.nonzero_command_steps = 0
        self.desired_velocity_sum = [0.0, 0.0, 0.0]
        self.measured_velocity_sum = [0.0, 0.0, 0.0]

    def payload(self) -> dict:
        return {
            "decision_id": self.decision_id,
            "episode_id": self.episode_id,
            "policy_version": self.policy_version,
            "action_id": self.action_id,
            "start_sequence": self.start_sequence,
            "end_sequence": self.sequence,
            "steps": self.steps,
            "energy_j": self.energy_j,
            "distance_m": self.distance_m,
            "elapsed_s": self.elapsed_s,
            "terminated": self.terminated,
            "truncated": self.truncated,
            "success": self.success,
            "hard_reasons": list(self.hard_reasons),
            "ready": self.ready,
            "complete": self.complete,
            "rejected_commands": self.rejected_commands,
            "execution": {
                "nonzero_command_steps": self.nonzero_command_steps,
                "desired_velocity_mean": [value / max(1, self.steps)
                                          for value in self.desired_velocity_sum],
                "measured_velocity_mean": [value / max(1, self.steps)
                                           for value in self.measured_velocity_sum],
            },
        }
