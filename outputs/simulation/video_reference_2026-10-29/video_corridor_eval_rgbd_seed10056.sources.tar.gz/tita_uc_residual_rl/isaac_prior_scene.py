from __future__ import annotations

import numpy as np

from .joint_navigation import GridScene
from .start_recovery import ContinuousRecoveryGeometry


def calibrated_prior_scene(environment, start_xy, goal_xy, geometry_report, resolution_m=.05,
                           planner_vertices_xy_m=None, minimum_obstacle_clearance_m=.05):
    minimum = np.minimum(start_xy, goal_xy) - np.array([1.0, 2.5]) - resolution_m / 2.
    maximum = np.maximum(start_xy, goal_xy) + np.array([2.0, 2.5])
    maze = None
    if getattr(environment.cfg, "navigation_scene_file", ""):
        from .navigation_maze import load_maze
        maze = load_maze(environment.cfg.navigation_scene_file)
        origin_xy = environment._environment_origins()[0, :2].cpu().numpy()
        bounds = maze["bounds_xy_m"]
        minimum = np.minimum(minimum, origin_xy + np.array([bounds[0], bounds[2]]) - resolution_m / 2.)
        maximum = np.maximum(maximum, origin_xy + np.array([bounds[1], bounds[3]]))
    width, height = np.ceil((maximum - minimum) / resolution_m).astype(int)
    horizontal, vertical = np.meshgrid(minimum[0] + (np.arange(width) + .5) * resolution_m,
                                      minimum[1] + (np.arange(height) + .5) * resolution_m)
    occupancy = np.zeros((height, width), dtype=bool)
    ceiling = np.full((height, width), 3.)
    steps = np.zeros((height, width))
    footprint = np.vstack([profile["footprint_vertices_xy_m"] for profile in geometry_report["profiles"].values()])
    if planner_vertices_xy_m is not None:
        footprint = np.vstack((footprint, np.asarray(planner_vertices_xy_m)))
    if not np.isfinite(minimum_obstacle_clearance_m) or minimum_obstacle_clearance_m < 0.:
        raise ValueError("planner obstacle clearance must be finite and non-negative")
    extent = np.abs(footprint).max(0) + minimum_obstacle_clearance_m + resolution_m / 2.
    origin = environment._environment_origins()[0].cpu().numpy()
    cfg = environment.cfg
    if maze is not None:
        turning_extent = np.full(2, np.linalg.norm(footprint, axis=1).max() + minimum_obstacle_clearance_m + resolution_m / 2.)
        occupancy, ceiling = authored_box_layers(horizontal, vertical, maze["boxes"], origin[:2], turning_extent, maze["floor_height_m"])
    if cfg.tunnel_enabled:
        tunnel_height, tunnel_width, tunnel_length = environment.tunnel_dimensions[0].cpu().tolist()
        start = origin[0] + cfg.tunnel_start_x_m
        within_length = (horizontal >= start - extent[0]) & (horizontal <= start + tunnel_length + extent[0])
        ceiling[within_length & (np.abs(vertical - origin[1]) <= tunnel_width / 2. + extent[1])] = tunnel_height
        for side in (-1, 1):
            center = origin[1] + side * (tunnel_width + cfg.tunnel_wall_thickness_m) / 2.
            occupancy |= within_length & (np.abs(vertical - center) <= cfg.tunnel_wall_thickness_m / 2. + extent[1])
    if cfg.stair_enabled:
        step_height, tread, stair_width = environment.stair_dimensions[0].cpu().tolist()
        start = origin[0] + cfg.stair_start_x_m
        stair_end = start + cfg.stair_num_steps * tread + cfg.stair_landing_length_m
        if getattr(cfg, "stair_training_corridor_enabled", False):
            for side in (-1., 1.):
                center = origin[1] + side * (stair_width + .10) / 2.
                occupancy |= ((horizontal >= origin[0] - extent[0]) & (horizontal <= stair_end + extent[0])
                              & (np.abs(vertical - center) <= .05 + extent[1]))
        support_levels = np.floor((horizontal - start) / tread) + 1.
        support_levels = support_levels.clip(0., cfg.stair_num_steps)
        supported = ((horizontal >= start) & (horizontal <= stair_end)
                     & (np.abs(vertical - origin[1]) <= stair_width / 2.))
        ceiling[supported] -= support_levels[supported] * step_height
        for level in range(cfg.stair_num_steps):
            edge = start + level * tread
            cells = (np.abs(horizontal - edge) <= extent[0] + resolution_m) & (np.abs(vertical - origin[1]) <= stair_width / 2. + extent[1])
            steps[cells] = step_height
    recovery_geometry = None
    if maze is not None and not cfg.tunnel_enabled and not getattr(cfg, 'stair_training_corridor_enabled', False):
        rectangles = tuple((box['center'][0] + origin[0] - box['size'][0] / 2.,
                            box['center'][1] + origin[1] - box['size'][1] / 2.,
                            box['center'][0] + origin[0] + box['size'][0] / 2.,
                            box['center'][1] + origin[1] + box['size'][1] / 2.)
                           for box in maze['boxes'] if box['kind'] == 'wall')
        if rectangles:
            recovery_geometry = ContinuousRecoveryGeometry(rectangles,
                float(np.linalg.norm(footprint, axis=1).max() + minimum_obstacle_clearance_m), resolution_m / 2.)
    return GridScene(occupancy, ceiling, steps, resolution_m, tuple(minimum), recovery_geometry)


def authored_box_layers(horizontal, vertical, boxes, origin_xy, footprint_extent_xy_m, floor_height_m=0.):
    horizontal, vertical = np.asarray(horizontal), np.asarray(vertical)
    extent = np.asarray(footprint_extent_xy_m, dtype=float)
    origin = np.asarray(origin_xy, dtype=float)
    if (horizontal.ndim != 2 or horizontal.shape != vertical.shape or extent.shape != (2,) or origin.shape != (2,)
            or not np.isfinite([*extent, *origin, floor_height_m]).all() or (extent < 0.).any()):
        raise ValueError("authored map requires aligned planar grids and finite positive inflation")
    occupancy = np.zeros(horizontal.shape, dtype=bool)
    ceiling = np.full(horizontal.shape, 3.)
    for box in boxes:
        center = np.asarray(box["center"], dtype=float)
        size = np.asarray(box["size"], dtype=float)
        if center.shape != (3,) or size.shape != (3,) or not np.isfinite([center, size]).all() or (size <= 0.).any():
            raise ValueError("authored map boxes must have finite positive geometry")
        inside = ((np.abs(horizontal - origin[0] - center[0]) <= size[0] / 2. + extent[0])
                  & (np.abs(vertical - origin[1] - center[1]) <= size[1] / 2. + extent[1]))
        if box["kind"] == "wall":
            occupancy |= inside
        elif box["kind"] == "roof":
            ceiling[inside] = np.minimum(ceiling[inside], center[2] - size[2] / 2. - floor_height_m)
        else:
            raise ValueError("unsupported authored box kind")
    return occupancy, ceiling


def release_verified_riser_inflation(scene, traversal_settled, riser_edge_x_m, wheel_clearance_m, inflation_extent_m):
    if not traversal_settled:
        return scene
    if (not np.isfinite([riser_edge_x_m, wheel_clearance_m, inflation_extent_m]).all()
            or wheel_clearance_m <= 0. or inflation_extent_m < wheel_clearance_m):
        raise ValueError("verified riser release requires finite wheel clearance")
    horizontal = scene.origin_xy[0] + (np.arange(scene.shape[1]) + .5) * scene.resolution_m
    ahead = ((horizontal > riser_edge_x_m + wheel_clearance_m)
             & (horizontal <= riser_edge_x_m + inflation_extent_m))
    steps = scene.step_height_m.copy()
    steps[:, ahead] = 0.
    return GridScene(scene.occupancy, scene.ceiling_height_m, steps, scene.resolution_m, scene.origin_xy, scene.recovery_geometry)


def fuse_observed_ceiling(scene, scan, ground_z_m, footprint_extent_xy_m, pedestrians=()):
    if scan.normals_world is None:
        return scene, 0
    ceiling = scene.ceiling_height_m.copy()
    count = 0
    extent = np.asarray(footprint_extent_xy_m)
    for point, normal in zip(scan.points_world_m, scan.normals_world):
        if normal[2] >= -.98 or point[2] - ground_z_m < .20:
            continue
        if any(np.linalg.norm(point[:2] - [person.x, person.y]) < person.radius_m + .15 for person in pedestrians):
            continue
        lower = scene.world_to_cell(point[:2] - extent)
        upper = scene.world_to_cell(point[:2] + extent)
        for horizontal in range(max(0, lower[0]), min(scene.shape[1], upper[0] + 1)):
            for vertical in range(max(0, lower[1]), min(scene.shape[0], upper[1] + 1)):
                ceiling[vertical, horizontal] = min(ceiling[vertical, horizontal], point[2] - ground_z_m)
        count += 1
    if count:
        return GridScene(scene.occupancy, ceiling, scene.step_height_m, scene.resolution_m, scene.origin_xy, scene.recovery_geometry), count
    return scene, 0
