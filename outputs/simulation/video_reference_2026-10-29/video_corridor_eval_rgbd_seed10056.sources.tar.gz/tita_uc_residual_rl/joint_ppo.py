from __future__ import annotations

from dataclasses import dataclass
import math
from pathlib import Path

import numpy as np
import torch
from torch import nn

from .joint_navigation import JointDecision, JointObservation, POSTURES, SPEEDS
from .navigation_formula import decode_action
from .mode_sequence_cost import mode_sequence_times
from .grid_path_geometry import polyline_cells
from .mode_transition_calibration import transition_cost_matrix
from .path_tracking_feedback import signed_path_tracking_error
from .route_continuity import route_change_distance


LEGACY_FEATURE_COUNT = 24
HISTORY_FEATURE_COUNT = 32
HISTORY_FEATURE_CONTRACT = 'tita.joint_action_features.v2_observed_motion_history32'
FEATURE_COUNT = 36
FEATURE_CONTRACT = 'tita.joint_action_features.v3_observed_route_execution36'
MAX_ACTIONS = 28
LEGACY_WAIT_ACTION_CONTRACT = 'tita.risk_priced_wait.v1'
WAIT_ACTION_CONTRACT = 'tita.risk_priced_wait.v2_periodic_risk'
TEMPERATURE_POLICY_SCHEMA = 'tita.joint_masked_ppo.v2_temperature'
TEMPERATURE_POLICY_CONTRACT = 'tita.joint_policy_temperature.v1'


def joint_action_features(scene, paths, posture_specs, current_posture, measured_speed, pedestrian_risk, path_risks=None, transition_costs_s=None,
                          pedestrians=(), pedestrian_motion_context=(), pose=None, previous_path=None):
    transitions = transition_cost_matrix(transition_costs_s)
    features = np.zeros((MAX_ACTIONS, FEATURE_COUNT), dtype=np.float32)
    if pedestrian_motion_context and len(pedestrian_motion_context) != len(pedestrians):
        raise ValueError('pedestrian history must align with the current observed tracks')
    for path_index, path in enumerate(paths[:3]):
        route_features = np.zeros(4, dtype=np.float32)
        if pose is not None:
            route_distance = route_change_distance(previous_path, path, (pose.x, pose.y))
            _, heading_error = signed_path_tracking_error(path.points_xy_m, (pose.x, pose.y), pose.yaw,
                                                          heading_lookahead_m=.25)
            route_features[:] = (min(route_distance / 3., 2.), float(route_distance > .35),
                                 abs(heading_error) / np.pi, abs(heading_error) / .2 / 60.)
        geometry_samples = polyline_cells(scene, path.points_xy_m) if path.continuous_geometry else None
        cells = geometry_samples[0] if geometry_samples is not None else [scene.world_to_cell(point) for point in path.points_xy_m]
        cells = [cell for cell in cells if scene.in_bounds(cell)]
        ceiling = min((scene.ceiling_height_m[y, x] for x, y in cells), default=0.)
        step = max((scene.step_height_m[y, x] for x, y in cells), default=0.)
        delta = np.diff(path.points_xy_m, axis=0)
        headings = np.arctan2(delta[:, 1], delta[:, 0])
        curvature = np.abs(np.arctan2(np.sin(np.diff(headings)), np.cos(np.diff(headings)))).sum()
        context_features = np.zeros(8, dtype=np.float32)
        nearest = None
        if pedestrians:
            start = path.points_xy_m[0]
            nearest_index = min(range(len(pedestrians)), key=lambda index:
                np.hypot(pedestrians[index].x - start[0], pedestrians[index].y - start[1]))
            nearest = pedestrians[nearest_index]
            nonzero_segments = np.flatnonzero(np.linalg.norm(delta, axis=1) > 1e-9)
            tangent = delta[nonzero_segments[0]] if len(nonzero_segments) else np.array([1., 0.])
            tangent = tangent / max(float(np.linalg.norm(tangent)), 1e-9)
            normal = np.array([-tangent[1], tangent[0]])
            context_features[:3] = (min(np.hypot(nearest.x - start[0], nearest.y - start[1]) / 5., 2.),
                                    np.clip(np.dot([nearest.vx, nearest.vy], tangent), -2., 2.),
                                    np.clip(np.dot([nearest.vx, nearest.vy], normal), -2., 2.))
            if pedestrian_motion_context:
                context = pedestrian_motion_context[nearest_index]
                context_features[4:] = (min(context.stationary_duration_s / 20., 2.),
                    min(context.moving_duration_s / 20., 2.),
                    np.clip(np.dot([context.last_motion_vx, context.last_motion_vy], normal), -2., 2.),
                    min(context.observed_duration_s / 60., 2.))
        sequence_times = [mode_sequence_times(scene, path, posture_specs, ratio, geometry_samples=geometry_samples,
                                              transition_costs_s=transitions) for ratio in SPEEDS]
        for mode, specification in enumerate(posture_specs):
            for speed_index, ratio in enumerate(SPEEDS):
                speed = specification.vmax_mps * ratio
                action = path_index * 9 + mode * 3 + speed_index
                row = features[action]
                risk = pedestrian_risk if path_risks is None else path_risks[path_index]
                if np.ndim(risk):
                    risk = risk[mode * 3 + speed_index]
                expected_time = sequence_times[speed_index][mode] + transitions[current_posture, mode]
                row[:12] = (1., path.length_m / 10., np.clip(expected_time / 60., 0., 5.),
                            np.clip(ceiling - specification.body_height_m - .04, -1., 1.),
                            np.clip(specification.max_step_m - step, -1., 1.),
                            curvature / 10., speed, measured_speed, risk,
                            float(mode != current_posture), specification.body_height_m, step)
                row[12 + mode] = 1.
                row[15 + speed_index] = 1.
                row[18 + current_posture] = 1.
                row[21] = float(mode != 1)
                row[22] = specification.base_clearance_m
                row[24:32] = context_features
                row[32:] = route_features
                if nearest is not None:
                    row[27] = min(2. * (.5 + nearest.radius_m) / max(speed, 1e-6) / 30., 3.)
    features[-1, 23] = 1.
    features[-1, 7:9] = (measured_speed, pedestrian_risk)
    if paths:
        features[-1, 24:32] = features[0, 24:32]
        features[-1, 27] = 0.
    return features


class JointActorCritic(nn.Module):
    def __init__(self, cost_prior=False, wait_cost_step_s=None, risk_cost_per_decision=False, policy_temperature=1.):
        super().__init__()
        self.cost_prior = cost_prior
        if not math.isfinite(policy_temperature) or policy_temperature <= 0.:
            raise ValueError('joint policy temperature must be positive and finite')
        self.policy_temperature = float(policy_temperature)
        if wait_cost_step_s is not None and (not math.isfinite(wait_cost_step_s) or wait_cost_step_s <= 0.):
            raise ValueError('wait decision interval must be positive and finite')
        self.wait_cost_step_s = wait_cost_step_s
        if risk_cost_per_decision and wait_cost_step_s is None:
            raise ValueError('periodic action risk requires an explicit decision interval')
        self.risk_cost_per_decision = risk_cost_per_decision
        self.actor = nn.Sequential(nn.Linear(FEATURE_COUNT, 64), nn.Tanh(), nn.Linear(64, 64), nn.Tanh(), nn.Linear(64, 1))
        self.critic = nn.Sequential(nn.Linear(FEATURE_COUNT, 64), nn.Tanh(), nn.Linear(64, 1))

    def distribution(self, features, mask):
        logits = self.actor(features).squeeze(-1)
        if self.cost_prior:
            cost = 4.8 * features[..., 2] + 1.5 * features[..., 1] + .25 * features[..., 9]
            if features.shape[-1] == FEATURE_COUNT:
                cost = cost + 4.8 * features[..., 35] + .05 * features[..., 33]
            nominal_cost = cost
            if self.risk_cost_per_decision:
                cost = cost + .8 * features[..., 8] * self.wait_cost_step_s
            else:
                cost = cost + .8 * features[..., 8] * (1. + 3. * features[..., 6]) * features[..., 2] * 60.
            movement_cost = cost[..., :-1].masked_fill(~mask[..., :-1], 1e6).min(-1).values
            cost = cost.clone()
            if self.wait_cost_step_s is None:
                cost[..., -1] = movement_cost + 1.
            else:
                cost[..., -1] = nominal_cost[..., -1] + (.08 + .8 * features[..., -1, 8]) * self.wait_cost_step_s
            logits = logits - 3. * cost
        logits = (logits / self.policy_temperature).masked_fill(~mask, -1e9)
        distribution = torch.distributions.Categorical(logits=logits)
        weights = mask.to(features.dtype)
        pooled = (features * weights.unsqueeze(-1)).sum(-2) / weights.sum(-1, keepdim=True)
        return distribution, self.critic(pooled).squeeze(-1)


@dataclass
class JointTransition:
    features: np.ndarray
    mask: np.ndarray
    action: int
    old_log_prob: float
    old_value: float
    reward: float = 0.
    done: bool = False


class JointPPOPolicy:
    def __init__(self, seed=11, learning_rate=3e-4, training=False, cost_prior=False, wait_cost_step_s=None, risk_cost_per_decision=False, policy_temperature=1.):
        torch.manual_seed(seed)
        self.model = JointActorCritic(cost_prior=cost_prior, wait_cost_step_s=wait_cost_step_s,
                                     risk_cost_per_decision=risk_cost_per_decision, policy_temperature=policy_temperature)
        self.optimizer = torch.optim.Adam(self.model.parameters(), lr=learning_rate)
        self.training = training
        self.last_transition = None
        self.transitions = []
        self.updates = 0
        self.feature_migration = None

    def act(self, observation: JointObservation, epsilon=0.):
        if observation.action_features is None:
            raise ValueError("joint PPO requires geometry-conditioned action features")
        mask = np.zeros(MAX_ACTIONS, dtype=bool)
        mask[:len(observation.valid_actions) - 1] = observation.valid_actions[:-1]
        mask[-1] = bool(observation.valid_actions[-1]) if self.model.wait_cost_step_s is not None else True
        if not mask.any():
            raise ValueError('joint PPO requires at least one feasible action or explicit unavoidable-stop fallback')
        features = np.asarray(observation.action_features, dtype=np.float32)
        if features.shape in ((MAX_ACTIONS, LEGACY_FEATURE_COUNT), (MAX_ACTIONS, HISTORY_FEATURE_COUNT)):
            features = np.pad(features, ((0, 0), (0, FEATURE_COUNT - features.shape[1])))
        if features.shape != (MAX_ACTIONS, FEATURE_COUNT) or not np.isfinite(features).all():
            raise ValueError('joint PPO requires finite features matching the declared observation contract')
        with torch.no_grad():
            distribution, value = self.model.distribution(torch.from_numpy(features), torch.from_numpy(mask))
            action = distribution.sample() if self.training else distribution.logits.argmax()
        index = int(action)
        self.last_transition = JointTransition(features.copy(), mask, index, float(distribution.log_prob(action)), float(value))
        if index == MAX_ACTIONS - 1:
            return JointDecision(False, reason="ppo_safe_wait")
        path, mode, speed = decode_action(index, len(observation.paths))
        return JointDecision(True, index, path, mode, speed, observation.paths[path].path_id, POSTURES[mode], SPEEDS[speed], "masked_joint_ppo")

    def finish_transition(self, reward, done):
        if self.last_transition is None:
            raise RuntimeError("no pending upper policy transition")
        self.last_transition.reward = float(reward)
        self.last_transition.done = bool(done)
        self.transitions.append(self.last_transition)
        self.last_transition = None

    def use_analytic_baseline(self):
        if self.training or not self.model.cost_prior:
            raise ValueError("analytic baseline requires a frozen cost-prior policy")
        with torch.no_grad():
            for parameter in self.model.actor.parameters():
                parameter.zero_()

    def configure_risk_priced_wait(self, decision_interval_s):
        if not math.isfinite(decision_interval_s) or decision_interval_s <= 0.:
            raise ValueError('wait decision interval must be positive and finite')
        self.model.wait_cost_step_s = float(decision_interval_s)
        self.model.risk_cost_per_decision = True

    def update(self, bootstrap_value=0., epochs=4):
        if not self.transitions:
            return {}
        records = list(self.transitions)
        advantages = np.zeros(len(records), dtype=np.float32)
        following_value = float(bootstrap_value)
        following_advantage = 0.
        for index in reversed(range(len(records))):
            record = records[index]
            continuation = 0. if record.done else 1.
            delta = record.reward + .995 * continuation * following_value - record.old_value
            following_advantage = delta + .995 * .95 * continuation * following_advantage
            advantages[index] = following_advantage
            following_value = record.old_value
        returns = torch.tensor(advantages + np.asarray([record.old_value for record in records], dtype=np.float32))
        advantage = torch.tensor(advantages)
        advantage = (advantage - advantage.mean()) / advantage.std(unbiased=False).clamp_min(1e-6)
        features = torch.tensor(np.stack([record.features for record in records]))
        masks = torch.tensor(np.stack([record.mask for record in records]))
        actions = torch.tensor([record.action for record in records])
        old_log_prob = torch.tensor([record.old_log_prob for record in records])
        for _ in range(epochs):
            distribution, value = self.model.distribution(features, masks)
            ratio = (distribution.log_prob(actions) - old_log_prob).exp()
            actor_loss = -torch.minimum(ratio * advantage, ratio.clamp(.8, 1.2) * advantage).mean()
            value_loss = (value - returns).square().mean()
            entropy = distribution.entropy().mean()
            loss = actor_loss + .5 * value_loss - .02 * entropy
            self.optimizer.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(self.model.actor.parameters(), .5)
            nn.utils.clip_grad_norm_(self.model.critic.parameters(), .5)
            self.optimizer.step()
        self.transitions.clear()
        self.updates += 1
        return {"samples": len(records), "loss": float(loss), "actor_loss": float(actor_loss), "value_loss": float(value_loss), "entropy": float(entropy), "update": self.updates}

    def save(self, path, metadata=None):
        path = Path(path)
        temporary = path.with_name(path.name + ".tmp")
        torch.save({"schema": TEMPERATURE_POLICY_SCHEMA if self.model.policy_temperature != 1. else "tita.joint_masked_ppo.v1", "model": self.model.state_dict(),
                    "optimizer": self.optimizer.state_dict(), "updates": self.updates,
                    "features": FEATURE_COUNT, "max_actions": MAX_ACTIONS, "metadata": metadata or {},
                    "feature_contract": FEATURE_CONTRACT,
                    "feature_migration": self.feature_migration,
                    "cost_prior": self.model.cost_prior,
                    "wait_cost_step_s": self.model.wait_cost_step_s,
                    "risk_cost_per_decision": self.model.risk_cost_per_decision,
                    "policy_temperature": self.model.policy_temperature,
                    "policy_sampling_contract": TEMPERATURE_POLICY_CONTRACT if self.model.policy_temperature != 1. else None,
                    "wait_action_contract": (WAIT_ACTION_CONTRACT if self.model.risk_cost_per_decision else LEGACY_WAIT_ACTION_CONTRACT) if self.model.wait_cost_step_s is not None else None,
                    "torch_rng_state": torch.get_rng_state()}, temporary)
        temporary.replace(path)

    @classmethod
    def load(cls, path, training=False):
        payload = torch.load(path, map_location="cpu", weights_only=True)
        if payload["schema"] not in ("tita.joint_masked_ppo.v1", TEMPERATURE_POLICY_SCHEMA):
            raise ValueError("unsupported joint PPO schema")
        temperature = payload.get('policy_temperature', 1.)
        if payload['schema'] == TEMPERATURE_POLICY_SCHEMA:
            if 'policy_temperature' not in payload or payload.get('policy_sampling_contract') != TEMPERATURE_POLICY_CONTRACT:
                raise ValueError('joint PPO temperature sampling contract mismatch')
        elif temperature != 1. or payload.get('policy_sampling_contract') is not None:
            raise ValueError('nondefault temperature requires the explicit temperature policy schema')
        source_features = payload.get('features', LEGACY_FEATURE_COUNT)
        if source_features not in (LEGACY_FEATURE_COUNT, HISTORY_FEATURE_COUNT, FEATURE_COUNT):
            raise ValueError('unsupported joint PPO feature count')
        if source_features == HISTORY_FEATURE_COUNT and payload.get('feature_contract') != HISTORY_FEATURE_CONTRACT:
            raise ValueError('joint PPO motion-history feature contract mismatch')
        if source_features == FEATURE_COUNT and payload.get('feature_contract') != FEATURE_CONTRACT:
            raise ValueError('joint PPO motion-history feature contract mismatch')
        wait_step = payload.get('wait_cost_step_s')
        periodic_risk = payload.get('risk_cost_per_decision', False)
        expected_wait_contract = (WAIT_ACTION_CONTRACT if periodic_risk else LEGACY_WAIT_ACTION_CONTRACT) if wait_step is not None else None
        if payload.get('wait_action_contract') != expected_wait_contract:
            raise ValueError('joint PPO wait action contract mismatch')
        policy = cls(training=training, cost_prior=payload.get("cost_prior", False), wait_cost_step_s=wait_step,
                     risk_cost_per_decision=periodic_risk, policy_temperature=temperature)
        state = dict(payload['model'])
        if source_features < FEATURE_COUNT:
            for key in ('actor.0.weight', 'critic.0.weight'):
                original = state[key]
                if original.shape != (64, source_features):
                    raise ValueError('legacy joint PPO input weight shape mismatch')
                expanded = original.new_zeros((64, FEATURE_COUNT))
                expanded[:, :source_features] = original
                state[key] = expanded
        policy.model.load_state_dict(state)
        policy.feature_migration = ({'source_features': source_features, 'target_features': FEATURE_COUNT,
            'method': 'preserve_legacy_weights_and_moments_initialize_added_input_columns_to_zero',
            'new_motion_history_training_and_physics_acceptance_required': True,
            'new_route_execution_training_and_physics_acceptance_required': True} if source_features < FEATURE_COUNT
            else payload.get('feature_migration'))
        if training:
            policy.optimizer.load_state_dict(payload["optimizer"])
            if source_features < FEATURE_COUNT:
                for parameter, moments in policy.optimizer.state.items():
                    for key, value in tuple(moments.items()):
                        if isinstance(value, torch.Tensor) and value.shape == (64, source_features):
                            expanded = value.new_zeros(parameter.shape)
                            expanded[:, :source_features] = value
                            moments[key] = expanded
            if "torch_rng_state" in payload:
                torch.set_rng_state(payload["torch_rng_state"])
        policy.updates = payload["updates"]
        return policy
