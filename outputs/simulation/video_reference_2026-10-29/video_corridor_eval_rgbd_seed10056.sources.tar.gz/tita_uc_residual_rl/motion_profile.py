"""Simulation-only posture speed contracts and physics-clocked command shaping."""

from __future__ import annotations

from dataclasses import dataclass
import json
import math
from pathlib import Path


@dataclass(frozen=True)
class CommandShapingConfig:
    linear_acceleration_mps2: float = 0.35
    linear_deceleration_mps2: float = 0.65
    angular_acceleration_radps2: float = 0.8

    def __post_init__(self):
        values = (self.linear_acceleration_mps2, self.linear_deceleration_mps2,
                  self.angular_acceleration_radps2)
        if not all(math.isfinite(value) and value > 0.0 for value in values):
            raise ValueError("command shaping limits must be finite and positive")


class PhysicsCommandShaper:
    def __init__(self, config: CommandShapingConfig):
        self.config = config
        self.command = (0.0, 0.0, 0.0)

    def reset(self):
        self.command = (0.0, 0.0, 0.0)

    def step(self, target, dt_s, *, safety_override=False, linear_limit=None, angular_limit=None):
        if len(target) != 3 or not all(math.isfinite(float(value)) for value in target):
            self.reset()
            return self.command
        if not math.isfinite(dt_s) or dt_s <= 0.0:
            raise ValueError("command shaping requires a positive physics timestep")
        if linear_limit is not None and (not math.isfinite(linear_limit) or linear_limit < 0.0):
            raise ValueError("linear command limit must be finite and non-negative")
        if angular_limit is not None and (not math.isfinite(angular_limit) or angular_limit < 0.0):
            raise ValueError("angular command limit must be finite and non-negative")
        target = tuple(float(value) for value in target)
        if linear_limit is not None:
            target_scale = min(1.0, linear_limit / max(math.hypot(*target[:2]), 1e-12))
            target = (target[0] * target_scale, target[1] * target_scale, target[2])
        if angular_limit is not None:
            target = (target[0], target[1], max(-angular_limit, min(angular_limit, target[2])))
        if safety_override:
            self.command = target
            return self.command
        previous = self.command
        change = (target[0] - previous[0], target[1] - previous[1])
        change_norm = math.hypot(*change)
        decelerating = (math.hypot(*target[:2]) < math.hypot(*previous[:2])
                        or target[0] * previous[0] + target[1] * previous[1] < 0.0)
        rate = (self.config.linear_deceleration_mps2 if decelerating
                else self.config.linear_acceleration_mps2)
        fraction = min(1.0, rate * dt_s / max(change_norm, 1e-12))
        linear = (previous[0] + fraction * change[0], previous[1] + fraction * change[1])
        if linear_limit is not None:
            scale = min(1.0, linear_limit / max(math.hypot(*linear), 1e-12))
            linear = (linear[0] * scale, linear[1] * scale)
        yaw_delta = self.config.angular_acceleration_radps2 * dt_s
        yaw = previous[2] + max(-yaw_delta, min(yaw_delta, target[2] - previous[2]))
        if angular_limit is not None:
            yaw = max(-angular_limit, min(angular_limit, yaw))
        self.command = (*linear, yaw)
        return self.command


def load_motion_profile(path):
    profile = json.loads(Path(path).read_text())
    if profile.get("schema") != "tita.isaac_motion_profile.v1" or profile.get("simulation_only") is not True:
        raise ValueError("motion profiles must explicitly be simulation-only v1 profiles")
    speeds = profile.get("posture_vmax_mps", [])
    if len(speeds) != 3 or not all(math.isfinite(value) and value > 0.0 for value in speeds):
        raise ValueError("motion profile requires three positive posture speed limits")
    if not speeds[1] > max(speeds[0], speeds[2]):
        raise ValueError("MID must be the fastest posture in this navigation contract")
    CommandShapingConfig(**profile["command_shaping"])
    if not isinstance(profile.get("planner_physics_lockstep", False), bool):
        raise ValueError("planner_physics_lockstep must be a boolean")
    return profile


def planner_command_current(sequence, episode_id, source, interval_steps=5):
    if not isinstance(source, dict):
        return False
    source_sequence = source.get("sequence")
    source_episode = source.get("episode_id")
    return (type(source_sequence) is int and type(source_episode) is int
            and source_episode == episode_id
            and 0 <= source_sequence <= sequence
            and sequence - source_sequence < interval_steps)
