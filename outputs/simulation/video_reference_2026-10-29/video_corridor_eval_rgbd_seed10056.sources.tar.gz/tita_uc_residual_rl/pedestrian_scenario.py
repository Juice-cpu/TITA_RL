from __future__ import annotations

import json
import math
from pathlib import Path

from .joint_navigation import Pedestrian


def load_pedestrian_scenario(path: Path) -> tuple[Pedestrian, ...]:
    document = json.loads(path.read_text())
    if document.get("version") != 1:
        raise ValueError("unsupported pedestrian scenario version")
    entries = document.get("pedestrians")
    if not isinstance(entries, list) or not 1 <= len(entries) <= 16:
        raise ValueError("scenario requires one to sixteen pedestrians")
    people = []
    for entry in entries:
        values = [float(entry[key]) for key in ("x", "y", "vx", "vy")]
        if not all(math.isfinite(value) for value in values):
            raise ValueError("pedestrian state must be finite")
        if float(entry.get("radius_m", .30)) != .30:
            raise ValueError("scenario radius must match the physical capsule radius .30 m")
        people.append(Pedestrian(*values, .30))
    return tuple(people)
