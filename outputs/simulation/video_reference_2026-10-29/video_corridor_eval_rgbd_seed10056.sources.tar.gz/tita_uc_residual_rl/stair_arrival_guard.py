from dataclasses import dataclass
import math


@dataclass
class StairArrivalGuard:
    support_hold_s: float = .5
    supported_since_s: float | None = None

    def observe(self, time_s: float, wheels_fully_supported: bool, both_wheels_grounded: bool) -> bool:
        if not math.isfinite(time_s) or not math.isfinite(self.support_hold_s) or self.support_hold_s <= 0.:
            raise ValueError("stair arrival requires finite time and positive support hold")
        if self.supported_since_s is not None and time_s < self.supported_since_s:
            raise ValueError("stair arrival time must be monotonic")
        if not wheels_fully_supported or not both_wheels_grounded:
            self.supported_since_s = None
            return False
        if self.supported_since_s is None:
            self.supported_since_s = time_s
        return time_s - self.supported_since_s + 1e-9 >= self.support_hold_s
