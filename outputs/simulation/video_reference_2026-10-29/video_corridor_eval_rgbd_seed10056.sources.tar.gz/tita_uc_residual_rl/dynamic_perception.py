from __future__ import annotations

from dataclasses import dataclass
import math

import numpy as np

from .joint_navigation import Pedestrian
from .observed_motion_axis_prior import ObservedMotionAxisPrior
from .observed_shuttle_prediction import ObservedShuttleForecaster, validate_observed_shuttle_forecast


def _fit_circle(points):
    design = np.column_stack((2.0 * points, np.ones(len(points))))
    coefficients, _, rank, _ = np.linalg.lstsq(design, np.sum(points * points, axis=1), rcond=None)
    squared_radius = coefficients[2] + float(coefficients[:2] @ coefficients[:2])
    if rank < 3 or squared_radius <= 0.:
        return None
    radius = math.sqrt(squared_radius)
    return (coefficients[:2], radius) if .25 <= radius <= .40 else None


def _separate_touching_arcs(points):
    remaining = points.copy()
    generator = np.random.default_rng(0)
    detections = []
    while len(remaining) >= 6:
        best = None
        best_count = 5
        for attempt in range(96):
            candidate = _fit_circle(remaining[generator.choice(len(remaining), 3, replace=False)])
            if candidate is None:
                continue
            center, radius = candidate
            inliers = np.abs(np.linalg.norm(remaining - center, axis=1) - radius) < .012
            count = int(inliers.sum())
            if count > best_count and _continuous_curved_arc(remaining[inliers], center):
                best, best_count = inliers, count
        if best is None:
            break
        fitted = _fit_circle(remaining[best])
        if fitted is None:
            break
        center, radius = fitted
        if _continuous_curved_arc(remaining[best], center):
            detections.append((center, radius))
        remaining = remaining[~best]
    return detections


def _continuous_curved_arc(points, center):
    angles = np.sort(np.arctan2(points[:, 1] - center[1], points[:, 0] - center[0]))
    gaps = np.diff(np.r_[angles, angles[0] + 2. * math.pi])
    largest_gap = int(gaps.argmax())
    return bool(2. * math.pi - gaps[largest_gap] >= 1.0
                and np.delete(gaps, largest_gap).max() <= .35)


def circle_detections(points_xy_m: np.ndarray, cluster_radius_m: float = 0.18) -> list[tuple[np.ndarray, float]]:
    points = np.asarray(points_xy_m, dtype=float).reshape(-1, 2)
    if not np.isfinite(points).all() or cluster_radius_m <= 0:
        raise ValueError("lidar points and clustering radius must be finite and valid")
    remaining = set(range(len(points)))
    detections = []
    while remaining:
        pending = [remaining.pop()]
        component = []
        while pending:
            index = pending.pop()
            component.append(index)
            neighbors = [other for other in remaining if np.linalg.norm(points[other] - points[index]) <= cluster_radius_m]
            remaining.difference_update(neighbors)
            pending.extend(neighbors)
        if len(component) < 4:
            continue
        cluster = points[component]
        if np.ptp(cluster, axis=0).max() > 2.5:
            continue
        fitted = _fit_circle(cluster)
        if fitted is not None:
            center, radius = fitted
            residual = np.abs(np.linalg.norm(cluster - center, axis=1) - radius)
        if fitted is not None and residual.mean() < .025 and residual.max() < .05:
            detections.append((center, radius))
        else:
            detections.extend(_separate_touching_arcs(cluster))
    return detections


@dataclass
class MotionTrack:
    identifier: int
    state: np.ndarray
    covariance: np.ndarray
    radius_m: float
    last_seen_s: float
    observations: int = 1
    first_seen_s: float | None = None
    stationary_since_s: float | None = None
    moving_since_s: float | None = None
    last_motion_vx: float = 0.
    last_motion_vy: float = 0.


@dataclass(frozen=True)
class PedestrianMotionContext:
    identifier: int
    stationary_duration_s: float
    moving_duration_s: float
    last_motion_vx: float
    last_motion_vy: float
    observed_duration_s: float
    restart_axis_vx: float = 0.
    restart_axis_vy: float = 0.
    restart_axis_source: str = 'legacy'
    shuttle_prediction: dict | None = None

    def __post_init__(self):
        values = (self.stationary_duration_s, self.moving_duration_s, self.last_motion_vx,
                  self.last_motion_vy, self.observed_duration_s, self.restart_axis_vx, self.restart_axis_vy)
        if (not isinstance(self.identifier, int) or self.identifier < 0
                or not all(math.isfinite(value) for value in values)
                or min(self.stationary_duration_s, self.moving_duration_s, self.observed_duration_s) < 0.
                or self.restart_axis_source not in ('legacy', 'track_observed_peak', 'scene_observed_dominant_axis', 'unavailable')):
            raise ValueError('observed motion history requires a valid track identifier and finite nonnegative ages')
        if self.shuttle_prediction is not None:
            validate_observed_shuttle_forecast(self.shuttle_prediction)


class LidarPedestrianTracker:
    def __init__(self, association_radius_m: float = 0.65, stale_after_s: float = 0.6,
                 motion_margin_m: float = 0., static_solid_boxes_xyz_m=(), static_center_guard_m: float = .01,
                 observed_shuttle_prediction: bool = False, observed_shuttle_plateau_gate: bool = False) -> None:
        if observed_shuttle_plateau_gate and not observed_shuttle_prediction:
            raise ValueError('motion plateau gate requires observed shuttle prediction')
        if not math.isfinite(motion_margin_m) or motion_margin_m < 0.:
            raise ValueError('pedestrian motion margin must be finite and nonnegative')
        boxes = np.asarray(static_solid_boxes_xyz_m, dtype=float)
        if not boxes.size:
            boxes = np.empty((0, 6))
        if (boxes.ndim != 2 or boxes.shape[1] != 6 or not np.isfinite(boxes).all()
                or (boxes[:, 3:] <= boxes[:, :3]).any()
                or not math.isfinite(static_center_guard_m) or static_center_guard_m < 0.):
            raise ValueError('static center filtering requires finite solid boxes and a nonnegative interior guard')
        self.static_solid_boxes_xyz_m = tuple(map(tuple, boxes))
        self.static_center_guard_m = float(static_center_guard_m)
        self.shuttle_forecaster = ObservedShuttleForecaster(observed_shuttle_plateau_gate) if observed_shuttle_prediction else None
        self.last_rejected_static_centers_xy_m = []
        self.last_circle_detections = []
        self.association_radius_m = association_radius_m
        self.stale_after_s = stale_after_s
        self.motion_margin_m = motion_margin_m
        self.tracks: list[MotionTrack] = []
        self.last_time_s: float | None = None
        self.next_identifier = 0
        self.restart_axis_prior = ObservedMotionAxisPrior()

    def reset(self) -> None:
        self.tracks.clear()
        self.last_time_s = None
        self.next_identifier = 0
        self.restart_axis_prior.reset()
        self.last_rejected_static_centers_xy_m = []
        self.last_circle_detections = []
        if self.shuttle_forecaster is not None:
            self.shuttle_forecaster = ObservedShuttleForecaster(self.shuttle_forecaster.motion_plateau_gate)

    def update(self, points_xy_m: np.ndarray, timestamp_s: float, scan_height_m: float | None = None) -> tuple[Pedestrian, ...]:
        if not math.isfinite(timestamp_s) or (self.last_time_s is not None and timestamp_s <= self.last_time_s):
            raise ValueError("sensor timestamps must increase strictly")
        if self.static_solid_boxes_xyz_m and (scan_height_m is None or not math.isfinite(scan_height_m)):
            raise ValueError('static center filtering requires the measured finite lidar scan height')
        self.last_rejected_static_centers_xy_m = []
        self.last_circle_detections = []
        dt = 0.0 if self.last_time_s is None else timestamp_s - self.last_time_s
        self.last_time_s = timestamp_s
        transition = np.eye(4)
        transition[:2, 2:] = np.eye(2) * dt
        observation = np.column_stack((np.eye(2), np.zeros((2, 2))))
        noise = np.eye(2) * 0.015 ** 2
        for track in self.tracks:
            track.state = transition @ track.state
            track.covariance = transition @ track.covariance @ transition.T + np.diag([0.001, 0.001, 0.025, 0.025]) * dt
        unused = set(range(len(self.tracks)))
        for center, radius in circle_detections(points_xy_m):
            self.last_circle_detections.append({'center_xy_m': center.tolist(), 'radius_m': float(radius)})
            if self.static_solid_boxes_xyz_m:
                point = np.r_[center, scan_height_m]
                if any(np.all(point > np.asarray(box[:3]) + self.static_center_guard_m)
                       and np.all(point < np.asarray(box[3:]) - self.static_center_guard_m)
                       for box in self.static_solid_boxes_xyz_m):
                    self.last_rejected_static_centers_xy_m.append(center.tolist())
                    continue
            distances = [(float(np.linalg.norm(self.tracks[index].state[:2] - center)), index) for index in unused]
            nearest = min(distances, default=(float("inf"), -1))
            if nearest[0] < self.association_radius_m:
                track = self.tracks[nearest[1]]
                unused.remove(nearest[1])
                innovation = center - observation @ track.state
                innovation_covariance = observation @ track.covariance @ observation.T + noise
                gain = np.linalg.solve(innovation_covariance, observation @ track.covariance).T
                track.state = track.state + gain @ innovation
                residual = np.eye(4) - gain @ observation
                track.covariance = residual @ track.covariance @ residual.T + gain @ noise @ gain.T
                track.radius_m = 0.8 * track.radius_m + 0.2 * radius
                track.last_seen_s = timestamp_s
                track.observations += 1
            else:
                self.tracks.append(MotionTrack(self.next_identifier, np.r_[center, 0.0, 0.0], np.diag([0.03 ** 2, 0.03 ** 2, 0.3 ** 2, 0.3 ** 2]), radius, timestamp_s))
                self.next_identifier += 1
        self.tracks = [track for track in self.tracks if timestamp_s - track.last_seen_s <= self.stale_after_s]
        for track in self.tracks:
            if track.first_seen_s is None:
                track.first_seen_s = timestamp_s
            speed = float(np.linalg.norm(track.state[2:]))
            if speed >= .08:
                if track.moving_since_s is None:
                    track.moving_since_s = timestamp_s
                track.stationary_since_s = None
                track.last_motion_vx, track.last_motion_vy = (float(value) for value in track.state[2:])
            elif speed <= .04:
                if track.stationary_since_s is None:
                    track.stationary_since_s = timestamp_s
                track.moving_since_s = None
        self.restart_axis_prior.update(timestamp_s, ((track.identifier, float(track.state[2]), float(track.state[3]))
            for track in self.tracks if track.last_seen_s == timestamp_s and track.observations >= 3))
        if self.shuttle_forecaster is not None:
            for track in self.tracks:
                if track.last_seen_s == timestamp_s and track.observations >= 3:
                    self.shuttle_forecaster.update(track.identifier, timestamp_s, track.state[:2], track.state[2:])
        return self.pedestrians()

    def motion_context(self) -> tuple[PedestrianMotionContext, ...]:
        if self.last_time_s is None:
            return ()
        contexts = []
        for track in self.tracks:
            restart_axis, source = self.restart_axis_prior.for_track(track.identifier)
            contexts.append(PedestrianMotionContext(track.identifier,
                0. if track.stationary_since_s is None else self.last_time_s - track.stationary_since_s,
                0. if track.moving_since_s is None else self.last_time_s - track.moving_since_s,
                track.last_motion_vx, track.last_motion_vy, track.last_seen_s - track.first_seen_s,
                float(restart_axis[0]), float(restart_axis[1]), source,
                self.shuttle_forecaster.forecast(track.identifier, self.last_time_s) if self.shuttle_forecaster is not None else None))
        return tuple(contexts)

    def pedestrians(self) -> tuple[Pedestrian, ...]:
        return tuple(Pedestrian(
            float(track.state[0]), float(track.state[1]), float(track.state[2]), float(track.state[3]),
            float(track.radius_m + 2.0 * math.sqrt(np.linalg.eigvalsh(track.covariance[:2, :2]).max()) + self.motion_margin_m),
        ) for track in self.tracks)

    def point_velocities(self, points_xy_m: np.ndarray) -> np.ndarray:
        points = np.asarray(points_xy_m, dtype=float).reshape(-1, 2)
        velocities = np.zeros_like(points)
        distances = np.full(len(points), float("inf"))
        for track in self.tracks:
            candidate = np.linalg.norm(points - track.state[:2], axis=1)
            matched = (candidate < track.radius_m + 0.15) & (candidate < distances)
            velocities[matched] = track.state[2:]
            distances[matched] = candidate[matched]
        return velocities
