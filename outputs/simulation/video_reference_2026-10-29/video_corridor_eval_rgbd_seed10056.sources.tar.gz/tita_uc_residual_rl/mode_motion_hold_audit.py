import math

from .joint_navigation import JointSafetyConfig
from .mode_execution import ModeExecutionGuard


def audit_mode_motion_hold(document):
    binding = document.get('mode_motion_hold_binding', {})
    configured = document.get('upper_safety_config', {}).get('minimum_mode_motion_hold_s', 0.)
    if not binding.get('enabled'):
        return {'passed': configured == 0., 'failures': ['hidden_nondefault_motion_hold'] if configured else [],
            'switches_checked': 0, 'windows': []}
    failures = []
    hold = ModeExecutionGuard().transition_s
    if (binding.get('contract') != 'tita.mode_guard_command_hold.v1'
            or binding.get('minimum_command_hold_s') != hold or configured != hold
            or '--bind-mode-motion-hold' not in document.get('invocation', [])):
        failures.append('guard_hold_not_bound_to_actual_runner_configuration')
    trajectory = document.get('trajectory', [])
    if not trajectory or document.get('completed_steps', 0) <= 0:
        return {'passed': False, 'failures': failures + ['actual_trajectory_required'], 'switches_checked': 0, 'windows': []}
    dt = document['elapsed_simulation_s'] / document['completed_steps']
    if not math.isfinite(dt) or dt <= 0.:
        return {'passed': False, 'failures': failures + ['invalid_actual_control_period'], 'switches_checked': 0, 'windows': []}
    safety = JointSafetyConfig(**document['upper_safety_config'])
    previous = {}
    windows = []
    for index, row in enumerate(trajectory):
        episode = row['episode']
        old = previous.get(episode)
        previous[episode] = row['posture']
        if old is None or old == row['posture']:
            continue
        window = []
        for current in trajectory[index:]:
            elapsed = (current['step'] - row['step']) * dt
            if current['episode'] != episode or current['posture'] != row['posture'] or elapsed >= hold - 1e-9:
                break
            window.append(current)
        expected = math.ceil((hold - 1e-9) / dt)
        contiguous = len(window) == expected and all(current['step'] == row['step'] + offset for offset, current in enumerate(window))
        commands_zero = all(all(math.isfinite(value) and value == 0. for value in current['command']) for current in window)
        guard_not_ready = all(current.get('mode_execution_ready') is False for current in window)
        speed = math.hypot(*row['measured_velocity_before'][:2])
        mode = ('LOW', 'MID', 'HIGH').index(old)
        radius = speed * safety.braking_horizon_s(mode, speed) + safety.transition_position_margin_m
        maximum_displacement = max(math.dist(current['root_position_before'][:2], row['root_position_before'][:2]) for current in window)
        covered = math.isfinite(maximum_displacement) and maximum_displacement <= radius + 1e-6
        passed = contiguous and commands_zero and guard_not_ready and covered
        windows.append({'episode': episode, 'switch_step': row['step'], 'from_mode': old, 'to_mode': row['posture'],
            'passed': passed, 'complete_contiguous_command_hold': contiguous, 'all_commands_exactly_zero': commands_zero,
            'guard_never_ready_before_minimum': guard_not_ready,
            'maximum_measured_displacement_m': maximum_displacement, 'added_braking_and_transition_radius_m': radius,
            'observed_drift_covered': covered})
        if not passed:
            failures.append(f'mode_motion_hold_or_drift_binding_failed:{episode}:{row["step"]}')
    if not windows:
        failures.append('no_actual_mode_transition_to_verify')
    return {'passed': not failures, 'failures': failures, 'switches_checked': len(windows), 'windows': windows,
        'scope': 'Observed mandatory zero-command hold and conservative nominal drift coverage for this recorded execution only; not a worst-case physical stopping or arbitrary actuator guarantee.'}
