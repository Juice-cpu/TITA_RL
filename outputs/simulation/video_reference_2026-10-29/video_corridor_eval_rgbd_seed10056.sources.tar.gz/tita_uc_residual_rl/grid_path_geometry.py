import math

import numpy as np


def polyline_cells(scene, points_xy_m):
    points = np.asarray(points_xy_m, dtype=float)
    if points.ndim != 2 or points.shape[1] != 2 or not len(points) or not np.isfinite(points).all():
        raise ValueError("path geometry requires finite planar points")
    cells, distances = [], []

    def append(cell, distance):
        if not cells or cell != cells[-1]:
            cells.append(cell)
            distances.append(distance)

    traveled = 0.
    previous_cell = None
    origin = np.asarray(scene.origin_xy)
    for segment in range(max(1, len(points) - 1)):
        start, end = points[segment], points[min(segment + 1, len(points) - 1)]
        length = float(np.linalg.norm(end - start))
        count = max(1, int(math.ceil(length / (scene.resolution_m / 4.))))
        for fraction in np.linspace(0., 1., count + 1):
            point = start + fraction * (end - start)
            cell = scene.world_to_cell(point)
            distance = traveled + float(fraction) * length
            if previous_cell is not None and cell[0] != previous_cell[0] and cell[1] != previous_cell[1]:
                append((previous_cell[0], cell[1]), distance)
                append((cell[0], previous_cell[1]), distance)
            normalized = (point - origin) / scene.resolution_m
            horizontal_index, vertical_index = round(normalized[0]), round(normalized[1])
            horizontal_boundary = abs(normalized[0] - horizontal_index) <= 1e-9
            vertical_boundary = abs(normalized[1] - vertical_index) <= 1e-9
            horizontal_cells = (horizontal_index - 1, horizontal_index) if horizontal_boundary else (cell[0],)
            vertical_cells = (vertical_index - 1, vertical_index) if vertical_boundary else (cell[1],)
            for horizontal in horizontal_cells:
                for vertical in vertical_cells:
                    append((horizontal, vertical), distance)
            append(cell, distance)
            previous_cell = cell
        traveled += length
    if distances[-1] < traveled:
        cells.append(cells[-1])
        distances.append(traveled)
    return tuple(cells), np.asarray(distances)


def simplify_free_polyline(scene, points_xy_m, unavailable=None, traversal_cost=None):
    points = np.asarray(points_xy_m, dtype=float)
    unavailable = scene.occupancy if unavailable is None else np.asarray(unavailable, dtype=bool) | scene.occupancy
    if unavailable.shape != scene.shape:
        raise ValueError("path simplification requires an aligned hard geometry mask")
    prefix_cost = None
    if traversal_cost is not None:
        traversal_cost = np.asarray(traversal_cost, dtype=float)
        if traversal_cost.shape != scene.shape or not np.isfinite(traversal_cost).all() or (traversal_cost < 0.).any():
            raise ValueError("path simplification requires aligned finite nonnegative traversal costs")
        def segment_cost(start, end):
            length = float(np.linalg.norm(end - start))
            count = max(1, int(math.ceil(length / (scene.resolution_m / 2.))))
            samples = start + ((np.arange(count) + .5) / count)[:, None] * (end - start)
            cells = [scene.world_to_cell(point) for point in samples]
            if not all(scene.in_bounds(cell) for cell in cells):
                return float("inf")
            return length * (1. + float(np.mean([traversal_cost[cell[1], cell[0]] for cell in cells])))
        prefix_cost = np.r_[0., np.cumsum([segment_cost(start, end) for start, end in zip(points, points[1:])])]
    anchors = [points[0]]
    anchor = 0
    while anchor < len(points) - 1:
        destination = len(points) - 1
        while destination > anchor + 1:
            cells, _ = polyline_cells(scene, [points[anchor], points[destination]])
            if (all(scene.in_bounds(cell) and not unavailable[cell[1], cell[0]] for cell in cells)
                    and (prefix_cost is None or segment_cost(points[anchor], points[destination])
                         <= prefix_cost[destination] - prefix_cost[anchor] + 1e-8)):
                break
            destination -= 1
        anchors.append(points[destination])
        anchor = destination
    dense = []
    for start, end in zip(anchors, anchors[1:]):
        count = max(1, int(math.ceil(float(np.linalg.norm(end - start)) / (scene.resolution_m / 2.))))
        dense.extend(np.linspace(start, end, count, endpoint=False))
    dense.append(anchors[-1])
    return np.asarray(dense)
