import hashlib

import numpy as np


OBSERVED_ASTAR_COST_CONTRACT = 'tita.observed_shuttle_astar_cost_envelope.v1'


def _forecast_spatial_segments(forecast, horizon_s):
    from .observed_shuttle_prediction import validate_observed_shuttle_forecast
    validate_observed_shuttle_forecast(forecast)
    times = np.asarray(forecast['times_s'], dtype=float)
    points = np.asarray(forecast['points_xy_m'], dtype=float)
    horizon = min(horizon_s, times[-1])
    end = np.array([np.interp(horizon, times, points[:, axis]) for axis in range(2)])
    points = np.vstack((points[times < horizon], end))
    points = points[np.r_[True, np.linalg.norm(np.diff(points, axis=0), axis=1) > 1e-9]]
    if len(points) == 1:
        return ((points[0], points[0]),)
    directions = np.diff(points, axis=0)
    directions /= np.linalg.norm(directions, axis=1, keepdims=True)
    corners = np.r_[True, np.linalg.norm(np.diff(directions, axis=0), axis=1) > 1e-8, True]
    points = points[corners]
    return tuple(zip(points[:-1], points[1:]))


def predicted_pedestrian_cost(scene, pedestrians, *, horizon_s=8., robot_radius_m=.6,
                              weight=20., sigma_m=.35, pedestrian_motion_context=(),
                              observed_shuttle_prediction=False):
    if (not np.isfinite([horizon_s, robot_radius_m, weight, sigma_m]).all()
            or min(horizon_s, robot_radius_m, sigma_m) <= 0. or weight < 0.):
        raise ValueError('pedestrian planning costs require finite positive dimensions and nonnegative weight')
    if pedestrian_motion_context and len(pedestrian_motion_context) != len(pedestrians):
        raise ValueError('A* pedestrian history must align with current observed tracks')
    horizontal, vertical = np.meshgrid(
        scene.origin_xy[0] + (np.arange(scene.shape[1]) + .5) * scene.resolution_m,
        scene.origin_xy[1] + (np.arange(scene.shape[0]) + .5) * scene.resolution_m)
    cost = np.zeros(scene.shape)
    for person_index, person in enumerate(pedestrians):
        if not np.isfinite([person.x, person.y, person.vx, person.vy, person.radius_m]).all() or person.radius_m <= 0.:
            raise ValueError('predicted pedestrians must have finite states and positive radii')
        displacement = np.array([person.vx, person.vy]) * horizon_s
        squared_length = float(displacement @ displacement)
        fraction = np.clip(((horizontal - person.x) * displacement[0] + (vertical - person.y) * displacement[1])
                           / max(squared_length, 1e-12), 0., 1.)
        distance = np.hypot(horizontal - person.x - fraction * displacement[0],
                            vertical - person.y - fraction * displacement[1])
        clearance = np.maximum(distance - person.radius_m - robot_radius_m, 0.)
        cost = np.maximum(cost, weight * np.exp(-.5 * (clearance / sigma_m) ** 2))
        context = pedestrian_motion_context[person_index] if pedestrian_motion_context else None
        forecast = getattr(context, 'shuttle_prediction', None)
        if not observed_shuttle_prediction or forecast is None:
            continue
        segments = _forecast_spatial_segments(forecast, horizon_s)
        if np.linalg.norm(np.subtract(forecast['points_xy_m'][0], [person.x, person.y])) > .05:
            raise ValueError('A* shuttle forecast is not anchored to current observed pedestrian')
        for start, end in segments:
            displacement = end - start
            squared_length = float(displacement @ displacement)
            fraction = np.clip(((horizontal - start[0]) * displacement[0] + (vertical - start[1]) * displacement[1])
                / max(squared_length, 1e-12), 0., 1.)
            distance = np.hypot(horizontal - start[0] - fraction * displacement[0],
                vertical - start[1] - fraction * displacement[1])
            clearance = np.maximum(distance - person.radius_m - robot_radius_m - forecast['uncertainty_radius_m'], 0.)
            cost = np.maximum(cost, weight * np.exp(-.5 * (clearance / sigma_m) ** 2))
    return cost


def pedestrian_cost_summary(scene, pedestrians, contexts, cost, *, horizon_s, robot_radius_m, weight):
    nominal = predicted_pedestrian_cost(scene, pedestrians, horizon_s=horizon_s,
        robot_radius_m=robot_radius_m, weight=weight)
    return {'contract': OBSERVED_ASTAR_COST_CONTRACT, 'shape': list(scene.shape),
        'origin_xy_m': list(scene.origin_xy), 'resolution_m': scene.resolution_m,
        'horizon_s': horizon_s, 'robot_radius_m': robot_radius_m, 'weight': weight, 'sigma_m': .35,
        'cost_sha256': hashlib.sha256(np.asarray(cost, dtype='<f8').tobytes()).hexdigest(),
        'nominal_cost_sha256': hashlib.sha256(np.asarray(nominal, dtype='<f8').tobytes()).hexdigest(),
        'changed_cells': int(np.count_nonzero(cost > nominal + 1e-12)),
        'maximum_cost_increase': float((cost - nominal).max()),
        'nominal_cost_never_reduced': bool(np.all(cost >= nominal)),
        'forecast_contexts': sum(context.shuttle_prediction is not None for context in contexts),
        'future_actor_waypoints_used': False}
