from __future__ import annotations

import numpy as np
from .grid_path_geometry import polyline_cells
from .mode_transition_calibration import transition_cost_matrix
from .start_recovery import path_sample_free


def mode_sequence_times(scene, path, posture_specs, speed_ratio, lookahead_m=1.0, transition_s=6.0, yaw_speed_radps=.30, geometry_samples=None, transition_costs_s=None):
    transitions = transition_cost_matrix(transition_costs_s if transition_costs_s is not None else
                                         np.where(np.eye(3, dtype=bool), 0., transition_s))
    if geometry_samples is not None:
        cells, distances = geometry_samples
    elif path.continuous_geometry:
        cells, distances = polyline_cells(scene, path.points_xy_m)
    else:
        cells = [scene.world_to_cell(point) for point in path.points_xy_m]
        distances = np.r_[0., np.cumsum(np.linalg.norm(np.diff(path.points_xy_m, axis=0), axis=1))]
    if not all(scene.in_bounds(cell) for cell in cells):
        return np.full(3, np.inf)
    heights = np.array([scene.ceiling_height_m[vertical, horizontal] for horizontal, vertical in cells])
    steps = np.array([scene.step_height_m[vertical, horizontal] for horizontal, vertical in cells])
    free = path_sample_free(scene, path, cells, distances)
    feasible = np.column_stack([free & (heights >= specification.body_height_m + .04)
                                & (steps <= specification.max_step_m + 1e-6) for specification in posture_specs])
    deltas = np.diff(path.points_xy_m, axis=0)
    lengths = np.diff(distances)
    headings = np.arctan2(deltas[:, 1], deltas[:, 0])
    turning = np.abs(np.arctan2(np.sin(np.diff(headings)), np.cos(np.diff(headings)))).sum() / yaw_speed_radps
    result = np.full(3, np.inf)
    for initial in range(3):
        if not posture_specs[initial].supports_speed(posture_specs[initial].vmax_mps * speed_ratio):
            continue
        costs = np.full(3, np.inf)
        if feasible[0, initial]:
            costs[initial] = 0.
        for index, length in enumerate(lengths):
            following = np.full(3, np.inf)
            for destination, specification in enumerate(posture_specs):
                if not feasible[index, destination] or not feasible[index + 1, destination]:
                    continue
                if distances[index + 1] <= lookahead_m and destination != initial:
                    continue
                switch_cost = transitions[:, destination]
                speed = specification.vmax_mps * speed_ratio
                if not specification.supports_speed(speed):
                    alternatives = [specification.vmax_mps * ratio for ratio in (.4, .7, 1.)
                                    if specification.supports_speed(specification.vmax_mps * ratio)]
                    if not alternatives:
                        continue
                    speed = min(alternatives)
                following[destination] = np.min(np.where(feasible[index], costs + switch_cost, np.inf)) + length / speed
            costs = following
        result[initial] = costs.min() + turning
    return result
