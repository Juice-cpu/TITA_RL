from __future__ import annotations

import math

import numpy as np


MODE_COMMAND_LIMITS = {
    "LOW": (.08, .25, .40),
    "MID": (.30, .60, .10),
    "HIGH": (.30, .60, .02),
}


def curvature_preserving_command(command, maximum_linear_mps, maximum_yaw_radps):
    command = np.asarray(command, dtype=float)
    limits = np.asarray([maximum_linear_mps, maximum_yaw_radps], dtype=float)
    if command.shape != (2,) or not np.isfinite(command).all() or not np.isfinite(limits).all() or (limits <= 0.).any():
        raise ValueError("curvature limits require finite commands and positive speed limits")
    scale = min(1., float(np.min(limits / np.maximum(np.abs(command), 1e-12))))
    return (command * scale).tolist()


def limit_mode_navigation_command(previous, target, posture, dt_s):
    previous = np.asarray(previous, dtype=float)
    target = np.asarray(target, dtype=float)
    if previous.shape != (2,) or target.shape != (2,) or not np.isfinite([previous, target]).all():
        raise ValueError("navigation limiter requires finite forward/yaw commands")
    if posture not in MODE_COMMAND_LIMITS or not math.isfinite(dt_s) or dt_s <= 0.:
        raise ValueError("invalid command limiter mode or timestep")
    linear_acceleration, angular_acceleration, filter_time_s = MODE_COMMAND_LIMITS[posture]
    filtered = previous + (1. - math.exp(-dt_s / filter_time_s)) * (target - previous)
    delta_limit = np.array([linear_acceleration, angular_acceleration]) * dt_s
    return np.clip(filtered, previous - delta_limit, previous + delta_limit).tolist()
