from __future__ import annotations

import numpy as np


def authored_pedestrian_obstacles(environment):
    cfg = environment.cfg
    origin = environment._environment_origins()[0].cpu().numpy()
    boxes = []
    if getattr(cfg, "navigation_scene_file", ""):
        from .navigation_maze import load_maze
        for box in load_maze(cfg.navigation_scene_file)["boxes"]:
            center, size = np.asarray(box["center"]), np.asarray(box["size"])
            boxes.append((box["name"], origin[:2] + center[:2] - size[:2] / 2.,
                          origin[:2] + center[:2] + size[:2] / 2., center[2] - size[2] / 2., center[2] + size[2] / 2.))
    if cfg.tunnel_enabled:
        height, width, length = environment.tunnel_dimensions[0].cpu().tolist()
        start = origin[0] + cfg.tunnel_start_x_m
        thickness = cfg.tunnel_wall_thickness_m
        for side in (-1., 1.):
            center = origin[1] + side * (width + thickness) / 2.
            boxes.append(("tunnel_wall", np.array([start, center - thickness / 2.]),
                          np.array([start + length, center + thickness / 2.]), 0., height + thickness))
        boxes.append(("low_ceiling", np.array([start, origin[1] - width / 2. - thickness]),
                      np.array([start + length, origin[1] + width / 2. + thickness]), height, height + thickness))
    if cfg.stair_enabled and cfg.stair_training_corridor_enabled:
        height, tread, width = environment.stair_dimensions[0].cpu().tolist()
        end = origin[0] + cfg.stair_start_x_m + cfg.stair_num_steps * tread + cfg.stair_landing_length_m
        for side in (-1., 1.):
            center = origin[1] + side * (width + .1) / 2.
            boxes.append(("stair_corridor_wall", np.array([origin[0], center - .05]),
                          np.array([end, center + .05]), 0., .8))
    return boxes


def ground_height_at_xy(environment, position_xy):
    origin = environment._environment_origins()[0].cpu().numpy()
    cfg = environment.cfg
    if cfg.stair_enabled:
        height, tread, width = environment.stair_dimensions[0].cpu().tolist()
        start = origin[0] + cfg.stair_start_x_m
        end = start + cfg.stair_num_steps * tread + cfg.stair_landing_length_m
        if start <= position_xy[0] <= end and abs(position_xy[1] - origin[1]) <= width / 2.:
            level = min(cfg.stair_num_steps, int((position_xy[0] - start) // tread) + 1)
            return float(origin[2] + level * height)
    return float(origin[2])


def validate_pedestrian_trajectories(pedestrians, obstacles, duration_s, maximum_support_height_m=0.):
    if not np.isfinite(duration_s) or duration_s <= 0.:
        raise ValueError("pedestrian validation duration must be finite and positive")
    for index, person in enumerate(pedestrians):
        position = np.array([person.x, person.y])
        velocity = np.array([person.vx, person.vy])
        for name, lower, upper, bottom, top in obstacles:
            if bottom >= 1.8 + maximum_support_height_m or top <= 0.:
                continue
            minimum, maximum = 0., duration_s
            for axis in range(2):
                start, end = lower[axis] - person.radius_m, upper[axis] + person.radius_m
                if abs(velocity[axis]) < 1e-12:
                    if not start < position[axis] < end:
                        maximum = -1.
                        break
                else:
                    enter, leave = sorted(((start - position[axis]) / velocity[axis], (end - position[axis]) / velocity[axis]))
                    minimum, maximum = max(minimum, enter), min(maximum, leave)
            if minimum < maximum:
                raise ValueError(f"physical pedestrian {index} intersects {name} during its scripted trajectory")
    for index, first in enumerate(pedestrians):
        for second in pedestrians[index + 1:]:
            position = np.array([first.x - second.x, first.y - second.y])
            velocity = np.array([first.vx - second.vx, first.vy - second.vy])
            time = np.clip(-position @ velocity / max(float(velocity @ velocity), 1e-12), 0., duration_s)
            if np.linalg.norm(position + velocity * time) < first.radius_m + second.radius_m - 1e-6:
                raise ValueError("scripted physical pedestrians intersect one another")
    return {"status": "passed", "method": "conservative_capsule_xy_sweep_against_authored_walls_roof_and_other_people",
            "horizon_s": duration_s, "actors": len(pedestrians), "static_boxes": len(obstacles)}


def validate_pedestrian_tracks(tracks, obstacles, duration_s, maximum_support_height_m=0.):
    from .joint_navigation import Pedestrian

    if not tracks:
        raise ValueError('track validation requires at least one pedestrian')
    times = np.unique(np.concatenate([track.breakpoints(duration_s) for track in tracks]))
    if len(times) > 100000:
        raise ValueError('combined pedestrian schedule is too complex for complete validation')
    for start, end in zip(times[:-1], times[1:]):
        if end - start < 1e-9:
            continue
        midpoint = (start + end) / 2.
        states = [track.state_at(midpoint) for track in tracks]
        initial = tuple(Pedestrian(person.x - person.vx * (midpoint - start),
            person.y - person.vy * (midpoint - start), person.vx, person.vy, person.radius_m) for person in states)
        validate_pedestrian_trajectories(initial, obstacles, float(end - start), maximum_support_height_m)
    return {'status': 'passed', 'method': 'all_piecewise_linear_intervals_capsule_sweep_against_static_boxes_and_other_people',
            'horizon_s': duration_s, 'actors': len(tracks), 'static_boxes': len(obstacles),
            'intervals': len(times) - 1, 'repeating_tracks': sum(track.repeat for track in tracks)}
