"""Audit obstacle response separately from nominal rates and goal completion."""

from __future__ import annotations

from collections import defaultdict
import json
import math
from pathlib import Path

import numpy as np

from .realtime_metrics import timing_statistics
from .sudden_obstacle import conservative_clearance, trigger_satisfied


def read_jsonl(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]


def _milliseconds(start, end):
    if type(start) is not int or type(end) is not int or end < start:
        raise ValueError("missing timestamp or reversed response time order")
    return (end - start) / 1_000_000


def _one(records, event):
    if len(records) != 1:
        raise ValueError(f"expected exactly one {event}, got {len(records)}")
    return records[0]


def _yaw(quaternion):
    scalar, roll, pitch, yaw = quaternion
    return math.atan2(2 * (scalar * yaw + roll * pitch), 1 - 2 * (pitch**2 + yaw**2))


def _angle_difference(first, second):
    return math.atan2(math.sin(first - second), math.cos(first - second))


def sustained_response(rows, predicate, count=3):
    if count < 1:
        raise ValueError("response confirmation count must be positive")
    consecutive = []
    for row in rows:
        if predicate(row):
            if consecutive and row["control_step"] != consecutive[-1]["control_step"] + 1:
                consecutive = []
            consecutive.append(row)
            if len(consecutive) == count:
                return {"onset": consecutive[0], "confirmed": consecutive[-1]}
        else:
            consecutive = []
    return None


def analyze_response_events(events):
    grouped = defaultdict(list)
    for record in events:
        grouped[record["event"]].append(record)
    identities = grouped["clock_identity"]
    if not identities or len({(row["hostname"], row["boot_id"], row["clock"]) for row in identities}) != 1:
        raise ValueError("response traces require a verified same-host monotonic clock")
    if not {"isaac", "probe", "bridge_ros", "planner", "gate", "upper"} <= {row["component"] for row in identities}:
        raise ValueError("missing response timing component")
    appearance = _one(grouped["obstacle_appeared"], "obstacle appearance")
    detection = _one(grouped["lidar_first_hit"], "first lidar hit")
    appeared_ns, detected_ns = appearance["monotonic_ns"], detection["monotonic_ns"]
    _milliseconds(appeared_ns, detected_ns)
    publications = sorted(grouped["probe_scan_published"], key=lambda row: row["monotonic_ns"])
    if not publications:
        raise ValueError("no detected-obstacle scan published")
    for row in publications:
        if row["source_probe"]["appeared_ns"] != appeared_ns or row["source_probe"]["detected_ns"] != detected_ns:
            raise ValueError("scan refers to another probe event")
        _milliseconds(detected_ns, row["monotonic_ns"])
    by_stamp = {row["scan_stamp_ns"]: row for row in publications}
    first_scan = publications[0]
    received = {}
    for component in ("planner", "gate"):
        matching = [row for row in grouped[f"{component}_scan_received"]
                    if row["scan_stamp_ns"] == first_scan["scan_stamp_ns"]]
        if not matching:
            raise ValueError(f"first affected scan not received by {component}")
        received[component] = min(matching, key=lambda row: row["monotonic_ns"])
        _milliseconds(first_scan["monotonic_ns"], received[component]["monotonic_ns"])
    solves = sorted([row for row in grouped["planner_solve"]
                     if row.get("source_scan_stamp_ns") in by_stamp], key=lambda row: row["start_ns"])
    if not solves:
        raise ValueError("no local solve with a known post-detection scan marker")
    for row in solves:
        _milliseconds(by_stamp[row["source_scan_stamp_ns"]]["monotonic_ns"], row["start_ns"])
        _milliseconds(row["start_ns"], row["end_ns"])
    solves_by_start = {row["start_ns"]: row for row in solves}
    applications = sorted(grouped["control_input_applied"], key=lambda row: row["monotonic_ns"])
    affected_inputs = []
    for row in applications:
        source = row.get("planner_source", {})
        start_ns = source.get("solve_started_ns")
        if start_ns not in solves_by_start:
            continue
        solve = solves_by_start[start_ns]
        if source.get("scan_stamp_ns") != solve["source_scan_stamp_ns"]:
            raise ValueError("application and solve have different source scans")
        if source.get("sequence") != solve["source_feedback_sequence"]:
            raise ValueError("application and solve have different feedback sequences")
        _milliseconds(solve["end_ns"], row["monotonic_ns"])
        affected_inputs.append(row)
    if not affected_inputs:
        raise ValueError("post-detection planner command never applied")
    first_input = affected_inputs[0]
    used_solve = solves_by_start[first_input["planner_source"]["solve_started_ns"]]
    steps = [row["control_step"] for row in applications]
    if len(set(steps)) != len(steps):
        raise ValueError("duplicate physical control step")
    return {
        "appearance": appearance,
        "detection": detection,
        "first_scan": first_scan,
        "first_planner_scan_received": received["planner"],
        "first_gate_scan_received": received["gate"],
        "first_known_scan_solve": solves[0],
        "first_known_scan_input": first_input,
        "first_input_solve": used_solve,
        "latencies_ms": {
            "appearance_to_lidar_hit_ms": _milliseconds(appeared_ns, detected_ns),
            "appearance_to_scan_publish_ms": _milliseconds(appeared_ns, first_scan["monotonic_ns"]),
            "appearance_to_planner_scan_ms": _milliseconds(appeared_ns, received["planner"]["processed_ns"]),
            "appearance_to_gate_scan_ms": _milliseconds(appeared_ns, received["gate"]["monotonic_ns"]),
            "appearance_to_first_solve_ms": _milliseconds(appeared_ns, solves[0]["end_ns"]),
            "appearance_to_first_known_scan_input_ms": _milliseconds(appeared_ns, first_input["monotonic_ns"]),
            "detection_to_first_known_scan_input_ms": _milliseconds(detected_ns, first_input["monotonic_ns"]),
            "first_used_solve_duration_ms": _milliseconds(used_solve["start_ns"], used_solve["end_ns"]),
            "first_used_solve_to_input_ms": _milliseconds(used_solve["end_ns"], first_input["monotonic_ns"]),
        },
        "first_known_scan_input_sim_delay_s": first_input["sim_time_s"] - appearance["sim_time_s"],
    }


def align_clean_reference(control_rows, reference_rows, config, appearance):
    reference_trigger = next((row for row in reference_rows
                              if trigger_satisfied(config, row["position"][:2], row["linear_b"][0])), None)
    if reference_trigger is None:
        raise ValueError("clean reference did not cross the common physical trigger")
    offset = reference_trigger["sim_time_s"] - appearance["sim_time_s"]
    reference_times = np.asarray([row["sim_time_s"] for row in reference_rows])
    aligned = []
    for row in control_rows:
        elapsed = row["sim_time_s"] - appearance["sim_time_s"]
        if elapsed < -1 or elapsed > 10:
            continue
        target = row["sim_time_s"] + offset
        insertion = int(np.searchsorted(reference_times, target))
        candidates = [index for index in (insertion - 1, insertion) if 0 <= index < len(reference_times)]
        nearest = min(candidates, key=lambda index: abs(reference_times[index] - target))
        reference = reference_rows[nearest]
        if abs(reference["sim_time_s"] - target) > 0.011:
            continue
        aligned.append({
            "control_step": row["control_step"], "elapsed_sim_s": elapsed,
            "position_difference_m": float(np.linalg.norm(np.asarray(row["position"][:2]) - reference["position"][:2])),
            "speed_difference_mps": row["linear_b"][0] - reference["linear_b"][0],
            "heading_difference_rad": _angle_difference(_yaw(row["quaternion_wxyz"]), _yaw(reference["quaternion_wxyz"])),
            "command_speed_difference_mps": row["desired"][0] - reference["desired"][0],
            "command_yaw_difference_radps": row["desired"][2] - reference["desired"][2],
        })
    pre = [row for row in aligned if row["elapsed_sim_s"] < -0.0001]
    if len(pre) < 20:
        raise ValueError("insufficient matched pre-event clean reference samples")
    quality = {name: float(np.sqrt(np.mean([row[name]**2 for row in pre])))
               for name in ("position_difference_m", "speed_difference_mps", "heading_difference_rad")}
    quality["samples"] = len(pre)
    quality["passed"] = (quality["position_difference_m"] <= 0.05
                         and quality["speed_difference_mps"] <= config["minimum_measured_slowdown_mps"] / 2
                         and quality["heading_difference_rad"] <= config["minimum_measured_heading_change_rad"] / 2)
    return aligned, quality, offset


def _response_summary(response, timing_rows, appearance):
    if response is None:
        return None
    onset, confirmed = response["onset"], response["confirmed"]
    onset_timing, confirmed_timing = timing_rows[onset["control_step"]], timing_rows[confirmed["control_step"]]
    return {"onset_control_step": onset["control_step"], "confirmed_control_step": confirmed["control_step"],
            "onset_wall_ms": _milliseconds(appearance["monotonic_ns"], onset_timing["monotonic_ns"]),
            "confirmed_wall_ms": _milliseconds(appearance["monotonic_ns"], confirmed_timing["monotonic_ns"]),
            "onset_sim_s": onset_timing["sim_time_s"] - appearance["sim_time_s"],
            "confirmed_sim_s": confirmed_timing["sim_time_s"] - appearance["sim_time_s"]}


def analyze_response_trial(directory, config, result, clean_directory):
    directory, clean_directory = Path(directory), Path(clean_directory)
    events = [row for path in sorted((directory / "timing").glob("*.jsonl")) for row in read_jsonl(path)]
    response = analyze_response_events(events)
    appearance = response["appearance"]
    control = read_jsonl(directory / "control_trace.jsonl")
    clean = read_jsonl(clean_directory / "control_trace.jsonl")
    aligned, quality, offset = align_clean_reference(control, clean, config, appearance)
    inputs = {row["control_step"]: row for row in events if row["event"] == "control_input_applied"}
    physical = {row["control_step"]: row for row in events if row["event"] == "physical_sample"}
    if len(inputs) != len(control) or len(physical) != len(control) - appearance["control_step"]:
        raise ValueError("response sample count differs from executed physical steps")
    detected_ns = response["detection"]["monotonic_ns"]
    post = [row for row in aligned if row["control_step"] in physical
            and physical[row["control_step"]]["monotonic_ns"] >= detected_ns]
    command_post = [row for row in post if inputs[row["control_step"]]["monotonic_ns"] >= detected_ns]
    command_response = sustained_response(command_post, lambda row:
        abs(row["command_speed_difference_mps"]) >= config["minimum_response_command_delta_mps"]
        or abs(row["command_yaw_difference_radps"]) >= config["minimum_response_yaw_delta_radps"])
    slowdown = sustained_response(post, lambda row: row["speed_difference_mps"] <= -config["minimum_measured_slowdown_mps"])
    turning = sustained_response(post, lambda row: abs(row["heading_difference_rad"]) >= config["minimum_measured_heading_change_rad"])
    measured_response = sustained_response(post, lambda row:
        row["speed_difference_mps"] <= -config["minimum_measured_slowdown_mps"]
        or abs(row["heading_difference_rad"]) >= config["minimum_measured_heading_change_rad"])
    markers = {
        "command_deviation": _response_summary(command_response, inputs, appearance),
        "measured_response": _response_summary(measured_response, physical, appearance),
        "measured_slowdown": _response_summary(slowdown, physical, appearance),
        "measured_turn": _response_summary(turning, physical, appearance),
    }
    if not quality["passed"]:
        markers = {name: None for name in markers}
    probe_config = {**config, "center_m": appearance["center_m"], "size_m": appearance["size_m"]}
    samples = sorted(physical.values(), key=lambda row: row["control_step"])
    clearances = [conservative_clearance(probe_config, row["position_xy"]) for row in samples]
    last_time = control[-1]["sim_time_s"]
    tail = [row for row in control if row["sim_time_s"] >= last_time - 5]
    tail_positions = np.asarray([row["position"][:2] for row in tail])
    tail_motion = float(np.linalg.norm(np.diff(tail_positions, axis=0), axis=1).sum())
    manifest = json.loads((directory / "run_manifest.json").read_text())
    final_goal_distance = float(np.linalg.norm(np.asarray(control[-1]["position"][:2]) - manifest["goal"]))
    tail_goal_progress = float(np.linalg.norm(tail_positions[0] - manifest["goal"]) - final_goal_distance)
    contact_max = max(row["obstacle_contact_force_n"] for row in samples)
    successful = bool(result["success"])
    all_applications = sorted(inputs.values(), key=lambda row: row["control_step"])
    wall_s = (all_applications[-1]["monotonic_ns"] - all_applications[0]["monotonic_ns"]) / 1e9
    solves = [row for row in events if row["event"] == "planner_solve"]
    upper = [row for row in events if row["event"] == "upper_inference"]
    response.update({
        "algorithm": result["algorithm"], "seed": result["seed"], "directory": str(directory.resolve()),
        "clean_reference": str(clean_directory.resolve()), "reference_alignment_offset_s": offset,
        "reference_pre_event_rms": quality, "response_markers": markers,
        "success": successful, "complete": bool(result["complete"]), "truncated": bool(result["truncated"]),
        "hard_failure": bool(result["hard_failure"]), "navigation_time_s": result["navigation_time_s"],
        "navigation_time_success_only_s": result["navigation_time_success_only_s"],
        "mechanical_energy_j": result["mechanical_energy_j"], "distance_m": result["distance_m"],
        "minimum_conservative_clearance_m": min(clearances), "obstacle_contact_force_max_n": contact_max,
        "obstacle_contact_detected": contact_max > 1., "final_goal_distance_m": final_goal_distance,
        "passed_obstacle_in_x": any(row["position_xy"][0] > appearance["center_m"][0] + appearance["size_m"][0] / 2
                                    + config["conservative_robot_radius_m"] for row in samples),
        "tail_5s_distance_m": tail_motion, "stalled_last_5s": not successful and tail_motion < 0.25,
        "tail_5s_net_displacement_m": float(np.linalg.norm(tail_positions[-1] - tail_positions[0])),
        "tail_5s_goal_progress_m": tail_goal_progress,
        "active_wall_s": wall_s, "real_time_factor": result["navigation_time_s"] / wall_s,
        "wall_input_hz": (len(inputs) - 1) / wall_s,
        "all_local_solve_ms": timing_statistics([_milliseconds(row["start_ns"], row["end_ns"]) for row in solves]),
        "upper_inference_ms": timing_statistics([_milliseconds(row["start_ns"], row["end_ns"]) for row in upper]),
    })
    return response, aligned


def summarize_algorithms(trials):
    summaries = {}
    for algorithm in sorted({row["algorithm"] for row in trials}):
        group = [row for row in trials if row["algorithm"] == algorithm]
        metrics = {name: timing_statistics([row["latencies_ms"][name] for row in group])
                   for name in group[0]["latencies_ms"]}
        for marker in ("command_deviation", "measured_response", "measured_slowdown", "measured_turn"):
            samples = [row["response_markers"][marker]["confirmed_wall_ms"] for row in group
                       if row["response_markers"][marker] is not None]
            metrics[f"{marker}_confirmed_ms"] = timing_statistics(samples) if samples else None
        summaries[algorithm] = {
            "n": len(group), "successes": sum(row["success"] for row in group),
            "contacts": sum(row["obstacle_contact_detected"] for row in group),
            "stalled": sum(row["stalled_last_5s"] for row in group),
            "reference_quality_passed": sum(row["reference_pre_event_rms"]["passed"] for row in group),
            "metrics_ms": metrics,
            "minimum_clearance_m": min(row["minimum_conservative_clearance_m"] for row in group),
            "maximum_contact_force_n": max(row["obstacle_contact_force_max_n"] for row in group),
            "mean_final_goal_distance_m": float(np.mean([row["final_goal_distance_m"] for row in group])),
            "mean_input_hz": float(np.mean([row["wall_input_hz"] for row in group])),
        }
    return summaries
