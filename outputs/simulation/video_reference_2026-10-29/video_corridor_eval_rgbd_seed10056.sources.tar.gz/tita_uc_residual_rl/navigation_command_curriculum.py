"""Seeded forward, reverse, turning and stop commands for Isaac rollouts."""

from __future__ import annotations

from dataclasses import dataclass
import math

import numpy as np
import torch


def hold_reset_commands(command, episode_steps, hold_steps):
    if (command.ndim != 2 or command.shape[1] != 3 or episode_steps.shape != command.shape[:1]
            or episode_steps.dtype != torch.long or not isinstance(hold_steps, int) or hold_steps < 0):
        raise ValueError('reset hold requires aligned commands, integer episode steps and nonnegative duration')
    held = command.clone()
    held[episode_steps < hold_steps] = 0.
    return held


def navigation_tracking_penalty(
    velocity: torch.Tensor,
    angular_velocity: torch.Tensor,
    projected_gravity: torch.Tensor,
    command: torch.Tensor,
    linear_weight: float,
    yaw_weight: float,
    tilt_weight: float,
) -> torch.Tensor:
    linear_error = (velocity[:, :2] - command[:, :2]).square().sum(dim=1)
    yaw_error = (angular_velocity[:, 2] - command[:, 2]).square()
    tilt_error = projected_gravity[:, :2].square().sum(dim=1)
    return linear_weight * linear_error + yaw_weight * yaw_error + tilt_weight * tilt_error


@dataclass(frozen=True)
class NavigationCommandConfig:
    min_vx: float = -0.15
    max_vx: float = 0.15
    max_wz: float = 0.30
    hold_steps: int = 50
    linear_acceleration: float = 0.30
    angular_acceleration: float = 0.60
    stop_probability: float = 0.25

    def __post_init__(self) -> None:
        values = (self.min_vx, self.max_vx, self.max_wz,
                  self.linear_acceleration, self.angular_acceleration,
                  self.stop_probability)
        if not all(math.isfinite(value) for value in values):
            raise ValueError("command curriculum parameters must be finite")
        if self.min_vx > self.max_vx or self.max_wz < 0 or self.hold_steps < 1:
            raise ValueError("invalid command bounds or hold steps")
        if min(self.linear_acceleration, self.angular_acceleration) <= 0:
            raise ValueError("command accelerations must be positive")
        if not 0 <= self.stop_probability <= 1:
            raise ValueError("stop probability must lie in [0, 1]")


class NavigationCommandCurriculum:
    def __init__(self, num_envs: int, device: str, seed: int,
                 config: NavigationCommandConfig | None = None) -> None:
        if num_envs < 1:
            raise ValueError("num_envs must be positive")
        self.config = config or NavigationCommandConfig()
        self.rng = np.random.default_rng(seed)
        self.current = torch.zeros((num_envs, 3), device=device)
        self.target = torch.zeros_like(self.current)
        self.remaining = torch.zeros(num_envs, dtype=torch.long, device=device)

    def step(self, dt: float) -> torch.Tensor:
        if not math.isfinite(dt) or dt <= 0:
            raise ValueError("dt must be finite and positive")
        indices = torch.nonzero(self.remaining <= 0).flatten()
        if len(indices):
            count = len(indices)
            targets = np.zeros((count, 3), dtype=np.float32)
            targets[:, 0] = self.rng.uniform(self.config.min_vx, self.config.max_vx, count)
            targets[:, 2] = self.rng.uniform(-self.config.max_wz, self.config.max_wz, count)
            targets[self.rng.random(count) < self.config.stop_probability] = 0.0
            self.target[indices] = torch.as_tensor(targets, device=self.current.device)
            self.remaining[indices] = self.config.hold_steps
        limits = self.current.new_tensor([
            self.config.linear_acceleration * dt, 0.0,
            self.config.angular_acceleration * dt,
        ])
        self.current += torch.minimum(torch.maximum(self.target - self.current, -limits), limits)
        self.remaining -= 1
        return self.current.clone()

    def reset(self, mask: torch.Tensor) -> None:
        self.current[mask] = 0.0
        self.target[mask] = 0.0
        self.remaining[mask] = 0
