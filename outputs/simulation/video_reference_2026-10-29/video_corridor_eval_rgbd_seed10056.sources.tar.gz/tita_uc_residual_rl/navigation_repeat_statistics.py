"""Paired repeated-execution statistics with explicit missing-trial accounting."""

from __future__ import annotations

from itertools import combinations

import numpy as np

from .navigation_benchmark import path_comparison, path_length, truncate_at_goal_region


def describe_samples(values):
    samples = np.asarray(values, dtype=float)
    if samples.ndim != 1 or not np.isfinite(samples).all():
        raise ValueError("statistics require a finite one-dimensional sample")
    if not len(samples):
        return {"n": 0, "mean": None, "std": None, "median": None, "min": None, "max": None}
    return {"n": len(samples), "mean": float(np.mean(samples)),
            "std": float(np.std(samples, ddof=1)) if len(samples) > 1 else None,
            "median": float(np.median(samples)), "min": float(np.min(samples)), "max": float(np.max(samples))}


def paired_difference(first, second, *, resamples=10000, seed=20261019):
    first = np.asarray(first, dtype=float)
    second = np.asarray(second, dtype=float)
    if first.ndim != 1 or first.shape != second.shape or not np.isfinite(first).all() or not np.isfinite(second).all():
        raise ValueError("paired samples must have matching finite one-dimensional shapes")
    if type(resamples) is not int or resamples < 100:
        raise ValueError("bootstrap requires at least 100 resamples")
    differences = first - second
    result = describe_samples(differences)
    result.update(bootstrap_mean_ci95=None, bootstrap_resamples=resamples,
                  definition="first minus second; paired execution seeds resampled together; exploratory percentile interval")
    if len(differences) >= 2:
        generator = np.random.default_rng(seed)
        indices = generator.integers(0, len(differences), size=(resamples, len(differences)))
        result["bootstrap_mean_ci95"] = np.percentile(np.mean(differences[indices], axis=1), [2.5, 97.5]).tolist()
    return result


def build_repeat_statistics(review, config, scene, reference_paths, plan):
    if plan.get("schema") != "tita.navigation_repeats.v1" or plan.get("simulation_only") is not True:
        raise ValueError("expected a simulation-only repeat plan")
    algorithms, seeds = plan["algorithms"], plan["seeds"]
    if set(algorithms) != {"neupan", "dct", "rl"} or len(algorithms) != 3:
        raise ValueError("repeat plan must contain the three distinct comparison algorithms")
    if not seeds or len(seeds) != len(set(seeds)) or any(type(seed) is not int for seed in seeds):
        raise ValueError("repeat seeds must be unique nonempty integers")
    protocol, cap = plan["protocol"], float(plan["speed_cap_mps"])
    if protocol != "equal_cruise" or cap != 0.6:
        raise ValueError("this repeat report requires the requested common .6 m/s protocol")
    if any(config["protocols"][protocol][f"{algorithm}_max_mps"] != cap for algorithm in algorithms):
        raise ValueError("algorithm maximum speed permissions differ")
    reference_length = path_length(truncate_at_goal_region(reference_paths["MID"]["xy_m"], scene["goal_xy_m"], config["goal_tolerance_m"]))
    expected = {(algorithm, seed) for seed in seeds for algorithm in algorithms}
    indexed, trials = {}, []
    for result in review["results"]:
        identity = (result["algorithm"], result["seed"])
        if result["protocol"] != protocol or identity not in expected or identity in indexed:
            raise ValueError("unexpected protocol, duplicate trial or unplanned trial")
        if result["speed_cap_mps"] != cap or not result["complete"]:
            raise ValueError("completed trial has a different cap or is incomplete")
        if result["distance_m"] <= 0 or result["navigation_time_s"] <= 0:
            raise ValueError("physical trial requires positive distance and elapsed time")
        overlap = result["comparison_to_closest_branch"]["symmetric_path_overlap"]
        if not 0 <= overlap <= 1:
            raise ValueError("invalid spatial path overlap")
        raw_efficiency = reference_length / result["distance_m"]
        trial = {"algorithm": identity[0], "seed": identity[1], "success": bool(result["success"]),
                 "protocol": protocol, "speed_cap_mps": cap, "directory": result["directory"],
                 "navigation_time_s": result["navigation_time_s"], "path_length_m": result["distance_m"],
                 "reference_path_overlap_pct": overlap * 100,
                 "reference_path_efficiency_raw_ratio": raw_efficiency,
                 "reference_path_efficiency_pct": min(1.0, raw_efficiency) * 100,
                 "time_efficiency_pct": min(1.0, reference_length / cap / result["navigation_time_s"]) * 100,
                 "mechanical_energy_j": result["mechanical_energy_j"], "energy_j_per_m": result["energy_j_per_m"],
                 "mean_speed_mps": result["distance_m"] / result["navigation_time_s"],
                 "selected_branch": result["selected_branch"],
                 "command_cap_passed": result["command_cap_passed"],
                 "action_reward_audit_passed": result["action_reward_audit_passed"],
                 "planner_clock_audit_passed": result["planner_clock_audit"]["passed"],
                 "measured_speed_max_mps": result["measured_speed_max_mps"],
                 "measured_speed_exceedance_fraction": result["measured_speed_exceedance_fraction"],
                 "posture_action_histogram": result["posture_action_histogram"]}
        if not np.isfinite([value for value in trial.values() if type(value) in (float, int)]).all():
            raise ValueError("nonfinite physical metrics must not be silently dropped")
        indexed[identity] = result
        trials.append(trial)
    metrics = ("navigation_time_s", "path_length_m", "reference_path_overlap_pct", "reference_path_efficiency_pct",
               "time_efficiency_pct", "mechanical_energy_j", "energy_j_per_m", "mean_speed_mps")
    groups = {}
    for algorithm in algorithms:
        completed = [trial for trial in trials if trial["algorithm"] == algorithm]
        successful = [trial for trial in completed if trial["success"]]
        missing_seeds = [seed for seed in seeds if (algorithm, seed) not in indexed]
        actions = {str(action): sum(trial["posture_action_histogram"].get(str(action), 0) for trial in completed) for action in range(9)}
        failure_aware_efficiencies = [trial["reference_path_efficiency_pct"] if trial["success"] else 0.0 for trial in completed] + [0.0] * len(missing_seeds)
        groups[algorithm] = {
            "planned": len(seeds), "completed": len(completed), "successes": len(successful),
            "physical_failures": len(completed) - len(successful), "missing": len(missing_seeds),
            "missing_seeds": missing_seeds, "success_rate": len(successful) / len(seeds),
            "performance": {metric: describe_samples([trial[metric] for trial in successful]) for metric in metrics},
            "success_weighted_reference_path_efficiency_pct": describe_samples(failure_aware_efficiencies),
            "command_cap_pass_count": sum(trial["command_cap_passed"] for trial in completed),
            "synchronization_pass_count": sum(trial["action_reward_audit_passed"] and trial["planner_clock_audit_passed"] for trial in completed),
            "speed_exceedance_fraction_per_run": describe_samples([trial["measured_speed_exceedance_fraction"] for trial in completed]),
            "measured_speed_max_mps": max((trial["measured_speed_max_mps"] for trial in completed), default=None),
            "posture_action_totals": actions,
            "successful_branch_counts": {branch: sum(trial["selected_branch"] == branch for trial in successful) for branch in ("north", "south")},
        }
    between_algorithms, differences = [], []
    for first, second in combinations(algorithms, 2):
        paired_seeds = [seed for seed in seeds if (first, seed) in indexed and (second, seed) in indexed
                        and indexed[first, seed]["success"] and indexed[second, seed]["success"]]
        path_comparisons = [path_comparison(indexed[first, seed]["trajectory_xy_m"], indexed[second, seed]["trajectory_xy_m"],
                                            spacing_m=config["path_sample_spacing_m"], tolerance_m=config["path_overlap_tolerance_m"])
                            for seed in paired_seeds]
        overlaps = [comparison["symmetric_path_overlap"] * 100 for comparison in path_comparisons]
        between_algorithms.append({"algorithms": [first, second], "paired_seeds": paired_seeds,
                                   "overlap_pct": describe_samples(overlaps), "per_seed_overlap_pct": dict(zip(paired_seeds, overlaps)),
                                   "symmetric_mean_separation_cm": describe_samples([comparison["symmetric_chamfer_m"] * 100 for comparison in path_comparisons])})
        differences.append({"first": first, "second": second, "paired_seeds": paired_seeds,
                            **paired_difference([indexed[first, seed]["navigation_time_s"] for seed in paired_seeds],
                                                [indexed[second, seed]["navigation_time_s"] for seed in paired_seeds],
                                                resamples=plan["bootstrap_resamples"], seed=plan["bootstrap_seed"])})
    repeatability = {}
    for algorithm in algorithms:
        records = [indexed[algorithm, seed] for seed in seeds if (algorithm, seed) in indexed]
        starts = np.asarray([record["trajectory_xy_m"][0] for record in records], dtype=float)
        repeatability[algorithm] = {
            "n": len(records),
            "start_xy_max_range_m": float(np.max(np.ptp(starts, axis=0))) if len(records) else None,
            "navigation_time_resolution_s": 0.02,
            "successful_time_range_s": None if groups[algorithm]["performance"]["navigation_time_s"]["n"] == 0 else
                groups[algorithm]["performance"]["navigation_time_s"]["max"] - groups[algorithm]["performance"]["navigation_time_s"]["min"],
            "scope": "first recorded planar positions and time variation only; no evidence of randomized scenario coverage",
        }
    return {"schema": "tita.navigation_repeat_statistics.v1", "simulation_only": True,
            "plan": plan, "planned_trials": len(expected), "completed_trials": len(trials),
            "successful_trials": sum(trial["success"] for trial in trials), "algorithm_statistics": groups,
            "missing_trials": [{"algorithm": algorithm, "seed": seed} for seed in seeds for algorithm in algorithms if (algorithm, seed) not in indexed],
            "deployment_or_incomplete_evidence": review.get("skipped_incomplete_runs", []),
            "common_reference_length_to_goal_region_m": reference_length,
            "between_algorithm_path_overlap": between_algorithms, "paired_navigation_time_differences_s": differences,
            "execution_repeatability": repeatability,
            "trials": sorted(trials, key=lambda trial: (seeds.index(trial["seed"]), algorithms.index(trial["algorithm"]))),
            "definitions": {
                "dispersion": "sample standard deviation (ddof=1); undefined for fewer than two trials",
                "performance_population": "successful completed trials; all planned outcomes remain in success denominator",
                "reference_overlap": "closest legal offline branch, arc-length symmetric coverage at common tolerance; not obstacle IoU",
                "between_algorithm_overlap": "same-seed successful executed trajectories; distinct from reference-path adherence",
                "path_efficiency": "min(1, common conservative Astar length to shared goal region / executed distance); raw ratios retained, not certified geodesic SPL",
                "time_efficiency": "min(1, common reference length / common speed cap / successful navigation time)",
                "energy": "integral of absolute joint mechanical power, not measured battery electricity",
                "scope": plan["scope"],
            }}
