from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path


@dataclass(frozen=True)
class ValidatedStepLimits:
    max_step_m: float
    speeds_mps: tuple[float, ...]
    evidence_sha256: tuple[str, ...]
    simulation_only: bool = True


def load_validated_step_limits(reports, asset, official_checkpoint, residual_checkpoint, velocity_calibration,
                               convex_cylinder_collisions=False):
    if len(reports) < 2:
        raise ValueError("step execution requires at least two independent geometry probes")
    expected = {name: hashlib.sha256(Path(path).read_bytes()).hexdigest() for name, path in (
        ("asset", asset), ("checkpoint", official_checkpoint), ("residual_checkpoint", residual_checkpoint),
        ("velocity_calibration", velocity_calibration))}
    heights, geometries, evidence = [], set(), []
    common_speeds = None
    for source in reports:
        content = Path(source).read_bytes()
        report = json.loads(content)
        if report.get("convex_cylinder_collisions", False) != convex_cylinder_collisions:
            raise ValueError("step validation cylinder collision backend mismatch")
        if report.get("backend") != "real_isaac_sim_full_tower_biped" or report.get("assist") is not False:
            raise ValueError("step validation requires actual unassisted biped physics")
        if report.get("acceptance") != "both_wheels_fully_on_tread_then_one_second_stopped_grounded_upright_height_tracked":
            raise ValueError("step validation lacks strict stopped-contact acceptance")
        for name, digest in expected.items():
            if report.get("input_artifacts", {}).get(name, {}).get("sha256") != digest:
                raise ValueError(f"step validation {name} mismatch")
        cases = report.get("cases", [])
        if not cases or any(case.get("mode") != "HIGH" or not case.get("success") or case.get("hard_failure")
                            or case.get("hard_reasons") for case in cases) or report.get("failures"):
            raise ValueError("every accepted speed case must pass without a hard failure")
        speeds = {round(float(case["speed_mps"]), 6) for case in cases}
        height = float(report["height_m"])
        if not math.isfinite(height) or height <= 0. or any(not math.isfinite(speed) or speed <= 0. for speed in speeds):
            raise ValueError("validated heights and speeds must be finite and positive")
        heights.append(height)
        geometries.add((height, report["start_x_m"], report["step_width_m"], report["approach_yaw_magnitude_rad"]))
        common_speeds = speeds if common_speeds is None else common_speeds.intersection(speeds)
        evidence.append(hashlib.sha256(content).hexdigest())
    if len(geometries) < 2 or not common_speeds:
        raise ValueError("step probes need distinct geometry and a common validated execution speed")
    return ValidatedStepLimits(min(heights), tuple(sorted(common_speeds)), tuple(evidence))
