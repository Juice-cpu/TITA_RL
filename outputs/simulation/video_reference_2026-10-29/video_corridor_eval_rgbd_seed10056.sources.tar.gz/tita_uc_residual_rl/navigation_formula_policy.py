"""Candidate-wise masked PPO contract, separate from legacy 9-action weights."""

from __future__ import annotations

from dataclasses import asdict
from pathlib import Path

import numpy as np
import torch
from torch import nn

from .navigation_formula import (
    ACTIONS_PER_PATH,
    FORMULA_VERSION,
    FormulaConfig,
    FormulaEvaluation,
    decode_action,
)


FEATURE_NAMES = (
    "present", "feasible", "energy_normalized", "time_normalized", "length_normalized",
    "clearance_cost", "posture_switch", "Pclr", "Ph", "Patt", "objective",
    "posture_LOW", "posture_MID", "posture_HIGH", "speed_ratio", "safe_stop",
)


def candidate_features(evaluations: tuple[FormulaEvaluation, ...], config: FormulaConfig,
                       path_capacity: int) -> tuple[np.ndarray, np.ndarray]:
    if isinstance(path_capacity, bool) or not isinstance(path_capacity, int) or path_capacity <= 0:
        raise ValueError("path_capacity must be a positive integer")
    if not evaluations or len(evaluations) % ACTIONS_PER_PATH:
        raise ValueError("expected a complete ordered candidate table")
    path_count = len(evaluations) // ACTIONS_PER_PATH
    if path_count > path_capacity:
        raise ValueError("candidate paths exceed the model capacity; never truncate safety inputs")
    count = ACTIONS_PER_PATH * path_capacity
    features = np.zeros((count + 1, len(FEATURE_NAMES)), dtype=np.float32)
    masks = np.zeros(count + 1, dtype=np.bool_)
    for action_id, item in enumerate(evaluations):
        expected = decode_action(action_id, path_count)
        if item.action_id != action_id or (item.path_index, item.posture_index, item.speed_index) != expected:
            raise ValueError("candidate table must be ordered by the independent action contract")
        if not item.feasible:
            features[action_id, 0] = 1.0
            continue
        vector = (
            1.0, 1.0, item.energy_j / config.energy_ref_j, item.time_s / config.time_ref_s,
            item.length_m / config.length_ref_m, item.clearance_cost, item.switch_cost,
            item.penalty_clearance, item.penalty_height, item.penalty_attitude, item.objective,
            float(item.posture_index == 0), float(item.posture_index == 1),
            float(item.posture_index == 2), (0.4, 0.7, 1.0)[item.speed_index], 0.0,
        )
        with np.errstate(over="ignore"):
            features[action_id] = vector
        if not np.isfinite(features[action_id]).all():
            raise ValueError("candidate features exceed finite float32 range")
        masks[action_id] = True
    masks[-1] = not masks[:-1].any()
    features[-1, (0, 1, -1)] = (1.0, float(masks[-1]), 1.0)
    return features, masks


class FormulaActorCritic(nn.Module):
    """Shared candidate encoder: path slots are not bound to robot postures."""

    def __init__(self, path_capacity: int):
        super().__init__()
        if isinstance(path_capacity, bool) or not isinstance(path_capacity, int) or path_capacity <= 0:
            raise ValueError("path_capacity must be a positive integer")
        self.path_capacity = path_capacity
        self.action_count = ACTIONS_PER_PATH * path_capacity + 1
        self.encoder = nn.Sequential(nn.Linear(len(FEATURE_NAMES), 128), nn.ELU(), nn.Linear(128, 64), nn.ELU())
        self.actor = nn.Linear(64, 1)
        self.critic = nn.Linear(64, 1)

    def forward(self, observations: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        if observations.shape[-2:] != (self.action_count, len(FEATURE_NAMES)):
            raise ValueError("incorrect formula feature layout")
        if not torch.isfinite(observations).all():
            raise ValueError("formula features must be finite")
        hidden = self.encoder(observations)
        valid = observations[..., 1:2]
        pooled = (hidden * valid).sum(dim=-2) / valid.sum(dim=-2).clamp_min(1.0)
        return self.actor(hidden).squeeze(-1), self.critic(pooled).squeeze(-1)

    def distribution(self, observations: torch.Tensor, valid_actions: torch.Tensor):
        logits, values = self(observations)
        valid_actions = valid_actions.to(device=logits.device, dtype=torch.bool)
        if valid_actions.shape != logits.shape or torch.any(~valid_actions.any(dim=-1)):
            raise ValueError("formula distribution requires a feasible action or safe stop")
        if not torch.equal(valid_actions, observations[..., 1].to(dtype=torch.bool)):
            raise ValueError("formula feature and safety masks disagree")
        return torch.distributions.Categorical(logits=logits.masked_fill(~valid_actions, torch.finfo(logits.dtype).min)), values

    @torch.no_grad()
    def act(self, observations, valid_actions, deterministic: bool = False):
        distribution, values = self.distribution(observations, valid_actions)
        actions = distribution.logits.argmax(dim=-1) if deterministic else distribution.sample()
        return actions, distribution.log_prob(actions), values, distribution.entropy()


def formula_reward(evaluations: tuple[FormulaEvaluation, ...], action_id: int) -> float:
    """Reward for a selected, predicted whole-route action, not measured execution."""

    if not 0 <= action_id < len(evaluations) or not evaluations[action_id].feasible:
        raise ValueError("unsafe/missing actions and stop transitions cannot enter PPO updates")
    reward = evaluations[action_id].reward
    if reward is None or not np.isfinite(reward):
        raise ValueError("selected formula reward must be finite")
    return float(reward)


def save_formula_checkpoint(path: str | Path, model: FormulaActorCritic, config: FormulaConfig,
                            *, optimizer_state: dict | None = None,
                            metadata: dict | None = None) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    torch.save({
        "formula_version": FORMULA_VERSION,
        "feature_names": FEATURE_NAMES,
        "path_capacity": model.path_capacity,
        "model_state_dict": model.state_dict(),
        "formula_config": asdict(config),
        "optimizer_state_dict": optimizer_state,
        "reward_semantics": "predicted_whole_route_not_measured_execution",
        "metadata": dict(metadata or {}),
    }, target)


def load_formula_checkpoint(path: str | Path, *, device: str = "cpu"):
    payload = torch.load(path, map_location=device, weights_only=True)
    if payload.get("formula_version") != FORMULA_VERSION or tuple(payload.get("feature_names", ())) != FEATURE_NAMES:
        raise ValueError("incompatible formula/feature version; legacy 9-action policies cannot be reused")
    config = FormulaConfig.from_dict(payload["formula_config"])
    model = FormulaActorCritic(payload["path_capacity"]).to(device)
    model.load_state_dict(payload["model_state_dict"])
    model.eval()
    return model, config, payload
