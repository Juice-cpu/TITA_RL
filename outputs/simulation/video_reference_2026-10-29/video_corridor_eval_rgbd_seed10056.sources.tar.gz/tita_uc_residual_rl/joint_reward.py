from __future__ import annotations

from dataclasses import dataclass
import math


@dataclass(frozen=True)
class JointRewardWeights:
    progress: float = 8.0
    time: float = 0.08
    path_length: float = 0.15
    energy: float = 0.002
    risk: float = 0.8
    clearance: float = 2.0
    attitude: float = 0.5
    mode_switch: float = 0.25
    rapid_switch: float = 1.0
    path_switch: float = 0.05
    success: float = 20.0
    failure: float = 25.0


def navigation_terminal_outcome(reached, hard_failure, simulator_truncated=False,
                                execution_timeout=False, nominal_clearance_m=float("inf"),
                                pedestrian_contact_force_n=0., horizon=False):
    if math.isnan(nominal_clearance_m) or not math.isfinite(pedestrian_contact_force_n) or pedestrian_contact_force_n < 0.:
        raise ValueError("terminal navigation feedback must be physically valid")
    unsafe = bool(hard_failure or simulator_truncated or execution_timeout
                  or nominal_clearance_m < 0. or pedestrian_contact_force_n > 1.)
    success = bool(reached) and not unsafe
    failure = unsafe or bool(horizon) and not success
    return success, failure, success or failure


def joint_reward_terms(progress_m, dt_s, traveled_m, power_w, pedestrian_risk, clearance_m,
                       roll_rad, pitch_rad, mode_switch=False, rapid_switch=False,
                       path_switch=False, success=False, failure=False, weights=None):
    weights = weights or JointRewardWeights()
    values = (progress_m, dt_s, traveled_m, power_w, pedestrian_risk, roll_rad, pitch_rad)
    if not all(math.isfinite(value) for value in values) or dt_s <= 0 or min(traveled_m, power_w) < 0:
        raise ValueError("upper reward feedback must be finite and physically valid")
    if not 0 <= pedestrian_risk <= 1 or math.isnan(clearance_m):
        raise ValueError("invalid risk or clearance feedback")
    return {
        "progress": weights.progress * progress_m,
        "time": -weights.time * dt_s,
        "path_length": -weights.path_length * traveled_m,
        "energy": -weights.energy * power_w * dt_s,
        "risk": -weights.risk * pedestrian_risk * dt_s,
        "clearance": -weights.clearance * max(.15 - clearance_m, 0.) * dt_s,
        "attitude": -weights.attitude * (roll_rad ** 2 + pitch_rad ** 2) * dt_s,
        "mode_switch": -weights.mode_switch * bool(mode_switch),
        "rapid_switch": -weights.rapid_switch * bool(rapid_switch),
        "path_switch": -weights.path_switch * bool(path_switch),
        "success": weights.success * bool(success),
        "failure": -weights.failure * bool(failure),
    }
