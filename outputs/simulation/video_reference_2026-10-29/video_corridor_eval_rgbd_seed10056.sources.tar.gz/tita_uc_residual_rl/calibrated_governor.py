from __future__ import annotations

import math

import torch

from .velocity_calibration import ANGULAR_FIELDS, GOVERNOR_FIELDS, POSTURES, validate_governor_profiles


class BatchedCalibratedGovernor:
    def __init__(self, profiles: dict, num_envs: int, device: str | torch.device, transition_time_s: float = 1.5) -> None:
        if num_envs < 1 or not math.isfinite(transition_time_s) or transition_time_s <= 0:
            raise ValueError("governor dimensions and transition time must be positive")
        validated = validate_governor_profiles(profiles)
        self.fields = GOVERNOR_FIELDS + ANGULAR_FIELDS
        self.table = torch.tensor([[validated[name][field] for field in self.fields] for name in POSTURES], device=device)
        self.parameters = self.table[1].repeat(num_envs, 1)
        self.transition_time_s = transition_time_s

    def reset(self, mask: torch.Tensor) -> None:
        if mask.shape != (len(self.parameters),) or mask.dtype != torch.bool:
            raise ValueError("governor reset requires one boolean per environment")
        self.parameters[mask] = self.table[1]

    def command(self, requested: torch.Tensor, measured: torch.Tensor, posture_weights: torch.Tensor, dt: float) -> torch.Tensor:
        expected = (len(self.parameters), 3)
        if not math.isfinite(dt) or dt <= 0:
            raise ValueError("governor time step must be finite and positive")
        if any(value.shape != expected or not torch.isfinite(value).all() for value in (requested, measured, posture_weights)):
            raise ValueError("governor inputs must be aligned finite Nx3 tensors")
        if torch.any(posture_weights < 0) or not torch.allclose(posture_weights.sum(dim=1), torch.ones_like(posture_weights[:, 0]), atol=1e-5):
            raise ValueError("posture weights must be probabilities")
        self.parameters.lerp_(posture_weights @ self.table, min(dt / self.transition_time_s, 1.0))
        values = {field: self.parameters[:, index] for index, field in enumerate(self.fields)}
        linear = requested[:, :2] * values["linear_scale"][:, None]
        linear[:, 0] += values["linear_bias"] + values["linear_kp"] * (requested[:, 0] - measured[:, 0])
        linear[:, 1] += values["lateral_kp"] * (requested[:, 1] - measured[:, 1])
        scale = (values["max_linear_command"] / torch.linalg.vector_norm(linear, dim=1).clamp_min(1e-8)).clamp(max=1.0)
        linear *= scale[:, None]
        yaw = values["angular_bias"] + values["angular_scale"] * requested[:, 2] + values["angular_kp"] * (requested[:, 2] - measured[:, 2])
        yaw = torch.minimum(torch.maximum(yaw, -values["max_angular_command"]), values["max_angular_command"])
        return torch.cat((linear, yaw[:, None]), dim=1)


def constrain_navigation_command(command: torch.Tensor, posture_weights: torch.Tensor, speed_limits: torch.Tensor,
                                 stop_mask: torch.Tensor | None = None) -> torch.Tensor:
    limited = command.clone()
    allowed = posture_weights @ speed_limits
    speed = torch.linalg.vector_norm(limited[:, :2], dim=1)
    limited[:, :2] *= (allowed / speed.clamp_min(1e-8)).clamp(max=1.0)[:, None]
    if stop_mask is not None:
        limited[stop_mask] = 0.0
    return limited
