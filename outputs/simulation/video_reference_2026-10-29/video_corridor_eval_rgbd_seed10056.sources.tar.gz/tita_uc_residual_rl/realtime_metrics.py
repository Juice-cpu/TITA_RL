"""Join same-host decision telemetry by episode, decision and command packet."""

from __future__ import annotations

from collections import defaultdict
import json
from pathlib import Path

import numpy as np


def timing_statistics(values):
    samples = np.asarray(values, dtype=float)
    if samples.ndim != 1 or not len(samples) or not np.isfinite(samples).all() or (samples < 0).any():
        raise ValueError("timing statistics require finite nonnegative samples")
    return {"n": int(len(samples)), "mean": float(samples.mean()),
            "p50": float(np.percentile(samples, 50)), "p95": float(np.percentile(samples, 95)),
            "p99": float(np.percentile(samples, 99)), "max": float(samples.max())}


def _identity(record):
    return record["episode_id"], record["decision_id"]


def _unique(records, key):
    indexed = {}
    for record in records:
        identity = key(record)
        if identity in indexed:
            raise ValueError(f"duplicate timing identity: {identity}")
        indexed[identity] = record
    return indexed


def _milliseconds(start, end):
    if type(start) is not int or type(end) is not int or end < start:
        raise ValueError("missing timestamp or reversed cross-process time order")
    return (end - start) / 1_000_000


def analyze_timing_events(events):
    grouped = defaultdict(list)
    for record in events:
        grouped[record["event"]].append(record)
    clocks = grouped["clock_identity"]
    if not clocks or len({(record["hostname"], record["boot_id"], record["clock"]) for record in clocks}) != 1:
        raise ValueError("timing traces do not share a verified same-host monotonic clock")
    if not {"isaac", "upper", "gate", "bridge_ros", "planner"} <= {record["component"] for record in clocks}:
        raise ValueError("missing timing component")
    published = _unique(grouped["upper_decision_published"], _identity)
    inferred = _unique(grouped["upper_inference"], _identity)
    gates = _unique(grouped["gate_decision_received"], _identity)
    sent = _unique(grouped["command_sent"], lambda record: record["command_sequence"])
    received = _unique(grouped["command_received"], lambda record: record["command_sequence"])
    boundaries = _unique(grouped["boundary_ready"], lambda record: (record["episode_id"], record["start_sequence"]))
    applied = {}
    for record in sorted(grouped["control_input_applied"], key=lambda item: item["monotonic_ns"]):
        applied.setdefault(_identity(record), record)
    if not published or set(published) != set(inferred) or set(published) != set(applied) or set(published) != set(gates):
        raise ValueError("missing or unmatched inference/publication/gate/application decision")
    decisions = []
    for identity, publication in sorted(published.items(), key=lambda item: item[1]["monotonic_ns"]):
        inference, application = inferred[identity], applied[identity]
        if inference.get("start_sequence", publication["start_sequence"]) != publication["start_sequence"]:
            raise ValueError("inference and publication refer to different source boundaries")
        packet = application["command_sequence"]
        if packet not in sent or packet not in received:
            raise ValueError("applied command packet has no matched send/receive record")
        if _identity(sent[packet]) != identity or _identity(received[packet]) != identity:
            raise ValueError("applied packet belongs to another decision")
        if application["control_step"] - 1 != publication["start_sequence"]:
            raise ValueError("decision was not first applied at its acknowledged boundary")
        boundary_key = (identity[0], publication["start_sequence"])
        if boundary_key not in boundaries:
            raise ValueError("missing source boundary timestamp")
        source = publication["source_timing"]
        boundary_ns = boundaries[boundary_key]["monotonic_ns"]
        applied_ns = application["monotonic_ns"]
        publish_ns = publication["atomic_publish_start_ns"]
        row = {"episode_id": identity[0], "decision_id": identity[1],
               "action_id": publication["action_id"], "start_sequence": publication["start_sequence"],
               "first_applied_command_sequence": packet,
               "upper_inference_ms": _milliseconds(inference["start_ns"], inference["end_ns"]),
               "decision_callback_to_publish_ms": _milliseconds(publication["callback_start_ns"], publish_ns),
               "decision_publish_to_gate_ms": _milliseconds(publish_ns, gates[identity]["monotonic_ns"]),
               "decision_publish_to_apply_ms": _milliseconds(publish_ns, applied_ns),
               "gate_to_used_packet_send_ms": _milliseconds(gates[identity]["monotonic_ns"], sent[packet]["monotonic_ns"]),
               "used_packet_send_to_receive_ms": _milliseconds(sent[packet]["monotonic_ns"], received[packet]["monotonic_ns"]),
               "used_packet_receive_to_apply_ms": _milliseconds(received[packet]["monotonic_ns"], applied_ns),
               "observation_snapshot_to_apply_ms": _milliseconds(source["state_snapshot_start_ns"], applied_ns),
               "observation_snapshot_to_upper_receive_ms": _milliseconds(source["state_snapshot_start_ns"], publication["feedback_received_ns"]),
               "feedback_receive_to_callback_ms": _milliseconds(publication["feedback_received_ns"], publication["callback_start_ns"]),
               "boundary_ready_to_callback_ms": _milliseconds(boundary_ns, publication["callback_start_ns"]),
               "boundary_ready_to_apply_ms": _milliseconds(boundary_ns, applied_ns)}
        _milliseconds(publication["callback_start_ns"], inference["start_ns"])
        _milliseconds(inference["end_ns"], publish_ns)
        _milliseconds(boundary_ns, source["state_snapshot_start_ns"])
        _milliseconds(source["state_snapshot_start_ns"], source["ros_feedback_publish_ns"])
        _milliseconds(source["ros_feedback_publish_ns"], publication["feedback_received_ns"])
        decisions.append(row)
    input_events = sorted(grouped["control_input_applied"], key=lambda record: record["monotonic_ns"])
    finish_events = sorted(grouped["control_step_finished"], key=lambda record: record["monotonic_ns"])
    planner_events = sorted(grouped["planner_solve"], key=lambda record: record["start_ns"])
    active_wall_s = _milliseconds(input_events[0]["monotonic_ns"], finish_events[-1]["monotonic_ns"]) / 1000
    simulated_s = finish_events[-1]["sim_time_s"] - input_events[0]["sim_time_s"]
    event_periods = {
        "upper_application": np.diff([record["monotonic_ns"] for record in applied.values()]) / 1_000_000,
        "lower_control_input": np.diff([record["monotonic_ns"] for record in input_events]) / 1_000_000,
        "fresh_local_planning": np.diff([record["start_ns"] for record in planner_events]) / 1_000_000,
    }
    periods = {name: timing_statistics(values) for name, values in event_periods.items()}
    durations = {"lower_actor_ms": [_milliseconds(record["start_ns"], record["end_ns"]) for record in grouped["lower_actor"]],
                 "local_planning_ms": [_milliseconds(record["start_ns"], record["end_ns"]) for record in planner_events]}
    if active_wall_s <= 0 or simulated_s <= 0:
        raise ValueError("active navigation duration must be positive")
    return {"clock_identity": {name: clocks[0][name] for name in ("hostname", "boot_id", "clock")},
            "decisions": decisions, "duration_samples": durations,
            "decision_statistics": {name: timing_statistics([row[name] for row in decisions])
                                    for name in decisions[0] if name.endswith("_ms")},
            "duration_statistics": {name: timing_statistics(values) for name, values in durations.items()},
            "wall_period_ms": periods,
            "wall_effective_hz": {name: 1000 / values["mean"] for name, values in periods.items()},
            "active_navigation_wall_s": active_wall_s, "active_navigation_sim_s": simulated_s,
            "active_navigation_rtf": simulated_s / active_wall_s,
            "control_samples": len(input_events), "planner_solves": len(planner_events),
            "audit_passed": True}


def analyze_timing_directory(directory):
    events = []
    for path in sorted(Path(directory).glob("*.jsonl")):
        events.extend(json.loads(line) for line in path.read_text().splitlines() if line.strip())
    return analyze_timing_events(events)
