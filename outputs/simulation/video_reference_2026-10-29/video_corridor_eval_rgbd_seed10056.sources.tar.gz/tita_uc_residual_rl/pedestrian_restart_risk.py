import math

import numpy as np


def observed_restart_velocity(person, context, stationary_speed_mps=.05, speed_margin_mps=.05):
    if (not all(math.isfinite(value) for value in (stationary_speed_mps, speed_margin_mps))
            or stationary_speed_mps <= 0. or speed_margin_mps < 0.):
        raise ValueError('restart prediction requires positive stationary threshold and nonnegative speed margin')
    if context is None or math.hypot(person.vx, person.vy) > stationary_speed_mps:
        return None
    if context.restart_axis_source == 'unavailable':
        return None
    previous = np.asarray([context.last_motion_vx, context.last_motion_vy] if context.restart_axis_source == 'legacy'
                          else [context.restart_axis_vx, context.restart_axis_vy], dtype=float)
    speed = float(np.linalg.norm(previous))
    if not np.isfinite(previous).all():
        raise ValueError('observed restart history must be finite')
    if speed <= stationary_speed_mps:
        return None
    return previous * ((speed + speed_margin_mps) / speed)


def observed_moving_velocity_segment(person, context, stationary_speed_mps=.05, speed_margin_mps=.05):
    if (not all(math.isfinite(value) for value in (stationary_speed_mps, speed_margin_mps))
            or stationary_speed_mps <= 0. or speed_margin_mps < 0.):
        raise ValueError('moving velocity prediction requires valid stationary threshold and speed margin')
    velocity = np.asarray([person.vx, person.vy], dtype=float)
    if not np.isfinite(velocity).all():
        raise ValueError('observed velocity must be finite')
    speed = float(np.linalg.norm(velocity))
    if context is None or context.restart_axis_source == 'unavailable' or speed <= stationary_speed_mps:
        return None
    previous = np.asarray([context.last_motion_vx, context.last_motion_vy] if context.restart_axis_source == 'legacy'
                          else [context.restart_axis_vx, context.restart_axis_vy], dtype=float)
    if not np.isfinite(previous).all():
        raise ValueError('observed moving velocity history must be finite')
    previous_speed = float(np.linalg.norm(previous))
    if previous_speed <= stationary_speed_mps or abs(float(previous @ velocity)) < .85 * previous_speed * speed:
        return None
    fast = velocity * (max(previous_speed, speed) + speed_margin_mps) / speed
    half_interval = (fast - velocity) / 2.
    if np.linalg.norm(half_interval) <= 1e-12:
        return None
    return (velocity + fast) / 2., half_interval


def minimum_restart_tube_distance(times, robot_positions, person_xy, person_velocity_xy, restart_velocity_xy):
    times = np.asarray(times, dtype=float)
    robot = np.asarray(robot_positions, dtype=float)
    center = np.asarray(person_xy, dtype=float)
    velocity = np.asarray(person_velocity_xy, dtype=float)
    restart = np.asarray(restart_velocity_xy, dtype=float)
    if (times.ndim != 1 or len(times) < 2 or robot.shape != (len(times), 2)
            or any(value.shape != (2,) for value in (center, velocity, restart))
            or not all(np.isfinite(value).all() for value in (times, robot, center, velocity, restart))
            or times[0] < 0. or (np.diff(times) <= 0.).any()):
        raise ValueError('restart tube requires increasing nonnegative times and aligned finite planar geometry')
    speed = float(np.linalg.norm(restart))
    if speed <= 0.:
        raise ValueError('restart tube requires a nonzero observed motion axis')
    axis = restart / speed
    relative = robot - center - times[:, None] * velocity
    axial = relative @ axis
    knots = [times]
    for sign in (-1., 1.):
        residual = axial + sign * speed * times
        differences = np.diff(residual)
        fractions = np.divide(-residual[:-1], differences, out=np.full(len(differences), np.nan),
                              where=np.abs(differences) > 1e-15)
        valid = (fractions > 0.) & (fractions < 1.)
        knots.append(times[:-1][valid] + fractions[valid] * np.diff(times)[valid])
    evaluation_times = np.unique(np.concatenate(knots))
    positions = np.column_stack([np.interp(evaluation_times, times, robot[:, axis_index]) for axis_index in range(2)])
    relative = positions - center - evaluation_times[:, None] * velocity
    displacement = relative - np.clip(relative @ axis, -speed * evaluation_times, speed * evaluation_times)[:, None] * axis
    movement = np.diff(displacement, axis=0)
    squared = np.sum(movement * movement, axis=1)
    fractions = np.divide(-np.sum(displacement[:-1] * movement, axis=1), squared,
                          out=np.zeros_like(squared), where=squared > 0.)
    closest = displacement[:-1] + np.clip(fractions, 0., 1.)[:, None] * movement
    return float(np.linalg.norm(closest, axis=1).min())
