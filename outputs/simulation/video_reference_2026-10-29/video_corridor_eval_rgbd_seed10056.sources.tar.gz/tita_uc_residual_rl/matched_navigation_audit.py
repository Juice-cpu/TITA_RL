from __future__ import annotations


CONTROLLED_FIELDS = (
    'seed', 'backend', 'convex_cylinder_collisions', 'goal_xy_m', 'terrain', 'execution_config',
    'mode_command_limits', 'upper_safety_config', 'astar_config', 'physics_device',
    'neupan_robot_vertices_xy_m', 'runtime_versions', 'steps', 'upper_cost_prior',
)


def invocation_options(invocation):
    if not isinstance(invocation, list) or not invocation:
        raise ValueError('missing execution invocation')
    options = {}
    flag = None
    for value in invocation[1:]:
        if value.startswith('--'):
            if value in options:
                raise ValueError('repeated execution option')
            flag = value
            options[flag] = []
        elif flag is None:
            raise ValueError('execution invocation has an unbound value')
        else:
            options[flag].append(value)
    return options


def audit_matched_navigation(first, second, comparison='pedestrians'):
    if comparison not in ('pedestrians', 'analytic_actor', 'upper_checkpoint'):
        raise ValueError('unknown controlled comparison')
    differences, missing = [], []
    for name in CONTROLLED_FIELDS:
        if name not in first or name not in second:
            missing.append(name)
        elif first[name] != second[name]:
            differences.append(name)
    sources = [report.get('execution_source_provenance', {}).get('files_sha256') for report in (first, second)]
    if not all(sources):
        missing.append('execution_source_provenance')
    elif sources[0] != sources[1]:
        differences.append('execution_source_provenance')
    ignored_inputs = {'pedestrian_scenario'} if comparison == 'pedestrians' else {'upper_policy'} if comparison == 'upper_checkpoint' else set()
    artifacts = [report.get('input_artifacts', {}) for report in (first, second)]
    if not all(artifacts):
        missing.append('input_artifacts')
    else:
        hashes = [{name: value.get('sha256') for name, value in inputs.items() if name not in ignored_inputs}
                  for inputs in artifacts]
        if hashes[0] != hashes[1] or any(value is None for inputs in hashes for value in inputs.values()):
            differences.append('input_artifacts')
    ignored_options = {'--output'}
    ignored_options |= ({'--pedestrian-scenario', '--dynamic-pedestrian'} if comparison == 'pedestrians'
                        else {'--analytic-baseline'} if comparison == 'analytic_actor' else {'--upper-policy'})
    try:
        options = [{name: value for name, value in invocation_options(report.get('invocation')).items()
                    if name not in ignored_options} for report in (first, second)]
        if options[0] != options[1]:
            differences.append('invocation')
    except ValueError:
        missing.append('invocation')
    keys = ('tolerance_m', 'hold_s', 'maximum_speed_mps', 'maximum_yaw_rate_radps', 'maximum_attitude_rad')
    arrivals = [report.get('goal_acceptance', {}) for report in (first, second)]
    if any(any(key not in arrival for key in keys) for arrival in arrivals):
        missing.append('goal_acceptance')
    elif any(arrivals[0][key] != arrivals[1][key] for key in keys) or arrivals[0].get('braking_entry_margin_m', 0.) != arrivals[1].get('braking_entry_margin_m', 0.):
        differences.append('goal_acceptance')
    return {'schema': 'tita.matched_navigation_protocol_audit.v1', 'comparison': comparison,
            'status': 'mismatched' if differences else 'insufficient_evidence' if missing else 'passed',
            'uncontrolled_differences': differences, 'missing_evidence': missing,
            'scope': 'Protocol matching only; does not certify execution acceptance or statistical superiority.'}
