"""Geometry contract for the first narrow-versus-wide route scene."""

from __future__ import annotations

from dataclasses import dataclass
import math


@dataclass(frozen=True)
class RouteBox:
    """One axis-aligned collision box in a route-choice environment."""

    name: str
    center: tuple[float, float, float]
    size: tuple[float, float, float]


@dataclass(frozen=True)
class RouteChoiceConfig:
    """Small deterministic scene with a short narrow and long wide branch."""

    wall_start_x_m: float = 0.50
    wall_end_x_m: float = 6.00
    obstacle_start_x_m: float = 2.00
    obstacle_length_m: float = 2.00
    obstacle_half_width_m: float = 0.40
    narrow_width_m: float = 0.65
    wide_width_m: float = 1.60
    wall_height_m: float = 0.80
    wall_thickness_m: float = 0.10
    start_x_m: float = 0.0
    goal_x_m: float = 5.50

    def __post_init__(self) -> None:
        positive = (
            self.obstacle_length_m,
            self.obstacle_half_width_m,
            self.narrow_width_m,
            self.wide_width_m,
            self.wall_height_m,
            self.wall_thickness_m,
        )
        if any(value <= 0.0 for value in positive):
            raise ValueError("route-choice dimensions must be positive")
        if self.wall_end_x_m <= self.wall_start_x_m:
            raise ValueError("route-choice wall end must be after its start")
        if self.obstacle_start_x_m <= self.start_x_m:
            raise ValueError("route-choice obstacle must be after the start")
        if self.obstacle_end_x_m >= self.goal_x_m:
            raise ValueError("route-choice goal must be after the obstacle")
        if self.goal_x_m > self.wall_end_x_m:
            raise ValueError("route-choice goal must remain inside the outer walls")
        if self.wide_width_m <= self.narrow_width_m:
            raise ValueError("wide route must be wider than narrow route")

    @property
    def obstacle_end_x_m(self) -> float:
        return self.obstacle_start_x_m + self.obstacle_length_m

    @property
    def narrow_center_y_m(self) -> float:
        return self.obstacle_half_width_m + self.narrow_width_m / 2.0

    @property
    def wide_center_y_m(self) -> float:
        return -(self.obstacle_half_width_m + self.wide_width_m / 2.0)

    def nominal_route_length_m(self, branch: str) -> float:
        """Return the three-segment centerline length for one branch."""

        centers = {"narrow": self.narrow_center_y_m, "wide": self.wide_center_y_m}
        try:
            center_y = centers[branch]
        except KeyError as exc:
            raise ValueError("branch must be 'narrow' or 'wide'") from exc
        approach = math.hypot(self.obstacle_start_x_m - self.start_x_m, center_y)
        departure = math.hypot(self.goal_x_m - self.obstacle_end_x_m, center_y)
        return approach + self.obstacle_length_m + departure


def route_choice_boxes(
    origin_xy: tuple[float, float], config: RouteChoiceConfig | None = None
) -> tuple[RouteBox, ...]:
    """Return the world-space boxes making one route-choice environment."""

    cfg = config or RouteChoiceConfig()
    origin_x, origin_y = origin_xy
    wall_length = cfg.wall_end_x_m - cfg.wall_start_x_m
    wall_center_x = origin_x + (cfg.wall_start_x_m + cfg.wall_end_x_m) / 2.0
    center_z = cfg.wall_height_m / 2.0
    narrow_wall_y = (
        origin_y
        + cfg.obstacle_half_width_m
        + cfg.narrow_width_m
        + cfg.wall_thickness_m / 2.0
    )
    wide_wall_y = (
        origin_y
        - cfg.obstacle_half_width_m
        - cfg.wide_width_m
        - cfg.wall_thickness_m / 2.0
    )
    obstacle_center_x = origin_x + cfg.obstacle_start_x_m + cfg.obstacle_length_m / 2.0
    return (
        RouteBox(
            name="central_obstacle",
            center=(obstacle_center_x, origin_y, center_z),
            size=(
                cfg.obstacle_length_m,
                2.0 * cfg.obstacle_half_width_m,
                cfg.wall_height_m,
            ),
        ),
        RouteBox(
            name="narrow_outer_wall",
            center=(wall_center_x, narrow_wall_y, center_z),
            size=(wall_length, cfg.wall_thickness_m, cfg.wall_height_m),
        ),
        RouteBox(
            name="wide_outer_wall",
            center=(wall_center_x, wide_wall_y, center_z),
            size=(wall_length, cfg.wall_thickness_m, cfg.wall_height_m),
        ),
    )

