from __future__ import annotations

import hashlib
import math
from pathlib import Path
import tarfile


REQUIRED_ARTIFACTS = ('asset', 'checkpoint', 'upper_policy', 'low_residual_checkpoint',
                      'geometry_calibration', 'neupan_yaml', 'dune_audit', 'dune_checkpoint')
HARD_REASONS = ('infeasible_projection', 'velocity', 'acceleration', 'torque',
                'collision', 'height', 'attitude', 'clearance')


def _sha256(path):
    with Path(path).open('rb') as stream:
        return _stream_sha256(stream)


def _stream_sha256(stream):
    digest = hashlib.sha256()
    for chunk in iter(lambda: stream.read(1024 * 1024), b''):
        digest.update(chunk)
    return digest.hexdigest()


def verify_execution_artifacts(document):
    failures = []
    artifacts = document.get('input_artifacts', {})
    for name in REQUIRED_ARTIFACTS:
        if name not in artifacts:
            failures.append(f'missing_artifact:{name}')
    for name, artifact in artifacts.items():
        try:
            if _sha256(artifact['path']) != artifact['sha256']:
                failures.append(f'artifact_hash_mismatch:{name}')
        except (OSError, KeyError, TypeError):
            failures.append(f'artifact_unreadable:{name}')
    provenance = document.get('execution_source_provenance', {})
    try:
        if _sha256(provenance['archive']) != provenance['archive_sha256']:
            failures.append('source_archive_hash_mismatch')
        expected = provenance['files_sha256']
        if not any(name.startswith('vendor/NeuPAN/neupan/') for name in expected):
            failures.append('vendor_source_snapshot_missing')
        with tarfile.open(provenance['archive'], 'r:gz') as archive:
            actual = {member.name: member for member in archive.getmembers()}
            if set(actual) != set(expected):
                failures.append('source_archive_manifest_mismatch')
            for name, digest in expected.items():
                member = actual.get(name)
                if member is None or not member.isfile():
                    failures.append(f'source_member_missing:{name}')
                    continue
                with archive.extractfile(member) as stream:
                    if _stream_sha256(stream) != digest:
                        failures.append(f'source_member_hash_mismatch:{name}')
    except (OSError, KeyError, TypeError, tarfile.TarError):
        failures.append('source_archive_unreadable')
    return failures


def audit_navigation_execution(document, verify_artifacts=True):
    failures, missing = [], []
    if document.get('backend') != 'vendor' or document.get('neupan_init_error') or document.get('neupan_calls', 0) <= 0:
        failures.append('actual_vendor_execution_required')
    if document.get('upper_trained_here') is not False:
        failures.append('not_frozen_independent_evaluation')
    if document.get('success') is not True or document.get('evaluation_status') != 'success':
        failures.append('navigation_report_did_not_succeed')
    if document.get('runtime_error') or document.get('terminated_or_truncated', 0):
        failures.append('runtime_or_physical_termination')
    reasons = document.get('hard_reason_counts', {})
    if not all(name in reasons and reasons[name] == 0 for name in HARD_REASONS):
        failures.append('hard_reason_evidence_not_zero')
    if document.get('physical_pedestrian_contact_steps', 0) or document.get('peak_physical_pedestrian_contact_force_n', 0.) > 1.:
        failures.append('physical_pedestrian_contact')
    if document.get('nominal_pedestrian_overlap_steps', 0):
        failures.append('nominal_pedestrian_overlap')
    observations = document.get('observation_sources', {})
    if not observations.get('lidar_enabled') or document.get('rendered_camera_frames', 0) <= 0:
        failures.append('physical_lidar_and_rendered_rgbd_required')
    if len(document.get('episode_results', [])) != 1:
        failures.append('single_independent_episode_required')
    if verify_artifacts:
        failures.extend(verify_execution_artifacts(document))
    trajectory = document.get('trajectory', [])
    try:
        dt = float(document['runtime_versions']['control_step_s'])
        goal = document['goal_xy_m']
        if not math.isfinite(dt) or not 0. < dt <= .1 or len(goal) != 2 or not all(math.isfinite(value) for value in goal):
            raise ValueError('invalid time or goal')
    except (KeyError, TypeError, ValueError):
        missing.append('physical_timing_or_goal_missing')
        dt, goal = .02, (0., 0.)
    stable_since = None
    last_time = None
    last_step = None
    for record in trajectory:
        feedback = record.get('goal_feedback_after')
        if feedback is None:
            missing.append('exact_post_step_goal_feedback_missing')
            stable_since = None
            break
        try:
            time = float(feedback['time_s'])
            position = feedback['root_position_world_m']
            speed = float(feedback['planar_speed_mps'])
            yaw = float(feedback['yaw_rate_radps'])
            roll, pitch = float(feedback['roll_rad']), float(feedback['pitch_rad'])
            height = float(feedback['posture_height_m'])
            target = float(feedback['posture_target_height_m'])
            contacts = feedback['wheel_contacts']
            step = record['step']
            values = (time, *position, speed, yaw, roll, pitch, height, target)
            if len(position) != 3 or not all(math.isfinite(value) for value in values) or speed < 0.:
                raise ValueError('nonfinite physical feedback')
            if last_time is not None and (abs(time - last_time - dt) > 1e-6 or step != last_step + 1):
                raise ValueError('physical feedback gap')
            stable = (math.hypot(position[0] - goal[0], position[1] - goal[1]) <= .3
                      and speed <= .03 and abs(yaw) <= .05 and max(abs(roll), abs(pitch)) <= .2
                      and contacts == [True, True] and record.get('mode_execution_ready') is True
                      and record.get('pending_posture') is None and abs(height - target) <= .025
                      and not record.get('terminated') and not record.get('truncated')
                      and not record.get('execution_timeout_reason'))
            stable_since = time if stable and stable_since is None else stable_since if stable else None
            last_time, last_step = time, step
        except (KeyError, TypeError, ValueError):
            failures.append('invalid_or_discontinuous_physical_goal_feedback')
            stable_since = None
            break
    hold = last_time - stable_since if stable_since is not None else 0.
    if not trajectory:
        missing.append('physical_trajectory_missing')
    if not missing and hold < 1. - 1e-9:
        failures.append('continuous_one_second_stopped_goal_not_verified')
    return {'schema': 'tita.independent_navigation_acceptance_audit.v1',
            'status': 'failed' if failures else 'insufficient_evidence' if missing else 'passed',
            'failures': sorted(set(failures)), 'missing_evidence': sorted(set(missing)),
            'verified_final_stopped_hold_s': hold, 'artifact_hashes_checked': verify_artifacts,
            'scope': 'Independent replay of logged physical feedback and provenance; not new simulation, global optimality, or hardware validation'}
