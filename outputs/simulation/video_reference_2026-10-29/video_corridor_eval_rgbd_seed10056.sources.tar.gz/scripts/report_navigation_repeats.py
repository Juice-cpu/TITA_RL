#!/usr/bin/env python3
"""Render paired repeated-trial tables and figures from independently recomputed traces."""

from __future__ import annotations

import argparse
import csv
import hashlib
import html
import json
from pathlib import Path
import sys

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tita_uc_residual_rl.navigation_repeat_statistics import build_repeat_statistics


NAMES = {"neupan": "NeuPAN", "dct": "DCT-core", "rl": "RL + NeuPAN"}
COLORS = {"neupan": "#3876ad", "dct": "#da8b4b", "rl": "#148c83"}
TABLE_METRICS = [("navigation_time_s", "Navigation time ↓ / s", 3),
                 ("path_length_m", "路程 / m", 3),
                 ("reference_path_overlap_pct", "参考路径重合度 ↑ / %", 2),
                 ("reference_path_efficiency_pct", "共同参考路径效率 ↑ / %", 2),
                 ("time_efficiency_pct", "时间效率 ↑ / %", 2),
                 ("energy_j_per_m", "单位距离机械能 ↓ / J·m⁻¹", 2)]


def metric_label(statistic, digits=2):
    if statistic["mean"] is None:
        return "—"
    mean = f"{statistic['mean']:.{digits}f}"
    return f"{mean} ± {statistic['std']:.{digits}f}" if statistic["std"] is not None else f"{mean} (n=1)"


def write_csv(path, rows, columns):
    with path.open("x", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def draw_comparison(summary, output):
    algorithms = summary["plan"]["algorithms"]
    selected_metrics = [("navigation_time_s", "Navigation time ↓", "仿真时间 / s", 3),
                        ("reference_path_overlap_pct", "参考路径重合度 ↑", "%", 2),
                        ("reference_path_efficiency_pct", "共同参考路径效率 ↑", "%", 2),
                        ("energy_j_per_m", "单位距离机械能 ↓", "J / m", 2)]
    figure, axes = plt.subplots(2, 2, figsize=(14, 10))
    for axis, (metric, title, unit, digits) in zip(axes.flat, selected_metrics):
        groups = summary["algorithm_statistics"]
        means = [groups[algorithm]["performance"][metric]["mean"] for algorithm in algorithms]
        deviations = [groups[algorithm]["performance"][metric]["std"] for algorithm in algorithms]
        axis.bar(range(3), [np.nan if value is None else value for value in means],
                 color=[COLORS[algorithm] for algorithm in algorithms], width=0.53, alpha=0.8)
        for position, algorithm in enumerate(algorithms):
            trials = [trial for trial in summary["trials"] if trial["algorithm"] == algorithm and trial["success"]]
            offsets = np.linspace(-0.14, 0.14, len(trials))
            axis.scatter(position + offsets, [trial[metric] for trial in trials], s=25, color="#263442", alpha=0.65, zorder=4)
            if means[position] is not None and deviations[position] is not None:
                axis.errorbar(position, means[position], yerr=deviations[position], color="black", capsize=6, fmt="none", zorder=5)
            if means[position] is not None:
                axis.annotate(metric_label(groups[algorithm]["performance"][metric], digits),
                              (position, means[position] + (deviations[position] or 0)),
                              xytext=(0, 10), textcoords="offset points", ha="center", fontsize=10)
        axis.set_xticks(range(3), [NAMES[algorithm] for algorithm in algorithms])
        axis.set_title(title, loc="left", fontsize=14, pad=14)
        axis.set_ylabel(unit)
        axis.grid(axis="y", alpha=0.15)
        axis.set_axisbelow(True)
        finite_means = [value for value in means if value is not None]
        axis.set_ylim(0, 108 if metric.endswith("_pct") else max(finite_means, default=1) * 1.22)
    figure.suptitle("统一二档上限 0.6 m/s｜三算法重复实验", fontsize=21, x=0.065, ha="left")
    figure.text(0.065, 0.058, f"每算法计划 {len(summary['plan']['seeds'])} 次；成功 {summary['successful_trials']}/{summary['planned_trials']}。柱高为均值，误差线为样本标准差，散点为成功回合。", fontsize=11)
    figure.text(0.065, 0.034, "固定初态与场景，物理控制时间分辨率 0.02 s；显示为 0.000 的标准差不代表真实零不确定性。", fontsize=10, color="#475569")
    figure.text(0.065, 0.012, "冻结权重、无新增扰动；DCT 仅导航核心。到达不等于安全验收；不是跨场景泛化或独立训练种子比较。", fontsize=10, color="#986027")
    figure.tight_layout(rect=(0.025, 0.075, 0.99, 0.94), h_pad=3)
    figure.savefig(output / "navigation_repeat_comparison.png", dpi=170)
    plt.close(figure)


def draw_paired_times(summary, output):
    seeds, algorithms = summary["plan"]["seeds"], summary["plan"]["algorithms"]
    trials = {(trial["algorithm"], trial["seed"]): trial for trial in summary["trials"] if trial["success"]}
    figure, axis = plt.subplots(figsize=(12, 5))
    for algorithm in algorithms:
        values = [trials[algorithm, seed]["navigation_time_s"] if (algorithm, seed) in trials else np.nan for seed in seeds]
        axis.plot(range(len(seeds)), values, "o-", color=COLORS[algorithm], linewidth=1.5, label=NAMES[algorithm])
    axis.set_xticks(range(len(seeds)), [str(seed) for seed in seeds])
    axis.set(xlabel="配对执行种子（不是模型训练种子）", ylabel="成功到达耗时 / s", title="逐种子 Navigation time｜纵轴局部放大；未成功回合不连线")
    axis.grid(alpha=0.15)
    axis.legend(frameon=False)
    figure.tight_layout()
    figure.savefig(output / "paired_navigation_times.png", dpi=170)
    plt.close(figure)


def draw_overlap_matrix(summary, output):
    algorithms = summary["plan"]["algorithms"]
    matrix = np.full((3, 3), np.nan)
    pair_lookup = {}
    for pair in summary["between_algorithm_path_overlap"]:
        first, second = (algorithms.index(algorithm) for algorithm in pair["algorithms"])
        if pair["overlap_pct"]["mean"] is not None:
            matrix[first, second] = matrix[second, first] = pair["overlap_pct"]["mean"]
        pair_lookup[first, second] = pair_lookup[second, first] = pair
    figure, axis = plt.subplots(figsize=(9, 6))
    image = axis.imshow(matrix, cmap="YlGnBu", vmin=0, vmax=100)
    for row_index in range(3):
        for column_index in range(3):
            pair = pair_lookup.get((row_index, column_index))
            label = "—" if pair is None else f"{metric_label(pair['overlap_pct'])}%\n均差 {metric_label(pair['symmetric_mean_separation_cm'])} cm\n配对 n={pair['overlap_pct']['n']}"
            axis.text(column_index, row_index, label, ha="center", va="center", color="white" if np.isfinite(matrix[row_index, column_index]) and matrix[row_index, column_index] > 65 else "#334155", fontsize=11)
    labels = [NAMES[algorithm] for algorithm in algorithms]
    axis.set_xticks(range(3), labels)
    axis.set_yticks(range(3), labels)
    axis.set_title("算法间实际轨迹重合度｜同种子成功回合配对", pad=18)
    figure.colorbar(image, ax=axis, label="对称弧长覆盖率 / %")
    figure.text(0.1, 0.025, "注意：这里比较算法之间的实轨，不是与 A* 参考路径的重合度。容差 0.20 m，弧长采样 0.05 m。", fontsize=9)
    figure.tight_layout(rect=(0, 0.06, 1, 1))
    figure.savefig(output / "between_algorithm_overlap.png", dpi=170)
    plt.close(figure)


def draw_repeated_trajectories(review, summary, output):
    from matplotlib.patches import Rectangle

    scene = json.loads((review / "navigation_scene.json").read_text())
    reviewed_results = json.loads((review / "comparison_summary.json").read_text())["results"]
    branch_file = review / "branch_reference_paths.json"
    branches = json.loads(branch_file.read_text()) if branch_file.exists() else {}
    figure, axes = plt.subplots(1, 3, figsize=(15, 7))
    for axis, algorithm in zip(axes, summary["plan"]["algorithms"]):
        for box in scene["boxes"]:
            lower = np.asarray(box["center"][:2]) - np.asarray(box["size"][:2]) / 2
            axis.add_patch(Rectangle(lower, *box["size"][:2], color="#8598aa", alpha=0.75))
        for branch, color in [("north", "#40acc4"), ("south", "#b69bd5")]:
            if branch in branches:
                points = np.asarray(branches[branch]["MID"]["xy_m"])
                axis.plot(*points.T, "--", color=color, linewidth=1.2, alpha=0.7)
        records = [result for result in reviewed_results if result["algorithm"] == algorithm]
        for index, record in enumerate(records):
            points = np.asarray(record["trajectory_xy_m"])
            axis.plot(*points.T, color=COLORS[algorithm], linewidth=1.2, alpha=0.5, label=f"实轨 n={len(records)}" if index == 0 else None)
        axis.scatter(*scene["start_xy_m"], color="#147d77", s=32, label="起点")
        axis.scatter(*scene["goal_xy_m"], color="#d9743d", marker="*", s=100, label="终点")
        min_x, max_x, min_y, max_y = scene["bounds_xy_m"]
        axis.set(xlim=(min_x - 0.3, max_x + 0.3), ylim=(min_y - 0.3, max_y + 0.3), xlabel="x / m", ylabel="y / m", title=NAMES[algorithm])
        axis.set_aspect("equal")
        axis.grid(alpha=0.1)
        axis.legend(fontsize=8, loc="upper right", framealpha=0.8)
    figure.suptitle("各算法全部重复回合实轨｜曲线重叠不等于只运行一次", fontsize=17)
    figure.text(0.06, 0.025, "虚线为北 / 南离线分支参考，实线为各回合实际物理轨迹。场景与地图来自已知几何先验；固定初态，无新增扰动。", fontsize=10)
    figure.tight_layout(rect=(0, 0.05, 1, 0.95))
    figure.savefig(output / "repeated_trajectories.png", dpi=170)
    plt.close(figure)


def write_tables(summary, output):
    rows = []
    columns = ["algorithm", "planned", "completed", "successes", "physical_failures", "missing", "success_rate"]
    for metric in summary["algorithm_statistics"][summary["plan"]["algorithms"][0]]["performance"]:
        columns.extend(f"{metric}_{field}" for field in ("n", "mean", "std", "median", "min", "max"))
    headings = ["算法", "成功/计划"] + [label for _, label, _ in TABLE_METRICS]
    markdown = ["# 统一二档上限 0.6 m/s：重复实验", "", "所有性能值均为成功回合的均值 ± 样本标准差；失败及未完成保留在成功率分母。", "",
                "| " + " | ".join(headings) + " |", "| " + " | ".join("---" for heading in headings) + " |"]
    html_rows = []
    for algorithm in summary["plan"]["algorithms"]:
        group = summary["algorithm_statistics"][algorithm]
        row = {"algorithm": algorithm, **{field: group[field] for field in columns[:7] if field != "algorithm"}}
        for metric, statistic in group["performance"].items():
            row.update({f"{metric}_{field}": statistic[field] for field in ("n", "mean", "std", "median", "min", "max")})
        rows.append(row)
        cells = [NAMES[algorithm], f"{group['successes']}/{group['planned']}"] + [metric_label(group["performance"][metric], digits) for metric, label, digits in TABLE_METRICS]
        markdown.append("| " + " | ".join(cells) + " |")
        html_rows.append("<tr>" + "".join(f"<td>{html.escape(cell)}</td>" for cell in cells) + "</tr>")
    write_csv(output / "algorithm_summary.csv", rows, columns)
    trial_rows = [{key: json.dumps(value) if isinstance(value, dict) else value for key, value in trial.items()} for trial in summary["trials"]]
    trial_columns = list(trial_rows[0]) if trial_rows else ["algorithm", "seed", "success"]
    write_csv(output / "per_trial_metrics.csv", trial_rows, trial_columns)
    pair_rows = [{"first": pair["algorithms"][0], "second": pair["algorithms"][1], **pair["overlap_pct"],
                  "mean_separation_cm": pair["symmetric_mean_separation_cm"]["mean"],
                  "std_separation_cm": pair["symmetric_mean_separation_cm"]["std"]} for pair in summary["between_algorithm_path_overlap"]]
    write_csv(output / "between_algorithm_overlap.csv", pair_rows, ["first", "second", "n", "mean", "std", "median", "min", "max", "mean_separation_cm", "std_separation_cm"])
    difference_rows = [{**pair, "ci95_low": pair["bootstrap_mean_ci95"][0] if pair["bootstrap_mean_ci95"] else None,
                        "ci95_high": pair["bootstrap_mean_ci95"][1] if pair["bootstrap_mean_ci95"] else None} for pair in summary["paired_navigation_time_differences_s"]]
    write_csv(output / "paired_time_differences.csv", difference_rows, ["first", "second", "n", "mean", "std", "ci95_low", "ci95_high"])
    markdown.extend(["", "## 算法间实际轨迹重合度", "", "| 算法配对 | 同种子成功配对数 | 重合度 / % | 对称平均轨迹距离 / cm |", "| --- | --- | --- | --- |"])
    for pair in summary["between_algorithm_path_overlap"]:
        markdown.append(f"| {' / '.join(NAMES[algorithm] for algorithm in pair['algorithms'])} | {pair['overlap_pct']['n']} | {metric_label(pair['overlap_pct'])} | {metric_label(pair['symmetric_mean_separation_cm'])} |")
    markdown.extend(["", "路径效率采用共同保守 A* 参考路径截断至同一到达区域后的长度，不使用各算法自己的首选计划；数值截断到 100%，原始比值保留。不是认证最短路 SPL。", "",
                     "本轮只是在同一静态先验场景上的冻结策略执行重复；没有新增随机地形或初态扰动，不是独立训练种子或多地图验证。DCT 仅导航核心。"])
    (output / "summary_table.md").write_text("\n".join(markdown) + "\n")
    return headings, html_rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("review", type=Path)
    parser.add_argument("--plan", type=Path, default=ROOT / "configs/navigation_repeat_equal06_v2.json")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    review, output = args.review.resolve(), args.output.resolve()
    def load(name):
        return json.loads((review / name).read_text())
    plan = json.loads(args.plan.read_text())
    summary = build_repeat_statistics(load("comparison_summary.json"), load("benchmark_config.json"),
                                      load("navigation_scene.json"), load("reference_paths.json"), plan)
    output.mkdir(parents=True, exist_ok=False)
    sources = [ROOT / "scripts/analyze_navigation_benchmark.py", Path(__file__).resolve(),
               ROOT / "tita_uc_residual_rl/navigation_repeat_statistics.py",
               ROOT / "tita_uc_residual_rl/navigation_benchmark.py",
               ROOT / "tita_uc_residual_rl/navigation_maze.py"]
    source_hashes = {}
    for source in sources:
        snapshot = output / "analysis_sources" / source.relative_to(ROOT)
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        content = source.read_bytes()
        snapshot.write_bytes(content)
        source_hashes[str(source.relative_to(ROOT))] = hashlib.sha256(content).hexdigest()
    summary["provenance"] = {
        "source_review": str(review), "plan_sha256": hashlib.sha256(args.plan.read_bytes()).hexdigest(),
        "review_input_sha256": {name: hashlib.sha256((review / name).read_bytes()).hexdigest()
                                for name in ("comparison_summary.json", "benchmark_config.json", "navigation_scene.json", "reference_paths.json")},
        "analysis_source_sha256": source_hashes,
    }
    (output / "repeat_statistics.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
    plt.rcParams.update({"font.family": "Noto Sans CJK JP", "axes.unicode_minus": False,
                         "axes.spines.top": False, "axes.spines.right": False,
                         "figure.facecolor": "#f7fafc", "savefig.facecolor": "#f7fafc"})
    draw_comparison(summary, output)
    draw_paired_times(summary, output)
    draw_overlap_matrix(summary, output)
    draw_repeated_trajectories(review, summary, output)
    headings, rows = write_tables(summary, output)
    groups = summary["algorithm_statistics"]
    audit_note = "；".join(f"{NAMES[algorithm]}：限速 {groups[algorithm]['command_cap_pass_count']}/{groups[algorithm]['completed']}，同步 {groups[algorithm]['synchronization_pass_count']}/{groups[algorithm]['completed']}" for algorithm in plan["algorithms"])
    behaviour_note = "；".join(f"{NAMES[algorithm]} 非零动作计数 { {action: count for action, count in groups[algorithm]['posture_action_totals'].items() if count} }，分支 {groups[algorithm]['successful_branch_counts']}" for algorithm in plan["algorithms"])
    document = f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>TITA｜统一 0.6 m/s 重复实验</title><style>body{{margin:0;background:#f3f7fa;color:#182c40;font:16px/1.7 system-ui,sans-serif}}main{{max-width:1350px;margin:auto;padding:30px 24px}}section{{background:white;border:1px solid #dfe7ef;padding:24px;border-radius:14px;margin:22px 0}}h1{{font-size:30px}}h2{{font-size:22px}}img{{display:block;width:100%;height:auto}}table{{width:100%;border-collapse:collapse;font-size:14px}}th,td{{padding:11px 9px;border-bottom:1px solid #e5ebf2;text-align:left;white-space:nowrap}}.scroll{{overflow-x:auto}}.note{{border-left:5px solid #d99142}}code{{font-size:13px;overflow-wrap:anywhere}}li{{margin:6px 0}}</style>
<main><h1>TITA｜共同二档上限 0.6 m/s</h1><p>NeuPAN / DCT-core / 冻结 RL + NeuPAN；每算法计划 {len(plan['seeds'])} 次，全新样本，不混入上次试跑。</p>
<section class="note"><strong>执行完成 {summary['completed_trials']}/{summary['planned_trials']}，成功到达 {summary['successful_trials']}/{summary['planned_trials']}。</strong><p>性能列只统计成功回合；所有失败和未完成计入成功率分母。固定地图、起终点和权重，无新增随机初态 / 地形扰动；种子是执行种子，不是新训练模型。物理控制时间分辨率 0.02 s，四舍五入后的零标准差不是零不确定性证明。</p><p>{html.escape(audit_note)}</p><p>这不是实机安全验收。原 LOW 0.4 m/s 停车超时尚未解决；本轮共同 0.6 上限不替代该验收。DCT 不含视觉语义或接触穿越。</p></section>
<section><h2>核心指标：均值 ± 样本标准差</h2><div class="scroll"><table><thead><tr>{''.join(f'<th>{html.escape(label)}</th>' for label in headings)}</tr></thead><tbody>{''.join(rows)}</tbody></table></div><img src="navigation_repeat_comparison.png"></section>
<section><h2>同种子逐回合对照</h2><img src="paired_navigation_times.png"><p>此图局部放大时间差，不应将小差异直接解释为算法优越性。配对差与探索性 bootstrap 区间保存在 <code>paired_time_differences.csv</code>。</p></section>
<section><h2>算法之间的路径是否一致</h2><img src="between_algorithm_overlap.png"><p>此图比较同种子算法的实际轨迹。主表的“参考路径重合度”则比较实轨与合法分支 A* 参考，两者不能混用。0.20 m 容差下 100% 覆盖不代表轨迹完全相同，故附对称平均轨迹距离，不事后调小容差制造差异。</p></section>
<section><h2>实轨与动作</h2><img src="repeated_trajectories.png"><p>{html.escape(behaviour_note)}</p><p>动作 5 为 MID / ratio 1.0；如果 RL 始终为该动作，不能宣称学到了自适应选档或路线优势。</p></section>
<section><h2>指标定义与原始数据</h2><ul><li>Navigation time：物理仿真 elapsed time，包含落地起步；失败不混作成功到达时间。</li><li>重合度：沿轨迹每 0.05 m 采样，在 0.20 m 容差内双向覆盖均值。地图与参考路径来自已知场景先验，不是在线建图。</li><li>共同参考路径效率：min(1, 共同参考至 0.35 m 到达区域的长度 / 实走距离)。保守 A* 不是认证最短路，原始比值保留。</li><li>时间效率：共同参考长度 / (0.6 × 成功耗时)，至多 100%；单位距离能量为关节绝对机械功，不是电池电耗。</li><li>汇总：<code>algorithm_summary.csv</code>、<code>summary_table.md</code>；每回合：<code>per_trial_metrics.csv</code>；完整统计：<code>repeat_statistics.json</code>。</li></ul><p>独立复算目录：<code>{html.escape(str(review))}</code>。当前共同参考至到达区域长度：{summary['common_reference_length_to_goal_region_m']:.4f} m。</p></section></main></html>'''
    (output / "index.html").write_text(document)
    print(output / "index.html")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
