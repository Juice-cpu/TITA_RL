#!/usr/bin/env python3
"""Generate compact reports for the seed-22 navigation pilot matrices."""

from __future__ import annotations

import csv
import json
import math
import os
import shutil
from collections import defaultdict
from pathlib import Path
from typing import Any

import numpy as np

from tita_uc_residual_rl.navigation_comparison_protocol import _canonical_dynamic_events


REPO = Path("/home/ky/tita_uc_residual_rl")
STATIC_ROOT = REPO / "rl_runs/navigation_benchmark/formal_static_matrix_seed22_20261024"
DYNAMIC_ROOT = REPO / "rl_runs/navigation_benchmark/formal_dynamic_matrix_seed22_20261024"
BASELINE_ROOT = REPO / "rl_runs/navigation_benchmark/formal_dynamic_no_obstacle_baseline_seed22_20261024"
OUTPUT_ROOT = Path("/home/ky/Documents/Codex/2026-10-22/01a1637e-689a-7ad3-a978-cd7867126368-2/outputs/formal_navigation_20261024")

METHOD_LABELS = {"neupan": "A* + NeuPAN", "dct": "A* + DCT-core", "rl": "A* + RL + NeuPAN"}
METHODS = ("neupan", "dct", "rl")
ACTION_INFO = {
    0: ("LOW", 0.4), 1: ("LOW", 0.7), 2: ("LOW", 1.0),
    3: ("MID", 0.4), 4: ("MID", 0.7), 5: ("MID", 1.0),
    6: ("HIGH", 0.4), 7: ("HIGH", 0.7), 8: ("HIGH", 1.0),
}


def read_json(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def finite(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def mean(rows: list[dict[str, Any]], key: str) -> float | None:
    values = [finite(row.get(key)) for row in rows]
    values = [value for value in values if value is not None]
    return float(np.mean(values)) if values else None


def percentile(values: list[float], q: float) -> float | None:
    return float(np.percentile(values, q)) if values else None


def static_rows() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for summary_path in sorted((STATIC_ROOT / "static").glob("*/comparison_summary.json")):
        scene = summary_path.parent.name
        summary = read_json(summary_path)
        for result in summary.get("results", []):
            method = str(result["algorithm"])
            run_dir = Path(result["directory"])
            geometry = result.get("actual_path_geometry") or {}
            isaac_path = run_dir / "isaac_summary.json"
            isaac = read_json(isaac_path) if isaac_path.exists() else {}
            histogram = {int(key): int(value) for key, value in (result.get("posture_action_histogram") or {}).items()}
            selected_action = max(histogram, key=histogram.get) if histogram else None
            selected_route, selected_speed_ratio = ACTION_INFO.get(selected_action, (None, None))
            planned = finite(result.get("reference_path_length_m"))
            reference_goal = finite(result.get("reference_length_to_goal_region_m"))
            actual = finite(result.get("distance_m"))
            rows.append({
                "scene": scene,
                "obstacle_count": 1 if "single" in scene else 2,
                "method": method,
                "method_label": METHOD_LABELS[method],
                "seed": 22,
                "success": bool(result.get("success")),
                "complete": bool(result.get("complete")),
                "hard_failure": bool(result.get("hard_failure")),
                "truncated": bool(result.get("truncated")),
                "navigation_time_s": finite(result.get("navigation_time_s")),
                "planning_path_length_m": planned,
                "actual_trajectory_length_m": actual,
                "path_length_ratio_to_common_reference": (actual / reference_goal) if actual is not None and reference_goal else None,
                "path_efficiency": finite(result.get("path_efficiency_success_only")),
                "path_overlap_to_selected_plan": finite((result.get("comparison_to_first_selected_plan") or {}).get("symmetric_path_overlap")),
                "min_lateral_clearance_m": finite(geometry.get("lateral_clearance_m")),
                "min_overhead_margin_m": finite(geometry.get("overhead_margin_m")),
                "mechanical_energy_j": finite(result.get("mechanical_energy_j")),
                "energy_j_per_m": finite(result.get("energy_j_per_m")),
                "dominant_action_id": selected_action,
                "dominant_route": selected_route,
                "dominant_speed_ratio": selected_speed_ratio,
                "soft_contact_force_max_n": finite(isaac.get("soft_contact_force_max_n")),
                "contact_violation_proxy": bool((finite(isaac.get("soft_contact_force_max_n")) or 0.0) > 0.0),
                "video": str(run_dir / "navigation.mp4"),
                "summary": str(summary_path),
            })
    return rows


def baseline_rows() -> list[dict[str, Any]]:
    summary_path = BASELINE_ROOT / "comparison_summary.json"
    summary = read_json(summary_path)
    rows = []
    for result in summary.get("results", []):
        method = str(result["algorithm"])
        run_dir = Path(result["directory"])
        rows.append({
            "condition": "no_obstacle_baseline",
            "method": method,
            "method_label": METHOD_LABELS[method],
            "seed": 22,
            "success": bool(result.get("success")),
            "navigation_time_s": finite(result.get("navigation_time_s")),
            "actual_trajectory_length_m": finite(result.get("distance_m")),
            "mechanical_energy_j": finite(result.get("mechanical_energy_j")),
            "energy_j_per_m": finite(result.get("energy_j_per_m")),
            "planning_path_length_m": finite(result.get("reference_path_length_m")),
            "video": str(run_dir / "navigation.mp4"),
            "comparison_summary": str(summary_path),
        })
    return rows


def timing_events(run_dir: Path) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    for path in sorted((run_dir / "timing").glob("*.jsonl")):
        with path.open(encoding="utf-8") as handle:
            for line in handle:
                try:
                    value = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if "event" in value:
                    events.append(value)
    return _canonical_dynamic_events(events)


def event_time(event: dict[str, Any]) -> int:
    return int(event.get("monotonic_ns", event.get("at_ns")))


def first_after(events: list[dict[str, Any]], name: str, lower_bound: int) -> dict[str, Any] | None:
    candidates = [event for event in events if event.get("event") == name and event_time(event) >= lower_bound]
    return min(candidates, key=event_time) if candidates else None


def ms_between(start: dict[str, Any] | None, end: dict[str, Any] | None) -> float | None:
    if start is None or end is None:
        return None
    return (event_time(end) - event_time(start)) / 1e6


def event_periods(events: list[dict[str, Any]], name: str) -> list[float]:
    rows = sorted((event for event in events if event.get("event") == name), key=event_time)
    return [(event_time(second) - event_time(first)) / 1e9 for first, second in zip(rows, rows[1:])]


def dynamic_rows() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for condition_dir in sorted((DYNAMIC_ROOT / "dynamic").glob("*")):
        if not condition_dir.is_dir():
            continue
        condition = condition_dir.name
        for run_dir in sorted(condition_dir.glob("equal_cruise_*_seed22")):
            method = run_dir.name.split("_")[2]
            summary_path = condition_dir / "comparison_summary.json"
            summary = read_json(summary_path)
            result = next(item for item in summary["results"] if item["algorithm"] == method)
            events = sorted(timing_events(run_dir), key=event_time)
            appeared = first_after(events, "obstacle_appeared", -1)
            if appeared is None:
                continue
            perception = first_after(events, "perception_first_hit", event_time(appeared))
            map_updated = first_after(events, "map_updated", event_time(perception or appeared))
            astar_started = first_after(events, "astar_started", event_time(map_updated or perception or appeared))
            astar_completed = first_after(events, "astar_completed", event_time(astar_started or map_updated or appeared))
            candidates = first_after(events, "candidates_published", event_time(astar_completed or astar_started or appeared))
            rl_completed = first_after(events, "rl_decision_completed", event_time(candidates or appeared))
            planner_start = first_after(events, "local_planner_started", event_time(rl_completed or candidates or appeared))
            planner_end = first_after(events, "local_planner_completed", event_time(planner_start or candidates or appeared))
            control = first_after(events, "control_applied", event_time(planner_end or planner_start or candidates or appeared))
            confirmed = first_after(events, "avoidance_confirmed", event_time(appeared))
            stopped = first_after(events, "obstacle_motion_stopped", event_time(appeared))
            chains = {
                "obstacle_appeared": appeared,
                "perception_first_hit": perception,
                "map_updated": map_updated,
                "astar_started": astar_started,
                "astar_completed": astar_completed,
                "candidates_published": candidates,
                "rl_decision_completed": rl_completed,
                "local_planner_started": planner_start,
                "local_planner_completed": planner_end,
                "control_applied": control,
                "avoidance_confirmed": confirmed,
                "obstacle_motion_stopped": stopped,
            }
            latencies = {
                "appearance_to_perception_ms": ms_between(appeared, perception),
                "perception_to_map_update_ms": ms_between(perception, map_updated),
                "map_update_to_astar_start_ms": ms_between(map_updated, astar_started),
                "map_update_to_astar_complete_ms": ms_between(map_updated, astar_completed),
                "astar_to_candidates_ms": ms_between(astar_completed, candidates),
                "candidates_to_rl_ms": ms_between(candidates, rl_completed),
                "rl_to_local_planner_ms": ms_between(rl_completed, planner_start),
                "local_planner_compute_ms": ms_between(planner_start, planner_end),
                "candidates_to_local_planner_complete_ms": ms_between(candidates, planner_end),
                "local_planner_to_control_ms": ms_between(planner_end, control),
                "appearance_to_control_ms": ms_between(appeared, control),
                "appearance_to_avoidance_confirmation_ms": ms_between(appeared, confirmed),
            }
            limits = {
                "appearance_to_perception_ms": 250.0,
                "perception_to_map_update_ms": 250.0,
                "map_update_to_astar_complete_ms": 250.0,
                "astar_to_candidates_ms": 100.0,
                "candidates_to_local_planner_complete_ms": 250.0,
                "local_planner_to_control_ms": 100.0,
                "appearance_to_control_ms": 1000.0,
            }
            timeout_flags = {key: latencies.get(key) is not None and latencies[key] > limit for key, limit in limits.items()}
            isaac_path = run_dir / "isaac_summary.json"
            isaac = read_json(isaac_path) if isaac_path.exists() else {}
            periods = {}
            for name in ("map_updated", "astar_completed", "rl_decision_completed", "local_planner_completed", "control_applied"):
                values = event_periods(events, name)
                if values:
                    periods[name] = {"count": len(values) + 1, "p50_s": percentile(values, 50), "p95_s": percentile(values, 95), "max_s": max(values), "mean_hz": 1.0 / float(np.mean(values))}
            astar_compute_durations_ms = [
                (event_time(event) - int(event["start_ns"])) / 1e6
                for event in events
                if event.get("event") == "astar_completed"
                and event_time(event) >= event_time(appeared)
                and event.get("start_ns") is not None
            ]
            rows.append({
                "condition": condition,
                "method": method,
                "method_label": METHOD_LABELS[method],
                "seed": 22,
                "success": bool(result.get("success")),
                "truncated": bool(result.get("truncated")),
                "navigation_time_s": finite(result.get("navigation_time_s")),
                "actual_trajectory_length_m": finite(result.get("distance_m")),
                "mechanical_energy_j": finite(result.get("mechanical_energy_j")),
                "energy_j_per_m": finite(result.get("energy_j_per_m")),
                "soft_contact_force_max_n": finite(isaac.get("soft_contact_force_max_n")),
                "contact_violation_proxy": bool((finite(isaac.get("soft_contact_force_max_n")) or 0.0) > 0.0),
                "replanning_count": sum(1 for event in events if event.get("event") == "astar_completed" and event_time(event) >= event_time(appeared)),
                "astar_compute_durations_ms": astar_compute_durations_ms,
                "astar_compute_total_ms": sum(astar_compute_durations_ms),
                "avoidance_confirmed_present": confirmed is not None,
                "avoidance_verified": False,
                "obstacle_motion_stopped_logged": stopped is not None,
                "control_response_observed": control is not None,
                "event_counts": {name: sum(1 for event in events if event.get("event") == name) for name in ("obstacle_appeared", "perception_first_hit", "map_updated", "astar_started", "astar_completed", "candidates_published", "rl_decision_started", "rl_decision_completed", "local_planner_started", "local_planner_completed", "control_applied", "avoidance_confirmed", "obstacle_motion_stopped")},
                "latencies_ms": latencies,
                "timeout_flags": timeout_flags,
                "timeout_count": sum(timeout_flags.values()),
                "period_statistics": periods,
                "video": str(run_dir / "navigation.mp4"),
                "timing_dir": str(run_dir / "timing"),
                "comparison_summary": str(summary_path),
            })
    return rows


def aggregate(rows: list[dict[str, Any]], keys: tuple[str, ...], metric_keys: tuple[str, ...]) -> list[dict[str, Any]]:
    grouped: dict[tuple[Any, ...], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[tuple(row[key] for key in keys)].append(row)
    output: list[dict[str, Any]] = []
    for group_key, group_rows in sorted(grouped.items(), key=lambda item: str(item[0])):
        item = dict(zip(keys, group_key))
        item["n"] = len(group_rows)
        item["successes"] = sum(bool(row.get("success")) for row in group_rows)
        item["success_rate"] = item["successes"] / len(group_rows)
        for metric in metric_keys:
            item[metric + "_mean"] = mean(group_rows, metric)
        output.append(item)
    return output


def dynamic_paired_rows(dynamic: list[dict[str, Any]], baseline: list[dict[str, Any]]) -> list[dict[str, Any]]:
    base_by_method = {row["method"]: row for row in baseline}
    output = []
    for row in dynamic:
        base = base_by_method[row["method"]]
        dynamic_time = row.get("navigation_time_s")
        base_time = base.get("navigation_time_s")
        dynamic_energy = row.get("mechanical_energy_j")
        base_energy = base.get("mechanical_energy_j")
        output.append({
            "condition": row["condition"],
            "method": row["method"],
            "method_label": row["method_label"],
            "seed": row["seed"],
            "baseline_success": base["success"],
            "dynamic_success": row["success"],
            "baseline_navigation_time_s": base_time,
            "dynamic_navigation_time_s": dynamic_time,
            "additional_time_s": (dynamic_time - base_time) if dynamic_time is not None and base_time is not None else None,
            "additional_time_percent_of_baseline": ((dynamic_time - base_time) / base_time * 100.0) if dynamic_time is not None and base_time else None,
            "baseline_energy_j": base_energy,
            "dynamic_energy_j": dynamic_energy,
            "additional_energy_j": (dynamic_energy - base_energy) if dynamic_energy is not None and base_energy is not None else None,
            "baseline_energy_j_per_m": base.get("energy_j_per_m"),
            "dynamic_energy_j_per_m": row.get("energy_j_per_m"),
            "replanning_count": row.get("replanning_count"),
            "astar_compute_total_ms": row.get("astar_compute_total_ms"),
            "avoidance_confirmed": row.get("avoidance_confirmed_present"),
            "video": row.get("video"),
        })
    return output


def markdown_table(rows: list[dict[str, Any]], columns: list[tuple[str, str]], digits: int = 3) -> str:
    lines = ["| " + " | ".join(label for label, _ in columns) + " |", "|" + "|".join("---" for _ in columns) + "|"]
    for row in rows:
        values = []
        for _, key in columns:
            value = row.get(key)
            if isinstance(value, float):
                values.append(f"{value:.{digits}f}")
            elif value is None:
                values.append("—")
            else:
                values.append(str(value))
        lines.append("| " + " | ".join(values) + " |")
    return "\n".join(lines)


def dynamic_stage_statistics(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    latency_names = sorted({name for row in rows for name in row["latencies_ms"]})
    groups: dict[tuple[str, str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        groups[(row["condition"], row["method"], row["method_label"])].append(row)
    output: list[dict[str, Any]] = []
    for (condition, method, method_label), group_rows in sorted(groups.items()):
        for stage in latency_names:
            values = [finite(row["latencies_ms"].get(stage)) for row in group_rows]
            values = [value for value in values if value is not None]
            output.append({
                "condition": condition,
                "method": method,
                "method_label": method_label,
                "stage": stage,
                "n": len(values),
                "p50_ms": percentile(values, 50),
                "p95_ms": percentile(values, 95),
                "max_ms": max(values) if values else None,
            })
    return output


def link_videos(static: list[dict[str, Any]], dynamic: list[dict[str, Any]]) -> None:
    video_root = OUTPUT_ROOT / "videos"
    video_root.mkdir(parents=True, exist_ok=True)
    for row in static + dynamic:
        source = Path(row["video"])
        if not source.exists():
            continue
        prefix = row.get("scene", row.get("condition"))
        target = video_root / f"{prefix}_{row['method']}_seed22.mp4"
        if target.exists() or target.is_symlink():
            target.unlink()
        target.symlink_to(source)


def main() -> None:
    static = static_rows()
    dynamic = dynamic_rows()
    baseline = baseline_rows()
    paired = dynamic_paired_rows(dynamic, baseline)
    dynamic_stage_stats = dynamic_stage_statistics(dynamic)
    static_aggregate = aggregate(static, ("method", "method_label"), ("navigation_time_s", "planning_path_length_m", "actual_trajectory_length_m", "path_length_ratio_to_common_reference", "path_efficiency", "path_overlap_to_selected_plan", "min_lateral_clearance_m", "min_overhead_margin_m", "mechanical_energy_j", "energy_j_per_m"))
    static_by_obstacle = aggregate(static, ("obstacle_count", "method", "method_label"), ("navigation_time_s", "actual_trajectory_length_m", "energy_j_per_m", "min_lateral_clearance_m"))
    dynamic_aggregate = aggregate(dynamic, ("condition", "method", "method_label"), ("navigation_time_s", "actual_trajectory_length_m", "mechanical_energy_j", "energy_j_per_m", "replanning_count", "timeout_count"))
    write_csv(OUTPUT_ROOT / "formal_navigation_static.csv", static)
    write_csv(OUTPUT_ROOT / "formal_navigation_dynamic.csv", dynamic)
    write_csv(OUTPUT_ROOT / "formal_navigation_dynamic_baseline.csv", baseline)
    write_csv(OUTPUT_ROOT / "formal_navigation_dynamic_paired.csv", paired)
    write_csv(OUTPUT_ROOT / "formal_navigation_dynamic_stage_stats.csv", dynamic_stage_stats)
    write_json(OUTPUT_ROOT / "formal_navigation_summary.json", {"static_trials": static, "dynamic_trials": dynamic, "dynamic_baseline": baseline, "dynamic_paired": paired, "dynamic_stage_statistics": dynamic_stage_stats, "static_aggregate": static_aggregate, "static_by_obstacle": static_by_obstacle, "dynamic_aggregate": dynamic_aggregate})
    link_videos(static, dynamic + baseline)

    static_table = markdown_table(static_aggregate, [("方法", "method_label"), ("n", "n"), ("成功率", "success_rate"), ("导航时间均值(s)", "navigation_time_s_mean"), ("规划路径(m)", "planning_path_length_m_mean"), ("实际轨迹(m)", "actual_trajectory_length_m_mean"), ("共同参考长度比", "path_length_ratio_to_common_reference_mean"), ("最小侧向净空(m)", "min_lateral_clearance_m_mean"), ("单位距离能耗(J/m)", "energy_j_per_m_mean")])
    static_obstacle_table = markdown_table(static_by_obstacle, [("障碍数", "obstacle_count"), ("方法", "method_label"), ("n", "n"), ("成功率", "success_rate"), ("导航时间均值(s)", "navigation_time_s_mean"), ("实际轨迹(m)", "actual_trajectory_length_m_mean"), ("单位距离能耗(J/m)", "energy_j_per_m_mean")])
    dynamic_table = markdown_table(dynamic_aggregate, [("场景", "condition"), ("方法", "method_label"), ("成功率", "success_rate"), ("导航时间(s)", "navigation_time_s_mean"), ("重规划次数", "replanning_count_mean"), ("单位距离能耗(J/m)", "energy_j_per_m_mean")])
    paired_table = markdown_table(paired, [("动态场景", "condition"), ("方法", "method_label"), ("无障碍时间(s)", "baseline_navigation_time_s"), ("动态时间(s)", "dynamic_navigation_time_s"), ("额外时间(s)", "additional_time_s"), ("增加比例(%)", "additional_time_percent_of_baseline"), ("A*重规划次数", "replanning_count")])
    double_v1 = next(row for row in static if row["scene"] == "navigation_benchmark_heldout_double_v1" and row["method"] == "rl")
    double_v1_neupan = next(row for row in static if row["scene"] == "navigation_benchmark_heldout_double_v1" and row["method"] == "neupan")
    double_v1_dct = next(row for row in static if row["scene"] == "navigation_benchmark_heldout_double_v1" and row["method"] == "dct")
    report = f"""# 导航对比实验正式 Pilot 报告（seed=22）

生成日期：2026-10-24。全部结果来自 Isaac 仿真，使用仿真时间和独立墙钟时间分开记录；不是实机实时认证，也不是多 seed 论文统计。

## 结论摘要

- 静态泛化共 4 个训练未见布局、12 个成对回合：1 障碍 2 个布局、2 障碍 2 个布局；三种方法均为 4/4 到达，静态成功率均为 100%。
- RL 与 NeuPAN 共用 A* 候选路线、机器人、传感器、NeuPAN、速度约束和安全门，仅替换上层选择器。在本 pilot 中 RL 没有降低成功率；但平均导航时间为 NeuPAN 的约 1.42 倍，单位距离能耗也更高，差异主要来自 `double_v1` 的 RL 回合明显变慢。
- 双障碍 `v1` 的变慢原因已定位：RL 主导动作是 `action_id={double_v1['dominant_action_id']}`（`{double_v1['dominant_route']} + {double_v1['dominant_speed_ratio']:.1f}x`），而 NeuPAN/DCT-core 都是 `action_id=4`（`MID + 0.7x`）。RL 的期望速度上限为 `0.24 m/s`，基线为 `0.42 m/s`；路线实际长度相近（RL `{double_v1['actual_trajectory_length_m']:.3f} m`，NeuPAN `{double_v1_neupan['actual_trajectory_length_m']:.3f} m`，DCT-core `{double_v1_dct['actual_trajectory_length_m']:.3f} m`），所以时间差主要来自速度动作，而不是绕了更长的路线。
- DCT 结果只标为 `DCT-core`。静态 pilot 中 DCT-core 也是 4/4 到达；它不是完整 DCT 系统。
- 动态两个条件共 6 个回合全部在 39.98 s 仿真观察窗内未到达目标，因此到达率为 0/3、0/3。日志确实记录了障碍出现、首次感知、地图更新、A* 开始/完成、候选发布、局部规划和控制响应；但三种方法均缺少 `avoidance_confirmed`，所以“障碍仍运动时成功避让”不能判定为通过。
- 动态报告把“有控制响应”和“已验证绕过障碍”严格分开；没有 `avoidance_confirmed` 的回合不计作动态避障成功。

## 静态结果

{static_table}

按障碍数量分组：

{static_obstacle_table}

静态逐回合数据见 `formal_navigation_static.csv`。`planning_path_length_m` 是实验导出的首选候选/参考路径长度，`actual_trajectory_length_m` 是实测轨迹长度；路径重合度单独记录，不能代替路径效率。最小侧向净空来自场景几何沿实测位置的名义圆形 footprint 计算；顶端净空另列，且开放顶端报告上限为 0.5 m。静态回合的硬失败和接触力代理均为 0。

## 动态结果

{dynamic_table}

相对同场景、同 seed、无动态障碍 baseline：

{paired_table}

动态逐回合数据见 `formal_navigation_dynamic.csv`。每回合的 `latencies_ms` 记录：障碍出现→首次感知、感知→地图更新、地图更新→A*、A*→候选、候选→RL、局部规划求解、局部规划→控制、障碍出现→控制；`timeout_flags` 按协议阈值记录超时。由于每个条件只有 seed=22 一个回合，单回合的 P50/P95/最大值相同；局部规划、控制和地图更新的周期统计在 `period_statistics` 中，分别以墙钟秒和可测频率表示。

动态正式协议状态：`map_updated`、A* 和候选事件存在；`avoidance_confirmed` 缺失。因此当前数据支持“系统感知并触发了在线地图/A* 更新与控制链路”，不支持“已完成安全绕行”的结论。相对无障碍 baseline，两个动态条件均把三种方法推到 `39.98 s` 超时，额外观察时间约 `11.3–11.6 s`；动态 A* 额外完成 `2–4` 次，单次 A* 计算约 `1.54–1.71 s`。`moving_crossing` 中 DCT-core 的最大软接触力为 480.306 N，另外两种方法为 0 N；这也是该回合不能被描述为成功避让的直接证据。

## 视频

视频软链接集中在 `videos/`；原始视频仍保留在仓库实验目录。静态 12 个视频、动态 6 个视频和无障碍 baseline 3 个视频均由对应实际回合生成，当前共 21 个视频。

## 文件

- `formal_navigation_static.csv`
- `formal_navigation_dynamic.csv`
- `formal_navigation_dynamic_baseline.csv`
- `formal_navigation_dynamic_paired.csv`（相对无障碍 baseline 的额外耗时）
- `formal_navigation_dynamic_stage_stats.csv`（各动态阶段的 P50/P95/最大值）
- `formal_navigation_summary.json`
- `videos/`
- 原始静态矩阵：`{STATIC_ROOT}`
- 原始动态矩阵：`{DYNAMIC_ROOT}`
"""
    (OUTPUT_ROOT / "formal_navigation_report_20261024.md").write_text(report, encoding="utf-8")
    (REPO / "rl_runs/navigation_benchmark/formal_navigation_report_20261024.md").write_text(report, encoding="utf-8")
    write_json(REPO / "rl_runs/navigation_benchmark/formal_navigation_summary_20261024.json", {"static_trials": static, "dynamic_trials": dynamic, "dynamic_baseline": baseline, "dynamic_paired": paired, "dynamic_stage_statistics": dynamic_stage_stats, "static_aggregate": static_aggregate, "static_by_obstacle": static_by_obstacle, "dynamic_aggregate": dynamic_aggregate})
    write_csv(REPO / "rl_runs/navigation_benchmark/formal_navigation_static_20261024.csv", static)
    write_csv(REPO / "rl_runs/navigation_benchmark/formal_navigation_dynamic_20261024.csv", dynamic)
    write_csv(REPO / "rl_runs/navigation_benchmark/formal_navigation_dynamic_stage_stats_20261024.csv", dynamic_stage_stats)
    write_csv(REPO / "rl_runs/navigation_benchmark/formal_navigation_dynamic_baseline_20261024.csv", baseline)
    write_csv(REPO / "rl_runs/navigation_benchmark/formal_navigation_dynamic_paired_20261024.csv", paired)
    print(OUTPUT_ROOT / "formal_navigation_report_20261024.md")


if __name__ == "__main__":
    main()
