#!/usr/bin/env python3
"""Validate the local TITA navigation-tower asset without Isaac Sim."""

from __future__ import annotations

import argparse
import sys
import xml.etree.ElementTree as ET
from pathlib import Path


EXPECTED_JOINT_NAMES = (
    "joint_left_leg_1",
    "joint_left_leg_2",
    "joint_left_leg_3",
    "joint_left_leg_4",
    "joint_right_leg_1",
    "joint_right_leg_2",
    "joint_right_leg_3",
    "joint_right_leg_4",
)


REQUIRED_FIXED_LINKS = ("tower_base_link", "radar_link", "left_camera", "right_camara", "imu_link")


def validate(path: Path) -> None:
    root = ET.parse(path).getroot()
    joint_names = tuple(
        joint.attrib["name"]
        for joint in root.findall("joint")
        if joint.attrib.get("type") != "fixed"
    )
    if joint_names != EXPECTED_JOINT_NAMES:
        raise ValueError(
            "expected the official 8-DOF joint order, got " + repr(joint_names)
        )
    if any(root.find(f"link[@name='{name}']") is None for name in REQUIRED_FIXED_LINKS):
        missing = [name for name in REQUIRED_FIXED_LINKS if root.find(f"link[@name='{name}']") is None]
        raise ValueError(f"missing required fixed links: {', '.join(missing)}")

    missing_meshes: list[Path] = []
    for mesh in root.findall(".//mesh"):
        mesh_path = (path.parent / mesh.attrib["filename"]).resolve()
        if not mesh_path.is_file():
            missing_meshes.append(mesh_path)
    if missing_meshes:
        raise FileNotFoundError("missing mesh files:\n" + "\n".join(map(str, missing_meshes)))

    print(f"asset: {path}")
    print(f"non-fixed joints ({len(joint_names)}): OK")
    print("required navigation frames: OK")
    print(f"mesh files ({len(root.findall('.//mesh'))}): OK")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "urdf",
        nargs="?",
        type=Path,
        default=Path("assets/tita_tower/urdf/tita_with_tower.urdf"),
    )
    args = parser.parse_args()
    try:
        validate(args.urdf)
    except (ET.ParseError, FileNotFoundError, ValueError) as exc:
        print(f"validation failed: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
