import argparse
import json
from pathlib import Path

from tita_uc_residual_rl.matched_navigation_audit import audit_matched_navigation


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--first', required=True, type=Path)
    parser.add_argument('--second', required=True, type=Path)
    parser.add_argument('--comparison', choices=('pedestrians', 'analytic_actor', 'upper_checkpoint'), default='pedestrians')
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    report = audit_matched_navigation(json.loads(args.first.read_text()), json.loads(args.second.read_text()), args.comparison)
    report.update(first_report=str(args.first.resolve()), second_report=str(args.second.resolve()))
    with args.output.open('x') as stream:
        json.dump(report, stream, indent=2)
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
