#!/usr/bin/env python3
"""Analyze unified static/dynamic navigation comparison exports."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from tita_uc_residual_rl.navigation_comparison_protocol import (
    analyze_dynamic_events,
    compare_trial,
    diagnose_ppo_policy,
    summarize_dynamic_runs,
    summarize_trials,
)


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def read_jsonl(path: Path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def read_records(path: Path):
    raw = read_json(path) if path.suffix == ".json" else read_jsonl(path)
    if isinstance(raw, dict):
        return raw.get("trials", raw.get("results", raw.get("runs", [])))
    return raw


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--static-trials", type=Path, help="JSON array or JSONL of static trial exports")
    parser.add_argument("--dynamic-events", type=Path, help="JSON array or JSONL event trace for one dynamic run")
    parser.add_argument("--dynamic-runs", type=Path, help="JSON array of already analyzed dynamic runs")
    parser.add_argument("--ppo-histogram", type=Path, help="JSON object mapping action IDs to counts")
    parser.add_argument("--ppo-records", type=Path, help="JSON array of state/action records")
    parser.add_argument("--reference-path", type=Path)
    parser.add_argument("--common-reference-path", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    report: dict[str, object] = {"schema": "tita.navigation_comparison_report.v1"}
    reference = read_json(args.reference_path) if args.reference_path else None
    common_reference = read_json(args.common_reference_path) if args.common_reference_path else None
    if args.static_trials:
        raw = read_records(args.static_trials)
        report["static"] = summarize_trials(
            compare_trial(trial, reference_path=reference, common_reference_path=common_reference)
            for trial in raw
        )
    if args.dynamic_events:
        report["dynamic_run"] = analyze_dynamic_events(read_records(args.dynamic_events))
    if args.dynamic_runs:
        report["dynamic"] = summarize_dynamic_runs(read_records(args.dynamic_runs))
    if args.ppo_histogram:
        records = read_records(args.ppo_records) if args.ppo_records else None
        report["ppo_diagnosis"] = diagnose_ppo_policy(read_json(args.ppo_histogram), state_action_records=records)
    if len(report) == 1:
        parser.error("provide at least one input")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
