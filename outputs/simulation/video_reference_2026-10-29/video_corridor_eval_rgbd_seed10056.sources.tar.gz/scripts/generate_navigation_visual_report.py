#!/usr/bin/env python3
"""Create chart-based HTML and Markdown reports for the navigation pilot."""

from __future__ import annotations

import csv
import html
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib import font_manager


OUTPUT = Path("/home/ky/Documents/Codex/2026-10-22/01a1637e-689a-7ad3-a978-cd7867126368-2/outputs/formal_navigation_20261024")
CHARTS = OUTPUT / "charts"
SUMMARY = OUTPUT / "formal_navigation_summary.json"

METHODS = ["neupan", "dct", "rl"]
LABELS = {"neupan": "A* + NeuPAN", "dct": "A* + DCT-core", "rl": "A* + RL + NeuPAN"}
COLORS = {"neupan": "#276FBF", "dct": "#F28E2B", "rl": "#2CA25F"}


def load_csv(name: str) -> list[dict[str, str]]:
    with (OUTPUT / name).open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def f(value: object) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def set_style() -> None:
    candidates = [
        path for path in font_manager.findSystemFonts()
        if "NotoSansCJK" in path or "Noto Sans CJK" in path
    ]
    if candidates:
        font_manager.fontManager.addfont(candidates[0])
        plt.rcParams["font.family"] = font_manager.FontProperties(fname=candidates[0]).get_name()
    plt.rcParams.update({"axes.unicode_minus": False, "figure.dpi": 140, "savefig.dpi": 180})


def save(fig: plt.Figure, name: str) -> None:
    CHARTS.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(CHARTS / name, bbox_inches="tight")
    plt.close(fig)


def static_charts(static: list[dict[str, str]]) -> None:
    rows = {method: [row for row in static if row["method"] == method] for method in METHODS}
    fig, axes = plt.subplots(2, 2, figsize=(13, 8))
    metrics = [
        ("navigation_time_s", "Navigation time (s)"),
        ("actual_trajectory_length_m", "Actual trajectory length (m)"),
        ("min_lateral_clearance_m", "Minimum lateral clearance (m)"),
        ("energy_j_per_m", "Energy per distance (J/m)"),
    ]
    for axis, (key, title) in zip(axes.flat, metrics):
        means = [np.mean([f(row[key]) for row in rows[method]]) for method in METHODS]
        axis.bar(range(len(METHODS)), means, color=[COLORS[m] for m in METHODS])
        axis.set_title(title)
        axis.set_xticks(range(len(METHODS)), ["NeuPAN", "DCT-core", "RL+NeuPAN"], rotation=15)
        axis.grid(axis="y", alpha=0.25)
        for i, value in enumerate(means):
            axis.text(i, value, f"{value:.2f}", ha="center", va="bottom", fontsize=9)
    fig.suptitle("Static held-out generalization: mean metrics (n=4 per method)")
    save(fig, "static_mean_metrics.png")

    fig, axes = plt.subplots(1, 2, figsize=(12, 4.8))
    for axis, obstacle_count in zip(axes, [1, 2]):
        subset = [row for row in static if int(row["obstacle_count"]) == obstacle_count]
        for method in METHODS:
            values = [f(row["navigation_time_s"]) for row in subset if row["method"] == method]
            axis.bar(METHODS.index(method), np.mean(values), color=COLORS[method], label=LABELS[method])
        axis.set_title(f"{obstacle_count} static obstacle(s)")
        axis.set_xticks(range(3), ["NeuPAN", "DCT-core", "RL+NeuPAN"], rotation=15)
        axis.set_ylabel("Mean navigation time (s)")
        axis.grid(axis="y", alpha=0.25)
    axes[1].legend(loc="upper left", fontsize=8)
    fig.suptitle("Static navigation time by obstacle count")
    save(fig, "static_time_by_obstacle_count.png")

    fig, ax = plt.subplots(figsize=(8, 4.8))
    for method in METHODS:
        subset = [row for row in static if row["method"] == method]
        rate = 100.0 * sum(row["success"] == "True" for row in subset) / len(subset)
        ax.bar(METHODS.index(method), rate, color=COLORS[method], label=LABELS[method])
    ax.set_ylim(0, 110)
    ax.set_ylabel("Success rate (%)")
    ax.set_xticks(range(3), ["NeuPAN", "DCT-core", "RL+NeuPAN"])
    ax.set_title("Static held-out success rate")
    ax.grid(axis="y", alpha=0.25)
    for i in range(3):
        ax.text(i, 100, "100%", ha="center", va="bottom")
    save(fig, "static_success_rate.png")


def dynamic_charts(dynamic: list[dict[str, str]], paired: list[dict[str, str]], stage_stats: list[dict[str, str]]) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(13, 5))
    conditions = ["moving_crossing", "appears_then_stops"]
    for condition_index, condition in enumerate(conditions):
        subset = [row for row in paired if row["condition"] == condition]
        x = np.arange(len(METHODS))
        width = 0.35
        axes[0].bar(x + condition_index * width - width / 2, [f(row["additional_time_s"]) for row in subset], width, label=condition)
        axes[1].bar(x + condition_index * width - width / 2, [f(row["additional_time_percent_of_baseline"]) for row in subset], width, label=condition)
    for axis, title, ylabel in zip(axes, ["Additional time vs no-obstacle baseline", "Relative time increase"], ["Additional time (s)", "Increase (%)"]):
        axis.set_title(title)
        axis.set_xticks(np.arange(len(METHODS)) + width / 2, ["NeuPAN", "DCT-core", "RL+NeuPAN"])
        axis.set_ylabel(ylabel)
        axis.grid(axis="y", alpha=0.25)
        axis.legend()
    save(fig, "dynamic_additional_time_vs_baseline.png")

    fig, axes = plt.subplots(1, 2, figsize=(13, 5))
    for condition_index, condition in enumerate(conditions):
        subset = [row for row in paired if row["condition"] == condition]
        x = np.arange(len(METHODS))
        width = 0.35
        axes[0].bar(x + condition_index * width - width / 2, [f(row["replanning_count"]) for row in subset], width, label=condition)
        axes[1].bar(x + condition_index * width - width / 2, [f(row["astar_compute_total_ms"]) / 1000.0 for row in subset], width, label=condition)
    axes[0].set_title("Dynamic A* replanning count")
    axes[0].set_ylabel("Number of completed replans")
    axes[1].set_title("Dynamic A* compute overhead")
    axes[1].set_ylabel("Total A* compute (s)")
    for axis in axes:
        axis.set_xticks(np.arange(len(METHODS)) + width / 2, ["NeuPAN", "DCT-core", "RL+NeuPAN"])
        axis.grid(axis="y", alpha=0.25)
        axis.legend()
    save(fig, "dynamic_astar_overhead.png")

    selected_stages = [
        "appearance_to_perception_ms",
        "perception_to_map_update_ms",
        "map_update_to_astar_complete_ms",
        "local_planner_compute_ms",
        "appearance_to_control_ms",
    ]
    stage_labels = ["Appear→sense", "Sense→map", "Map→A* done", "Local solve", "Appear→control"]
    fig, axes = plt.subplots(1, 2, figsize=(15, 6), sharey=True)
    for axis, condition in zip(axes, conditions):
        subset = [row for row in stage_stats if row["condition"] == condition and row["stage"] in selected_stages]
        matrix = np.array([[f(next(row["p50_ms"] for row in subset if row["stage"] == stage)) for stage in selected_stages] for _ in METHODS])
        # Rebuild by method because stage_stats is long-form.
        matrix = np.array([[f(next(row["p50_ms"] for row in subset if row["stage"] == stage and row["method"] == method)) or 0.0 for stage in selected_stages] for method in METHODS])
        image = axis.imshow(matrix, aspect="auto", cmap="YlOrRd")
        axis.set_title(condition)
        axis.set_yticks(range(len(METHODS)), ["NeuPAN", "DCT-core", "RL+NeuPAN"])
        axis.set_xticks(range(len(selected_stages)), stage_labels, rotation=35, ha="right")
        for i in range(matrix.shape[0]):
            for j in range(matrix.shape[1]):
                axis.text(j, i, f"{matrix[i, j]:.0f}", ha="center", va="center", fontsize=8)
    fig.colorbar(image, ax=axes.ravel().tolist(), label="P50 latency (ms)")
    fig.suptitle("Dynamic event-chain latency heatmap")
    save(fig, "dynamic_event_latency_heatmap.png")


def speed_ablation_charts(ablation: list[dict[str, str]]) -> None:
    labels = [row["scene"].replace("navigation_benchmark_heldout_", "") for row in ablation]
    x = np.arange(len(labels))
    width = 0.36

    fig, ax = plt.subplots(figsize=(9, 5))
    original = [f(row["original_navigation_time_s"]) for row in ablation]
    forced = [f(row["ablation_navigation_time_s"]) for row in ablation]
    ax.bar(x - width / 2, original, width, label="Original RL: 0.4x", color="#9ECAE1")
    ax.bar(x + width / 2, forced, width, label="Route-preserved speed override: 0.7x", color="#2171B5")
    ax.set_ylabel("Navigation time (s)")
    ax.set_title("RL speed-action ablation: navigation time")
    ax.set_xticks(x, labels)
    ax.grid(axis="y", alpha=0.25)
    ax.legend(fontsize=8)
    for positions, values in ((x - width / 2, original), (x + width / 2, forced)):
        for position, value in zip(positions, values):
            ax.text(position, value, f"{value:.2f}", ha="center", va="bottom", fontsize=9)
    save(fig, "rl_speed_ablation_time.png")

    fig, ax = plt.subplots(figsize=(9, 5))
    original = [f(row["original_energy_j_per_m"]) for row in ablation]
    forced = [f(row["ablation_energy_j_per_m"]) for row in ablation]
    ax.bar(x - width / 2, original, width, label="Original RL: 0.4x", color="#FDD0A2")
    ax.bar(x + width / 2, forced, width, label="Speed override: 0.7x", color="#E6550D")
    ax.set_ylabel("Mechanical energy per distance (J/m)")
    ax.set_title("RL speed-action ablation: energy intensity")
    ax.set_xticks(x, labels)
    ax.grid(axis="y", alpha=0.25)
    ax.legend(fontsize=8)
    for positions, values in ((x - width / 2, original), (x + width / 2, forced)):
        for position, value in zip(positions, values):
            ax.text(position, value, f"{value:.2f}", ha="center", va="bottom", fontsize=9)
    save(fig, "rl_speed_ablation_energy.png")

    fig, ax = plt.subplots(figsize=(9, 5))
    original = [f(row["original_min_lateral_clearance_m"]) for row in ablation]
    forced = [f(row["ablation_min_lateral_clearance_m"]) for row in ablation]
    ax.bar(x - width / 2, original, width, label="Original RL: 0.4x", color="#A1D99B")
    ax.bar(x + width / 2, forced, width, label="Speed override: 0.7x", color="#238B45")
    ax.set_ylabel("Minimum lateral clearance (m)")
    ax.set_title("RL speed-action ablation: safety geometry")
    ax.set_xticks(x, labels)
    ax.grid(axis="y", alpha=0.25)
    ax.legend(fontsize=8)
    for positions, values in ((x - width / 2, original), (x + width / 2, forced)):
        for position, value in zip(positions, values):
            ax.text(position, value, f"{value:.3f}", ha="center", va="bottom", fontsize=9)
    save(fig, "rl_speed_ablation_clearance.png")


def html_report(static: list[dict[str, str]], dynamic: list[dict[str, str]], paired: list[dict[str, str]], ablation: list[dict[str, str]]) -> None:
    chart_names = [
        ("static_mean_metrics.png", "静态平均性能指标"),
        ("static_time_by_obstacle_count.png", "按障碍数量分组的静态导航时间"),
        ("static_success_rate.png", "静态成功率"),
        ("dynamic_additional_time_vs_baseline.png", "动态相对无障碍 baseline 的额外耗时"),
        ("dynamic_astar_overhead.png", "动态 A* 重规划次数与计算开销"),
        ("dynamic_event_latency_heatmap.png", "动态事件链延迟热力图"),
        ("rl_speed_ablation_time.png", "RL 速度动作消融：导航时间"),
        ("rl_speed_ablation_energy.png", "RL 速度动作消融：单位距离能耗"),
        ("rl_speed_ablation_clearance.png", "RL 速度动作消融：最小净空"),
    ]
    rows = []
    for row in paired:
        rows.append("<tr>" + "".join(f"<td>{html.escape(str(row[key]))}</td>" for key in ("condition", "method_label", "baseline_navigation_time_s", "dynamic_navigation_time_s", "additional_time_s", "additional_time_percent_of_baseline", "replanning_count", "astar_compute_total_ms")) + "</tr>")
    video_links = []
    for path in sorted((OUTPUT / "videos").glob("*.mp4")):
        video_links.append(f'<li><a href="videos/{html.escape(path.name)}">{html.escape(path.name)}</a></li>')
    figures = "\n".join(f'<h2>{title}</h2><img src="charts/{name}" alt="{title}">' for name, title in chart_names)
    document = f"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><title>导航实验图表报告</title>
<style>body{{font-family:Arial,'Noto Sans CJK TC',sans-serif;max-width:1500px;margin:30px auto;line-height:1.5;color:#222}} img{{max-width:100%;border:1px solid #ddd;margin-bottom:20px}} table{{border-collapse:collapse;width:100%;font-size:14px}} th,td{{border:1px solid #ccc;padding:6px 8px;text-align:right}} th{{background:#f1f3f5}} td:first-child,td:nth-child(2){{text-align:left}} .note{{background:#fff8e1;padding:12px;border-left:4px solid #f0ad00}}</style></head>
<body><h1>导航对比实验图表报告（seed=22）</h1>
<div class="note"><b>实验范围：</b>Isaac 仿真 pilot；静态 12 回合、动态 6 回合、无障碍 baseline 3 回合。动态条件均未出现 avoidance_confirmed，因此图表不把它们标记为成功避障。</div>
<h2>关键结论</h2><ul><li>静态三种方法均为 4/4 到达。</li><li>双障碍 v1 中 RL 选择 MID 路线的 0.4x 速度档，基线选择 MID 的 0.7x 速度档，导致 RL 时间约 39.28 s，而基线约 22.92 s。</li><li>速度消融保持 MID 路线不变，仅把速度替换为 0.7x 后，两个双障碍布局均恢复到约 23 s；最小净空、成功率和安全代理没有下降。</li><li>动态相对无障碍 baseline 额外观察时间约 11.3–11.6 s；A* 额外完成 2–4 次。</li></ul>
{figures}
<h2>RL 速度动作消融数据</h2><p>消融只替换速度 index，保留 PPO 选择的 route index。原始 RL 与消融均为成功到达、无硬失败、无截断、无接触力代理违反。</p>
<table><thead><tr><th>布局</th><th>路线</th><th>原始速度</th><th>强制速度</th><th>原始时间(s)</th><th>消融时间(s)</th><th>减少(s)</th><th>原始净空(m)</th><th>消融净空(m)</th><th>原始能耗(J/m)</th><th>消融能耗(J/m)</th></tr></thead><tbody>{''.join("<tr>" + "".join(f"<td>{html.escape(str(row[key]))}</td>" for key in ("scene", "original_dominant_route", "original_dominant_speed_ratio", "ablation_dominant_speed_ratio", "original_navigation_time_s", "ablation_navigation_time_s", "time_reduction_s", "original_min_lateral_clearance_m", "ablation_min_lateral_clearance_m", "original_energy_j_per_m", "ablation_energy_j_per_m")) + "</tr>" for row in ablation)}</tbody></table>
<h2>动态 paired baseline 数据</h2><table><thead><tr><th>条件</th><th>方法</th><th>无障碍时间(s)</th><th>动态时间(s)</th><th>额外时间(s)</th><th>增加(%)</th><th>A*重规划次数</th><th>A*总计算(ms)</th></tr></thead><tbody>{''.join(rows)}</tbody></table>
<h2>视频</h2><p>全部视频均来自实际回合：</p><ul>{''.join(video_links)}</ul>
<p>原始数据：<code>formal_navigation_static.csv</code>、<code>formal_navigation_dynamic.csv</code>、<code>formal_navigation_dynamic_paired.csv</code>、<code>formal_navigation_dynamic_stage_stats.csv</code>、<code>formal_navigation_rl_speed_ablation.csv</code>、<code>formal_navigation_rl_speed_ablation.json</code>。</p></body></html>"""
    (OUTPUT / "formal_navigation_visual_report.html").write_text(document, encoding="utf-8")

    markdown = "# 导航对比实验图表报告（seed=22）\n\n"
    markdown += "静态图表、动态 paired baseline、事件链延迟和视频索引如下。动态回合缺少 `avoidance_confirmed`，因此不能判定为成功避障。\n\n"
    for name, title in chart_names:
        markdown += f"## {title}\n\n![{title}](/home/ky/Documents/Codex/2026-10-22/01a1637e-689a-7ad3-a978-cd7867126368-2/outputs/formal_navigation_20261024/charts/{name})\n\n"
    markdown += "## RL 速度动作消融\n\n保持 RL 选择的 `MID` 路线不变，仅将速度动作从 `0.4x` 强制替换为 `0.7x`。`double_v1` 的导航时间从 `39.28 s` 降到 `22.94 s`，`double_v2` 从 `38.82 s` 降到 `22.76 s`；两回合成功、无硬失败和安全代理违反，最小净空基本不变，单位距离能耗下降。该结果把当前变慢原因主要定位到速度动作/奖励校准，而不是路线选择或局部路径跟踪；但这是 `seed=22`、`n=2` 的 pilot，不能单独证明 RL 已充分训练或结论对所有布局都成立。\n\n"
    markdown += "消融逐回合数据：`/home/ky/Documents/Codex/2026-10-22/01a1637e-689a-7ad3-a978-cd7867126368-2/outputs/formal_navigation_20261024/formal_navigation_rl_speed_ablation.csv`；结构化结果：`/home/ky/Documents/Codex/2026-10-22/01a1637e-689a-7ad3-a978-cd7867126368-2/outputs/formal_navigation_20261024/formal_navigation_rl_speed_ablation.json`。\n\n"
    markdown += "## 可视化报告\n\n`/home/ky/Documents/Codex/2026-10-22/01a1637e-689a-7ad3-a978-cd7867126368-2/outputs/formal_navigation_20261024/formal_navigation_visual_report.html`\n"
    (OUTPUT / "formal_navigation_visual_report.md").write_text(markdown, encoding="utf-8")


def main() -> None:
    set_style()
    with SUMMARY.open(encoding="utf-8") as handle:
        summary = json.load(handle)
    static = load_csv("formal_navigation_static.csv")
    dynamic = load_csv("formal_navigation_dynamic.csv")
    paired = load_csv("formal_navigation_dynamic_paired.csv")
    stage_stats = load_csv("formal_navigation_dynamic_stage_stats.csv")
    ablation = load_csv("formal_navigation_rl_speed_ablation.csv")
    static_charts(static)
    dynamic_charts(dynamic, paired, stage_stats)
    speed_ablation_charts(ablation)
    html_report(static, dynamic, paired, ablation)
    print(OUTPUT / "formal_navigation_visual_report.html")


if __name__ == "__main__":
    main()
