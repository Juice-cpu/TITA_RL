"""Evaluate a full prediction snapshot without ROS, simulation, or actuation."""

from __future__ import annotations

import argparse
from dataclasses import asdict
import json
from pathlib import Path

from tita_uc_residual_rl.navigation_formula import (
    FORMULA_VERSION,
    ActionPrediction,
    DecisionContext,
    FormulaConfig,
    PathPrediction,
    enumerate_best,
    evaluate_candidates,
)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("snapshot", type=Path, help="JSON with config, context, paths, predictions")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--allow-uncalibrated", action="store_true", help="offline equation checks only; never enables motion")
    args = parser.parse_args()
    payload = json.loads(args.snapshot.read_text(encoding="utf-8"))
    config = FormulaConfig.from_dict(payload["config"])
    context = DecisionContext(**payload["context"])
    paths = tuple(PathPrediction(**item) for item in payload["paths"])
    predictions = tuple(ActionPrediction(**item) for item in payload["predictions"])
    evaluations = evaluate_candidates(paths, predictions, context, config,
                                       require_calibration=not args.allow_uncalibrated)
    best = enumerate_best(evaluations)
    result = {
        "formula_version": FORMULA_VERSION,
        "calibrated": config.calibrated,
        "offline_only": True,
        "selected_action": best.action_id if best is not None else None,
        "selected_path": paths[best.path_index].path_id if best is not None else None,
        "status": "feasible" if best is not None else "safe_stop",
        "evaluations": [asdict(item) for item in evaluations],
    }
    text = json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
    else:
        print(text, end="")


if __name__ == "__main__":
    main()
