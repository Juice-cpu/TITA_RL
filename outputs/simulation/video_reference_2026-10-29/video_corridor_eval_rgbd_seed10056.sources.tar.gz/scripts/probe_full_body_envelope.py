from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from isaaclab.app import AppLauncher

parser = argparse.ArgumentParser()
parser.add_argument("--asset", required=True)
parser.add_argument("--checkpoint", required=True)
parser.add_argument("--posture-profile", type=Path, required=True)
parser.add_argument("--velocity-calibration", type=Path, required=True)
parser.add_argument("--residual-checkpoint", type=Path)
parser.add_argument("--modes", nargs="+", choices=("LOW", "MID", "HIGH"), default=("LOW", "MID", "HIGH"))
parser.add_argument("--linear-probe-speed", type=float, default=.15)
parser.add_argument("--linear-probe-speeds", type=float, nargs="+")
parser.add_argument("--combined-commands", action="store_true")
parser.add_argument("--yaw-probe-rate", type=float, default=.2)
parser.add_argument("--support-height", type=float, default=0.)
parser.add_argument("--support-foundation-depth", type=float, default=0.)
parser.add_argument("--support-mesh-collider", action="store_true")
parser.add_argument("--convex-cylinders", action="store_true")
parser.add_argument("--diagnostic-state", action="store_true")
parser.add_argument("--physics-device", choices=("cpu", "cuda:0"), default="cpu")
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--steps", type=int, default=800)
parser.add_argument("--settle-steps", type=int, default=400)
parser.add_argument("--seed", type=int, default=701)
AppLauncher.add_app_launcher_args(parser)
args = parser.parse_args()
simulation_app = AppLauncher(args).app

import numpy as np
import torch

from tita_uc_residual_rl.collision_envelope import UrdfCollisionEnvelope, convex_hull_xy
from tita_uc_residual_rl.isaaclab_tita_env import TitaResidualEnv, build_tita_cfg
from tita_uc_residual_rl.isaac_udp_bridge import governed_policy_command
from tita_uc_residual_rl.official_policy import FrozenOfficialTitaController, OfficialTitaActor
from tita_uc_residual_rl.posture_calibration import load_posture_calibration, posture_anchors
from tita_uc_residual_rl.velocity_calibration import load_velocity_calibration, blend_governor_parameters
from tita_uc_residual_rl.phase_b_learner import PhaseBActorCritic, load_phase_b_state_dict_compatible
from tita_uc_residual_rl.execution_contract import residual_training_scope
from tita_uc_residual_rl.experiment_provenance import input_hashes, snapshot_sources
from tita_uc_residual_rl.execution_probe_commands import envelope_probe_commands


def main() -> None:
    if args.output.exists() or not 0 < args.settle_steps < args.steps or not 0. <= args.support_height <= .1:
        raise ValueError("output must be new and steps must exceed settling steps")
    source_provenance = snapshot_sources(Path(__file__).resolve().parents[1], args.output.with_suffix(".sources.tar.gz"))
    artifacts = input_hashes({"asset": args.asset, "base_actor": args.checkpoint,
                             "residual": args.residual_checkpoint, "posture_profile": args.posture_profile,
                             "velocity_calibration": args.velocity_calibration})
    names = ("LOW", "MID", "HIGH")
    probe_speeds = args.linear_probe_speeds or [args.linear_probe_speed]
    commands_to_probe = envelope_probe_commands(probe_speeds, args.combined_commands, args.yaw_probe_rate)
    specifications = [(name, command) for name in args.modes for command in commands_to_probe]
    if args.support_height:
        specifications = [specification for specification in specifications for _ in range(2)]
    cfg = build_tita_cfg(args.asset, num_envs=len(specifications), terrain="stairs" if args.support_height else "flat")
    cfg.sim.device = args.physics_device
    cfg.convex_cylinder_collisions = args.convex_cylinders
    cfg.sim.disable_contact_processing = False
    cfg.sim.enable_scene_query_support = args.diagnostic_state
    cfg.scene.env_spacing = max(20., 2. * (max(probe_speeds) + .25) * args.steps * .02 + 4.)
    if args.support_height:
        cfg.stair_support_augmentation_enabled = True
        cfg.stair_foundation_depth_m = args.support_foundation_depth
        cfg.stair_mesh_collider_enabled = args.support_mesh_collider
        cfg.stair_support_augmentation_offset_m = 12.
        cfg.stair_start_x_m = 12.
        cfg.stair_step_height_range_m = (args.support_height, args.support_height)
        cfg.stair_tread_range_m = (.6, .6)
        cfg.stair_width_range_m = (30., 30.)
        cfg.stair_num_steps = 1
        cfg.stair_landing_length_m = 30.
        cfg.stair_step_assist_enabled = False
        cfg.stair_terminate_on_success = False
        cfg.scene.env_spacing = 80.
    profile = load_posture_calibration(args.posture_profile)
    cfg.posture_joint_anchors = posture_anchors(profile)
    cfg.posture_heights = tuple(profile["profiles"][name]["command_height_m"] for name in names)
    residual_payload = None
    if args.residual_checkpoint:
        residual_payload = torch.load(args.residual_checkpoint, map_location="cpu", weights_only=True)
        if any(name not in residual_training_scope(residual_payload) for name in args.modes):
            raise ValueError("envelope probe modes exceed residual training scope")
        execution = residual_payload["execution_config"]
        cfg.navigation_pose_observations = execution.get("navigation_pose_observations", False)
        if execution["asset_sha256"] != hashlib.sha256(Path(args.asset).read_bytes()).hexdigest():
            raise ValueError("residual asset mismatch")
        for field in ("residual_filter_alpha", "acceleration_limit", "enforce_acceleration_limit", "normalized_cost_clip", "objective_p95"):
            setattr(cfg, field, execution[field])
        cfg.residual_limit = residual_payload["policy_config"]["residual_limit"]
        cfg.posture_scale = residual_payload["policy_config"]["posture_scale"]
    cfg.seed = args.seed
    cfg.episode_length_s = args.steps * 0.02 + 5.0
    calibration = load_velocity_calibration(args.velocity_calibration, posture_joint_anchors=cfg.posture_joint_anchors,
                                            checkpoint_path=args.checkpoint, asset_path=args.asset)
    env = TitaResidualEnv(cfg)
    env.reset()
    controller = FrozenOfficialTitaController(OfficialTitaActor.from_checkpoint(args.checkpoint, env.device))
    controller.reset(env.num_envs, env.device)
    envelope = UrdfCollisionEnvelope(args.asset, include_visual_geometry=True)
    geometry = UrdfCollisionEnvelope(args.asset)
    parameters = [dict(calibration["profiles"]["MID"]) for _ in specifications]
    command = torch.tensor([item[1] for item in specifications], dtype=torch.float32, device=env.device)
    posture = torch.nn.functional.one_hot(torch.tensor([names.index(item[0]) for item in specifications], device=env.device), 3).float()
    residual = torch.zeros(env.num_envs, 8, device=env.device)
    residual_policy = None
    if residual_payload:
        residual_policy = PhaseBActorCritic(obs_dim=env._get_observations()["policy"].shape[-1], residual_limit=cfg.residual_limit, posture_scale=cfg.posture_scale).to(env.device)
        load_phase_b_state_dict_compatible(residual_policy, residual_payload["model_state_dict"])
        residual_policy.eval()
    failures = np.zeros(env.num_envs, dtype=int)
    failure_events = []
    minimum_root_separation_m = float("inf")
    records = [[] for _ in specifications]
    try:
        for step in range(args.steps):
            requested = command if step >= args.settle_steps else torch.zeros_like(command)
            env.set_velocity_command(requested)
            env.set_posture_command(posture)
            measured = torch.cat((env.robot.data.root_lin_vel_b[:, :2], env.robot.data.root_ang_vel_b[:, 2:3]), dim=1).cpu().tolist()
            commands = []
            for index, (name, target) in enumerate(specifications):
                parameters[index] = blend_governor_parameters(parameters[index], calibration["profiles"][name], min(env.step_dt / cfg.posture_feedforward_transition_s, 1.0))
                commands.append(governed_policy_command(tuple(requested[index].cpu().tolist()), tuple(measured[index]), **parameters[index]))
            proprioception = env.official_proprioception(controller.previous_policy_action)
            proprioception[:, 6:9] = proprioception.new_tensor(commands) * proprioception.new_tensor([2, 2, 0.25])
            target, _ = controller.target(proprioception, env.default_joint_target())
            env.set_base_target(target)
            if residual_policy is not None:
                with torch.no_grad():
                    residual = residual_policy.policy(env._get_observations()["policy"])
            _, _, terminated, truncated, _ = env.step(residual)
            controller.reset_envs(terminated | truncated)
            failures += terminated.cpu().numpy().astype(int)
            for index in torch.nonzero(terminated).flatten().cpu().tolist():
                failure_events.append({"step": step, "case": index, "posture": specifications[index][0],
                                       "command": list(specifications[index][1]),
                                       "terminal_root_position_world_m": env.last_transition_root_position[index].detach().cpu().tolist(),
                                       "hard_reason_flags": env.hard_reason_flags[index].detach().cpu().tolist()})
            if step >= args.settle_steps and step % 5 == 0:
                positions = env.robot.data.body_link_pos_w.cpu().numpy()
                rotations = env.robot.data.body_link_quat_w.cpu().numpy()
                root_positions = env.robot.data.root_pos_w.cpu().numpy()
                root_rotations = env.robot.data.root_quat_w.cpu().numpy()
                if env.num_envs > 1:
                    separations = np.linalg.norm(root_positions[:, None, :2] - root_positions[None, :, :2], axis=-1)
                    np.fill_diagonal(separations, np.inf)
                    minimum_root_separation_m = min(minimum_root_separation_m, float(separations.min()))
                origins = env._environment_origins().cpu().numpy()
                support_heights = env._stair_support_height().cpu().numpy()
                verified_wheel_levels = env._wheel_stair_state()[0].cpu().tolist()
                for index in range(env.num_envs):
                    ground = origins[index, 2] + support_heights[index]
                    record = envelope.measure(env.robot.body_names, positions[index], rotations[index], root_positions[index], root_rotations[index], ground)
                    record["simulated_collision_top_m"] = geometry.measure(env.robot.body_names, positions[index], rotations[index], root_positions[index], root_rotations[index], ground)["top_above_ground_m"]
                    record["support_height_m"] = float(support_heights[index])
                    record["verified_wheel_levels"] = verified_wheel_levels[index]
                    record["posture_height_m"] = float(env.posture_height[index])
                    record["measured_velocity"] = measured[index]
                    record["requested_velocity"] = list(specifications[index][1])
                    if args.diagnostic_state:
                        record["diagnostic_state"] = {
                            "root_position_world_m": root_positions[index].tolist(),
                            "root_quaternion_wxyz": root_rotations[index].tolist(),
                            "joint_positions_rad": env.robot.data.joint_pos[index, env._joint_ids].cpu().tolist(),
                            "wheel_axis_world_z_m": env.robot.data.body_pos_w[index, env._wheel_body_ids, 2].cpu().tolist(),
                            "wheel_positions_world_m": env.robot.data.body_link_pos_w[index, env._wheel_body_ids].cpu().tolist(),
                            "wheel_quaternions_wxyz": env.robot.data.body_link_quat_w[index, env._wheel_body_ids].cpu().tolist(),
                            "wheel_contacts": env._wheel_contact[index].cpu().tolist(),
                            "posture_offset_rad": env._posture_offset[index].cpu().tolist(),
                            "base_target_rad": env._base_target[index].cpu().tolist(),
                            "filtered_residual_rad": env._actions[index].cpu().tolist(),
                            "projected_gravity_body": env.robot.data.projected_gravity_b[index].cpu().tolist(),
                        }
                    records[index].append(record)
            if step % 200 == 0:
                print(f"geometry step={step} hard_failures={failures.tolist()}", flush=True)
        profiles = {}
        for name in args.modes:
            indices = [index for index, specification in enumerate(specifications) if specification[0] == name]
            samples = [record for index in indices for record in records[index]]
            profiles[name] = {
                "valid": not bool(failures[indices].any()) and minimum_root_separation_m >= 2., "hard_failures": int(failures[indices].sum()),
                "sample_count": len(samples),
                "validated_linear_speed_mps": max(probe_speeds),
                "validated_yaw_rate_radps": args.yaw_probe_rate,
                "tested_linear_speeds_mps": sorted(set(probe_speeds)),
                "combined_linear_yaw_commands_tested": args.combined_commands,
                "body_height_envelope_m": max(record["top_above_ground_m"] for record in samples),
                "simulated_collision_height_envelope_m": max(record["simulated_collision_top_m"] for record in samples),
                "minimum_base_clearance_m": min(record["base_clearance_m"] for record in samples),
                "posture_height_mean_m": float(np.mean([record["posture_height_m"] for record in samples])),
                "posture_height_maximum_absolute_error_m": max(abs(record["posture_height_m"] - profile["profiles"][name]["command_height_m"]) for record in samples),
                "posture_tracking_fraction_within_25mm": float(np.mean([abs(record["posture_height_m"] - profile["profiles"][name]["command_height_m"]) <= .025 for record in samples])),
                "mean_absolute_linear_tracking_error_mps": float(np.mean([abs(record["measured_velocity"][0] - record["requested_velocity"][0]) for record in samples])),
                "mean_absolute_yaw_tracking_error_radps": float(np.mean([abs(record["measured_velocity"][2] - record["requested_velocity"][2]) for record in samples])),
                "command_tracking_scope": "Geometric validity does not imply velocity tracking or closed-loop navigation success",
                "footprint_vertices_xy_m": convex_hull_xy(np.vstack([record["footprint_vertices_xy_m"] for record in samples])).tolist(),
            }
        support_diagnostics = []
        if args.diagnostic_state and args.support_height:
            from pxr import Usd, UsdGeom
            from tita_uc_residual_rl.isaac_scene_query import PhysicsDepthSensors
            sensor = PhysicsDepthSensors(ignored_path="/World/envs/")
            env.sim.render()
            bounds = UsdGeom.BBoxCache(Usd.TimeCode.Default(), [UsdGeom.Tokens.default_])
            for index in range(env.num_envs):
                platform = env.scene.stage.GetPrimAtPath(f"/World/stairs/env_{index}/Step_1")
                box = bounds.ComputeWorldBound(platform).ComputeAlignedRange()
                wheels = env.robot.data.body_link_pos_w[index, env._wheel_body_ids].cpu().numpy()
                hits = []
                for position in wheels:
                    origin = position.copy()
                    origin[2] += 1.
                    scan = sensor.scan(origin, np.array([[0., 0., -1.]]), args.steps * env.step_dt)
                    raw_hits = []

                    def record_hit(hit):
                        raw_hits.append({"body": str(hit.rigid_body), "position": list(hit.position), "distance": float(hit.distance)})
                        return True

                    sensor.query.raycast_all(tuple(origin), (0., 0., -1.), 8., record_hit)
                    hits.append({"points_world_m": scan.points_world_m.tolist(), "body_paths": scan.body_paths, "raw_hits": raw_hits})
                support_diagnostics.append({"case": index,
                                            "environment_origin_m": env._environment_origins()[index].cpu().tolist(),
                                            "terrain_origin_m": env.terrain.env_origins[index].cpu().tolist(),
                                            "platform_bounds_min_m": list(box.GetMin()),
                                            "platform_bounds_max_m": list(box.GetMax()),
                                            "wheel_ground_rays": hits})
        report = {
            "schema": "tita.full_body_envelope.v1", "simulation_only": True, "seed": args.seed,
            "scope": "URDF visual bounding boxes union collision primitives at measured Isaac body-link poses; flat and optional elevated support, frozen controller",
            "support_height_m": args.support_height, "execution_source_provenance": source_provenance,
            "diagnostic_state_recorded": args.diagnostic_state,
            "support_foundation_depth_m": cfg.stair_foundation_depth_m,
            "support_mesh_collider_enabled": cfg.stair_mesh_collider_enabled,
            "convex_cylinder_collisions": cfg.convex_cylinder_collisions,
            "physical_support_diagnostics": support_diagnostics,
            "navigation_pose_observations": cfg.navigation_pose_observations,
            "command_coverage_scope": "Finite sampled commands and support cases, not a continuous execution or safety certificate",
            "commands_tested_mps_radps": commands_to_probe,
            "physics_device": str(env.device), "contact_processing_enabled": True,
            "environment_spacing_m": cfg.scene.env_spacing,
            "minimum_robot_root_separation_m": minimum_root_separation_m if env.num_envs > 1 else None,
            "probe_isolation_valid": minimum_root_separation_m >= 2.,
            "failure_events": failure_events,
            "input_artifacts": artifacts,
            "steps": args.steps, "settle_steps": args.settle_steps, "samples_per_case": len(records[0]),
            "asset_sha256": hashlib.sha256(Path(args.asset).read_bytes()).hexdigest(),
            "checkpoint_sha256": hashlib.sha256(Path(args.checkpoint).read_bytes()).hexdigest(),
            "residual_sha256": hashlib.sha256(args.residual_checkpoint.read_bytes()).hexdigest() if args.residual_checkpoint else None,
            "posture_joint_anchors": cfg.posture_joint_anchors, "profiles": profiles,
            "cases": [{"posture": specification[0], "command": specification[1], "hard_failures": int(failures[index]), "samples": records[index]} for index, specification in enumerate(specifications)],
        }
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
        print(json.dumps(profiles, indent=2), flush=True)
    finally:
        env.close()
        simulation_app.close()


if __name__ == "__main__":
    main()
