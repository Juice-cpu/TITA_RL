#!/usr/bin/env python3
"""Evaluate rule, enumerated-objective, and learned upper policies."""

from __future__ import annotations

import argparse
from dataclasses import asdict
from pathlib import Path

from tita_uc_residual_rl.upper_level_experiment import (
    calibrate_rule_references,
    evaluate_policy,
    metrics_as_dicts,
    objective_weight_variants,
    paired_bootstrap_cost_difference,
    summarize_metrics,
    write_json,
)
from tita_uc_residual_rl.upper_level_objective import (
    EnumeratedObjectivePolicy,
    ShortestRoutePolicy,
)
from tita_uc_residual_rl.upper_level_policy import LearnedUpperPolicy, load_upper_checkpoint
from tita_uc_residual_rl.upper_level_types import UpperObjectiveWeights


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path)
    parser.add_argument("--episodes", type=int, default=108)
    parser.add_argument("--seed", type=int, default=33)
    parser.add_argument("--calibration-episodes", type=int, default=128)
    parser.add_argument("--include-sensitivity", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.episodes <= 0:
        raise ValueError("episodes must be positive")
    normalization = calibrate_rule_references(
        seed=20261009, episodes=args.calibration_episodes
    )
    base_weights = UpperObjectiveWeights()
    policies = {
        "shortest_rule": ShortestRoutePolicy(),
        "enumerated_argmin": EnumeratedObjectivePolicy(normalization, base_weights),
    }
    if args.checkpoint:
        model, payload = load_upper_checkpoint(args.checkpoint)
        policies["categorical_ppo"] = LearnedUpperPolicy(model, deterministic=True)
    output: dict[str, object] = {
        "normalization": asdict(normalization),
        "episodes": args.episodes,
        "seed": args.seed,
        "methods": {},
    }
    result_sets = {}
    for method, policy in policies.items():
        results = evaluate_policy(
            policy,
            method=method,
            seed=args.seed,
            episodes=args.episodes,
            normalization=normalization,
            weights=base_weights,
            split="test",
        )
        result_sets[method] = results
        output["methods"][method] = {
            "summary": summarize_metrics(results),
            "episodes": metrics_as_dicts(results),
        }
    output["paired_bootstrap"] = {}
    if "categorical_ppo" in result_sets:
        output["paired_bootstrap"]["ppo_minus_rule"] = paired_bootstrap_cost_difference(
            result_sets["categorical_ppo"], result_sets["shortest_rule"]
        )
        output["paired_bootstrap"]["ppo_minus_argmin"] = paired_bootstrap_cost_difference(
            result_sets["categorical_ppo"], result_sets["enumerated_argmin"]
        )
    if args.include_sensitivity:
        sensitivity = {}
        for name, weights in objective_weight_variants(base_weights).items():
            policy = EnumeratedObjectivePolicy(normalization, weights)
            results = evaluate_policy(
                policy,
                method=f"enumerated_{name}",
                seed=args.seed,
                episodes=args.episodes,
                normalization=normalization,
                weights=weights,
                split="test",
            )
            sensitivity[name] = {
                "weights": asdict(weights),
                "summary": summarize_metrics(results),
            }
        output["sensitivity"] = sensitivity
    write_json(args.output, output)
    print(f"wrote {args.output}")


if __name__ == "__main__":
    main()

