#!/usr/bin/env python3
"""Run a short TITA-UC Isaac Lab task smoke on a GPU-enabled host."""

from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path
import sys
import time
import traceback

# Make the repository package importable when Isaac Lab launches this script
# through its bundled Python interpreter.
REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from tita_realtime_trace import timing_enabled, trace_event

from isaaclab.app import AppLauncher

parser = argparse.ArgumentParser()
parser.add_argument("--asset", required=True, help="official 8-DOF TITA USD or URDF")
parser.add_argument("--num_envs", type=int, default=128)
parser.add_argument("--steps", type=int, default=100)
parser.add_argument("--log-interval", type=int, default=20)
parser.add_argument("--checkpoint", default=None, help="official tita_example_10000.pt")
parser.add_argument(
    "--residual-checkpoint",
    default=None,
    help="trained Phase B residual checkpoint; requires --checkpoint",
)
parser.add_argument(
    "--residual-manifest",
    type=Path,
    default=None,
    help="JSON mapping LOW/MID/HIGH to Style-Conditioned residual checkpoints",
)
parser.add_argument("--low-residual-checkpoint", default=None)
parser.add_argument("--mid-residual-checkpoint", default=None)
parser.add_argument("--high-residual-checkpoint", default=None)
parser.add_argument(
    "--style-transition-steps",
    type=int,
    default=12,
    help="blend residual actions after a LOW/MID/HIGH style switch",
)
parser.add_argument("--command-x", type=float, default=0.0)
parser.add_argument("--command-y", type=float, default=0.0)
parser.add_argument("--command-yaw", type=float, default=0.0)
parser.add_argument(
    "--motion-suite",
    action="store_true",
    help="run idle/forward/reverse/left-yaw/right-yaw in five parallel environments",
)
parser.add_argument("--posture", choices=("LOW", "MID", "HIGH"), default="MID")
parser.add_argument("--posture-calibration", type=Path, default=None)
parser.add_argument(
    "--posture-sequence",
    nargs="+",
    choices=("LOW", "MID", "HIGH"),
    default=None,
    help="ordered posture stages; total steps are stage count times --posture-segment-steps",
)
parser.add_argument("--posture-segment-steps", type=int, default=150)
parser.add_argument("--posture-tail-steps", type=int, default=50)
parser.add_argument(
    "--disable-posture-feedforward",
    action="store_true",
    help="test the frozen official controller without LOW/MID/HIGH joint offsets",
)
parser.add_argument("--metric-warmup-steps", type=int, default=100)
parser.add_argument("--episode-length-s", type=float, default=None)
parser.add_argument("--output", type=Path, default=None)
parser.add_argument("--acceleration-limit", type=float, default=None)
parser.add_argument("--residual-filter-alpha", type=float, default=0.25)
parser.add_argument("--enforce-acceleration-limit", action="store_true")
parser.add_argument("--disable-projector", action="store_true")
parser.add_argument("--verbose-state", action="store_true")
parser.add_argument("--seed", type=int, default=11)
parser.add_argument(
    "--terrain",
    choices=(
        "flat", "rough_warmup", "route_choice", "three_route", "tunnel", "stairs"
    ),
    default="flat",
)
parser.add_argument("--tunnel-height-range", type=float, nargs=2, default=None)
parser.add_argument("--tunnel-width-range", type=float, nargs=2, default=None)
parser.add_argument("--tunnel-length-range", type=float, nargs=2, default=None)
parser.add_argument("--stair-height-range", type=float, nargs=2, default=None)
parser.add_argument("--stair-tread-range", type=float, nargs=2, default=None)
parser.add_argument("--stair-width-range", type=float, nargs=2, default=None)
parser.add_argument("--stair-num-steps", type=int, default=None)
parser.add_argument("--stair-start-x", type=float, default=None)
parser.add_argument("--stair-landing-length", type=float, default=None)
parser.add_argument("--domain-randomization", action="store_true")
parser.add_argument(
    "--ros-bridge",
    action="store_true",
    help="publish Isaac state/scan/HMAP data to ROS and consume gated cmd_vel",
)
parser.add_argument("--ros-cmd-topic", default="/neupan_navigation/gated_cmd_vel")
parser.add_argument("--ros-training-lockstep", action="store_true")
parser.add_argument("--ros-boundary-attitude-limit-rad", type=float, default=None)
parser.add_argument("--ros-odom-topic", default="/odom")
parser.add_argument("--ros-imu-topic", default="/imu/data")
parser.add_argument("--ros-scan-topic", default="/neupan_navigation/scan")
parser.add_argument("--navigation-scene-file", default="")
parser.add_argument("--ros-hmap-cloud-topic", default="/hmap/tower/mapping/cloud")
parser.add_argument("--ros-hmap-odom-topic", default="/hmap/tower/mapping/odometry")
parser.add_argument("--ros-decision-topic", default="/neupan_navigation/upper_decision")
parser.add_argument("--ros-goal-topic", default="/goal_pose")
parser.add_argument("--ros-goal-x", type=float, default=8.0)
parser.add_argument("--ros-goal-y", type=float, default=0.0)
parser.add_argument("--ros-goal-yaw", type=float, default=0.0)
parser.add_argument("--ros-command-timeout", type=float, default=0.30)
parser.add_argument(
    "--disable-ros-velocity-governor",
    action="store_true",
    help="pass ROS velocity targets directly to the frozen official actor",
)
parser.add_argument("--ros-governor-linear-bias", type=float, default=-0.72)
parser.add_argument("--ros-governor-calibration", type=Path, default=None)
parser.add_argument("--motion-profile", type=Path, default=None)
parser.add_argument("--ros-governor-linear-scale", type=float, default=0.93)
parser.add_argument("--ros-governor-linear-kp", type=float, default=0.8)
parser.add_argument("--ros-governor-angular-kp", type=float, default=0.5)
parser.add_argument("--ros-governor-max-linear-command", type=float, default=0.90)
parser.add_argument("--ros-governor-max-angular-command", type=float, default=1.00)
parser.add_argument(
    "--real-time-factor",
    type=float,
    default=0.0,
    help=(
        "pace physics against wall time (1.0 = real time, 0 disables pacing); "
        "the ROS/NeuPAN closed loop should use 1.0"
    ),
)
parser.add_argument("--udp-host", default="127.0.0.1")
parser.add_argument("--udp-tx-port", type=int, default=19001)
parser.add_argument("--udp-rx-port", type=int, default=19002)
parser.add_argument('--research-trace', type=Path, default=None)
parser.add_argument('--record-video', type=Path, default=None)
parser.add_argument('--video-label', default='navigation research')
parser.add_argument('--ffmpeg-path', default='/home/ky/GBU_tita/.miniforge3/envs/habitat_ros/lib/python3.10/site-packages/imageio_ffmpeg/binaries/ffmpeg-linux-x86_64-v7.0.2')
AppLauncher.add_app_launcher_args(parser)
args = parser.parse_args()
if args.record_video is not None:
    args.enable_cameras = True
app_launcher = AppLauncher(args)
simulation_app = app_launcher.app

import torch  # noqa: E402
import omni.timeline  # noqa: E402
import omni.usd  # noqa: E402

from tita_uc_residual_rl.isaaclab_tita_env import (  # noqa: E402
    HARD_REASON_NAMES,
    TitaResidualEnv,
    build_tita_cfg,
)
from tita_uc_residual_rl.official_policy import FrozenOfficialTitaController, OfficialTitaActor  # noqa: E402
from tita_uc_residual_rl.phase_b_learner import (  # noqa: E402
    PhaseBActorCritic,
    load_phase_b_state_dict_compatible,
)
from tita_uc_residual_rl.isaac_udp_bridge import IsaacUdpBridge  # noqa: E402
from tita_uc_residual_rl.motion_profile import load_motion_profile
from tita_uc_residual_rl.training_contract import boundary_attitude_exceeded


def main() -> None:
    if args.ros_boundary_attitude_limit_rad is not None:
        if not args.ros_training_lockstep:
            raise ValueError("boundary attitude termination requires Isaac lockstep")
        boundary_attitude_exceeded([1.0, 0.0, 0.0, 0.0], args.ros_boundary_attitude_limit_rad)
    if args.posture_calibration is not None:
        os.environ["TITA_POSTURE_CALIBRATION"] = str(args.posture_calibration.resolve())
    if args.log_interval <= 0:
        raise ValueError("--log-interval must be positive")
    if args.style_transition_steps < 0:
        raise ValueError("--style-transition-steps must be non-negative")
    if args.motion_suite and args.posture_sequence is not None:
        raise ValueError("--motion-suite and --posture-sequence are separate validation protocols")
    if args.ros_bridge and (args.motion_suite or args.posture_sequence is not None):
        raise ValueError("--ros-bridge requires one environment and a fixed simulator posture")
    if args.ros_bridge and args.num_envs != 1:
        raise ValueError("--ros-bridge requires --num_envs 1")
    if args.real_time_factor < 0.0:
        raise ValueError("--real-time-factor must be non-negative")
    if args.posture_sequence is not None:
        if args.disable_posture_feedforward:
            raise ValueError("--posture-sequence requires posture feedforward")
        if args.posture_segment_steps <= 0:
            raise ValueError("--posture-segment-steps must be positive")
        if not 0 < args.posture_tail_steps <= args.posture_segment_steps:
            raise ValueError("--posture-tail-steps must be in [1, posture segment steps]")
        args.steps = len(args.posture_sequence) * args.posture_segment_steps
        print(
            f"[TITA-UC] posture sequence sets total steps to {args.steps}: "
            f"{' -> '.join(args.posture_sequence)}"
        )
    torch.manual_seed(args.seed)
    motion_suite = (
        (
            ("idle", (0.0, 0.0, 0.0)),
            ("forward", (0.4, 0.0, 0.0)),
            ("reverse", (-0.4, 0.0, 0.0)),
            ("yaw_left", (0.0, 0.0, 0.8)),
            ("yaw_right", (0.0, 0.0, -0.8)),
        )
        if args.motion_suite
        else None
    )
    effective_num_envs = len(motion_suite) if motion_suite is not None else args.num_envs
    if motion_suite is not None:
        print(f"[TITA-UC] motion suite uses {effective_num_envs} parallel environments")
    try:
        cfg = build_tita_cfg(
            args.asset,
            num_envs=effective_num_envs,
            terrain=args.terrain,
            domain_randomization=args.domain_randomization,
        )
    except BaseException as exc:
        print(f"[TITA-UC ERROR] build_tita_cfg failed: {type(exc).__name__}: {exc!r}", flush=True)
        raise
    cfg.seed = args.seed
    if args.navigation_scene_file:
        from tita_uc_residual_rl.navigation_maze import load_maze
        if args.terrain != "three_route":
            raise ValueError("--navigation-scene-file requires --terrain three_route")
        maze = load_maze(args.navigation_scene_file)
        cfg.navigation_scene_file = str(Path(args.navigation_scene_file).resolve())
        cfg.scene.env_spacing = 16.0
    if args.ros_bridge:
        from tita_uc_residual_rl.navigation_success import validate_navigation_goal
        cfg.navigation_goal_xy_m = validate_navigation_goal(
            (args.ros_goal_x, args.ros_goal_y), cfg.navigation_goal_tolerance_m)
    cfg.sudden_obstacle_file = os.environ.get("TITA_SUDDEN_OBSTACLE_CONFIG", "")
    if args.ros_training_lockstep:
        if not args.ros_bridge:
            raise ValueError("--ros-training-lockstep requires --ros-bridge")
        cfg.navigation_goal_tolerance_m = 0.35
    if args.episode_length_s is not None:
        if args.episode_length_s <= 0.0:
            raise ValueError("--episode-length-s must be positive")
        cfg.episode_length_s = args.episode_length_s
    if args.tunnel_height_range is not None:
        cfg.tunnel_height_range_m = tuple(args.tunnel_height_range)
    if args.tunnel_width_range is not None:
        cfg.tunnel_width_range_m = tuple(args.tunnel_width_range)
    if args.tunnel_length_range is not None:
        cfg.tunnel_length_range_m = tuple(args.tunnel_length_range)
    if args.stair_height_range is not None:
        cfg.stair_step_height_range_m = tuple(args.stair_height_range)
    if args.stair_tread_range is not None:
        cfg.stair_tread_range_m = tuple(args.stair_tread_range)
    if args.stair_width_range is not None:
        cfg.stair_width_range_m = tuple(args.stair_width_range)
    if args.stair_num_steps is not None:
        if args.stair_num_steps <= 0:
            raise ValueError("--stair-num-steps must be positive")
        cfg.stair_num_steps = args.stair_num_steps
    if args.stair_start_x is not None:
        if args.stair_start_x <= 0.0:
            raise ValueError("--stair-start-x must be positive")
        cfg.stair_start_x_m = args.stair_start_x
    if args.stair_landing_length is not None:
        if args.stair_landing_length <= 0.0:
            raise ValueError("--stair-landing-length must be positive")
        cfg.stair_landing_length_m = args.stair_landing_length
    if args.acceleration_limit is not None:
        cfg.acceleration_limit = args.acceleration_limit
    cfg.residual_filter_alpha = args.residual_filter_alpha
    cfg.enforce_acceleration_limit = args.enforce_acceleration_limit
    cfg.enable_safety_projector = not args.disable_projector
    cfg.enable_posture_feedforward = not args.disable_posture_feedforward
    governor_calibration = None
    if args.ros_governor_calibration is not None:
        if args.disable_posture_feedforward or args.residual_checkpoint is not None:
            raise ValueError("velocity calibration requires its unchanged frozen posture controller")
        from tita_uc_residual_rl.velocity_calibration import load_velocity_calibration
        governor_calibration = load_velocity_calibration(
            args.ros_governor_calibration, posture_joint_anchors=cfg.posture_joint_anchors,
            checkpoint_path=args.checkpoint, asset_path=args.asset,
        )
    env = TitaResidualEnv(cfg)
    obs, _ = env.reset()
    timeline = omni.timeline.get_timeline_interface()
    # Reset starts playback immediately.  Pause (rather than stop, which
    # invalidates PhysX handles in Isaac Lab) before replacing that playback
    # session's short range.
    timeline.pause()
    timeline.commit()
    # The imported URDF stage carries a short animation range (2 seconds in
    # the current asset).  ``timeline.set_end_time`` alone is not persistent:
    # Kit derives its range from the USD stage and resets the timeline back to
    # the authored EndTimeCode.  Extend both ranges after ``env.reset()``, when
    # the final stage is available, so a ROS navigation episode or PPO rollout
    # cannot receive a premature STOP event.
    requested_end_time = (
        float(timeline.get_current_time())
        + float(args.steps) * float(env.step_dt)
        + 1.0
    )
    stage = omni.usd.get_context().get_stage()
    if stage is None:
        raise RuntimeError("Isaac USD stage is unavailable after environment reset")
    time_codes_per_second = float(stage.GetTimeCodesPerSecond())
    if time_codes_per_second <= 0.0:
        raise RuntimeError(
            "USD stage has invalid TimeCodesPerSecond: "
            f"{time_codes_per_second}"
        )
    requested_end_time_code = requested_end_time * time_codes_per_second
    stage.SetStartTimeCode(0.0)
    if float(stage.GetEndTimeCode()) < requested_end_time_code:
        stage.SetEndTimeCode(requested_end_time_code)
    timeline.set_start_time(0.0)
    if float(timeline.get_end_time()) < requested_end_time:
        timeline.set_end_time(requested_end_time)
    timeline.set_looping(True)
    # ``env.reset()`` has already started a playback *session* whose private
    # end timecode was copied from the original two-second stage.  Updating
    # the global range does not expand that active session, so replace it with
    # an explicit range that covers this run.
    timeline.play(
        start_timecode=0.0,
        end_timecode=requested_end_time_code,
        looping=True,
    )
    # Timeline mutations are buffered for frame integrity in Isaac Sim 4.5.
    # Commit here on the main thread so the very next simulation frame sees
    # the extended range instead of the asset's original two-second range.
    timeline.commit()
    print(
        "[TITA-UC] timeline horizon "
        f"current={timeline.get_current_time():.3f}s "
        f"end={timeline.get_end_time():.3f}s playing={timeline.is_playing()} "
        f"looping={timeline.is_looping()} "
        f"stage_start_code={stage.GetStartTimeCode():.3f} "
        f"stage_end_code={stage.GetEndTimeCode():.3f} "
        f"time_codes_per_second={time_codes_per_second:.3f} "
        f"requested_end={requested_end_time:.3f}s requested_steps={args.steps}"
    )
    if not args.headless:
        if args.terrain == "three_route":
            env.sim.set_camera_view((4.0, -8.5, 8.5), (4.0, -0.4, 0.15))
        else:
            env.sim.set_camera_view((2.5, 2.5, 1.5), (0.0, 0.0, 0.3))
    base = None
    if args.checkpoint:
        actor = OfficialTitaActor.from_checkpoint(args.checkpoint, device=env.device)
        base = FrozenOfficialTitaController(actor)
        base.reset(env.num_envs, env.device)
        print(f"[TITA-UC] loaded frozen official checkpoint: {args.checkpoint}")
    else:
        print(
            "[TITA-UC] WARNING: no --checkpoint supplied; the base target stays at "
            "the default pose and the robot may fall. This run validates asset loading, "
            "not controlled balance or locomotion."
        )
    residual_policies = {}
    residual_paths = {}
    if args.residual_manifest is not None:
        manifest = json.loads(args.residual_manifest.expanduser().read_text(encoding="utf-8"))
        if not isinstance(manifest, dict):
            raise ValueError("--residual-manifest must contain a JSON object")
        for name in ("LOW", "MID", "HIGH"):
            if manifest.get(name):
                residual_paths[name] = str(Path(manifest[name]).expanduser().resolve())
    for name, path in (
        ("LOW", args.low_residual_checkpoint),
        ("MID", args.mid_residual_checkpoint),
        ("HIGH", args.high_residual_checkpoint),
    ):
        if path:
            residual_paths[name] = str(Path(path).expanduser().resolve())
    if args.residual_checkpoint and not residual_paths:
        residual_paths[args.posture] = str(Path(args.residual_checkpoint).expanduser().resolve())
    if residual_paths:
        if base is None:
            raise ValueError("residual checkpoints require --checkpoint")
        for name, path in residual_paths.items():
            payload = torch.load(path, map_location="cpu", weights_only=True)
            policy_config = payload.get("policy_config", {})
            residual_limit = float(policy_config.get("residual_limit", cfg.residual_limit))
            posture_scale = float(policy_config.get("posture_scale", cfg.posture_scale))
            if name == next(iter(residual_paths)):
                cfg.residual_limit = residual_limit
                cfg.posture_scale = posture_scale
            elif abs(residual_limit - cfg.residual_limit) > 1e-6 or abs(posture_scale - cfg.posture_scale) > 1e-6:
                raise ValueError("all Style-Conditioned residual checkpoints must share policy limits")
            policy = PhaseBActorCritic(
                obs_dim=obs["policy"].shape[-1],
                residual_limit=residual_limit,
                posture_scale=posture_scale,
            ).to(env.device)
            load_phase_b_state_dict_compatible(policy, payload["model_state_dict"])
            policy.eval()
            residual_policies[name] = policy
            print(f"[TITA-UC] loaded {name} residual checkpoint: {path}")
    ros_bridge = None
    if args.ros_bridge:
        try:
            ros_bridge = IsaacUdpBridge(
                env, host=args.udp_host, tx_port=args.udp_tx_port, rx_port=args.udp_rx_port,
                goal_x=args.ros_goal_x,
                goal_y=args.ros_goal_y,
                goal_yaw=args.ros_goal_yaw,
                command_timeout_s=args.ros_command_timeout,
                velocity_governor=not args.disable_ros_velocity_governor,
                governor_linear_bias=args.ros_governor_linear_bias,
                governor_linear_scale=args.ros_governor_linear_scale,
                governor_linear_kp=args.ros_governor_linear_kp,
                governor_angular_kp=args.ros_governor_angular_kp,
                governor_max_linear_command=args.ros_governor_max_linear_command,
                governor_max_angular_command=args.ros_governor_max_angular_command,
                governor_profiles=(governor_calibration["profiles"]
                                   if governor_calibration is not None else None),
                governor_transition_s=(cfg.posture_feedforward_transition_s
                                       if governor_calibration is not None else 0.0),
                command_shaping=(load_motion_profile(args.motion_profile)["command_shaping"]
                                 if args.motion_profile is not None else None),
                training_lockstep=args.ros_training_lockstep,
                planner_physics_lockstep=(load_motion_profile(args.motion_profile).get("planner_physics_lockstep", False)
                                          if args.motion_profile is not None else False),
            )
        except BaseException as exc:
            print(f"[TITA-UC ERROR] ROS bridge construction failed: {type(exc).__name__}: {exc!r}", flush=True)
            raise
        print(
            "[TITA-UC] ROS bridge enabled; waiting for NeuPAN gated cmd_vel; "
            f"velocity_governor={not args.disable_ros_velocity_governor}, "
            f"calibration={args.ros_governor_calibration or 'legacy_scalar'}"
        )
    if motion_suite is None:
        command = torch.tensor(
            [args.command_x, args.command_y, args.command_yaw], device=env.device
        ).repeat(env.num_envs, 1)
    else:
        command = torch.tensor(
            [suite_command for _, suite_command in motion_suite], device=env.device
        )
    posture_index = ("LOW", "MID", "HIGH").index(args.posture)
    posture_command = torch.nn.functional.one_hot(
        torch.full((env.num_envs,), posture_index, device=env.device), 3
    ).to(torch.float32)
    style_names = ("LOW", "MID", "HIGH")
    previous_style_index = torch.full(
        (env.num_envs,), posture_index, dtype=torch.long, device=env.device
    )
    style_switch_count = 0
    rapid_style_switch_count = 0
    last_style_switch_step = torch.full(
        (env.num_envs,), -10_000, dtype=torch.long, device=env.device
    )
    style_blend_remaining = torch.zeros(
        env.num_envs, dtype=torch.long, device=env.device
    )
    previous_residual_action = torch.zeros(env.num_envs, 8, device=env.device)
    posture_height_sum = 0.0
    posture_error_sum = 0.0
    posture_samples = 0
    cumulative_terminated = 0
    cumulative_terminated_by_env = torch.zeros(
        env.num_envs, dtype=torch.long, device=env.device
    )
    cumulative_reasons = torch.zeros(
        len(HARD_REASON_NAMES), dtype=torch.long, device=env.device
    )
    cumulative_reasons_by_env = torch.zeros(
        env.num_envs, len(HARD_REASON_NAMES), dtype=torch.long, device=env.device
    )
    cumulative_velocity_joints = torch.zeros(8, dtype=torch.long, device=env.device)
    cumulative_velocity_state_projections = torch.zeros(
        8, dtype=torch.long, device=env.device
    )
    cumulative_infeasible_joints = torch.zeros(8, dtype=torch.long, device=env.device)
    cumulative_infeasible_causes = torch.zeros(4, dtype=torch.long, device=env.device)
    cumulative_projection_joints = torch.zeros(8, dtype=torch.long, device=env.device)
    cumulative_projection_causes = torch.zeros(4, dtype=torch.long, device=env.device)
    velocity_absmax = torch.zeros(8, device=env.device)
    preprojection_velocity_absmax = torch.zeros(8, device=env.device)
    acceleration_absmax = torch.zeros(8, device=env.device)
    base_action_absmax_by_joint = torch.zeros(8, device=env.device)
    clearance_min = float("inf")
    clearance_max = float("-inf")
    soft_contact_force_max = 0.0
    observations_finite = True
    failure_snapshot_printed = False
    safety_hold_steps = 0
    initial_tunnel_successes = int(env.tunnel_success_count.sum().item())
    initial_stair_successes = int(env.stair_success_count.sum().item())
    stair_local_x_max = torch.full((env.num_envs,), float("-inf"), device=env.device)
    stair_root_z_max = torch.full_like(stair_local_x_max, float("-inf"))
    stair_verified_level_max = torch.zeros(env.num_envs, device=env.device)
    raw_soft_cost_samples: list[torch.Tensor] = []
    previous_root_xy = env.robot.data.root_pos_w[:, :2].clone()
    net_displacement_xy = torch.zeros(env.num_envs, 2, device=env.device)
    path_length = torch.zeros(env.num_envs, device=env.device)
    body_velocity_xy_sum_by_env = torch.zeros(env.num_envs, 2, device=env.device)
    yaw_rate_sum_by_env = torch.zeros(env.num_envs, device=env.device)
    motion_sample_count_by_env = torch.zeros(
        env.num_envs, dtype=torch.long, device=env.device
    )
    root_height_min = torch.full((env.num_envs,), float("inf"), device=env.device)
    root_height_max = torch.full((env.num_envs,), float("-inf"), device=env.device)
    tilt_max_rad = torch.zeros(env.num_envs, device=env.device)

    def root_yaw() -> torch.Tensor:
        quaternion = env.robot.data.root_quat_w
        w, x, y, z = quaternion.unbind(dim=1)
        return torch.atan2(2.0 * (w * z + x * y), 1.0 - 2.0 * (y * y + z * z))

    previous_yaw = root_yaw().clone()
    accumulated_yaw = torch.zeros(env.num_envs, device=env.device)
    body_velocity_xy_sum = torch.zeros(2, device=env.device)
    motion_sample_count = 0
    posture_stage_metrics = []
    if args.posture_sequence is not None:
        for stage, posture_name in enumerate(args.posture_sequence):
            posture_stage_metrics.append(
                {
                    "stage": stage,
                    "posture": posture_name,
                    "height_sum": 0.0,
                    "error_sum": 0.0,
                    "samples": 0,
                    "height_min": float("inf"),
                    "height_max": float("-inf"),
                    "terminated": 0,
                }
            )
    navigation_lidar_min = float("inf")
    navigation_lidar_max = float("-inf")
    navigation_lidar_finite = True
    navigation_lidar_samples = 0
    research_stream = None
    if args.research_trace is not None:
        args.research_trace.parent.mkdir(parents=True, exist_ok=True)
        research_stream = args.research_trace.open('x')
    research_video = None
    if args.record_video is not None:
        from tita_uc_residual_rl.research_capture import ResearchVideo
        research_video = ResearchVideo(env, args.record_video, args.ffmpeg_path, args.video_label)
    pacing_started_at = time.monotonic()
    # The environment step owns the Kit/PhysX update.  Do not gate the first
    # step on ``simulation_app.is_running()``: Isaac Sim 4.5 can report a false
    # value during the post-reset handoff even though the articulation is
    # ready to step and publish ROS bridge state.
    executed_steps = 0
    for step in range(args.steps):
        if hasattr(env, "sudden_obstacle_probe"):
            env.sudden_obstacle_probe.update(env, executed_steps)
        if ros_bridge is not None:
            ros_bridge.spin_once()
            window = ros_bridge.training_window
            if window is not None:
                waiting_since = time.monotonic()
                while window.ready and not window.complete:
                    ros_bridge.publish()
                    ros_bridge.spin_once()
                    if window.reset_requested:
                        env._defer_navigation_reset = False
                        obs, _ = env.reset()
                        env._defer_navigation_reset = True
                        if base is not None:
                            base.reset(env.num_envs, env.device)
                        ros_bridge.finish_training_reset()
                        previous_root_xy = env.robot.data.root_pos_w[:, :2].clone()
                        previous_yaw = root_yaw()
                        ros_bridge._last_publish = 0.0
                    if time.monotonic() - waiting_since > 90.0:
                        raise RuntimeError("timed out waiting for acknowledged training action")
                    if not args.headless:
                        env.sim.render()
                    time.sleep(0.005)
                if window.complete:
                    print("[TITA-UC] acknowledged PPO training completion", flush=True)
                    break
                pacing_started_at += time.monotonic() - waiting_since
            waiting_since = time.monotonic()
            while not ros_bridge.planner_command_ready():
                ros_bridge.publish()
                ros_bridge.spin_once()
                if time.monotonic() - waiting_since > 15.0:
                    raise RuntimeError("timed out waiting for physics-aligned planner command; simulation remains paused")
                if not args.headless:
                    env.sim.render()
                time.sleep(0.005)
            pacing_started_at += time.monotonic() - waiting_since
        posture_stage = None
        if args.posture_sequence is not None:
            posture_stage = min(
                step // args.posture_segment_steps, len(args.posture_sequence) - 1
            )
            posture_name = args.posture_sequence[posture_stage]
            posture_index = ("LOW", "MID", "HIGH").index(posture_name)
            posture_command = torch.nn.functional.one_hot(
                torch.full((env.num_envs,), posture_index, device=env.device), 3
            ).to(torch.float32)
        if ros_bridge is not None:
            command = ros_bridge.command_tensor(env.device, env.num_envs)
        env.set_velocity_command(command)
        if ros_bridge is not None:
            posture_index = ros_bridge.posture_index
            posture_command = torch.nn.functional.one_hot(
                torch.full((env.num_envs,), posture_index, device=env.device), 3
            ).to(torch.float32)
        env.set_posture_command(posture_command)
        current_style_index = torch.full(
            (env.num_envs,), posture_index, dtype=torch.long, device=env.device
        )
        changed_style = current_style_index != previous_style_index
        if changed_style.any():
            changed_count = int(changed_style.sum().item())
            style_switch_count += changed_count
            rapid_style_switch_count += int(
                (changed_style & ((step - last_style_switch_step) < 50)).sum().item()
            )
            last_style_switch_step[changed_style] = step
            style_blend_remaining[changed_style] = args.style_transition_steps
            previous_style_index = current_style_index.clone()
        if ros_bridge is not None and ros_bridge.training_window is not None:
            trace_event("isaac", "control_input_applied",
                        episode_id=ros_bridge._episode_id,
                        decision_id=ros_bridge.training_window.decision_id,
                        command_sequence=ros_bridge._last_command_sequence,
                        control_step=executed_steps + 1,
                        sim_time_s=ros_bridge._sim_time_s,
                        action_id=ros_bridge.training_window.action_id,
                        planner_source=ros_bridge._planner_source,
                        desired_command=list(ros_bridge._applied_desired_command),
                        safety_override=ros_bridge._safety_override)
        base_action_absmax = 0.0
        if base is not None:
            assert base.previous_policy_action is not None
            proprioception = env.official_proprioception(base.previous_policy_action)
            if timing_enabled() and torch.device(env.device).type == "cuda":
                torch.cuda.synchronize(env.device)
            actor_started_ns = time.monotonic_ns()
            base_target, policy_action = base.target(proprioception, env.default_joint_target())
            if timing_enabled() and torch.device(env.device).type == "cuda":
                torch.cuda.synchronize(env.device)
            actor_finished_ns = time.monotonic_ns()
            trace_event("isaac", "lower_actor", at_ns=actor_finished_ns,
                        start_ns=actor_started_ns, end_ns=actor_finished_ns,
                        control_step=executed_steps + 1)
            env.set_base_target(base_target)
            base_action_absmax = policy_action.abs().max().item()
            base_action_absmax_by_joint = torch.maximum(
                base_action_absmax_by_joint, policy_action.abs().amax(0)
            )
        with torch.no_grad():
            action = torch.zeros(env.num_envs, 8, device=env.device)
            if residual_policies:
                for style_index, style_name in enumerate(style_names):
                    policy = residual_policies.get(style_name)
                    if policy is None:
                        continue
                    mask = current_style_index == style_index
                    if mask.any():
                        action[mask] = policy.policy(obs["policy"][mask])
                if args.style_transition_steps > 0:
                    active_blend = style_blend_remaining > 0
                    if active_blend.any():
                        blend = 1.0 - (
                            style_blend_remaining[active_blend].to(torch.float32)
                            / float(args.style_transition_steps)
                        )
                        action[active_blend] = (
                            (1.0 - blend[:, None]) * previous_residual_action[active_blend]
                            + blend[:, None] * action[active_blend]
                        )
                        style_blend_remaining[active_blend] -= 1
                previous_residual_action = action.detach().clone()
        if cfg.stair_enabled:
            stair_local_x = (
                env.robot.data.root_pos_w[:, 0] - env._environment_origins()[:, 0]
            )
            stair_local_x_max = torch.maximum(stair_local_x_max, stair_local_x)
            stair_root_z_max = torch.maximum(
                stair_root_z_max, env.robot.data.root_pos_w[:, 2]
            )
            stair_verified_level_max = torch.maximum(
                stair_verified_level_max, env._verified_stair_level()
            )
        physics_started_ns = time.monotonic_ns()
        obs, reward, terminated, truncated, _ = env.step(action)
        physics_finished_ns = time.monotonic_ns()
        trace_event("isaac", "control_step_finished", at_ns=physics_finished_ns,
                    start_ns=physics_started_ns, end_ns=physics_finished_ns,
                    control_step=executed_steps + 1,
                    sim_time_s=(executed_steps + 1) * float(env.step_dt))
        executed_steps += 1
        if hasattr(env, "sudden_obstacle_probe"):
            env.sudden_obstacle_probe.sample(env, executed_steps)
        if ros_bridge is not None:
            window = ros_bridge.training_window
            at_boundary = (window is not None and
                           (window.steps + 1 >= window.steps_per_action
                            or bool(terminated[0]) or bool(truncated[0])))
            if (at_boundary and args.ros_boundary_attitude_limit_rad is not None
                    and boundary_attitude_exceeded(
                        env.robot.data.root_quat_w[0].tolist(),
                        args.ros_boundary_attitude_limit_rad)):
                terminated[0] = True
                truncated[0] = False
                env._hard_failure[0] = True
                env._last_hard_reason_flags[0, 6] = True
                if bool(env._navigation_success_step[0]):
                    env._navigation_success_count[0] -= 1
                    env._navigation_success_step[0] = False
            ros_bridge.record_step(
                energy_j=float(env.last_step_energy[0].item()),
                distance_m=float(env.last_step_distance[0].item()),
                terminated=bool(terminated[0].item()),
                truncated=bool(truncated[0].item()),
                success=bool(env.navigation_success_step[0].item()),
                hard_reasons=[bool(value) for value in env.hard_reason_flags[0].tolist()],
            )
            ros_bridge.publish()
        if research_stream is not None:
            research_stream.write(json.dumps({
                'control_step': executed_steps, 'episode_id': ros_bridge._episode_id if ros_bridge else 0,
                'sim_time_s': ros_bridge._sim_time_s if ros_bridge else executed_steps * float(env.step_dt),
                'action_id': ros_bridge.training_window.action_id if ros_bridge and ros_bridge.training_window else -1,
                'desired': ros_bridge._applied_desired_command if ros_bridge else None,
                'requested': ros_bridge._requested_desired_command if ros_bridge else None,
                'command_trace': ros_bridge._command_trace if ros_bridge else None,
                'command_packet_sequence': ros_bridge._last_command_sequence if ros_bridge else None,
                'command_received_sim_time_s': ros_bridge._command_received_sim_time_s if ros_bridge else None,
                'command_stale': ros_bridge._command_stale if ros_bridge else None,
                'planner_source': ros_bridge._planner_source if ros_bridge else None,
                'safety_override': ros_bridge._safety_override if ros_bridge else False,
                'policy_command': command[0].tolist(),
                'position': env.robot.data.root_pos_w[0].tolist(),
                'quaternion_wxyz': env.robot.data.root_quat_w[0].tolist(),
                'linear_b': env.robot.data.root_lin_vel_b[0].tolist(),
                'angular_b': env.robot.data.root_ang_vel_b[0].tolist(),
                'joint_velocity': env.robot.data.joint_vel[0].tolist(),
                'joint_effort': env.robot.data.applied_torque[0].tolist(),
                'contact_forces_w': env._contact_sensor.data.net_forces_w[0].tolist(),
                'contact_body_names': env._contact_sensor.body_names,
                'terminated': bool(terminated[0]), 'truncated': bool(truncated[0]),
                'hard_reasons': env.hard_reason_flags[0].tolist(),
            }) + '\n')
        if research_video is not None and (executed_steps % 5 == 0 or bool(terminated[0]) or bool(truncated[0])):
            root_position = env.robot.data.root_pos_w[0].tolist()
            research_video.capture(dict(
                sim_time_s=ros_bridge._sim_time_s if ros_bridge else executed_steps * float(env.step_dt),
                episode_id=ros_bridge._episode_id if ros_bridge else 0,
                action_id=ros_bridge.training_window.action_id if ros_bridge and ros_bridge.training_window else -1,
                control_step=executed_steps,
                goal_distance_m=math.dist(root_position[:2], cfg.navigation_goal_xy_m),
                status='hard_failure' if bool(terminated[0]) and bool(env._hard_failure[0]) else
                       'success' if bool(env.navigation_success_step[0]) else
                       'timeout' if bool(truncated[0]) else 'running'))
        if args.real_time_factor > 0.0:
            target_wall_time = pacing_started_at + (
                (step + 1) * float(env.step_dt) / args.real_time_factor
            )
            remaining = target_wall_time - time.monotonic()
            if remaining > 0.0:
                time.sleep(remaining)
        current_root_xy = env.robot.data.root_pos_w[:, :2].clone()
        current_yaw = root_yaw()
        valid_motion = ~(terminated | truncated)
        root_delta_xy = current_root_xy - previous_root_xy
        valid_delta_xy = torch.where(
            valid_motion.unsqueeze(1), root_delta_xy, torch.zeros_like(root_delta_xy)
        )
        net_displacement_xy += valid_delta_xy
        path_length += torch.linalg.vector_norm(valid_delta_xy, dim=1)
        yaw_delta = torch.atan2(
            torch.sin(current_yaw - previous_yaw),
            torch.cos(current_yaw - previous_yaw),
        )
        accumulated_yaw += torch.where(
            valid_motion, yaw_delta, torch.zeros_like(yaw_delta)
        )
        previous_root_xy = current_root_xy
        previous_yaw = current_yaw
        root_height = env.robot.data.root_pos_w[:, 2]
        root_height_min = torch.minimum(root_height_min, root_height)
        root_height_max = torch.maximum(root_height_max, root_height)
        tilt = torch.acos((-env.robot.data.projected_gravity_b[:, 2]).clamp(-1.0, 1.0))
        tilt_max_rad = torch.maximum(tilt_max_rad, tilt)
        navigation_ranges = env.navigation_lidar_ranges
        if navigation_ranges is not None and step >= 5:
            navigation_lidar_finite &= bool(torch.isfinite(navigation_ranges).all().item())
            navigation_lidar_min = min(
                navigation_lidar_min, float(navigation_ranges.min().item())
            )
            navigation_lidar_max = max(
                navigation_lidar_max, float(navigation_ranges.max().item())
            )
            navigation_lidar_samples += int(navigation_ranges.numel())
        if step >= args.metric_warmup_steps:
            posture_height_sum += float(env.posture_height.sum())
            posture_error_sum += float(
                torch.abs(env.posture_height - env.posture_target_height).sum()
            )
            posture_samples += env.num_envs
            raw_soft_cost_samples.append(env.raw_soft_costs.clone())
            body_velocity_xy_sum += env.robot.data.root_lin_vel_b[
                valid_motion, :2
            ].sum(dim=0)
            motion_sample_count += int(valid_motion.sum().item())
            body_velocity_xy_sum_by_env += torch.where(
                valid_motion.unsqueeze(1),
                env.robot.data.root_lin_vel_b[:, :2],
                torch.zeros_like(env.robot.data.root_lin_vel_b[:, :2]),
            )
            yaw_rate_sum_by_env += torch.where(
                valid_motion,
                env.robot.data.root_ang_vel_b[:, 2],
                torch.zeros_like(env.robot.data.root_ang_vel_b[:, 2]),
            )
            motion_sample_count_by_env += valid_motion.to(torch.long)
        if posture_stage is not None:
            step_in_stage = step % args.posture_segment_steps
            stage_metric = posture_stage_metrics[posture_stage]
            stage_metric["terminated"] += int(terminated.sum().item())
            if step_in_stage >= args.posture_segment_steps - args.posture_tail_steps:
                heights = env.posture_height
                errors = torch.abs(heights - env.posture_target_height)
                stage_metric["height_sum"] += float(heights.sum().item())
                stage_metric["error_sum"] += float(errors.sum().item())
                stage_metric["samples"] += env.num_envs
                stage_metric["height_min"] = min(
                    stage_metric["height_min"], float(heights.min().item())
                )
                stage_metric["height_max"] = max(
                    stage_metric["height_max"], float(heights.max().item())
                )
        observations_finite &= bool(torch.isfinite(obs["policy"]).all().item())
        clearance_min = min(clearance_min, float(env.clearance.min().item()))
        clearance_max = max(clearance_max, float(env.clearance.max().item()))
        soft_contact_force_max = max(
            soft_contact_force_max, float(env.soft_contact_force.max().item())
        )
        cumulative_terminated += int(terminated.sum().item())
        cumulative_terminated_by_env += terminated.to(torch.long)
        safety_hold_steps += int(env.safety_hold.sum().item())
        cumulative_reasons += env.hard_reason_flags.sum(0)
        cumulative_reasons_by_env += env.hard_reason_flags.to(torch.long)
        cumulative_velocity_joints += env.velocity_violation_flags.sum(0)
        cumulative_velocity_state_projections += (
            env.velocity_state_projection_flags.sum(0)
        )
        cumulative_infeasible_joints += env.infeasible_joint_flags.sum(0)
        cumulative_infeasible_causes += env.infeasible_cause_flags.sum((0, 1))
        cumulative_projection_joints += env.projection_joint_flags.sum(0)
        cumulative_projection_causes += env.projection_cause_flags.sum((0, 1))
        velocity_absmax = torch.maximum(velocity_absmax, env.joint_velocity_absmax())
        preprojection_velocity_absmax = torch.maximum(
            preprojection_velocity_absmax,
            env.preprojection_joint_velocity_absmax(),
        )
        acceleration_absmax = torch.maximum(acceleration_absmax, env.joint_acceleration_absmax())
        if base is not None:
            base.reset_envs(terminated | truncated)
        if args.verbose_state and terminated.any() and not failure_snapshot_printed:
            failed = torch.nonzero(terminated, as_tuple=False).flatten()
            terrain_types = getattr(env.terrain, "terrain_types", None)
            terrain_levels = getattr(env.terrain, "terrain_levels", None)
            for env_id in failed.tolist():
                qd = env.robot.data.joint_vel[env_id, env._joint_ids]
                qdd = env.robot.data.joint_acc[env_id, env._joint_ids]
                print(
                    f"[TITA-UC FAILURE] env={env_id} "
                    f"terrain_type={None if terrain_types is None else int(terrain_types[env_id])} "
                    f"terrain_level={None if terrain_levels is None else int(terrain_levels[env_id])} "
                    f"origin={[round(v, 4) for v in env._environment_origins()[env_id].tolist()]} "
                    f"root={[round(v, 4) for v in env.robot.data.root_pos_w[env_id].tolist()]} "
                    f"preview_clearance={float(env.clearance[env_id]):.4f} "
                    f"hard_clearance={float(env.hard_clearance[env_id]):.4f} "
                    f"reasons={env.hard_reason_flags[env_id].tolist()} "
                    f"qd={[round(v, 3) for v in qd.tolist()]} "
                    f"qdd={[round(v, 3) for v in qdd.tolist()]}"
                )
            failure_snapshot_printed = True
        if step == 0 or (step + 1) % args.log_interval == 0:
            print(
                f"[TITA-UC] step={step + 1} reward_mean={reward.mean().item():.6f} "
                f"terminated={terminated.sum().item()} truncated={truncated.sum().item()} "
                f"obs_shape={tuple(obs['policy'].shape)} base_action_absmax={base_action_absmax:.6f} "
                f"projected={env.projected.sum().item()} cumulative_terminated={cumulative_terminated} "
                f"hard_reasons={cumulative_reasons.tolist()} velocity_joints={cumulative_velocity_joints.tolist()} "
                f"velocity_state_projections={cumulative_velocity_state_projections.tolist()} "
                f"infeasible_joints={cumulative_infeasible_joints.tolist()} "
                f"infeasible_causes={cumulative_infeasible_causes.tolist()} "
                f"projection_joints={cumulative_projection_joints.tolist()} "
                f"projection_causes={cumulative_projection_causes.tolist()} "
                f"qd_absmax={[round(value, 3) for value in velocity_absmax.tolist()]} "
                f"qd_preprojection_absmax={[round(value, 3) for value in preprojection_velocity_absmax.tolist()]} "
                f"qdd_absmax={[round(value, 3) for value in acceleration_absmax.tolist()]} "
                f"base_action_by_joint={[round(value, 3) for value in base_action_absmax_by_joint.tolist()]}"
            )
            if args.verbose_state:
                q = env.robot.data.joint_pos[0, env._joint_ids]
                qd = env.robot.data.joint_vel[0, env._joint_ids]
                tau = env.robot.data.applied_torque[0, env._joint_ids]
                root_z = env.robot.data.root_pos_w[:, 2]
                print(
                    f"[TITA-UC STATE] root_z_minmax=({root_z.min().item():.4f},"
                    f"{root_z.max().item():.4f}) q={[round(v, 3) for v in q.tolist()]} "
                    f"qd={[round(v, 3) for v in qd.tolist()]} "
                    f"base_target={[round(v, 3) for v in env._base_target[0].tolist()]} "
                    f"q_cmd={[round(v, 3) for v in env._q_cmd[0].tolist()]} "
                    f"tau={[round(v, 3) for v in tau.tolist()]}"
                )
    final_posture_height = env.posture_height
    stair_local_x_range = (
        (stair_local_x_max.min().item(), stair_local_x_max.max().item())
        if cfg.stair_enabled
        else None
    )
    stair_root_z_range = (
        (stair_root_z_max.min().item(), stair_root_z_max.max().item())
        if cfg.stair_enabled
        else None
    )
    stair_levels = stair_verified_level_max.tolist() if cfg.stair_enabled else None
    raw_costs = (
        torch.cat(raw_soft_cost_samples, dim=0)
        if raw_soft_cost_samples
        else torch.zeros(1, 4, device=env.device)
    )
    cost_names = ("route", "energy", "mode", "smooth")
    body_velocity_xy_mean = body_velocity_xy_sum / max(motion_sample_count, 1)
    body_velocity_xy_mean_by_env = body_velocity_xy_sum_by_env / torch.clamp(
        motion_sample_count_by_env, min=1
    ).unsqueeze(1)
    yaw_rate_mean_by_env = yaw_rate_sum_by_env / torch.clamp(
        motion_sample_count_by_env, min=1
    )
    net_displacement_xy_mean = net_displacement_xy.mean(dim=0)
    navigation_lidar_minmax = (
        [navigation_lidar_min, navigation_lidar_max]
        if navigation_lidar_samples > 0
        else None
    )
    posture_stage_summary = None
    if posture_stage_metrics:
        posture_stage_summary = []
        for stage_metric in posture_stage_metrics:
            samples = max(int(stage_metric["samples"]), 1)
            posture_stage_summary.append(
                {
                    "stage": stage_metric["stage"],
                    "posture": stage_metric["posture"],
                    "target_height_m": cfg.posture_heights[
                        ("LOW", "MID", "HIGH").index(stage_metric["posture"])
                    ],
                    "tail_height_mean_m": stage_metric["height_sum"] / samples,
                    "tail_height_abs_error_mean_m": stage_metric["error_sum"] / samples,
                    "tail_height_minmax_m": [
                        stage_metric["height_min"],
                        stage_metric["height_max"],
                    ],
                    "terminated": stage_metric["terminated"],
                }
            )
    motion_suite_summary = None
    if motion_suite is not None:
        motion_suite_summary = []
        for env_id, (name, suite_command) in enumerate(motion_suite):
            motion_suite_summary.append(
                {
                    "name": name,
                    "command": list(suite_command),
                    "net_displacement_xy_m": net_displacement_xy[env_id].tolist(),
                    "path_length_m": float(path_length[env_id].item()),
                    "body_velocity_xy_mean_mps": body_velocity_xy_mean_by_env[env_id].tolist(),
                    "yaw_rate_mean_radps": float(yaw_rate_mean_by_env[env_id].item()),
                    "accumulated_yaw_rad": float(accumulated_yaw[env_id].item()),
                    "root_height_minmax_m": [
                        float(root_height_min[env_id].item()),
                        float(root_height_max[env_id].item()),
                    ],
                    "tilt_max_deg": float(torch.rad2deg(tilt_max_rad[env_id]).item()),
                    "terminated": int(cumulative_terminated_by_env[env_id].item()),
                    "hard_reasons": cumulative_reasons_by_env[env_id].tolist(),
                }
            )
    summary = {
        "posture_calibration_path": cfg.posture_calibration_path,
        "posture_joint_anchors": cfg.posture_joint_anchors,
        "velocity_governor_calibration": governor_calibration,
        "boundary_attitude_limit_rad": args.ros_boundary_attitude_limit_rad,
        "navigation_goal_xy_m": cfg.navigation_goal_xy_m,
        "navigation_goal_tolerance_m": cfg.navigation_goal_tolerance_m,
        "training_contract": (ros_bridge.training_window.payload()
                              if ros_bridge is not None
                              and ros_bridge.training_window is not None else None),
        "observations_finite": observations_finite,
        "navigation_lidar_finite": navigation_lidar_finite,
        "navigation_lidar_minmax_m": navigation_lidar_minmax,
        "navigation_lidar_samples": navigation_lidar_samples,
        "clearance_minmax_m": [clearance_min, clearance_max],
        "clearance_nonconstant": clearance_max - clearance_min > 1.0e-6,
        "soft_contact_force_max_n": soft_contact_force_max,
        "velocity_command": (
            [args.command_x, args.command_y, args.command_yaw]
            if motion_suite is None
            else None
        ),
        "motion_suite": motion_suite_summary,
        "net_displacement_xy_mean_m": net_displacement_xy_mean.tolist(),
        "path_length_mean_m": float(path_length.mean().item()),
        "body_velocity_xy_mean_mps": body_velocity_xy_mean.tolist(),
        "motion_sample_count": motion_sample_count,
        "posture_feedforward_enabled": cfg.enable_posture_feedforward,
        "posture": args.posture,
        "posture_sequence": posture_stage_summary,
        "posture_height_mean_m": posture_height_sum / max(posture_samples, 1),
        "posture_height_abs_error_mean_m": posture_error_sum / max(posture_samples, 1),
        "cumulative_terminated": cumulative_terminated,
        "tunnel_success_total": int(env.tunnel_success_count.sum().item()) - initial_tunnel_successes,
        "stair_success_total": int(env.stair_success_count.sum().item()) - initial_stair_successes,
        "stair_local_x_max_minmax_m": stair_local_x_range,
        "stair_root_z_max_minmax_m": stair_root_z_range,
        "stair_verified_level_max": stair_levels,
        "stair_geometry": {
            "step_height_range_m": list(cfg.stair_step_height_range_m),
            "tread_range_m": list(cfg.stair_tread_range_m),
            "width_range_m": list(cfg.stair_width_range_m),
            "num_steps": cfg.stair_num_steps,
            "start_x_m": cfg.stair_start_x_m,
            "landing_length_m": cfg.stair_landing_length_m,
        } if cfg.stair_enabled else None,
        "hard_reasons": cumulative_reasons.tolist(),
        "velocity_joint_counts": cumulative_velocity_joints.tolist(),
        "velocity_state_projection_counts": cumulative_velocity_state_projections.tolist(),
        "safety_hold_steps": safety_hold_steps,
        "seed": args.seed,
        "steps": executed_steps,
        "requested_steps": args.steps,
        "episode_length_s": cfg.episode_length_s,
        "residual_checkpoint": args.residual_checkpoint,
        "residual_manifest": str(args.residual_manifest.resolve()) if args.residual_manifest else None,
        "style_residual_checkpoints": residual_paths,
        "style_transition_steps": args.style_transition_steps,
        "style_switch_count": style_switch_count,
        "rapid_style_switch_count": rapid_style_switch_count,
        "raw_cost_mean": {
            name: float(raw_costs[:, index].mean())
            for index, name in enumerate(cost_names)
        },
        "raw_cost_p95": {
            name: float(torch.quantile(raw_costs[:, index], 0.95))
            for index, name in enumerate(cost_names)
        },
    }
    print(
        f"[TITA-UC SUMMARY] observations_finite={observations_finite} "
        f"clearance_minmax=({clearance_min:.4f},{clearance_max:.4f}) "
        f"clearance_nonconstant={clearance_max - clearance_min > 1e-6} "
        f"soft_contact_force_max={soft_contact_force_max:.3f} "
        f"safety_hold_steps={safety_hold_steps} "
        f"posture={args.posture} "
        f"posture_feedforward_enabled={cfg.enable_posture_feedforward} "
        f"posture_height_mean_m={posture_height_sum / max(posture_samples, 1):.6f} "
        f"posture_height_abs_error_mean_m={posture_error_sum / max(posture_samples, 1):.6f} "
        f"posture_height_final_minmax_m=({final_posture_height.min().item():.6f},"
        f"{final_posture_height.max().item():.6f}) "
        f"net_displacement_xy_mean_m={net_displacement_xy_mean.tolist()} "
        f"path_length_mean_m={path_length.mean().item():.6f} "
        f"body_velocity_xy_mean_mps={body_velocity_xy_mean.tolist()} "
        f"navigation_lidar_finite={navigation_lidar_finite} "
        f"navigation_lidar_minmax_m={navigation_lidar_minmax} "
        f"cumulative_terminated={cumulative_terminated} "
        f"tunnel_success_total={int(env.tunnel_success_count.sum().item()) - initial_tunnel_successes} "
        f"stair_success_total={int(env.stair_success_count.sum().item()) - initial_stair_successes} "
        f"stair_local_x_max_minmax_m={stair_local_x_range} "
        f"stair_root_z_max_minmax_m={stair_root_z_range} "
        f"stair_verified_level_max={stair_levels} "
        f"hard_reasons={cumulative_reasons.tolist()}"
    )
    if motion_suite_summary is not None:
        for result in motion_suite_summary:
            print(f"[TITA-UC MOTION] {json.dumps(result, sort_keys=True)}")
    if posture_stage_summary is not None:
        for result in posture_stage_summary:
            print(f"[TITA-UC POSTURE] {json.dumps(result, sort_keys=True)}")
    if args.output is not None:
        output = args.output.expanduser().resolve()
        output.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print(f"[TITA-UC SUMMARY] output={output}")
    if ros_bridge is not None:
        ros_bridge.close()
    if research_stream is not None:
        research_stream.close()
    if research_video is not None:
        research_video.close()
    env.close()


if __name__ == "__main__":
    try:
        main()
    except BaseException as exc:
        print(
            f"[TITA-UC FATAL] {type(exc).__name__}: {exc!r}",
            file=sys.stderr,
            flush=True,
        )
        traceback.print_exc()
        raise
    finally:
        simulation_app.close()
