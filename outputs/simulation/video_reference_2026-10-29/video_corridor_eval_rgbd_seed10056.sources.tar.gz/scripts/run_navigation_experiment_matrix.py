#!/usr/bin/env python3
"""Run paired held-out static and dynamic navigation experiment matrices."""

from __future__ import annotations

import argparse
from datetime import datetime
import json
from pathlib import Path
import subprocess
import sys
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from tita_uc_residual_rl.navigation_comparison_protocol import (
    FORMAL_DYNAMIC_EVENTS, analyze_dynamic_events,
)


STATIC_CASES = (
    "configs/navigation_benchmark_heldout_single_v1.json",
    "configs/navigation_benchmark_heldout_single_v2.json",
    "configs/navigation_benchmark_heldout_double_v1.json",
    "configs/navigation_benchmark_heldout_double_v2.json",
)
DYNAMIC_CASES = (
    ("moving_crossing", "configs/navigation_sudden_obstacle_moving_v1.json"),
    ("appears_then_stops", "configs/navigation_sudden_obstacle_stopped_v1.json"),
)
METHODS = ("neupan", "dct", "rl")


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def run_case(command: list[str], log_path: Path) -> None:
    with log_path.open("x") as stream:
        completed = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
    if completed.returncode:
        raise RuntimeError(f"experiment failed with status {completed.returncode}: {log_path}")


def timing_events(trial: Path) -> list[dict]:
    rows = []
    for path in sorted((trial / "timing").glob("*.jsonl")):
        rows.extend(json.loads(line) for line in path.read_text().splitlines() if line.strip())
    return rows


def static_matrix(args: argparse.Namespace, output: Path) -> dict:
    output.mkdir(parents=True, exist_ok=True)
    cases = [ROOT / value for value in args.static_case]
    manifest = {
        "schema": "tita.navigation_static_matrix.v1",
        "created_at": datetime.now(ZoneInfo("America/New_York")).isoformat(),
        "methods": list(METHODS), "protocol": "equal_cruise", "seeds": args.seeds,
        "pairing_key": "layout + seed + protocol",
        "cases": [str(path.relative_to(ROOT)) for path in cases],
        "dct_label": "DCT-core",
        "scope": "A* candidate paths, robot, sensors, NeuPAN/safety gate and speed contract are shared; only upper selector differs for RL vs NeuPAN.",
    }
    write_json(output / "static_matrix_manifest.json", manifest)
    summaries = []
    for config in cases:
        name = config.stem
        case_dir = output / name
        command = [sys.executable, str(ROOT / "scripts/run_navigation_benchmark.py"),
                   "--config", str(config), "--protocols", "equal_cruise",
                   "--algorithms", *METHODS, "--seeds", *map(str, args.seeds),
                   "--output", str(case_dir)]
        if args.record_video:
            command.append("--record-video")
        if args.prepare_only:
            command.append("--prepare-only")
        run_case(command, output / f"{name}.launcher.log")
        summary_path = case_dir / "comparison_summary.json"
        summaries.append({"case": name, "summary": json.loads(summary_path.read_text()) if summary_path.exists() else None})
    result = {**manifest, "cases_completed": summaries}
    write_json(output / "static_matrix_summary.json", result)
    return result


def dynamic_matrix(args: argparse.Namespace, output: Path) -> dict:
    output.mkdir(parents=True, exist_ok=True)
    manifest = {
        "schema": "tita.navigation_dynamic_matrix.v1",
        "created_at": datetime.now(ZoneInfo("America/New_York")).isoformat(),
        "methods": list(METHODS), "protocol": "equal_cruise", "seeds": args.seeds,
        "pairing_key": "motion condition + seed + method",
        "conditions": [{"name": name, "config": config} for name, config in DYNAMIC_CASES],
        "required_chain": ["obstacle_appeared", "perception_first_hit", "map_updated", "astar_started", "astar_completed", "candidates_published", "rl_decision_started", "rl_decision_completed", "local_planner_started", "local_planner_completed", "control_applied", "avoidance_confirmed"],
        "dct_label": "DCT-core",
        "scope": "A* dynamic map update is required; missing map/A*/candidate events remain an explicit protocol failure.",
    }
    write_json(output / "dynamic_matrix_manifest.json", manifest)
    condition_summaries = []
    for condition, probe in DYNAMIC_CASES:
        case_dir = output / condition
        command = [sys.executable, str(ROOT / "scripts/run_navigation_benchmark.py"),
                   "--config", str(ROOT / "configs/navigation_benchmark_sudden_v1.json"),
                   "--protocols", "equal_cruise", "--algorithms", *METHODS,
                   "--seeds", *map(str, args.seeds), "--measure-timing",
                   "--sudden-obstacle-config", str(ROOT / probe), "--output", str(case_dir)]
        if args.record_video:
            command.append("--record-video")
        run_case(command, output / f"{condition}.launcher.log")
        analyzed = []
        for trial in sorted(case_dir.glob("equal_cruise_*_seed*")):
            events = timing_events(trial)
            if not events:
                analyzed.append({"trial": trial.name, "error": "missing timing trace"})
                continue
            try:
                required = list(FORMAL_DYNAMIC_EVENTS)
                if "_rl_" in f"_{trial.name}_":
                    required[5:5] = ["rl_decision_started", "rl_decision_completed"]
                analyzed.append({"trial": trial.name, **analyze_dynamic_events(events, required_events=required)})
            except ValueError as error:
                analyzed.append({"trial": trial.name, "protocol_error": str(error)})
        condition_summaries.append({"condition": condition, "trials": analyzed})
    result = {**manifest, "conditions_completed": condition_summaries}
    write_json(output / "dynamic_matrix_summary.json", result)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("static", "dynamic", "all"), default="all")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seeds", nargs="+", type=int, default=[11, 22, 33])
    parser.add_argument("--static-case", action="append", default=None,
                        help="benchmark config path; repeat to override the default matrix")
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--record-video", action="store_true")
    args = parser.parse_args()
    if args.static_case is None:
        args.static_case = list(STATIC_CASES)
    output = args.output.resolve()
    if output.exists():
        raise FileExistsError(f"output already exists: {output}")
    output.mkdir(parents=True)
    if args.mode in ("static", "all"):
        static_matrix(args, output / "static")
    if args.mode in ("dynamic", "all"):
        if args.prepare_only:
            raise ValueError("dynamic matrix cannot use --prepare-only; it must produce timing traces")
        dynamic_matrix(args, output / "dynamic")
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
