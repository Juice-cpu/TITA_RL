from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from isaaclab.app import AppLauncher


parser = argparse.ArgumentParser()
parser.add_argument('--asset', required=True)
parser.add_argument('--checkpoint', required=True)
parser.add_argument('--residual-checkpoint', type=Path, required=True)
parser.add_argument('--velocity-calibration', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--generations', type=int, default=4)
parser.add_argument('--candidates', type=int, default=12)
parser.add_argument('--seed', type=int, default=7411)
parser.add_argument('--task', choices=('supported_stop', 'riser'), default='supported_stop')
parser.add_argument('--riser-height', type=float, default=.015)
AppLauncher.add_app_launcher_args(parser)
arguments = parser.parse_args()
simulation_app = AppLauncher(arguments).app

import torch

from tita_uc_residual_rl.calibrated_governor import BatchedCalibratedGovernor
from tita_uc_residual_rl.experiment_provenance import input_hashes, snapshot_sources
from tita_uc_residual_rl.isaaclab_tita_env import TitaResidualEnv, build_tita_cfg
from tita_uc_residual_rl.observation_encoding import encode_robot_observation
from tita_uc_residual_rl.official_policy import FrozenOfficialTitaController, OfficialTitaActor
from tita_uc_residual_rl.phase_b_learner import PhaseBActorCritic, load_phase_b_state_dict_compatible
from tita_uc_residual_rl.posture_bias_search import symmetric_posture_logit_bias, robust_posture_candidate_scores, robust_riser_candidate_scores
from tita_uc_residual_rl.stationary_execution_reward import stationary_execution_reward
from tita_uc_residual_rl.training_contact_contract import TrainingContactContract
from tita_uc_residual_rl.velocity_calibration import load_velocity_calibration


def main():
    source_root = Path(__file__).resolve().parents[1]
    if (source_root / 'execution_sources.json').exists():
        from freeze_execution_sources import verify_execution_sources
        verify_execution_sources(source_root)
    if (arguments.output.exists() or arguments.generations < 1 or arguments.candidates < 4
            or not 0. < arguments.riser_height <= .1):
        raise ValueError('search requires new outputs and positive population sizes')
    provenance = snapshot_sources(Path(__file__).resolve().parents[1], arguments.output.with_suffix('.sources.tar.gz'))
    artifacts = input_hashes({'asset': arguments.asset, 'checkpoint': arguments.checkpoint,
        'residual': arguments.residual_checkpoint, 'velocity_calibration': arguments.velocity_calibration})
    payload = torch.load(arguments.residual_checkpoint, map_location='cpu', weights_only=True)
    execution = payload['execution_config']
    if execution['asset_sha256'] != artifacts['asset']['sha256'] or execution['official_checkpoint_sha256'] != artifacts['checkpoint']['sha256']:
        raise ValueError('residual search execution inputs must match the trained controller')
    cfg = build_tita_cfg(arguments.asset, num_envs=arguments.candidates * 4, terrain='stairs')
    cfg.sim.device = 'cpu'
    cfg.sim.disable_contact_processing = False
    cfg.convex_cylinder_collisions = True
    for field in ('residual_filter_alpha', 'acceleration_limit', 'enforce_acceleration_limit',
                  'normalized_cost_clip', 'objective_p95', 'posture_joint_anchors', 'posture_heights',
                  'navigation_pose_observations'):
        setattr(cfg, field, execution[field])
    cfg.residual_limit = payload['policy_config']['residual_limit']
    cfg.posture_scale = payload['policy_config']['posture_scale']
    cfg.stair_support_augmentation_enabled = True
    cfg.stair_support_augmentation_offset_m = 1.5
    cfg.stair_start_x_m = 12.
    cfg.stair_step_height_range_m = (.01, .01)
    cfg.stair_tread_range_m = (.6, .6)
    cfg.stair_width_range_m = (1.6, 1.6)
    cfg.stair_num_steps = 1
    cfg.stair_landing_length_m = 8.
    cfg.stair_step_assist_enabled = False
    cfg.stair_training_corridor_enabled = True
    cfg.stair_terminate_on_success = False
    cfg.scene.env_spacing = 80.
    cfg.episode_length_s = 35.
    riser_task = arguments.task == 'riser'
    maximum_steps = 2400 if riser_task else 1400
    if riser_task:
        cfg.stair_support_augmentation_enabled = False
        cfg.stair_start_x_m = 1.2
        cfg.stair_step_height_range_m = (arguments.riser_height, arguments.riser_height)
        cfg.stair_approach_yaw_rad = .1
        cfg.stair_completion_height_tolerance_m = min(.003, arguments.riser_height * .2)
        cfg.stair_landing_length_m = 3.
        cfg.episode_length_s = maximum_steps * .02 + 5.
    cfg.seed = arguments.seed
    torch.manual_seed(arguments.seed)
    env = TitaResidualEnv(cfg)
    env.reset()
    actor = PhaseBActorCritic(obs_dim=env._get_observations()['policy'].shape[-1],
        residual_limit=cfg.residual_limit, posture_scale=cfg.posture_scale).to(env.device)
    load_phase_b_state_dict_compatible(actor, payload['model_state_dict'])
    actor.eval()
    if float(actor.policy.linear_command_gate_mps) != 0.:
        raise ValueError('bias search currently requires an ungated residual policy')
    base = FrozenOfficialTitaController(OfficialTitaActor.from_checkpoint(arguments.checkpoint, env.device))
    calibration = load_velocity_calibration(arguments.velocity_calibration,
        posture_joint_anchors=cfg.posture_joint_anchors, checkpoint_path=arguments.checkpoint,
        asset_path=arguments.asset)
    governor = BatchedCalibratedGovernor(calibration['profiles'], env.num_envs, env.device,
                                         cfg.posture_feedforward_transition_s)
    center = torch.zeros(2, device=env.device)
    standard_deviation = torch.full_like(center, .12)
    incumbent = center.clone()
    history = []
    records = []
    original_bias = actor.policy.network[-1].bias.detach().clone()
    try:
        for generation in range(arguments.generations):
            env.reset()
            base.reset(env.num_envs, env.device)
            governor.reset(torch.ones(env.num_envs, dtype=torch.bool, device=env.device))
            parameters = (center + torch.randn(arguments.candidates, 2, device=env.device) * standard_deviation).clamp(-.4, .4)
            parameters[0] = 0.
            parameters[1] = incumbent
            offsets = symmetric_posture_logit_bias(parameters).repeat_interleave(4, 0)
            scenario = torch.arange(env.num_envs, device=env.device) % 4
            if riser_task:
                yaw = torch.where(scenario == 1, .1, torch.where(scenario == 3, -.1, 0.))
                root_pose = torch.cat((env.robot.data.root_pos_w.clone(), torch.zeros(env.num_envs, 4, device=env.device)), 1)
                root_pose[:, 3] = torch.cos(yaw / 2.)
                root_pose[:, 6] = torch.sin(yaw / 2.)
                env.robot.write_root_pose_to_sim(root_pose)
            target_modes = torch.where(scenario < 2, 0, 1)
            if riser_task:
                target_modes.fill_(2)
            failed = torch.zeros(env.num_envs, dtype=torch.bool, device=env.device)
            truncated_ever = failed.clone()
            hold = torch.zeros(env.num_envs, device=env.device)
            longest_hold = hold.clone()
            pitch_error = hold.clone()
            height_error = hold.clone()
            speed_error = hold.clone()
            contacts = TrainingContactContract(env.num_envs, env.device, True, True)
            initial_root_quaternions = env.robot.data.root_quat_w.detach().cpu().tolist()
            traversed_ever = failed.clone()
            for step in range(maximum_steps):
                modes = torch.ones_like(target_modes) if step < 300 and not riser_task else target_modes
                weights = torch.nn.functional.one_hot(modes, 3).float()
                phase = torch.where(target_modes == 0, torch.full_like(hold, (step - 299) / 300.), torch.zeros_like(hold)) if 300 <= step < 600 else torch.zeros_like(hold)
                command = torch.zeros(env.num_envs, 3, device=env.device)
                if riser_task and step >= 400:
                    command[:, 0] = torch.minimum(torch.where(scenario < 2, .08, .1),
                        torch.full_like(hold, (step - 400) * float(env.step_dt) * .3))
                    quaternion = env.robot.data.root_quat_w
                    yaw = torch.atan2(2. * (quaternion[:, 0] * quaternion[:, 3] + quaternion[:, 1] * quaternion[:, 2]),
                                      1. - 2. * (quaternion[:, 2].square() + quaternion[:, 3].square()))
                    lateral = env.robot.data.root_pos_w[:, 1] - env._environment_origins()[:, 1]
                    command[:, 2] = (-1.5 * yaw - .8 * lateral).clamp(-.3, .3)
                    command[env.stair_traversed] = 0.
                elif not riser_task and 600 <= step < 800:
                    command[:, 0] = .1
                    command[:, 2] = torch.where(scenario % 2 == 0, -.15, .15)
                env.set_velocity_command(command)
                env.set_posture_command(weights, phase[:, None])
                measured = torch.cat((env.robot.data.root_lin_vel_b[:, :2], env.robot.data.root_ang_vel_b[:, 2:3]), 1)
                policy_command = governor.command(command, measured, weights, float(env.step_dt))
                with torch.no_grad():
                    proprioception = env.official_proprioception(base.previous_policy_action)
                    proprioception[:, 6:9] = policy_command * policy_command.new_tensor([2., 2., .25])
                    target, _ = base.target(proprioception, env.default_joint_target())
                    env.set_base_target(target)
                    observation = env._get_observations()['policy']
                    encoded = encode_robot_observation(observation, int(actor.policy.observation_encoding_version))
                    action = torch.tanh(actor.policy.network(encoded) + offsets) * cfg.residual_limit * actor.policy.posture_scales
                _, _, terminated, truncated, _ = env.step(action)
                failed |= terminated
                truncated_ever |= truncated
                contacts.observe(env._wheel_contact, float(env.step_dt))
                base.reset_envs(terminated | truncated)
                if step >= (300 if riser_task else 800):
                    verified = env.stair_traversed if riser_task else torch.ones_like(failed)
                    traversed_ever |= verified & ~failed & ~truncated_ever
                    hold, _ = stationary_execution_reward(hold, command, env.robot.data.root_lin_vel_w,
                        env.robot.data.root_ang_vel_b, env.robot.data.projected_gravity_b, env._wheel_contact,
                        env.posture_height - env.posture_target_height, phase,
                        failed | truncated_ever | ~verified, float(env.step_dt))
                    longest_hold = torch.maximum(longest_hold, hold)
                    gravity = env.robot.data.projected_gravity_b
                    pitch = torch.atan2(-gravity[:, 0], torch.linalg.vector_norm(gravity[:, 1:], dim=1))
                    sample_count = maximum_steps - (300 if riser_task else 800)
                    pitch_error += (pitch.abs() - .08).clamp_min(0.).square() / sample_count
                    height_error += (env.posture_height - env.posture_target_height).square() / sample_count
                    speed_error += (env.robot.data.root_lin_vel_w[:, :2].square().sum(1)
                                    + (env.robot.data.root_ang_vel_b[:, 2] - command[:, 2]).square()) / sample_count
            score_arguments = (longest_hold.reshape(-1, 4), pitch_error.reshape(-1, 4),
                height_error.reshape(-1, 4), speed_error.reshape(-1, 4), (failed | truncated_ever).reshape(-1, 4))
            scores = (robust_riser_candidate_scores(score_arguments[0], traversed_ever.reshape(-1, 4), *score_arguments[1:])
                      if riser_task else robust_posture_candidate_scores(*score_arguments))
            elite = scores.topk(max(2, arguments.candidates // 4)).indices
            winner = int(elite[0])
            incumbent = parameters[winner].clone()
            center = parameters[elite].mean(0)
            standard_deviation = parameters[elite].std(0, unbiased=False).clamp(min=.02, max=.15)
            record = {'generation': generation, 'candidate_parameters': parameters.tolist(), 'scores': scores.tolist(),
                      'longest_strict_hold_s': longest_hold.reshape(-1, 4).tolist(),
                      'final_strict_hold_s': hold.reshape(-1, 4).tolist(),
                      'mean_excess_pitch_squared': pitch_error.reshape(-1, 4).tolist(),
                      'hard_failure': failed.reshape(-1, 4).tolist(), 'truncated': truncated_ever.reshape(-1, 4).tolist(),
                      'traversed_ever': traversed_ever.reshape(-1, 4).tolist(),
                      'initial_root_quaternions_wxyz': initial_root_quaternions,
                      'selected_candidate': winner, 'selected_logit_bias_parameters': incumbent.tolist(),
                      'contact_contract': contacts.metadata()}
            records.append(record)
            checkpoint = copy.deepcopy(payload)
            checkpoint['model_state_dict'] = {key: value.detach().cpu().clone() for key, value in actor.state_dict().items()}
            offset = symmetric_posture_logit_bias(incumbent[None])[0]
            checkpoint['model_state_dict']['policy.network.4.bias'] = (original_bias + offset).detach().cpu()
            checkpoint['execution_source_provenance'] = provenance
            checkpoint['posture_bias_search'] = {'algorithm': 'bounded_logit_bias_cross_entropy_search',
                'task': arguments.task, 'riser_height_m': arguments.riser_height if riser_task else None,
                'generation': generation, 'input_artifacts': artifacts, 'selected_candidate': record,
                'scope': 'Actual CPU Isaac contact training with bounded symmetric sagittal logit offsets; not independent navigation acceptance'}
            destination = arguments.output.with_name(arguments.output.stem + f'.generation_{generation:02d}.pt')
            if destination.exists():
                raise ValueError('candidate checkpoint must be immutable')
            torch.save(checkpoint, destination)
            history.append(str(destination))
            print(json.dumps({'generation': generation, 'winner': winner, 'parameters': incumbent.tolist(),
                'score': float(scores[winner]), 'hold_s': record['longest_strict_hold_s'][winner],
                'checkpoint': str(destination)}), flush=True)
        report = {'schema': 'tita.real_isaac_posture_bias_search.v1', 'training_only': True,
                  'independent_navigation_accepted': False, 'physics_device': str(env.device),
                  'contact_processing_enabled': True, 'convex_cylinder_collisions': True,
                  'seed': arguments.seed, 'execution_source_provenance': provenance, 'input_artifacts': artifacts,
                  'task': arguments.task, 'riser_height_m': arguments.riser_height if riser_task else None,
                  'scenario_order': (['HIGH_.08_straight', 'HIGH_.08_positive_yaw', 'HIGH_.10_straight', 'HIGH_.10_negative_yaw'] if riser_task else
                      ['LOW_flat_negative_yaw', 'LOW_10mm_positive_yaw', 'MID_flat_negative_yaw', 'MID_10mm_positive_yaw']),
                  'checkpoints': history, 'generations': records}
        with arguments.output.open('x') as stream:
            json.dump(report, stream, indent=2)
    finally:
        env.close()


if __name__ == '__main__':
    try:
        main()
    finally:
        simulation_app.close()
