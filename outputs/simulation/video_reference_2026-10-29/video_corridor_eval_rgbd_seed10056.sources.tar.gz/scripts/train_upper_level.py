#!/usr/bin/env python3
"""Train the independent 9-action upper-level categorical PPO policy."""

from __future__ import annotations

import argparse
from dataclasses import asdict, replace
import json
from pathlib import Path
import random
import time

import numpy as np
import torch

from tita_uc_residual_rl.upper_level_experiment import (
    calibrate_rule_references,
    evaluate_policy,
    manual_action_gate,
    summarize_metrics,
    write_json,
)
from tita_uc_residual_rl.upper_level_policy import (
    CategoricalPPOConfig,
    LearnedUpperPolicy,
    MaskedCategoricalPPO,
    UpperActorCritic,
    generalized_advantage,
    save_upper_checkpoint,
)
from tita_uc_residual_rl.upper_level_toy_env import UpperLevelToyEnv
from tita_uc_residual_rl.upper_level_types import UpperObjectiveWeights


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=11)
    parser.add_argument("--num-envs", type=int, default=16)
    parser.add_argument("--iterations", type=int, default=150)
    parser.add_argument("--rollout-steps", type=int, default=64)
    parser.add_argument("--validation-episodes", type=int, default=36)
    parser.add_argument("--validation-interval", type=int, default=10)
    parser.add_argument("--calibration-episodes", type=int, default=128)
    parser.add_argument("--manual-rollouts-per-action", type=int, default=10)
    parser.add_argument("--device", default="cpu")
    parser.add_argument(
        "--ablation",
        choices=("none", "energy", "clearance", "switch", "attitude"),
        default="none",
    )
    return parser.parse_args()


def selected_weights(ablation: str) -> UpperObjectiveWeights:
    weights = UpperObjectiveWeights()
    if ablation == "none":
        return weights
    return replace(weights, **{ablation: 0.0})


def main() -> None:
    args = parse_args()
    if min(args.num_envs, args.iterations, args.rollout_steps) <= 0:
        raise ValueError("training sizes must be positive")
    args.run_dir.mkdir(parents=True, exist_ok=False)
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
    device = torch.device(args.device)
    normalization = calibrate_rule_references(
        seed=20261009, episodes=args.calibration_episodes
    )
    weights = selected_weights(args.ablation)
    ppo_config = CategoricalPPOConfig()
    configuration = {
        "seed": args.seed,
        "num_envs": args.num_envs,
        "iterations": args.iterations,
        "rollout_steps": args.rollout_steps,
        "validation_episodes": args.validation_episodes,
        "validation_interval": args.validation_interval,
        "ablation": args.ablation,
        "normalization": asdict(normalization),
        "objective_weights": asdict(weights),
        "ppo": asdict(ppo_config),
        "controller_contract": {
            "upper_hz": 2.0,
            "mppi_hz": 10.0,
            "low_level_hz": 50.0,
            "lower_controller_frozen": True,
        },
    }
    write_json(args.run_dir / "config.json", configuration)
    gate = manual_action_gate(
        seed=args.seed + 300_000,
        rollouts_per_action=args.manual_rollouts_per_action,
        normalization=normalization,
    )
    write_json(args.run_dir / "manual_action_gate.json", gate)
    if not bool(gate["passed"]):
        raise RuntimeError(
            "manual 8/10 action gate failed; calibrate vmax/envelope before PPO"
        )

    env = UpperLevelToyEnv(
        num_envs=args.num_envs,
        seed=args.seed,
        split="train",
        normalization=normalization,
        weights=weights,
    )
    model = UpperActorCritic().to(device)
    learner = MaskedCategoricalPPO(model, ppo_config)
    observations_np, masks_np = env.observation_matrix(), env.action_masks()
    metric_path = args.run_dir / "training_metrics.jsonl"
    best_key = (-1.0, float("inf"))
    completed_episodes = 0
    training_started = time.perf_counter()
    for iteration in range(1, args.iterations + 1):
        observation_rollout = []
        mask_rollout = []
        action_rollout = []
        log_probability_rollout = []
        value_rollout = []
        reward_rollout = []
        done_rollout = []
        action_histogram = np.zeros(9, dtype=np.int64)
        iteration_successes = 0
        iteration_hard_failures = 0
        for _ in range(args.rollout_steps):
            observations = torch.as_tensor(
                observations_np, dtype=torch.float32, device=device
            )
            masks = torch.as_tensor(masks_np, dtype=torch.bool, device=device)
            with torch.no_grad():
                actions, log_probabilities, values, _ = model.act(
                    observations, masks, deterministic=False
                )
            actions_np = actions.cpu().numpy()
            action_histogram += np.bincount(actions_np, minlength=9)
            next_observations, rewards_np, done_np, information, next_masks = env.step(
                actions_np
            )
            observation_rollout.append(observations)
            mask_rollout.append(masks)
            action_rollout.append(actions)
            log_probability_rollout.append(log_probabilities)
            value_rollout.append(values)
            reward_rollout.append(
                torch.as_tensor(rewards_np, dtype=torch.float32, device=device)
            )
            done_rollout.append(
                torch.as_tensor(done_np, dtype=torch.bool, device=device)
            )
            finished = np.flatnonzero(done_np)
            for index in finished:
                iteration_successes += int(bool(information[index].get("success", False)))
                iteration_hard_failures += int(
                    bool(information[index].get("hard_violation", False))
                )
                completed_episodes += 1
            if finished.size:
                env.reset(finished.tolist())
                next_observations = env.observation_matrix()
                next_masks = env.action_masks()
            observations_np, masks_np = next_observations, next_masks

        observation_tensor = torch.stack(observation_rollout)
        mask_tensor = torch.stack(mask_rollout)
        action_tensor = torch.stack(action_rollout)
        log_probability_tensor = torch.stack(log_probability_rollout)
        value_tensor = torch.stack(value_rollout)
        reward_tensor = torch.stack(reward_rollout)
        done_tensor = torch.stack(done_rollout)
        with torch.no_grad():
            last_observations = torch.as_tensor(
                observations_np, dtype=torch.float32, device=device
            )
            _, last_value = model(last_observations)
            advantages, returns = generalized_advantage(
                reward_tensor,
                value_tensor,
                last_value,
                done_tensor,
                ppo_config.gamma,
                ppo_config.gae_lambda,
            )
        stats = learner.update(
            observation_tensor,
            mask_tensor,
            action_tensor,
            log_probability_tensor,
            advantages,
            returns,
        )
        record: dict[str, object] = {
            "iteration": iteration,
            "samples": iteration * args.rollout_steps * args.num_envs,
            "completed_episodes": completed_episodes,
            "rollout_reward_mean": float(reward_tensor.mean()),
            "rollout_successes": iteration_successes,
            "rollout_hard_failures": iteration_hard_failures,
            "action_histogram": action_histogram.tolist(),
            **asdict(stats),
        }
        if iteration % args.validation_interval == 0 or iteration == args.iterations:
            validation_policy = LearnedUpperPolicy(
                model, deterministic=True, device=device
            )
            validation_results = evaluate_policy(
                validation_policy,
                method="categorical_ppo_validation",
                seed=args.seed + 500_000,
                episodes=args.validation_episodes,
                normalization=normalization,
                weights=weights,
                split="validation",
            )
            validation = summarize_metrics(validation_results)
            record["validation"] = validation
            key = (
                float(validation["success_rate"]),
                float(validation["total_cost"]["mean"]),  # type: ignore[index]
            )
            if key[0] > best_key[0] or (key[0] == best_key[0] and key[1] < best_key[1]):
                best_key = key
                save_upper_checkpoint(
                    args.run_dir / "upper_policy_best.pt",
                    model,
                    normalization=asdict(normalization),
                    config=ppo_config,
                    metadata={
                        "seed": args.seed,
                        "iteration": iteration,
                        "validation": validation,
                        "ablation": args.ablation,
                    },
                )
        with metric_path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")

    save_upper_checkpoint(
        args.run_dir / "upper_policy_last.pt",
        model,
        normalization=asdict(normalization),
        config=ppo_config,
        metadata={
            "seed": args.seed,
            "iteration": args.iterations,
            "ablation": args.ablation,
        },
    )
    write_json(
        args.run_dir / "training_summary.json",
        {
            "elapsed_wall_s": time.perf_counter() - training_started,
            "samples": args.iterations * args.rollout_steps * args.num_envs,
            "completed_episodes": completed_episodes,
            "best_validation_success_rate": best_key[0],
            "best_validation_cost": best_key[1],
            "checkpoint": "upper_policy_best.pt",
        },
    )


if __name__ == "__main__":
    main()

