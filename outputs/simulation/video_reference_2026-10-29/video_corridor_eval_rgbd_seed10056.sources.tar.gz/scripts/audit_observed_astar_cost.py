import argparse
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

import torch
import yaml

from tita_uc_residual_rl.isaac_prior_scene import calibrated_prior_scene
from tita_uc_residual_rl.navigation_acceptance_audit import verify_execution_artifacts
from tita_uc_residual_rl.observed_astar_cost_audit import audit_observed_astar_cost
from tita_uc_residual_rl.observed_shuttle_audit import audit_observed_shuttle_contexts


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--report', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--require-exercised', action='store_true')
    arguments = parser.parse_args()
    content = arguments.report.read_bytes()
    document = json.loads(content)
    artifacts = document['input_artifacts']
    geometry = json.loads(Path(artifacts['geometry_calibration']['path']).read_text())
    if 'high_geometry_calibration' in artifacts:
        geometry['profiles']['HIGH'] = json.loads(Path(artifacts['high_geometry_calibration']['path']).read_text())['profiles']['HIGH']
    configuration = yaml.safe_load(Path(artifacts['neupan_yaml']['path']).read_text())
    environment = SimpleNamespace(cfg=SimpleNamespace(navigation_scene_file=artifacts['navigation_scene']['path'],
        stair_enabled=False, tunnel_enabled=False), _environment_origins=lambda: torch.zeros((1, 3)))
    scene = calibrated_prior_scene(environment, (0., 0.), document['goal_xy_m'], geometry,
        planner_vertices_xy_m=configuration['robot']['vertices'],
        minimum_obstacle_clearance_m=configuration['adjust']['d_min'])
    artifact_failures = verify_execution_artifacts(document)
    causal = audit_observed_shuttle_contexts(document)
    cost = audit_observed_astar_cost(document, scene)
    result = {'schema': 'tita.causal_observed_astar_cost_audit.v1',
        'passed': not artifact_failures and causal['passed'] and cost['passed']
            and (cost['exercised'] or not arguments.require_exercised),
        'artifact_failures': artifact_failures, 'causal_contexts': causal, 'cost_binding': cost,
        'required_exercised': arguments.require_exercised, 'report': str(arguments.report.resolve()),
        'report_sha256': hashlib.sha256(content).hexdigest(), 'new_physics_proven': False,
        'scope': 'Exact observed forecast/cost-input replay and original artifact hashes; independent physical navigation still needs its separate acceptance audit.'}
    with arguments.output.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'passed': result['passed'], 'cost_binding': cost}))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
