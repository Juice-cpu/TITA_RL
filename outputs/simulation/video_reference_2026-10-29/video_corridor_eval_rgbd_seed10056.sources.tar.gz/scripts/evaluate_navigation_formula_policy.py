#!/usr/bin/env python3
"""Evaluate trained formula-policy checkpoints on held-out proxy scenarios."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch

from scripts.train_navigation_formula_policy import evaluate_argmin, evaluate_model
from tita_uc_residual_rl.navigation_formula_policy import load_formula_checkpoint


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-root", type=Path, required=True)
    parser.add_argument("--seeds", nargs="+", type=int, default=(11, 22, 33))
    parser.add_argument("--episodes", type=int, default=1200)
    parser.add_argument("--device", default="cpu")
    args = parser.parse_args()
    if args.episodes <= 0:
        raise ValueError("episodes must be positive")
    device = torch.device(args.device)
    reports: dict[str, object] = {}
    for seed in args.seeds:
        checkpoint = args.run_root / f"seed_{seed}" / "formula_policy_best.pt"
        model, config, _ = load_formula_checkpoint(checkpoint, device=device)
        eval_seed = seed + 1_900_000
        reports[str(seed)] = {
            "checkpoint": str(checkpoint),
            "test_seed": eval_seed,
            "formula_argmin_reference": evaluate_argmin(
                seed=eval_seed, episodes=args.episodes, config=config, path_capacity=model.path_capacity
            ),
            "ppo": evaluate_model(
                model, seed=eval_seed, episodes=args.episodes, config=config, device=device
            ),
        }
    output = args.run_root / "evaluation_reproducible.json"
    output.write_text(json.dumps(reports, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()
