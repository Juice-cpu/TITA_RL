#!/usr/bin/env python3
"""Measure upper decision and three-route feature extraction latency."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import time

import numpy as np

from tita_uc_residual_rl.upper_level_experiment import calibrate_rule_references, write_json
from tita_uc_residual_rl.upper_level_objective import EnumeratedObjectivePolicy, ShortestRoutePolicy
from tita_uc_residual_rl.upper_level_policy import LearnedUpperPolicy, load_upper_checkpoint
from tita_uc_residual_rl.upper_level_toy_env import UpperLevelToyEnv


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path)
    parser.add_argument("--samples", type=int, default=5000)
    return parser.parse_args()


def measure(policy, observations, samples: int) -> dict[str, float]:
    values = []
    for observation in observations[:samples]:
        started = time.perf_counter_ns()
        policy.decide(observation)
        values.append((time.perf_counter_ns() - started) / 1e6)
    values = np.asarray(values)
    return {
        "p50_ms": float(np.percentile(values, 50)),
        "p95_ms": float(np.percentile(values, 95)),
        "max_ms": float(np.max(values)),
    }


def measure_feature_extraction(env, samples: int) -> dict[str, float]:
    values = []
    for index in range(samples):
        started = time.perf_counter_ns()
        env.observation(index % env.num_envs).vector()
        values.append((time.perf_counter_ns() - started) / 1e6)
    values = np.asarray(values)
    return {
        "p50_ms": float(np.percentile(values, 50)),
        "p95_ms": float(np.percentile(values, 95)),
        "max_ms": float(np.max(values)),
    }


def main() -> None:
    args = parse_args()
    if args.samples <= 0:
        raise ValueError("samples must be positive")
    normalization = calibrate_rule_references(episodes=64)
    env = UpperLevelToyEnv(num_envs=16, seed=77, split="test", normalization=normalization)
    observations = []
    for index in range(env.num_envs):
        observations.append(env.observation(index))
    observations = observations * ((args.samples + len(observations) - 1) // len(observations))
    result = {
        "samples": args.samples,
        "three_route_feature_extraction": measure_feature_extraction(env, args.samples),
        "upper_policy": {
            "shortest_rule": measure(ShortestRoutePolicy(), observations, args.samples),
            "enumerated_argmin": measure(
                EnumeratedObjectivePolicy(normalization), observations, args.samples
            ),
        },
        "contract": {
            "upper_period_ms": 500.0,
            "mppi_period_ms": 100.0,
            "low_level_period_ms": 20.0,
            "hardware_output": "disabled_shadow_only",
        },
    }
    if args.checkpoint:
        model, _ = load_upper_checkpoint(args.checkpoint)
        result["upper_policy"]["categorical_ppo"] = measure(
            LearnedUpperPolicy(model), observations, args.samples
        )
    write_json(args.output, result)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
