#!/usr/bin/env python3
"""Evaluate the three TITA bottom-control modalities in Isaac Sim."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from isaaclab.app import AppLauncher

parser = argparse.ArgumentParser()
parser.add_argument("--asset", required=True)
parser.add_argument("--official-checkpoint", required=True)
parser.add_argument("--residual-checkpoint", type=Path, default=None)
parser.add_argument("--terrain", choices=("flat", "route_choice", "tunnel", "stairs"), required=True)
parser.add_argument("--fixed-posture", choices=("LOW", "MID", "HIGH"), required=True)
parser.add_argument("--num-envs", type=int, default=32)
parser.add_argument("--steps", type=int, default=300)
parser.add_argument("--warmup-steps", type=int, default=100)
parser.add_argument("--command-x", type=float, default=0.30)
parser.add_argument("--acceleration-limit", type=float, default=500.0)
parser.add_argument("--residual-filter-alpha", type=float, default=0.10)
parser.add_argument("--seed", type=int, default=211)
parser.add_argument("--output", type=Path, required=True)
AppLauncher.add_app_launcher_args(parser)
args = parser.parse_args()
app_launcher = AppLauncher(args)
simulation_app = app_launcher.app

import torch  # noqa: E402

from tita_uc_residual_rl.isaaclab_tita_env import (  # noqa: E402
    HARD_REASON_NAMES,
    TitaResidualEnv,
    build_tita_cfg,
)
from tita_uc_residual_rl.official_policy import (  # noqa: E402
    FrozenOfficialTitaController,
    OfficialTitaActor,
)
from tita_uc_residual_rl.phase_b_learner import (  # noqa: E402
    PhaseBActorCritic,
    load_phase_b_state_dict_compatible,
)


def _configure_terrain(cfg) -> None:
    if args.terrain == "tunnel":
        cfg.tunnel_height_range_m = (0.48, 0.52)
        cfg.tunnel_width_range_m = (0.70, 0.80)
        cfg.tunnel_length_range_m = (0.40, 0.60)
        cfg.tunnel_start_x_m = 0.75
        cfg.tunnel_wall_thickness_m = 0.10
        cfg.tunnel_success_reward = 10.0
        cfg.scene.env_spacing = max(cfg.scene.env_spacing, 4.5)
    elif args.terrain == "stairs":
        cfg.stair_step_height_range_m = (0.005, 0.015)
        cfg.stair_tread_range_m = (0.25, 0.35)
        cfg.stair_width_range_m = (1.0, 1.3)
        cfg.stair_num_steps = 2
        cfg.stair_start_x_m = 0.35
        cfg.stair_landing_length_m = 0.40
        cfg.stair_success_reward = 60.0
        cfg.stair_terminate_on_success = True
        cfg.scene.env_spacing = max(cfg.scene.env_spacing, 4.0)


def main() -> None:
    torch.manual_seed(args.seed)
    cfg = build_tita_cfg(
        args.asset,
        num_envs=args.num_envs,
        terrain=args.terrain,
        domain_randomization=False,
    )
    cfg.seed = args.seed
    cfg.acceleration_limit = args.acceleration_limit
    cfg.residual_filter_alpha = args.residual_filter_alpha
    cfg.enforce_acceleration_limit = True
    _configure_terrain(cfg)
    env = TitaResidualEnv(cfg)
    observation, _ = env.reset()
    observation = observation["policy"]
    official = FrozenOfficialTitaController(
        OfficialTitaActor.from_checkpoint(args.official_checkpoint, env.device)
    )
    official.reset(env.num_envs, env.device)
    residual = None
    if args.residual_checkpoint is not None:
        payload = torch.load(
            args.residual_checkpoint.expanduser(), map_location="cpu", weights_only=True
        )
        residual = PhaseBActorCritic(
            obs_dim=observation.shape[-1],
            residual_limit=cfg.residual_limit,
            posture_scale=cfg.posture_scale,
        ).to(env.device)
        load_phase_b_state_dict_compatible(residual, payload["model_state_dict"])
        residual.eval()

    posture_index = ("LOW", "MID", "HIGH").index(args.fixed_posture)
    posture_command = torch.nn.functional.one_hot(
        torch.full((env.num_envs,), posture_index, device=env.device), 3
    ).to(torch.float32)
    env.set_posture_command(posture_command)
    env._posture_mode.fill_(posture_index)
    env._posture_mode_age.fill_(1.0e6)
    env._posture_switch_event.zero_()
    env._rapid_posture_switch_event.zero_()
    env._last_collision_event.zero_()
    speed_limits = {"LOW": 0.15, "MID": 0.30, "HIGH": 0.20}
    command = torch.tensor(
        [min(args.command_x, speed_limits[args.fixed_posture]), 0.0, 0.0],
        device=env.device,
    ).repeat(env.num_envs, 1)
    for _ in range(args.warmup_steps):
        env.set_posture_command(posture_command)
        env.set_velocity_command(torch.zeros_like(command) if args.terrain == "stairs" else command)
        assert official.previous_policy_action is not None
        proprioception = env.official_proprioception(official.previous_policy_action)
        base_target, _ = official.target(proprioception, env.default_joint_target())
        env.set_base_target(base_target)
        with torch.no_grad():
            action = (
                torch.zeros(env.num_envs, 8, device=env.device)
                if residual is None
                else residual.policy(observation)
            )
        next_observation, _, terminated, truncated, _ = env.step(action)
        official.reset_envs(terminated | truncated)
        observation = next_observation["policy"]
    env._posture_switch_event.zero_()
    env._rapid_posture_switch_event.zero_()
    reward_sum = 0.0
    raw_cost_sum = torch.zeros(4, device=env.device)
    normalized_cost_sum = torch.zeros(4, device=env.device)
    hard_failures = 0
    hard_reasons = torch.zeros(len(HARD_REASON_NAMES), dtype=torch.long, device=env.device)
    mode_switch_events = 0
    rapid_mode_switch_events = 0
    dynamic_risk_sum = 0.0
    collision_context_names = (
        "peak_force",
        "local_x",
        "local_y",
        "root_z",
        "speed",
        "roll",
        "pitch",
        "yaw_rate",
        "vertical_margin",
        "lateral_margin",
        "navigation_clearance",
    )
    collision_context_sum = torch.zeros(
        len(collision_context_names), device=env.device
    )
    collision_context_samples = 0
    collision_zone_counts = {"before_entry": 0, "in_tunnel": 0, "after_exit": 0}
    tunnel_ever_exited = torch.zeros(env.num_envs, dtype=torch.bool, device=env.device)
    stair_ever_completed = torch.zeros_like(tunnel_ever_exited)
    success_events = 0
    completed_events = 0
    samples = args.steps * env.num_envs

    for _ in range(args.steps):
        env.set_posture_command(posture_command)
        env.set_velocity_command(command)
        assert official.previous_policy_action is not None
        proprioception = env.official_proprioception(official.previous_policy_action)
        base_target, _ = official.target(proprioception, env.default_joint_target())
        env.set_base_target(base_target)
        with torch.no_grad():
            action = (
                torch.zeros(env.num_envs, 8, device=env.device)
                if residual is None
                else residual.policy(observation)
            )
        previous_tunnel = env.tunnel_success_count.clone()
        previous_stair = env.stair_success_count.clone()
        next_observation, reward, terminated, truncated, _ = env.step(action)
        done = terminated | truncated
        tunnel_ever_exited |= env.tunnel_success_count > 0
        stair_ever_completed |= env.stair_success_count > 0
        success_events += int((env.tunnel_success_count - previous_tunnel).sum().item())
        completed_events += int((env.stair_success_count - previous_stair).sum().item())
        reward_sum += float(reward.sum())
        raw_cost_sum += env.raw_soft_costs.sum(0)
        normalized_cost_sum += env.soft_costs.sum(0)
        hard_failures += int(terminated.sum().item())
        hard_reasons += env.hard_reason_flags.sum(0)
        mode_switch_events += int(env.posture_switch_event.sum().item())
        rapid_mode_switch_events += int(env.rapid_posture_switch_event.sum().item())
        dynamic_risk_sum += float(env.dynamic_obstacle_risk.sum().item())
        collision_events = env.collision_event
        if collision_events.any():
            context = env.collision_context
            event_indices = collision_events.nonzero(as_tuple=False).flatten()
            collision_context_sum += torch.stack(
                [context[name][event_indices].sum() for name in collision_context_names]
            )
            collision_context_samples += int(event_indices.numel())
            local_x = context["local_x"][event_indices]
            in_tunnel = context["in_tunnel"][event_indices]
            start = float(cfg.tunnel_start_x_m)
            end = start + env.tunnel_dimensions[event_indices, 2]
            collision_zone_counts["before_entry"] += int(
                ((local_x < start) & ~in_tunnel).sum().item()
            )
            collision_zone_counts["in_tunnel"] += int(in_tunnel.sum().item())
            collision_zone_counts["after_exit"] += int(
                ((local_x > end) & ~in_tunnel).sum().item()
            )
        official.reset_envs(done)
        observation = next_observation["policy"]

    result = {
        "terrain": args.terrain,
        "fixed_posture": args.fixed_posture,
        "controller": "official+residual" if residual is not None else "official",
        "residual_checkpoint": str(args.residual_checkpoint) if args.residual_checkpoint else None,
        "num_envs": args.num_envs,
        "steps": args.steps,
        "samples": samples,
        "reward_mean": reward_sum / samples,
        "raw_cost_mean": (raw_cost_sum / samples).tolist(),
        "normalized_cost_mean": (normalized_cost_sum / samples).tolist(),
        "hard_failures": hard_failures,
        "hard_reason_counts": hard_reasons.tolist(),
        "hard_reason_names": list(HARD_REASON_NAMES),
        "mode_switch_events": mode_switch_events,
        "rapid_mode_switch_events": rapid_mode_switch_events,
        "dynamic_obstacle_risk_mean": dynamic_risk_sum / samples,
        "collision_context_samples": collision_context_samples,
        "collision_context_mean": (
            (collision_context_sum / max(collision_context_samples, 1)).tolist()
            if collision_context_samples
            else None
        ),
        "collision_context_names": list(collision_context_names),
        "collision_zone_counts": collision_zone_counts,
        "tunnel_success_events": success_events if args.terrain == "tunnel" else None,
        "tunnel_completed_envs": int(tunnel_ever_exited.sum().item()) if args.terrain == "tunnel" else None,
        "stair_success_events": completed_events if args.terrain == "stairs" else None,
        "stair_completed_envs": int(stair_ever_completed.sum().item()) if args.terrain == "stairs" else None,
        "seed": args.seed,
    }
    output = args.output.expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))
    env.close()


if __name__ == "__main__":
    try:
        main()
    finally:
        simulation_app.close()
