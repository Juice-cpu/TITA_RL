from __future__ import annotations

import argparse
import json
from pathlib import Path

from isaaclab.app import AppLauncher

parser = argparse.ArgumentParser()
parser.add_argument("--asset", required=True)
parser.add_argument("--checkpoint", required=True)
parser.add_argument("--residual-checkpoint", type=Path, required=True)
parser.add_argument("--velocity-calibration", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--step-height", type=float, default=.03)
parser.add_argument("--steps", type=int, default=1800)
parser.add_argument("--seed", type=int, default=713)
parser.add_argument("--high-only", action="store_true")
parser.add_argument("--speed", type=float, default=.15)
parser.add_argument("--speeds", type=float, nargs="+")
parser.add_argument("--start-x", type=float, default=1.2)
parser.add_argument("--step-width", type=float, default=1.2)
parser.add_argument("--approach-yaw-rad", type=float, default=0.)
parser.add_argument("--physics-device", choices=("cpu", "cuda:0"), default="cpu")
parser.add_argument("--convex-cylinders", action="store_true")
parser.add_argument("--demonstrations-output", type=Path)
AppLauncher.add_app_launcher_args(parser)
args = parser.parse_args()
simulation_app = AppLauncher(args).app

import torch

from tita_uc_residual_rl.calibrated_governor import BatchedCalibratedGovernor
from tita_uc_residual_rl.isaaclab_tita_env import TitaResidualEnv, build_tita_cfg, HARD_REASON_NAMES
from tita_uc_residual_rl.official_policy import FrozenOfficialTitaController, OfficialTitaActor
from tita_uc_residual_rl.phase_b_learner import PhaseBActorCritic, load_phase_b_state_dict_compatible
from tita_uc_residual_rl.velocity_calibration import load_velocity_calibration
from tita_uc_residual_rl.execution_contract import residual_training_scope
from tita_uc_residual_rl.stair_step_sequence import stair_stationary_state
from tita_uc_residual_rl.experiment_provenance import input_hashes, snapshot_sources


def main():
    if args.output.exists():
        raise ValueError("output must be new")
    if args.demonstrations_output is not None and args.demonstrations_output.exists():
        raise ValueError("demonstrations output must be new")
    source_provenance = snapshot_sources(Path(__file__).resolve().parents[1], args.output.with_suffix(".sources.tar.gz"))
    artifacts = input_hashes({"asset": args.asset, "checkpoint": args.checkpoint,
                             "residual_checkpoint": args.residual_checkpoint, "velocity_calibration": args.velocity_calibration})
    payload = torch.load(args.residual_checkpoint, map_location="cpu", weights_only=True)
    modes_to_probe = ("HIGH",) if args.high_only else ("LOW", "MID", "HIGH")
    speeds = args.speeds or [args.speed]
    names = tuple(name for speed in speeds for name in modes_to_probe)
    case_speeds = [speed for speed in speeds for name in modes_to_probe]
    if any(name not in residual_training_scope(payload) for name in names):
        raise ValueError("step probe modes exceed residual training scope")
    count = len(names)
    cfg = build_tita_cfg(args.asset, num_envs=count, terrain="stairs")
    cfg.sim.device = args.physics_device
    cfg.convex_cylinder_collisions = args.convex_cylinders
    cfg.sim.disable_contact_processing = False
    cfg.navigation_pose_observations = payload["execution_config"].get("navigation_pose_observations", False)
    for field in ("residual_filter_alpha", "acceleration_limit", "enforce_acceleration_limit", "normalized_cost_clip", "objective_p95", "posture_joint_anchors", "posture_heights"):
        setattr(cfg, field, payload["execution_config"][field])
    cfg.residual_limit = payload["policy_config"]["residual_limit"]
    cfg.posture_scale = payload["policy_config"]["posture_scale"]
    cfg.stair_step_height_range_m = (args.step_height, args.step_height)
    cfg.stair_tread_range_m = (.60, .60)
    cfg.stair_width_range_m = (args.step_width, args.step_width)
    cfg.stair_approach_yaw_rad = args.approach_yaw_rad
    cfg.stair_num_steps = 1
    cfg.stair_start_x_m = args.start_x
    cfg.stair_landing_length_m = 3.0
    cfg.stair_terminate_on_success = False
    cfg.stair_completion_height_tolerance_m = min(.003, args.step_height * .2)
    cfg.stair_step_assist_enabled = False
    cfg.stair_training_corridor_enabled = True
    cfg.episode_length_s = args.steps * .02 + 5.
    cfg.seed = args.seed
    calibration = load_velocity_calibration(args.velocity_calibration, posture_joint_anchors=cfg.posture_joint_anchors,
                                            checkpoint_path=args.checkpoint, asset_path=args.asset)
    env = TitaResidualEnv(cfg)
    obs, _ = env.reset()
    actor = FrozenOfficialTitaController(OfficialTitaActor.from_checkpoint(args.checkpoint, env.device))
    actor.reset(count, env.device)
    residual = PhaseBActorCritic(obs_dim=obs["policy"].shape[-1], residual_limit=cfg.residual_limit, posture_scale=cfg.posture_scale).to(env.device)
    load_phase_b_state_dict_compatible(residual, payload["model_state_dict"])
    residual.eval()
    governor = BatchedCalibratedGovernor(calibration["profiles"], count, env.device, cfg.posture_feedforward_transition_s)
    modes = torch.nn.functional.one_hot(torch.tensor([("LOW", "MID", "HIGH").index(name) for name in names], device=env.device), 3).float()
    failed = torch.zeros(count, dtype=torch.bool, device=env.device)
    success = failed.clone()
    stable = torch.zeros(count, dtype=torch.long, device=env.device)
    arrived = failed.clone()
    settled = stable.clone()
    reasons = [[] for _ in range(count)]
    samples = []
    failures = []
    demonstrations = []
    try:
        for step in range(args.steps):
            command = torch.zeros(count, 3, device=env.device)
            if step >= 400:
                command[:, 0] = torch.minimum(torch.tensor(case_speeds, device=env.device),
                                              command.new_full((count,), (step - 400) * float(env.step_dt) * .3))
                quaternion = env.robot.data.root_quat_w
                yaw = torch.atan2(2 * (quaternion[:, 0] * quaternion[:, 3] + quaternion[:, 1] * quaternion[:, 2]),
                                  1 - 2 * (quaternion[:, 2].square() + quaternion[:, 3].square()))
                lateral_error = env.robot.data.root_pos_w[:, 1] - env._environment_origins()[:, 1]
                command[:, 2] = (-1.5 * yaw - .8 * lateral_error).clamp(-.3, .3)
            command[failed | success | arrived] = 0.
            env.set_velocity_command(command)
            env.set_posture_command(modes)
            measured = torch.cat((env.robot.data.root_lin_vel_b[:, :2], env.robot.data.root_ang_vel_b[:, 2:3]), 1)
            policy_command = governor.command(command, measured, modes, float(env.step_dt))
            with torch.no_grad():
                proprioception = env.official_proprioception(actor.previous_policy_action)
                proprioception[:, 6:9] = policy_command * policy_command.new_tensor([2., 2., .25])
                target, _ = actor.target(proprioception, env.default_joint_target())
                env.set_base_target(target)
                raw_observation = env._get_observations()["policy"]
                action = residual.policy(raw_observation)
            demonstration_active = ~(failed | success)
            _, _, done, truncated, _ = env.step(action)
            if args.demonstrations_output is not None:
                valid = demonstration_active & ~done & ~truncated
                demonstrations.append((raw_observation[valid].cpu().clone(), action[valid].cpu().clone(),
                                       torch.nonzero(valid).flatten().cpu()))
            for index in range(count):
                if bool(done[index]) and not bool(failed[index] | success[index]):
                    reasons[index] = [name for name, flag in zip(HARD_REASON_NAMES, env.hard_reason_flags[index].tolist()) if flag]
                    failures.append({"step": step, "mode": names[index],
                                     "context": {key: float(value[index]) for key, value in env.collision_context.items()}})
            failed |= done & ~success
            wheel_local_x = env.robot.data.body_pos_w[:, env._wheel_body_ids, 0] - env._environment_origins()[:, 0:1]
            verified = ((env._verified_stair_level() >= 1) & env._wheel_contact.all(1) & ~failed
                        & (wheel_local_x >= args.start_x + cfg.wheel_radius + .03).all(1))
            stable = torch.where(verified, stable + 1, torch.zeros_like(stable))
            arrived |= stable >= 25
            target_height = modes @ modes.new_tensor(cfg.posture_heights)
            stationary = stair_stationary_state(verified, env._collision, env.robot.data.root_lin_vel_w,
                                                 env.robot.data.projected_gravity_b, env._wheel_contact,
                                                 env.posture_height - target_height)
            settled = torch.where(arrived & verified & stationary, settled + 1, torch.zeros_like(settled))
            success |= settled >= 50
            actor.reset_envs(done | truncated)
            if step % 25 == 0:
                samples.append({"step": step, "local_x_m": (env.robot.data.root_pos_w[:, 0] - env._environment_origins()[:, 0]).cpu().tolist(),
                                "local_y_m": (env.robot.data.root_pos_w[:, 1] - env._environment_origins()[:, 1]).cpu().tolist(),
                                "wheel_axis_z_m": env.robot.data.body_link_pos_w[:, env._wheel_body_ids, 2].cpu().tolist(),
                                "wheel_axis_reference_z_m": env._stair_wheel_axis_reference_z.cpu().tolist(),
                                "wheel_levels": env._wheel_stair_state()[0].cpu().tolist(), "contacts": env._wheel_contact.cpu().tolist(),
                                "arrived": arrived.cpu().tolist(), "settled_hold_steps": settled.cpu().tolist(),
                                "posture_height_m": env.posture_height.cpu().tolist(),
                                "posture_height_error_m": (env.posture_height - target_height).cpu().tolist(),
                                "root_velocity_mps": env.robot.data.root_lin_vel_w.cpu().tolist(),
                                "projected_gravity_b": env.robot.data.projected_gravity_b.cpu().tolist(),
                                "failed": failed.cpu().tolist(), "success": success.cpu().tolist()})
            if bool((failed | success).all()):
                break
        result = {"backend": "real_isaac_sim_full_tower_biped", "height_m": args.step_height, "seed": args.seed,
                  "convex_cylinder_collisions": cfg.convex_cylinder_collisions,
                  "physics_device": str(env.device), "contact_processing_enabled": True,
                  "input_artifacts": artifacts, "execution_source_provenance": source_provenance,
                  "controller": str(args.residual_checkpoint), "assist": False,
                  "step_width_m": args.step_width, "approach_yaw_magnitude_rad": args.approach_yaw_rad,
                  "speed_mps": args.speed, "start_x_m": args.start_x, "failures": failures,
                  "acceptance": "both_wheels_fully_on_tread_then_one_second_stopped_grounded_upright_height_tracked",
                  "cases": [{"mode": name, "speed_mps": case_speeds[index], "success": bool(success[index]),
                             "hard_failure": bool(failed[index]), "hard_reasons": reasons[index]} for index, name in enumerate(names)],
                  "samples": samples}
        if args.demonstrations_output is not None:
            observations, teacher_actions, case_indices = (torch.cat([entry[index] for entry in demonstrations]) for index in range(3))
            successful = success.cpu()[case_indices]
            demonstration_payload = {"schema": "tita.real_isaac_successful_expert_demonstrations.v1",
                                     "observations": observations[successful], "teacher_actions": teacher_actions[successful],
                                     "case_indices": case_indices[successful], "input_artifacts": artifacts,
                                     "execution_source_provenance": source_provenance, "acceptance": result["acceptance"],
                                     "cases": result["cases"], "seed": args.seed, "height_m": args.step_height}
            args.demonstrations_output.parent.mkdir(parents=True, exist_ok=True)
            with args.demonstrations_output.open("xb") as stream:
                torch.save(demonstration_payload, stream)
            result["successful_demonstration_samples"] = int(successful.sum())
            result["demonstrations_output"] = str(args.demonstrations_output.resolve())
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2) + "\n")
        print(json.dumps(result["cases"]), flush=True)
    except Exception:
        import traceback
        traceback.print_exc()
        raise
    finally:
        env.close()
        simulation_app.close()


if __name__ == "__main__":
    main()
