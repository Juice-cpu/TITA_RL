#!/usr/bin/env python3
"""Measure frozen-controller velocity response in Isaac only, without ROS."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT))

from isaaclab.app import AppLauncher

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--asset", required=True)
parser.add_argument("--checkpoint", required=True)
parser.add_argument("--plan", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--seed", type=int, default=11)
parser.add_argument("--posture-calibration", type=Path)
parser.add_argument("--governor-calibration", type=Path)
AppLauncher.add_app_launcher_args(parser)
args = parser.parse_args()
if args.posture_calibration is not None:
    os.environ["TITA_POSTURE_CALIBRATION"] = str(args.posture_calibration.resolve())
app_launcher = AppLauncher(args)
simulation_app = app_launcher.app

import numpy as np
import omni.timeline
import omni.usd
import torch

from tita_uc_residual_rl.isaac_udp_bridge import governed_policy_command
from tita_uc_residual_rl.isaaclab_tita_env import TitaResidualEnv, build_tita_cfg
from tita_uc_residual_rl.official_policy import FrozenOfficialTitaController, OfficialTitaActor
from tita_uc_residual_rl.velocity_calibration import blend_governor_parameters, load_velocity_calibration
from tita_uc_residual_rl.motion_profile import CommandShapingConfig, PhysicsCommandShaper


def main() -> None:
    plan = json.loads(args.plan.read_text())
    cases = plan["cases"]
    totals = []
    for case in cases:
        total = 0
        for stage in case["stages"]:
            if stage["posture"] not in ("LOW", "MID", "HIGH"):
                raise ValueError("probe posture must be LOW, MID, or HIGH")
            if not 0 < stage["tail_steps"] <= stage["steps"]:
                raise ValueError("probe requires 0 < tail_steps <= steps")
            if len(stage["command"]) != 3 or not np.isfinite(stage["command"]).all():
                raise ValueError("probe command must contain three finite values")
            total += stage["steps"]
        totals.append(total)
    if not cases or len(set(totals)) != 1:
        raise ValueError("probe cases must have identical, nonzero total step counts")
    steps = totals[0]
    cfg = build_tita_cfg(args.asset, num_envs=len(cases), terrain="flat")
    cfg.seed = args.seed
    cfg.episode_length_s = steps * cfg.sim.dt * cfg.decimation + 10.0
    calibration = (load_velocity_calibration(
        args.governor_calibration, posture_joint_anchors=cfg.posture_joint_anchors,
        checkpoint_path=args.checkpoint, asset_path=args.asset,
    ) if args.governor_calibration is not None else None)
    if calibration is not None:
        for case in cases:
            for specification in case["stages"]:
                if specification.get("governor") != calibration["profiles"][specification["posture"]]:
                    raise ValueError("probe plan governor differs from explicit calibration")
    env = TitaResidualEnv(cfg)
    env.reset()
    env._defer_navigation_reset = True
    timeline = omni.timeline.get_timeline_interface()
    timeline.pause()
    timeline.commit()
    stage_usd = omni.usd.get_context().get_stage()
    end_time = steps * float(env.step_dt) + 5.0
    end_code = end_time * stage_usd.GetTimeCodesPerSecond()
    stage_usd.SetStartTimeCode(0.0)
    stage_usd.SetEndTimeCode(end_code)
    timeline.set_start_time(0.0)
    timeline.set_end_time(end_time)
    timeline.play(start_timecode=0.0, end_timecode=end_code, looping=False)
    timeline.commit()
    controller = FrozenOfficialTitaController(
        OfficialTitaActor.from_checkpoint(args.checkpoint, env.device)
    )
    controller.reset(env.num_envs, env.device)
    zero_action = torch.zeros(env.num_envs, 8, device=env.device)
    stage_indices = [0] * len(cases)
    stage_starts = [0] * len(cases)
    failures = [0] * len(cases)
    truncations = [0] * len(cases)
    samples = [[[] for _ in case["stages"]] for case in cases]
    blended_parameters = ([dict(plan["governor_profiles"]["MID"]) for _ in cases]
                          if "governor_profiles" in plan else None)
    command_shapers = [PhysicsCommandShaper(CommandShapingConfig(**case["command_shaping"]))
                       if "command_shaping" in case else None for case in cases]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    trace_path = args.output.with_suffix(".trace.jsonl")
    with trace_path.open("w") as trace:
        for step in range(steps):
            measured_before = torch.cat((env.robot.data.root_lin_vel_b[:, :2],
                                         env.robot.data.root_ang_vel_b[:, 2:3]), dim=1).tolist()
            commands = []
            postures = []
            for case_index, case in enumerate(cases):
                stage_index = stage_indices[case_index]
                current = case["stages"][stage_index]
                if step - stage_starts[case_index] >= current["steps"]:
                    stage_starts[case_index] = step
                    stage_indices[case_index] += 1
                    stage_index = stage_indices[case_index]
                    current = case["stages"][stage_index]
                desired = tuple(current["command"])
                if command_shapers[case_index] is not None:
                    desired = command_shapers[case_index].step(desired, float(env.step_dt))
                parameters = current.get("governor")
                if blended_parameters is not None:
                    parameters = blend_governor_parameters(
                        blended_parameters[case_index], parameters,
                        min(float(env.step_dt) / cfg.posture_feedforward_transition_s, 1.0),
                    )
                    blended_parameters[case_index] = parameters
                command = (governed_policy_command(
                    desired, tuple(measured_before[case_index]), **parameters
                ) if "governor" in current else desired)
                commands.append(command)
                postures.append(("LOW", "MID", "HIGH").index(current["posture"]))
            env.set_velocity_command(torch.tensor(commands, device=env.device))
            env.set_posture_command(torch.nn.functional.one_hot(
                torch.tensor(postures, device=env.device), 3
            ).float())
            target, _ = controller.target(
                env.official_proprioception(controller.previous_policy_action),
                env.default_joint_target(),
            )
            env.set_base_target(target)
            _, _, terminated, truncated, _ = env.step(zero_action)
            velocity = torch.cat((env.robot.data.root_lin_vel_b[:, :2],
                                  env.robot.data.root_ang_vel_b[:, 2:3]), dim=1).tolist()
            heights = env.posture_height.tolist()
            gravity = env.robot.data.projected_gravity_b
            tilt = torch.acos(torch.clamp(-gravity[:, 2], -1.0, 1.0)).tolist()
            roll = torch.atan2(gravity[:, 1], -gravity[:, 2]).tolist()
            pitch = torch.atan2(-gravity[:, 0], torch.sqrt(
                gravity[:, 1].square() + gravity[:, 2].square()
            )).tolist()
            positions = env.robot.data.root_pos_w.tolist()
            termination = terminated.tolist()
            truncation = truncated.tolist()
            for case_index, case in enumerate(cases):
                failures[case_index] += int(termination[case_index])
                truncations[case_index] += int(truncation[case_index])
                stage_index = stage_indices[case_index]
                current = case["stages"][stage_index]
                local_step = step - stage_starts[case_index]
                record = {
                    "step": step + 1, "time_s": (step + 1) * float(env.step_dt),
                    "case": case["name"], "stage": stage_index,
                    "stage_step": local_step + 1, "posture": current["posture"],
                    "desired_or_raw_command": current["command"],
                    "policy_command": commands[case_index],
                    "governor_parameters": (blended_parameters[case_index]
                                            if blended_parameters is not None else current.get("governor")),
                    "velocity": velocity[case_index], "height_m": heights[case_index],
                    "tilt_rad": tilt[case_index],
                    "roll_rad": roll[case_index], "pitch_rad": pitch[case_index],
                    "position_w": positions[case_index],
                    "step_energy_j": float(env.last_step_energy[case_index]),
                    "step_distance_m": float(env.last_step_distance[case_index]),
                    "valid": failures[case_index] == 0 and truncations[case_index] == 0,
                    "terminated": termination[case_index], "truncated": truncation[case_index],
                }
                trace.write(json.dumps(record, allow_nan=False) + "\n")
                if local_step >= current["steps"] - current["tail_steps"]:
                    samples[case_index][stage_index].append(record)
            if (step + 1) % 100 == 0:
                print(f"[VELOCITY PROBE] step={step + 1}/{steps} failures={failures}", flush=True)
    results = []
    for case_index, case in enumerate(cases):
        for stage_index, specification in enumerate(case["stages"]):
            records = samples[case_index][stage_index]
            velocities = np.array([record["velocity"] for record in records])
            results.append({
                "case": case["name"], "stage": stage_index, "specification": specification,
                "samples": len(records), "all_valid": all(record["valid"] for record in records),
                "velocity_mean": velocities.mean(axis=0).tolist(),
                "velocity_std": velocities.std(axis=0).tolist(),
                "velocity_min": velocities.min(axis=0).tolist(),
                "velocity_max": velocities.max(axis=0).tolist(),
                "policy_command_mean": np.mean([record["policy_command"] for record in records], axis=0).tolist(),
                "height_mean_m": float(np.mean([record["height_m"] for record in records])),
                "tilt_max_rad": max(record["tilt_rad"] for record in records),
                "roll_absmax_rad": max(abs(record["roll_rad"]) for record in records),
                "pitch_absmax_rad": max(abs(record["pitch_rad"]) for record in records),
                "termination_steps": failures[case_index],
                "truncation_steps": truncations[case_index],
            })
    report = {
        "simulation_only": True, "seed": args.seed, "step_dt": float(env.step_dt),
        "steps": steps, "num_envs": env.num_envs, "plan": str(args.plan.resolve()),
        "checkpoint_sha256": hashlib.sha256(Path(args.checkpoint).read_bytes()).hexdigest(),
        "asset_sha256": hashlib.sha256(Path(args.asset).read_bytes()).hexdigest(),
        "posture_joint_anchors": cfg.posture_joint_anchors,
        "posture_calibration_path": cfg.posture_calibration_path,
        "posture_calibration_sha256": (hashlib.sha256(args.posture_calibration.read_bytes()).hexdigest()
                                        if args.posture_calibration is not None else None),
        "governor_calibration_sha256": (hashlib.sha256(args.governor_calibration.read_bytes()).hexdigest()
                                         if args.governor_calibration is not None else None),
        "posture_feedforward_transition_s": cfg.posture_feedforward_transition_s,
        "governor_transition_blending": blended_parameters is not None,
        "results": results, "trace": str(trace_path.resolve()),
    }
    args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    env.close()


if __name__ == "__main__":
    try:
        main()
    finally:
        simulation_app.close()
