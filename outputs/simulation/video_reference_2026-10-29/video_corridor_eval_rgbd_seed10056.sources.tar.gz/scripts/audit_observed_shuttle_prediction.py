import argparse
import hashlib
import json
from pathlib import Path

from tita_uc_residual_rl.observed_shuttle_audit import audit_observed_shuttle_prediction


parser = argparse.ArgumentParser()
parser.add_argument('--report', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--require-exercised', action='store_true')
args = parser.parse_args()
content = args.report.read_bytes()
result = {'schema': 'tita.actual_observed_shuttle_prediction_audit.v1', 'report': str(args.report.resolve()),
    'report_sha256': hashlib.sha256(content).hexdigest(), **audit_observed_shuttle_prediction(json.loads(content))}
if args.require_exercised:
    result['exercised'] = (result['contexts']['forecast_contexts'] > 0
        and result['risks'].get('risk_values_changed_from_restart_only', 0) > 0)
    result['passed'] = result['passed'] and result['exercised']
with args.output.open('x') as stream:
    json.dump(result, stream, indent=2)
print(json.dumps(result, indent=2))
raise SystemExit(0 if result['passed'] else 1)
