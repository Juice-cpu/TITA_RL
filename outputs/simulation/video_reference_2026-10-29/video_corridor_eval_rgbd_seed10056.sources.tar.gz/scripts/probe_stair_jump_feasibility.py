#!/usr/bin/env python3
"""Strictly probe lead-wheel/trailing-wheel stepping on a stair."""

from __future__ import annotations

import argparse
import itertools
import json
import math
import time
import traceback
from pathlib import Path

from isaaclab.app import AppLauncher


parser = argparse.ArgumentParser()
parser.add_argument("--asset", required=True)
parser.add_argument("--checkpoint", required=True)
parser.add_argument("--residual-checkpoint", type=Path, default=None)
parser.add_argument("--residual-only", action="store_true")
parser.add_argument("--steps", type=int, default=500)
parser.add_argument("--seed", type=int, default=211)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--stair-start-x", type=float, default=0.90)
parser.add_argument("--stair-height", type=float, default=0.17)
parser.add_argument("--approach-yaw-deg", type=float, default=0.0)
parser.add_argument(
    "--lead-side", choices=("left", "right", "random"), default="random"
)
parser.add_argument("--trigger-distances", type=float, nargs="+", default=(0.08, 0.12, 0.16))
parser.add_argument("--command-speeds", type=float, nargs="+", default=(0.10, 0.20, 0.30))
parser.add_argument("--pulse-command-speeds", type=float, nargs="+", default=())
parser.add_argument("--crouch-command-speeds", type=float, nargs="+", default=())
parser.add_argument("--extension-command-speeds", type=float, nargs="+", default=())
parser.add_argument("--settle-command-speed", type=float, default=0.0)
parser.add_argument("--crouch-steps", type=int, nargs="+", default=(6, 10))
parser.add_argument("--shift-steps", type=int, nargs="+", default=(10,))
parser.add_argument("--extension-steps", type=int, nargs="+", default=(12,))
parser.add_argument("--settle-steps", type=int, nargs="+", default=(12,))
parser.add_argument("--hip-extension-delay-steps", type=int, nargs="+", default=(0,))
parser.add_argument("--knee-extension-delay-steps", type=int, nargs="+", default=(0,))
parser.add_argument("--hip-crouch-rad", type=float, nargs="+", default=(0.15,))
parser.add_argument("--hip-extension-rad", type=float, nargs="+", default=(0.30,))
parser.add_argument("--knee-crouch-rad", type=float, nargs="+", default=(0.70,))
parser.add_argument("--knee-extension-rad", type=float, nargs="+", default=(0.80,))
parser.add_argument("--support-hip-rad", type=float, nargs="+", default=(0.25,))
parser.add_argument("--support-knee-rad", type=float, nargs="+", default=(0.30,))
parser.add_argument("--wheel-drive", type=float, nargs="+", default=(0.0,))
parser.add_argument("--wheel-impulse-scale", type=float, default=1.0)
parser.add_argument("--brake-torque", type=float, nargs="+", default=(10.0,))
parser.add_argument("--lateral-shift-rad", type=float, nargs="+", default=(0.18,))
parser.add_argument("--support-lateral-scale", type=float, nargs="+", default=(0.0,))
parser.add_argument("--inward-hold-rad", type=float, nargs="+", default=(0.0,))
parser.add_argument("--summary-only", action="store_true")
parser.add_argument("--realtime", action="store_true")
parser.add_argument("--stop-after-level", action="store_true")
parser.add_argument("--stable-hold-steps", type=int, default=25)
parser.add_argument("--residual-filter-alpha", type=float, default=0.10)
parser.add_argument("--action-limit", type=float, default=1.0)
parser.add_argument("--residual-phase-gating", action="store_true")
parser.add_argument("--disable-stair-assist", action="store_true")
parser.add_argument("--lead-place-hip-residuals", type=float, nargs="+", default=(0.0,))
parser.add_argument("--lead-place-knee-residuals", type=float, nargs="+", default=(0.0,))
parser.add_argument("--support-place-hip-residuals", type=float, nargs="+", default=(0.0,))
parser.add_argument("--support-place-knee-residuals", type=float, nargs="+", default=(0.0,))
AppLauncher.add_app_launcher_args(parser)
args = parser.parse_args()
app_launcher = AppLauncher(args)
simulation_app = app_launcher.app

import torch  # noqa: E402

from tita_uc_residual_rl.isaaclab_tita_env import (  # noqa: E402
    HARD_REASON_NAMES,
    TitaResidualEnv,
    build_tita_cfg,
)
from tita_uc_residual_rl.official_policy import (  # noqa: E402
    FrozenOfficialTitaController,
    OfficialTitaActor,
)
from tita_uc_residual_rl.phase_b_learner import (  # noqa: E402
    PhaseBActorCritic,
    load_phase_b_state_dict_compatible,
)


def main() -> None:
    print("[TITA-UC][probe] building candidate grid", flush=True)
    if (
        args.steps <= 0
        or args.stable_hold_steps <= 0
        or args.stair_start_x <= 0.0
        or args.stair_height <= 0.0
        or not 0.0 <= args.approach_yaw_deg < 90.0
    ):
        raise ValueError(
            "steps, stable hold steps, stair start, and stair height must be positive; "
            "approach yaw must be in [0, 90) degrees"
        )
    if not 0.0 < args.residual_filter_alpha <= 1.0:
        raise ValueError("residual filter alpha must be in (0, 1]")
    if not 0.0 < args.action_limit <= 1.0:
        raise ValueError("action limit must be in (0, 1]")
    numeric_grids = (
        args.trigger_distances,
        args.command_speeds,
        args.hip_crouch_rad,
        args.hip_extension_rad,
        args.knee_crouch_rad,
        args.knee_extension_rad,
    )
    if any(value <= 0.0 for grid in numeric_grids for value in grid):
        raise ValueError("motion-grid distances, speeds, and amplitudes must be positive")
    phase_command_grids = (
        args.pulse_command_speeds,
        args.crouch_command_speeds,
        args.extension_command_speeds,
    )
    if any(not math.isfinite(value) for grid in phase_command_grids for value in grid):
        raise ValueError("pulse and phase command speeds must be finite")
    if not math.isfinite(args.settle_command_speed):
        raise ValueError("settle command speed must be finite")
    if any(value < 0.0 for value in args.brake_torque):
        raise ValueError("brake torque must be non-negative")
    if args.wheel_impulse_scale < 1.0 or not math.isfinite(args.wheel_impulse_scale):
        raise ValueError("wheel impulse scale must be finite and at least 1")
    if any(not 0.0 <= value <= 1.0 for value in args.support_lateral_scale):
        raise ValueError("support lateral scale must be in [0, 1]")
    if any(not math.isfinite(value) or value < 0.0 for value in args.inward_hold_rad):
        raise ValueError("inward hold must be finite and non-negative")
    residual_grids = (
        args.lead_place_hip_residuals,
        args.lead_place_knee_residuals,
        args.support_place_hip_residuals,
        args.support_place_knee_residuals,
    )
    if any(
        not math.isfinite(value) or not -1.0 <= value <= 1.0
        for grid in residual_grids
        for value in grid
    ):
        raise ValueError("place residuals must be finite and in [-1, 1]")
    if any(
        value <= 0
        for value in (
            *args.shift_steps,
            *args.crouch_steps,
            *args.extension_steps,
            *args.settle_steps,
        )
    ):
        raise ValueError("motion-grid durations must be positive")
    if any(
        value < 0
        for value in (
            *args.hip_extension_delay_steps,
            *args.knee_extension_delay_steps,
        )
    ):
        raise ValueError("extension delays must be non-negative")
    if any(
        value != 0
        for value in (
            *args.hip_extension_delay_steps,
            *args.knee_extension_delay_steps,
        )
    ):
        raise ValueError(
            "joint-specific extension delays belong to the rejected symmetric jump probe"
        )
    pulse_command_speeds = args.pulse_command_speeds or (None,)
    crouch_command_speeds = args.crouch_command_speeds or (None,)
    extension_command_speeds = args.extension_command_speeds or (None,)
    internal_assist_grids = (
        args.trigger_distances,
        args.shift_steps,
        args.crouch_steps,
        args.extension_steps,
        args.settle_steps,
        args.hip_crouch_rad,
        args.hip_extension_rad,
        args.knee_crouch_rad,
        args.knee_extension_rad,
        args.support_hip_rad,
        args.support_knee_rad,
        args.wheel_drive,
        args.brake_torque,
        args.lateral_shift_rad,
        args.support_lateral_scale,
        args.inward_hold_rad,
    )
    if any(len(grid) != 1 for grid in internal_assist_grids):
        raise ValueError(
            "the alternating environment assist uses one motion profile per run; "
            "scan command speeds here and launch separate motion-profile runs"
        )
    candidates = list(
        itertools.product(
            args.trigger_distances,
            args.command_speeds,
            args.crouch_steps,
            args.extension_steps,
            args.hip_crouch_rad,
            args.hip_extension_rad,
            args.knee_crouch_rad,
            args.knee_extension_rad,
            pulse_command_speeds,
            args.hip_extension_delay_steps,
            args.knee_extension_delay_steps,
            crouch_command_speeds,
            extension_command_speeds,
            args.lead_place_hip_residuals,
            args.lead_place_knee_residuals,
            args.support_place_hip_residuals,
            args.support_place_knee_residuals,
        )
    )
    cfg = build_tita_cfg(args.asset, num_envs=len(candidates), terrain="stairs")
    cfg.seed = args.seed
    cfg.episode_length_s = 30.0
    cfg.stair_step_height_range_m = (args.stair_height, args.stair_height)
    cfg.stair_tread_range_m = (0.32, 0.32)
    cfg.stair_width_range_m = (1.0, 1.0)
    cfg.stair_num_steps = 1
    cfg.stair_start_x_m = args.stair_start_x
    cfg.stair_landing_length_m = 0.80
    cfg.stair_handrail_enabled = True
    cfg.stair_terminate_on_success = False
    cfg.stair_step_assist_enabled = not args.disable_stair_assist
    cfg.stair_approach_yaw_rad = math.radians(args.approach_yaw_deg)
    cfg.stair_approach_lead_side = args.lead_side
    cfg.stair_step_assist_trigger_distance_m = args.trigger_distances[0]
    cfg.stair_step_assist_shift_steps = args.shift_steps[0]
    cfg.stair_step_assist_retract_steps = args.crouch_steps[0]
    cfg.stair_step_assist_place_steps = args.extension_steps[0]
    cfg.stair_step_assist_settle_steps = args.settle_steps[0]
    cfg.stair_step_assist_hip_retract_rad = args.hip_crouch_rad[0]
    cfg.stair_step_assist_hip_place_rad = args.hip_extension_rad[0]
    cfg.stair_step_assist_knee_retract_rad = args.knee_crouch_rad[0]
    cfg.stair_step_assist_knee_place_rad = args.knee_extension_rad[0]
    cfg.stair_step_assist_support_hip_rad = args.support_hip_rad[0]
    cfg.stair_step_assist_support_knee_rad = args.support_knee_rad[0]
    cfg.stair_step_assist_wheel_drive = args.wheel_drive[0]
    cfg.stair_step_assist_wheel_impulse_scale = args.wheel_impulse_scale
    cfg.stair_step_assist_event_driven = True
    cfg.stair_step_assist_drive_from_shift = True
    cfg.stair_step_assist_brake_torque = args.brake_torque[0]
    cfg.stair_step_assist_lateral_shift_rad = args.lateral_shift_rad[0]
    cfg.stair_step_assist_support_lateral_scale = args.support_lateral_scale[0]
    cfg.stair_step_assist_inward_hold_rad = args.inward_hold_rad[0]
    cfg.stair_residual_phase_gating = args.residual_phase_gating
    cfg.residual_limit = args.action_limit
    cfg.posture_scale = 1.0
    cfg.residual_filter_alpha = args.residual_filter_alpha
    cfg.enforce_acceleration_limit = True
    cfg.acceleration_limit = 500.0
    # Keep failed candidates in the same physical trajectory so an automatic
    # reset cannot be mistaken for jump height. Training still terminates on
    # these failures; this override is only for the feasibility probe.
    cfg.reset_stabilization_steps = 10000
    env = TitaResidualEnv(cfg)
    print("[TITA-UC][probe] environment constructed; resetting", flush=True)
    observation, _ = env.reset()
    print(
        f"[TITA-UC][probe] reset complete; app_running={simulation_app.is_running()}",
        flush=True,
    )
    if not args.headless:
        env.sim.set_camera_view((2.7, 2.7, 1.7), (0.6, 0.0, 0.45))

    print("[TITA-UC][probe] loading frozen official policy", flush=True)
    official = FrozenOfficialTitaController(
        OfficialTitaActor.from_checkpoint(args.checkpoint, env.device)
    )
    official.reset(env.num_envs, env.device)
    residual = None
    if args.residual_checkpoint is not None:
        payload = torch.load(
            args.residual_checkpoint.expanduser(), map_location="cpu", weights_only=True
        )
        policy_config = payload.get("policy_config", {})
        residual = PhaseBActorCritic(
            obs_dim=observation["policy"].shape[-1],
            residual_limit=float(policy_config.get("residual_limit", cfg.residual_limit)),
            posture_scale=float(policy_config.get("posture_scale", cfg.posture_scale)),
        ).to(env.device)
        load_phase_b_state_dict_compatible(residual, payload["model_state_dict"])
        residual.eval()
        print(
            f"[TITA-UC][probe] loading residual checkpoint {args.residual_checkpoint}",
            flush=True,
        )
    high = torch.nn.functional.one_hot(
        torch.full((env.num_envs,), 2, device=env.device), 3
    ).to(torch.float32)
    zero_command = torch.zeros(env.num_envs, 3, device=env.device)
    forward_command = zero_command.clone()
    forward_command[:, 0] = torch.tensor(
        [v[1] for v in candidates], device=env.device
    )
    pulse_command = zero_command.clone()
    pulse_command[:, 0] = torch.tensor(
        [v[1] if v[8] is None else v[8] for v in candidates], device=env.device
    )
    crouch_command = zero_command.clone()
    crouch_command[:, 0] = torch.tensor(
        [
            (v[1] if v[8] is None else v[8]) if v[11] is None else v[11]
            for v in candidates
        ],
        device=env.device,
    )
    extension_command = zero_command.clone()
    extension_command[:, 0] = torch.tensor(
        [
            (v[1] if v[8] is None else v[8]) if v[12] is None else v[12]
            for v in candidates
        ],
        device=env.device,
    )
    settle_command = zero_command.clone()
    settle_command[:, 0] = args.settle_command_speed
    zero_action = torch.zeros(env.num_envs, 8, device=env.device)

    print("[TITA-UC][probe] stabilizing", flush=True)
    for stabilization_step in range(150):
        if not simulation_app.is_running():
            raise RuntimeError(
                "Isaac Sim stopped during probe stabilization at "
                f"step {stabilization_step}"
            )
        env.set_velocity_command(zero_command)
        env.set_posture_command(high)
        assert official.previous_policy_action is not None
        proprioception = env.official_proprioception(official.previous_policy_action)
        target, _ = official.target(proprioception, env.default_joint_target())
        env.set_base_target(target)
        observation, _, terminated, truncated, _ = env.step(zero_action)
        official.reset_envs(terminated | truncated)

    baseline_root_z = env.robot.data.root_pos_w[:, 2].clone()
    baseline_wheel_z = env.robot.data.body_pos_w[:, env._wheel_body_ids, 2].clone()
    baseline_wheel_track = torch.abs(
        env.robot.data.body_pos_w[:, env._wheel_body_ids[0], 1]
        - env.robot.data.body_pos_w[:, env._wheel_body_ids[1], 1]
    )
    max_root_z = baseline_root_z.clone()
    max_wheel_z = baseline_wheel_z.clone()
    min_wheel_z = baseline_wheel_z.clone()
    max_wheel_local_x = torch.full(
        (env.num_envs, 2), float("-inf"), device=env.device
    )
    min_wheel_track = baseline_wheel_track.clone()
    max_wheel_track = baseline_wheel_track.clone()
    max_vertical_speed = torch.zeros(env.num_envs, device=env.device)
    max_local_x = torch.full((env.num_envs,), float("-inf"), device=env.device)
    max_verified_level = torch.zeros(env.num_envs, device=env.device)
    max_wheel_levels = torch.zeros(env.num_envs, 2, device=env.device)
    first_lead_wheel_step = torch.full(
        (env.num_envs,), -1, dtype=torch.long, device=env.device
    )
    first_trail_wheel_step = torch.full_like(first_lead_wheel_step, -1)
    termination_counts = torch.zeros(env.num_envs, dtype=torch.long, device=env.device)
    raw_collision_steps = torch.zeros(
        env.num_envs, dtype=torch.long, device=env.device
    )
    max_base_contact_force = torch.zeros(env.num_envs, device=env.device)
    first_collision_step = torch.full(
        (env.num_envs,), -1, dtype=torch.long, device=env.device
    )
    first_collision_x = torch.full((env.num_envs,), float("nan"), device=env.device)
    first_collision_z = torch.full((env.num_envs,), float("nan"), device=env.device)
    first_collision_pitch = torch.full(
        (env.num_envs,), float("nan"), device=env.device
    )
    first_collision_roll = torch.full(
        (env.num_envs,), float("nan"), device=env.device
    )
    first_collision_phase = torch.full_like(first_collision_step, -1)
    first_collision_wheel_z = torch.full(
        (env.num_envs, 2), float("nan"), device=env.device
    )
    first_collision_wheel_force = torch.full(
        (env.num_envs, 2), float("nan"), device=env.device
    )
    first_collision_wheel_track = torch.full(
        (env.num_envs,), float("nan"), device=env.device
    )
    first_collision_q_cmd = torch.full(
        (env.num_envs, 8), float("nan"), device=env.device
    )
    first_collision_q = torch.full_like(first_collision_q_cmd, float("nan"))
    first_any_wheel_step = torch.full_like(first_collision_step, -1)
    first_any_wheel_root_z = torch.full(
        (env.num_envs,), float("nan"), device=env.device
    )
    first_any_wheel_phase = torch.full_like(first_collision_step, -1)
    first_any_wheel_q = torch.full_like(first_collision_q_cmd, float("nan"))
    first_any_wheel_q_cmd = torch.full_like(first_collision_q_cmd, float("nan"))
    first_any_wheel_position = torch.full(
        (env.num_envs, 2, 3), float("nan"), device=env.device
    )
    phase_counts = torch.zeros(
        env.num_envs, 7, dtype=torch.long, device=env.device
    )
    max_abs_pitch_before_collision = torch.zeros(env.num_envs, device=env.device)
    first_trigger_step = torch.full(
        (env.num_envs,), -1, dtype=torch.long, device=env.device
    )
    first_trigger_x = torch.full((env.num_envs,), float("nan"), device=env.device)
    first_trigger_z = torch.full((env.num_envs,), float("nan"), device=env.device)
    first_trigger_q_cmd = torch.full(
        (env.num_envs, 8), float("nan"), device=env.device
    )
    first_trigger_wheel_velocity = torch.full(
        (env.num_envs, 2), float("nan"), device=env.device
    )
    first_level_step = torch.full(
        (env.num_envs,), -1, dtype=torch.long, device=env.device
    )
    first_platform_step = torch.full_like(first_level_step, -1)
    collision_steps_before_level = torch.zeros_like(raw_collision_steps)
    collision_steps_before_platform = torch.zeros_like(raw_collision_steps)
    post_level_collision_steps = torch.zeros_like(raw_collision_steps)
    stable_hold_steps = torch.zeros_like(raw_collision_steps)
    max_stable_hold_steps = torch.zeros_like(raw_collision_steps)
    max_abs_roll = torch.zeros(env.num_envs, device=env.device)
    max_abs_pitch = torch.zeros(env.num_envs, device=env.device)
    reason_counts = torch.zeros(
        env.num_envs, len(HARD_REASON_NAMES), dtype=torch.long, device=env.device
    )
    jump_step = torch.full((env.num_envs,), -1, dtype=torch.long, device=env.device)
    active = torch.ones(env.num_envs, dtype=torch.bool, device=env.device)
    trigger_distance = torch.tensor([v[0] for v in candidates], device=env.device)
    print("[TITA-UC][probe] scanning alternating-step candidates", flush=True)
    for scan_step in range(args.steps):
        if scan_step % 25 == 0:
            print(
                f"[TITA-UC][probe] scan step {scan_step}/{args.steps}; "
                f"active={int(active.sum())}",
                flush=True,
            )
        if not simulation_app.is_running():
            raise RuntimeError(
                f"Isaac Sim stopped during candidate scan at step {scan_step}"
            )
        if not active.any():
            break
        newly_triggered = active & (jump_step < 0) & (
            env._clearance <= trigger_distance
        )
        trigger_local_x = (
            env.robot.data.root_pos_w[:, 0] - env._environment_origins()[:, 0]
        )
        first_trigger_step[newly_triggered] = scan_step
        first_trigger_x[newly_triggered] = trigger_local_x[newly_triggered]
        first_trigger_z[newly_triggered] = env.robot.data.root_pos_w[
            newly_triggered, 2
        ]
        first_trigger_q_cmd[newly_triggered] = env._q_cmd[newly_triggered]
        first_trigger_wheel_velocity[newly_triggered] = env.robot.data.joint_vel[
            newly_triggered
        ][:, env._joint_ids][:, (3, 7)]
        jump_step[newly_triggered] = 0
        action = (
            zero_action.clone()
            if residual is None
            else residual.policy(observation["policy"])
        )
        retracting = active & ((env._stair_phase == 2) | (env._stair_phase == 4))
        retract_hold = retracting & (env._stair_phase_progress >= 0.999)
        retract_ramp = retracting & ~retract_hold
        placing = active & ((env._stair_phase == 3) | (env._stair_phase == 5))
        settling = active & (env._stair_phase == 6) & (
            env._stair_phase_progress < 1.0
        )
        lead_placing = active & (env._stair_phase == 3)
        lead_is_left = env._stair_lead_is_left
        lead_hip_residual = action.new_tensor([v[13] for v in candidates])
        lead_knee_residual = action.new_tensor([v[14] for v in candidates])
        support_hip_residual = action.new_tensor([v[15] for v in candidates])
        support_knee_residual = action.new_tensor([v[16] for v in candidates])
        left_lead = lead_placing & lead_is_left
        right_lead = lead_placing & ~lead_is_left
        action[left_lead, 1] += lead_hip_residual[left_lead]
        action[left_lead, 2] += lead_knee_residual[left_lead]
        action[left_lead, 5] += support_hip_residual[left_lead]
        action[left_lead, 6] += support_knee_residual[left_lead]
        action[right_lead, 5] += lead_hip_residual[right_lead]
        action[right_lead, 6] += lead_knee_residual[right_lead]
        action[right_lead, 1] += support_hip_residual[right_lead]
        action[right_lead, 2] += support_knee_residual[right_lead]
        action.clamp_(-args.action_limit, args.action_limit)
        pulsing = active & (env._stair_phase > 0)
        reached_level = first_level_step >= 0
        reached_platform = first_platform_step >= 0
        stop_reached = (
            reached_level if args.stop_after_level else torch.zeros_like(reached_level)
        )
        moving = active & ~stop_reached
        command = torch.where(moving[:, None], forward_command, zero_command)
        command = torch.where((moving & pulsing)[:, None], pulse_command, command)
        command = torch.where((moving & retract_ramp)[:, None], crouch_command, command)
        command = torch.where((moving & retract_hold)[:, None], pulse_command, command)
        command = torch.where(
            (moving & placing)[:, None], extension_command, command
        )
        command = torch.where(settling[:, None], settle_command, command)
        env.set_velocity_command(command)
        env.set_posture_command(high)
        assert official.previous_policy_action is not None
        proprioception = env.official_proprioception(official.previous_policy_action)
        target, _ = official.target(proprioception, env.default_joint_target())
        env.set_base_target(target)

        if torch.any(retracting & placing):
            raise RuntimeError("retract and place phases must not overlap")

        observation, _, terminated, truncated, _ = env.step(action)
        if args.realtime:
            time.sleep(env.step_dt)
        done = terminated | truncated
        local_x = env.robot.data.root_pos_w[:, 0] - env._environment_origins()[:, 0]
        max_local_x = torch.maximum(max_local_x, local_x)
        max_root_z = torch.maximum(max_root_z, env.robot.data.root_pos_w[:, 2])
        wheel_pos = env.robot.data.body_pos_w[:, env._wheel_body_ids]
        wheel_track = torch.abs(wheel_pos[:, 0, 1] - wheel_pos[:, 1, 1])
        min_wheel_track = torch.minimum(min_wheel_track, wheel_track)
        max_wheel_track = torch.maximum(max_wheel_track, wheel_track)
        wheel_local_x = wheel_pos[:, :, 0] - env._environment_origins()[:, None, 0]
        max_wheel_z = torch.maximum(max_wheel_z, wheel_pos[:, :, 2])
        min_wheel_z = torch.minimum(min_wheel_z, wheel_pos[:, :, 2])
        max_wheel_local_x = torch.maximum(max_wheel_local_x, wheel_local_x)
        phase_counts.scatter_add_(
            1,
            env._stair_phase[:, None].clamp(0, 6),
            torch.ones(env.num_envs, 1, dtype=torch.long, device=env.device),
        )
        max_vertical_speed = torch.maximum(
            max_vertical_speed, env.robot.data.root_lin_vel_w[:, 2]
        )
        max_verified_level = torch.maximum(max_verified_level, env._verified_stair_level())
        wheel_levels, _, _ = env._wheel_stair_state()
        max_wheel_levels = torch.maximum(max_wheel_levels, wheel_levels)
        any_wheel_newly_reached = (first_any_wheel_step < 0) & (
            wheel_levels.amax(dim=1) >= 1
        )
        first_any_wheel_step[any_wheel_newly_reached] = scan_step
        first_any_wheel_root_z[any_wheel_newly_reached] = env.robot.data.root_pos_w[
            any_wheel_newly_reached, 2
        ]
        first_any_wheel_phase[any_wheel_newly_reached] = env._stair_phase[
            any_wheel_newly_reached
        ]
        first_any_wheel_q[any_wheel_newly_reached] = env.robot.data.joint_pos[
            any_wheel_newly_reached
        ][:, env._joint_ids]
        first_any_wheel_q_cmd[any_wheel_newly_reached] = env._q_cmd[
            any_wheel_newly_reached
        ]
        first_any_wheel_position[any_wheel_newly_reached] = wheel_pos[
            any_wheel_newly_reached
        ]
        lead_level = torch.where(
            env._stair_lead_is_left, wheel_levels[:, 0], wheel_levels[:, 1]
        )
        trail_level = torch.where(
            env._stair_lead_is_left, wheel_levels[:, 1], wheel_levels[:, 0]
        )
        new_lead = (first_lead_wheel_step < 0) & (lead_level >= 1)
        new_trail = (first_trail_wheel_step < 0) & (trail_level >= 1)
        first_lead_wheel_step[new_lead] = scan_step
        first_trail_wheel_step[new_trail] = scan_step
        gravity = env.robot.data.projected_gravity_b
        roll = torch.atan2(gravity[:, 1], -gravity[:, 2])
        pitch = torch.atan2(
            -gravity[:, 0],
            torch.sqrt(torch.square(gravity[:, 1]) + torch.square(gravity[:, 2])),
        )
        max_abs_roll = torch.maximum(max_abs_roll, roll.abs())
        max_abs_pitch = torch.maximum(max_abs_pitch, pitch.abs())
        collision_not_seen = first_collision_step < 0
        max_abs_pitch_before_collision = torch.maximum(
            max_abs_pitch_before_collision,
            torch.where(collision_not_seen, pitch.abs(), torch.zeros_like(pitch)),
        )
        termination_counts += terminated.long()
        raw_collision_steps += env._collision.long()
        collision_steps_before_level += (env._collision & ~reached_level).long()
        collision_steps_before_platform += (env._collision & ~reached_platform).long()
        post_level_collision_steps += (env._collision & reached_level).long()
        just_collided = (first_collision_step < 0) & env._collision
        first_collision_step[just_collided] = scan_step
        first_collision_x[just_collided] = local_x[just_collided]
        first_collision_z[just_collided] = env.robot.data.root_pos_w[
            just_collided, 2
        ]
        first_collision_pitch[just_collided] = pitch[just_collided]
        first_collision_roll[just_collided] = roll[just_collided]
        first_collision_phase[just_collided] = env._stair_phase[just_collided]
        first_collision_wheel_z[just_collided] = wheel_pos[just_collided, :, 2]
        collision_wheel_forces = torch.linalg.vector_norm(
            env._contact_sensor.data.net_forces_w_history[
                :, :, env._wheel_contact_body_ids
            ],
            dim=-1,
        ).amax(dim=1)
        first_collision_wheel_force[just_collided] = collision_wheel_forces[
            just_collided
        ]
        first_collision_wheel_track[just_collided] = wheel_track[just_collided]
        first_collision_q_cmd[just_collided] = env._q_cmd[just_collided]
        first_collision_q[just_collided] = env.robot.data.joint_pos[just_collided][
            :, env._joint_ids
        ]
        newly_reached_level = (first_level_step < 0) & (
            env._verified_stair_level() >= 1
        )
        first_level_step[newly_reached_level] = scan_step
        platform_entry_x = cfg.stair_start_x_m + cfg.base_collision_half_length_m
        stair_end_x = (
            cfg.stair_start_x_m
            + cfg.stair_num_steps * env.stair_dimensions[:, 1]
            + cfg.stair_landing_length_m
        )
        fully_on_platform = (
            (env._verified_stair_level() >= 1)
            & (local_x >= platform_entry_x)
            & (local_x <= stair_end_x - cfg.base_collision_half_length_m)
        )
        newly_reached_platform = (first_platform_step < 0) & fully_on_platform
        first_platform_step[newly_reached_platform] = scan_step
        planar_speed = torch.linalg.vector_norm(
            env.robot.data.root_lin_vel_w[:, :2], dim=1
        )
        stable = (
            fully_on_platform
            & ~env._collision
            & (planar_speed <= 0.20)
            & (env.robot.data.root_lin_vel_w[:, 2].abs() <= 0.15)
            & (roll.abs() <= 0.25)
            & (pitch.abs() <= 0.25)
        )
        stable_hold_steps = torch.where(
            stable, stable_hold_steps + 1, torch.zeros_like(stable_hold_steps)
        )
        max_stable_hold_steps = torch.maximum(
            max_stable_hold_steps, stable_hold_steps
        )
        net_forces = env._contact_sensor.data.net_forces_w_history
        hard_contact = net_forces[:, :, env._hard_contact_body_ids]
        base_contact_force = torch.linalg.vector_norm(hard_contact, dim=-1).amax(
            dim=(1, 2)
        )
        max_base_contact_force = torch.maximum(
            max_base_contact_force, base_contact_force
        )
        reason_counts += env.hard_reason_flags.long()
        jump_step[(jump_step >= 0) & active] += 1
        active &= ~done
        official.reset_envs(done)

    print("[TITA-UC][probe] candidate scan complete; writing result", flush=True)
    final_q = env.robot.data.joint_pos[:, env._joint_ids]
    final_q_cmd = env._q_cmd
    final_gravity = env.robot.data.projected_gravity_b
    final_roll = torch.atan2(final_gravity[:, 1], -final_gravity[:, 2])
    wheel_forces = env._contact_sensor.data.net_forces_w_history[
        :, :, env._wheel_contact_body_ids
    ]
    final_wheel_force = torch.linalg.vector_norm(wheel_forces, dim=-1).amax(dim=1)
    records = []
    for index, candidate in enumerate(candidates):
        strict_success = (
            int(first_platform_step[index]) >= 0
            and int(raw_collision_steps[index]) == 0
            and int(max_stable_hold_steps[index]) >= args.stable_hold_steps
        )
        records.append(
            {
                "trigger_distance_m": candidate[0],
                "command_x_mps": candidate[1],
                "hip_crouch_rad": candidate[4],
                "hip_extension_rad": candidate[5],
                "knee_crouch_rad": candidate[6],
                "knee_extension_rad": candidate[7],
                "support_hip_rad": args.support_hip_rad[0],
                "support_knee_rad": args.support_knee_rad[0],
                "pulse_command_x_mps": (
                    candidate[1] if candidate[8] is None else candidate[8]
                ),
                "crouch_command_x_mps": (
                    (candidate[1] if candidate[8] is None else candidate[8])
                    if candidate[11] is None
                    else candidate[11]
                ),
                "extension_command_x_mps": (
                    (candidate[1] if candidate[8] is None else candidate[8])
                    if candidate[12] is None
                    else candidate[12]
                ),
                "settle_command_x_mps": args.settle_command_speed,
                "lead_place_hip_residual_rad": candidate[13],
                "lead_place_knee_residual_rad": candidate[14],
                "support_place_hip_residual_rad": candidate[15],
                "support_place_knee_residual_rad": candidate[16],
                "hip_extension_delay_steps": candidate[9],
                "knee_extension_delay_steps": candidate[10],
                "crouch_steps": candidate[2],
                "extension_steps": candidate[3],
                "settle_steps": args.settle_steps[0],
                "shift_steps": args.shift_steps[0],
                "wheel_drive": args.wheel_drive[0],
                "brake_torque_nm": args.brake_torque[0],
                "lateral_shift_rad": args.lateral_shift_rad[0],
                "support_lateral_scale": args.support_lateral_scale[0],
                "inward_hold_rad": args.inward_hold_rad[0],
                "stair_height_m": args.stair_height,
                "approach_yaw_deg": args.approach_yaw_deg,
                "configured_lead_side": args.lead_side,
                "lead_side": "left" if bool(env._stair_lead_is_left[index]) else "right",
                "baseline_root_z_m": float(baseline_root_z[index]),
                "root_rise_max_m": float(max_root_z[index] - baseline_root_z[index]),
                "wheel_axis_rise_max_m": (
                    max_wheel_z[index] - baseline_wheel_z[index]
                ).tolist(),
                "wheel_axis_drop_max_m": (
                    baseline_wheel_z[index] - min_wheel_z[index]
                ).tolist(),
                "baseline_wheel_track_m": float(baseline_wheel_track[index]),
                "minimum_wheel_track_m": float(min_wheel_track[index]),
                "maximum_wheel_track_m": float(max_wheel_track[index]),
                "wheel_local_x_max_m": max_wheel_local_x[index].tolist(),
                "vertical_speed_max_mps": float(max_vertical_speed[index]),
                "local_x_max_m": float(max_local_x[index]),
                "verified_level_max": int(max_verified_level[index]),
                "left_wheel_level_max": int(max_wheel_levels[index, 0]),
                "right_wheel_level_max": int(max_wheel_levels[index, 1]),
                "first_lead_wheel_step": int(first_lead_wheel_step[index]),
                "first_trail_wheel_step": int(first_trail_wheel_step[index]),
                "termination_count": int(termination_counts[index]),
                "raw_collision_steps": int(raw_collision_steps[index]),
                "max_base_contact_force_n": float(max_base_contact_force[index]),
                "first_collision_step": int(first_collision_step[index]),
                "first_collision_local_x_m": float(first_collision_x[index]),
                "first_collision_root_z_m": float(first_collision_z[index]),
                "first_collision_pitch_rad": float(first_collision_pitch[index]),
                "first_collision_roll_rad": float(first_collision_roll[index]),
                "first_collision_phase": int(first_collision_phase[index]),
                "first_collision_wheel_axis_z_m": first_collision_wheel_z[index].tolist(),
                "first_collision_wheel_force_n": (
                    first_collision_wheel_force[index].tolist()
                ),
                "first_collision_wheel_track_m": float(
                    first_collision_wheel_track[index]
                ),
                "first_collision_projected_target": (
                    first_collision_q_cmd[index].tolist()
                ),
                "first_collision_joint_position_rad": first_collision_q[index].tolist(),
                "first_any_wheel_step": int(first_any_wheel_step[index]),
                "first_any_wheel_root_z_m": float(first_any_wheel_root_z[index]),
                "first_any_wheel_phase": int(first_any_wheel_phase[index]),
                "first_any_wheel_position_m": first_any_wheel_position[index].tolist(),
                "first_any_wheel_joint_position_rad": first_any_wheel_q[index].tolist(),
                "first_any_wheel_projected_target": (
                    first_any_wheel_q_cmd[index].tolist()
                ),
                "phase_step_counts": phase_counts[index].tolist(),
                "final_joint_position_rad": final_q[index].tolist(),
                "final_projected_target": final_q_cmd[index].tolist(),
                "final_abs_target_error_rad": torch.abs(
                    final_q_cmd[index] - final_q[index]
                ).tolist(),
                "final_wheel_contact_force_n": final_wheel_force[index].tolist(),
                "final_roll_rad": float(final_roll[index]),
                "max_abs_pitch_before_collision_rad": float(
                    max_abs_pitch_before_collision[index]
                ),
                "first_trigger_step": int(first_trigger_step[index]),
                "first_trigger_local_x_m": float(first_trigger_x[index]),
                "first_trigger_root_z_m": float(first_trigger_z[index]),
                "first_trigger_projected_target": first_trigger_q_cmd[index].tolist(),
                "first_trigger_wheel_velocity_rad_s": (
                    first_trigger_wheel_velocity[index].tolist()
                ),
                "first_level_step": int(first_level_step[index]),
                "first_platform_step": int(first_platform_step[index]),
                "collision_steps_before_level": int(
                    collision_steps_before_level[index]
                ),
                "collision_steps_before_platform": int(
                    collision_steps_before_platform[index]
                ),
                "post_level_collision_steps": int(post_level_collision_steps[index]),
                "max_stable_hold_steps": int(max_stable_hold_steps[index]),
                "max_abs_roll_rad": float(max_abs_roll[index]),
                "max_abs_pitch_rad": float(max_abs_pitch[index]),
                "strict_success": strict_success,
                "hard_reason_counts": {
                    name: int(reason_counts[index, reason_index])
                    for reason_index, name in enumerate(HARD_REASON_NAMES)
                },
            }
        )
    result = {
        "step_height_m": args.stair_height,
        "tread_m": 0.32,
        "stair_start_x_m": cfg.stair_start_x_m,
        "platform_end_m": (
            cfg.stair_start_x_m
            + cfg.stair_num_steps * cfg.stair_tread_range_m[0]
            + cfg.stair_landing_length_m
        ),
        "required_stable_hold_steps": args.stable_hold_steps,
        "residual_filter_alpha": args.residual_filter_alpha,
        "action_limit": args.action_limit,
        "residual_phase_gating": args.residual_phase_gating,
        "candidate_count": len(records),
        "successful_candidates": sum(r["verified_level_max"] >= 1 for r in records),
        "collision_free_successful_candidates": sum(
            r["strict_success"]
            for r in records
        ),
        "maximum_root_rise_m": max(r["root_rise_max_m"] for r in records),
        "maximum_vertical_speed_mps": max(r["vertical_speed_max_mps"] for r in records),
        "records": records,
    }
    encoded = json.dumps(result, indent=2)
    if args.summary_only:
        print(json.dumps({key: value for key, value in result.items() if key != "records"}, indent=2))
    else:
        print(encoded)
    args.output.expanduser().resolve().write_text(encoded + "\n", encoding="utf-8")
    env.close()


if __name__ == "__main__":
    try:
        main()
    except BaseException:
        traceback.print_exc()
        raise
    finally:
        simulation_app.close()
