import argparse
import hashlib
import json
from pathlib import Path

from tita_uc_residual_rl.mode_motion_hold_audit import audit_mode_motion_hold


parser = argparse.ArgumentParser()
parser.add_argument('--report', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
content = args.report.read_bytes()
result = {'schema': 'tita.actual_mode_motion_hold_binding_audit.v1', 'report': str(args.report.resolve()),
    'report_sha256': hashlib.sha256(content).hexdigest(), **audit_mode_motion_hold(json.loads(content))}
with args.output.open('x') as stream:
    json.dump(result, stream, indent=2)
print(json.dumps(result, indent=2))
raise SystemExit(0 if result['passed'] else 1)
