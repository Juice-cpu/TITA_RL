#!/usr/bin/env python3
"""Independently replay an Isaac velocity trace using explicit acceptance tolerances."""

import argparse
from collections import defaultdict
import json
import math
from pathlib import Path


def audit_probe(report_path: Path, *, linear_tolerance=0.02, yaw_tolerance=0.05,
                stop_deadline_s=2.0, initialization_deadline_s=3.0) -> dict:
    report = json.loads(report_path.read_text())
    trace_path = report_path.with_suffix(".trace.jsonl")
    grouped = defaultdict(list)
    with trace_path.open() as stream:
        for line in stream:
            record = json.loads(line)
            grouped[(record["case"], record["stage"])].append(record)
    errors = []
    stages = []
    stops = []
    initializations = []
    switches = []
    for measurement in report["results"]:
        key = (measurement["case"], measurement["stage"])
        rows = grouped.pop(key, [])
        specification = measurement["specification"]
        tail_steps = specification["tail_steps"]
        if len(rows) != specification["steps"] or len(rows) < tail_steps:
            errors.append(f"{key}: missing physics samples")
            continue
        if any(row["stage_step"] != index + 1 for index, row in enumerate(rows)):
            errors.append(f"{key}: physics sequence is discontinuous")
        if any(row["posture"] != specification["posture"] or
               row["desired_or_raw_command"] != specification["command"] for row in rows):
            errors.append(f"{key}: executed posture or command identity differs from plan")
        if not all(row["valid"] for row in rows):
            errors.append(f"{key}: hard failure or truncation occurred")
        tail = rows[-tail_steps:]
        mean = [sum(row["velocity"][axis] for row in tail) / tail_steps for axis in range(3)]
        if any(not math.isfinite(value) for row in rows for value in row["velocity"]):
            errors.append(f"{key}: non-finite velocity")
        if any(abs(mean[axis] - measurement["velocity_mean"][axis]) > 1e-9 for axis in range(3)):
            errors.append(f"{key}: reported mean differs from raw trace")
        desired = specification["command"]
        forward_error = abs(mean[0] - desired[0])
        lateral_error = abs(mean[1] - desired[1])
        yaw_error = abs(mean[2] - desired[2])
        if max(forward_error, lateral_error) > linear_tolerance or yaw_error > yaw_tolerance:
            errors.append(f"{key}: steady tail-mean tracking exceeds tolerance")
        stages.append({
            "case": key[0], "stage": key[1], "posture": specification["posture"],
            "desired": desired, "tail_mean": mean, "tail_steps": tail_steps,
            "linear_mean_abs_error_mps": forward_error,
            "lateral_mean_abs_error_mps": lateral_error,
            "yaw_mean_abs_error_radps": yaw_error,
            "tail_linear_max_abs_error_mps": max(abs(row["velocity"][0] - desired[0]) for row in tail),
            "tail_yaw_max_abs_error_radps": max(abs(row["velocity"][2] - desired[2]) for row in tail),
            "height_mean_m": measurement["height_mean_m"],
            "tilt_max_rad": measurement["tilt_max_rad"],
            "roll_absmax_rad": measurement.get("roll_absmax_rad"),
            "pitch_absmax_rad": measurement.get("pitch_absmax_rad"),
        })
        if "_to_" in key[0] and key[1] == 0 and "roll_rad" in rows[-1]:
            boundary = rows[-1]
            eligible = (abs(boundary["roll_rad"]) <= 0.12
                        and abs(boundary["pitch_rad"]) <= 0.12
                        and math.hypot(*boundary["velocity"][:2]) <= 0.2)
            switches.append({"case": key[0], "physical_boundary_eligible": eligible,
                             "roll_rad": boundary["roll_rad"], "pitch_rad": boundary["pitch_rad"],
                             "scope": "physical attitude/speed only; route lock and map feasibility checked by upper mask"})
            if not eligible:
                errors.append(f"{key}: source state violates upper switching attitude/speed limits")
        if desired == [0, 0, 0]:
            settled_step = None
            for row in reversed(rows):
                if (math.hypot(*row["velocity"][:2]) > linear_tolerance or
                        abs(row["velocity"][2]) > yaw_tolerance):
                    break
                settled_step = row["stage_step"]
            settled_s = None if settled_step is None else settled_step * report["step_dt"]
            initialization = key[1] == 0
            deadline = initialization_deadline_s if initialization else stop_deadline_s
            event = "initialization" if initialization else "braking"
            if settled_s is None or settled_s > deadline:
                errors.append(f"{key}: {event} did not settle before deadline")
            collection = initializations if initialization else stops
            collection.append({
                "case": key[0], "stage": key[1], "settled_after_s": settled_s,
                "event": event, "deadline_s": deadline,
                "forward_speed_integral_m": report["step_dt"] * sum(max(0.0, row["velocity"][0]) for row in rows),
                "scope": "body-frame speed integral, not a full collision-clearance or P5 certificate",
            })
    if grouped:
        errors.append("trace contains stages missing from the summary")
    if not stages:
        errors.append("empty validation run")
    return {
        "passed": not errors, "errors": errors, "report": str(report_path.resolve()),
        "seed": report["seed"], "num_envs": report["num_envs"],
        "steps_per_env": report["steps"], "step_dt": report["step_dt"],
        "linear_tail_mean_tolerance_mps": linear_tolerance,
        "yaw_tail_mean_tolerance_radps": yaw_tolerance,
        "stop_deadline_s": stop_deadline_s,
        "initialization_deadline_s": initialization_deadline_s,
        "stages_checked": len(stages), "stops_checked": len(stops),
        "initializations_checked": len(initializations),
        "switch_boundaries_checked": len(switches), "switch_boundaries": switches,
        "max_linear_tail_mean_error_mps": max((row["linear_mean_abs_error_mps"] for row in stages), default=None),
        "max_yaw_tail_mean_error_radps": max((row["yaw_mean_abs_error_radps"] for row in stages), default=None),
        "max_lateral_tail_mean_error_mps": max((row["lateral_mean_abs_error_mps"] for row in stages), default=None),
        "max_braking_settle_s": max((row["settled_after_s"] for row in stops
                                    if row["settled_after_s"] is not None), default=None),
        "unsettled_stops": sum(row["settled_after_s"] is None for row in stops),
        "stages": stages, "stops": stops, "initializations": initializations,
        "stop_criterion": "planar body speed <= linear tolerance and absolute yaw rate <= yaw tolerance, continuously to stage end",
        "scope": "flat-ground steady tracking, stopping and posture-transition replay; not PPO convergence",
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("report", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    result = audit_probe(arguments.report)
    arguments.output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps({key: value for key, value in result.items() if key not in ("stages", "stops")}, indent=2))
    raise SystemExit(0 if result["passed"] else 1)
