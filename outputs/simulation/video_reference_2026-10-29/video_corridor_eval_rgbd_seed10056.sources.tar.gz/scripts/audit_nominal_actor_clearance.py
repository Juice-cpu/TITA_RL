import argparse
import hashlib
import json
from pathlib import Path

from tita_uc_residual_rl.navigation_acceptance_audit import verify_execution_artifacts
from tita_uc_residual_rl.nominal_clearance_audit import audit_nominal_actor_clearance


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--report', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--allow-legacy-null-rows', action='store_true')
    arguments = parser.parse_args()
    content = arguments.report.read_bytes()
    document = json.loads(content)
    artifacts = document['input_artifacts']
    geometry = json.loads(Path(artifacts['geometry_calibration']['path']).read_text())
    if 'high_geometry_calibration' in artifacts:
        geometry['profiles']['HIGH'] = json.loads(Path(artifacts['high_geometry_calibration']['path']).read_text())['profiles']['HIGH']
    result = audit_nominal_actor_clearance(document, geometry, arguments.allow_legacy_null_rows)
    result['artifact_failures'] = verify_execution_artifacts(document)
    result['passed'] = result['passed'] and not result['artifact_failures']
    result['nominally_collision_free'] = result['nominally_collision_free'] and result['passed']
    result.update(report=str(arguments.report), report_sha256=hashlib.sha256(content).hexdigest())
    with arguments.output.open('x') as stream:
        json.dump(result, stream, indent=2)
    print(json.dumps(result), flush=True)
    raise SystemExit(0 if result['passed'] else 1)


if __name__ == '__main__':
    main()
