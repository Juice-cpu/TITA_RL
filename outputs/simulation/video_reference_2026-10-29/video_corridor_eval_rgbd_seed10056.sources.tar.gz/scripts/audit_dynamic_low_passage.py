import argparse
from dataclasses import replace
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

import torch
import yaml

from tita_uc_residual_rl.dynamic_low_passage_audit import audit_dynamic_low_passage
from tita_uc_residual_rl.geometry_calibration import calibrated_posture_specs
from tita_uc_residual_rl.isaac_prior_scene import calibrated_prior_scene
from tita_uc_residual_rl.joint_ppo import JointPPOPolicy


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--report', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    arguments = parser.parse_args()
    content = arguments.report.read_bytes()
    document = json.loads(content)
    artifacts = document['input_artifacts']
    geometry = json.loads(Path(artifacts['geometry_calibration']['path']).read_text())
    if 'high_geometry_calibration' in artifacts:
        high = json.loads(Path(artifacts['high_geometry_calibration']['path']).read_text())
        geometry['profiles']['HIGH'] = high['profiles']['HIGH']
    configuration = yaml.safe_load(Path(artifacts['neupan_yaml']['path']).read_text())
    environment = SimpleNamespace(cfg=SimpleNamespace(navigation_scene_file=artifacts['navigation_scene']['path'],
        stair_enabled=False, tunnel_enabled=False), _environment_origins=lambda: torch.zeros((1, 3)))
    scene = calibrated_prior_scene(environment, (0., 0.), document['goal_xy_m'], geometry,
        planner_vertices_xy_m=configuration['robot']['vertices'],
        minimum_obstacle_clearance_m=configuration['adjust']['d_min'])
    specifications = calibrated_posture_specs(geometry)
    limits = document.get('validated_step_limits')
    if limits:
        specifications = (*specifications[:2], replace(specifications[2], max_step_m=limits['max_step_m'],
            allowed_speeds_mps=tuple(limits['speeds_mps'])))
    policy = JointPPOPolicy.load(artifacts['upper_policy']['path'])
    if document.get('upper_action_risk_cost_period_s') is not None:
        policy.configure_risk_priced_wait(document['upper_action_risk_cost_period_s'])
    result = audit_dynamic_low_passage(document, scene, specifications, policy)
    result.update(report=str(arguments.report.resolve()), report_sha256=hashlib.sha256(content).hexdigest(),
        upper_policy=artifacts['upper_policy'])
    with arguments.output.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'passed': result['passed'], 'decision_failures': result['decisions']['failures'],
        'matched_witnesses': len(result['matched_witnesses']), 'new_counterfactual_physics': False}))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
