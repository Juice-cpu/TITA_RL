import argparse
import hashlib
import json
from pathlib import Path

from tita_uc_residual_rl.sustained_motion_audit import audit_sustained_mode_motion


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--report', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--posture', choices=('LOW', 'MID', 'HIGH'), default='LOW')
    parser.add_argument('--minimum-duration-s', type=float, default=5.)
    parser.add_argument('--minimum-displacement-m', type=float, default=.5)
    arguments = parser.parse_args()
    content = arguments.report.read_bytes()
    result = audit_sustained_mode_motion(json.loads(content), arguments.posture,
        arguments.minimum_duration_s, arguments.minimum_displacement_m)
    result.update(report=str(arguments.report.resolve()), report_sha256=hashlib.sha256(content).hexdigest())
    with arguments.output.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'passed': result['passed'], 'motion_passed': result['motion']['passed'],
        'dynamic_risk_causality_proven': False, 'interval_count': len(result['motion']['intervals'])}))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
