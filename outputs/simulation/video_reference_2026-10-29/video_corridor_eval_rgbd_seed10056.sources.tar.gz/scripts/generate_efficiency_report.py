#!/usr/bin/env python3
"""Generate a Chinese PDF report from a navigation efficiency result directory."""

from __future__ import annotations

import argparse
import csv
import json
import math
from collections import defaultdict
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    Image,
    KeepTogether,
    LongTable,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


ROOT = Path(__file__).resolve().parents[1]
FONT = Path("/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc")


def load_json(path: Path):
    return json.loads(path.read_text())


def number(value, digits: int = 2, missing: str = "—") -> str:
    if value is None:
        return missing
    try:
        value = float(value)
    except (TypeError, ValueError):
        return str(value)
    if not math.isfinite(value):
        return missing
    return f"{value:.{digits}f}"


def percent(value, digits: int = 1) -> str:
    if value is None:
        return "—"
    return f"{float(value) * 100:.{digits}f}%"


def paragraph(text: str, style: ParagraphStyle) -> Paragraph:
    return Paragraph(str(text).replace("&", "&amp;"), style)


def table(data, widths, styles, header=True, font_size=7.2):
    converted = []
    for row in data:
        converted.append([cell if isinstance(cell, Paragraph) else paragraph(cell, styles["TableCN"]) for cell in row])
    table = LongTable(converted, colWidths=widths, repeatRows=1 if header else 0, hAlign="LEFT")
    commands = [
        ("FONTNAME", (0, 0), (-1, -1), "CJK"),
        ("FONTSIZE", (0, 0), (-1, -1), font_size),
        ("LEADING", (0, 0), (-1, -1), font_size + 1.5),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#cbd5e1")),
        ("LEFTPADDING", (0, 0), (-1, -1), 3),
        ("RIGHTPADDING", (0, 0), (-1, -1), 3),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]
    if header:
        commands.extend([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1f4e79")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "CJK-Bold"),
        ])
        start = 1
    else:
        start = 0
    for row_index in range(start, len(converted)):
        if (row_index - start) % 2 == 1:
            commands.append(("BACKGROUND", (0, row_index), (-1, row_index), colors.HexColor("#f8fafc")))
    table.setStyle(TableStyle(commands))
    return table


def image(path: Path, width: float, height: float):
    if not path.exists():
        return paragraph(f"图像缺失：{path}", getSampleStyleSheet()["Normal"])
    return Image(str(path), width=width, height=height)


def physical_groups(rows):
    groups = defaultdict(list)
    for row in rows:
        groups[(row["batch"], row["algorithm"])].append(row)
    return groups


def effective_frequency(row, duration_key):
    count = row.get("planner_count")
    duration = row.get(duration_key)
    if count in (None, "") or duration in (None, ""):
        return None
    return float(count) / max(float(duration), 1e-9)


def build_styles():
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="TitleCN", parent=styles["Title"], fontName="CJK-Bold", fontSize=20, leading=25, alignment=TA_CENTER, textColor=colors.HexColor("#17365d"), spaceAfter=10))
    styles.add(ParagraphStyle(name="SubtitleCN", parent=styles["Normal"], fontName="CJK", fontSize=9, leading=13, alignment=TA_CENTER, textColor=colors.HexColor("#475569"), spaceAfter=14))
    styles.add(ParagraphStyle(name="H1CN", parent=styles["Heading1"], fontName="CJK-Bold", fontSize=13, leading=17, textColor=colors.HexColor("#1f4e79"), spaceBefore=8, spaceAfter=6))
    styles.add(ParagraphStyle(name="H2CN", parent=styles["Heading2"], fontName="CJK-Bold", fontSize=10.5, leading=14, textColor=colors.HexColor("#334155"), spaceBefore=6, spaceAfter=4))
    styles.add(ParagraphStyle(name="BodyCN", parent=styles["BodyText"], fontName="CJK", fontSize=8.5, leading=13, alignment=TA_LEFT, spaceAfter=5))
    styles.add(ParagraphStyle(name="SmallCN", parent=styles["BodyText"], fontName="CJK", fontSize=7.2, leading=10, textColor=colors.HexColor("#475569"), spaceAfter=3))
    styles.add(ParagraphStyle(name="TableCN", parent=styles["BodyText"], fontName="CJK", fontSize=7.1, leading=9, alignment=TA_LEFT))
    styles.add(ParagraphStyle(name="CalloutCN", parent=styles["BodyText"], fontName="CJK-Bold", fontSize=9.3, leading=14, backColor=colors.HexColor("#eef6ff"), borderColor=colors.HexColor("#9cc2e5"), borderWidth=0.6, borderPadding=7, spaceAfter=8))
    return styles


def make_report(result: Path, output: Path):
    data = load_json(result / "summary.json")
    physical_rows = list(csv.DictReader((result / "physical_trials.csv").open()))
    for row in physical_rows:
        for key, value in list(row.items()):
            if value == "":
                row[key] = None
            elif key == "success":
                row[key] = value.lower() == "true"
            elif key not in {"batch", "algorithm"}:
                try:
                    row[key] = float(value)
                except (TypeError, ValueError):
                    pass
    styles = build_styles()
    doc = SimpleDocTemplate(
        str(output),
        pagesize=landscape(A4),
        rightMargin=13 * mm,
        leftMargin=13 * mm,
        topMargin=12 * mm,
        bottomMargin=12 * mm,
        title="TITA 静态—动态导航效率实验报告",
        author="TITA navigation benchmark",
    )
    story = []
    story.append(Paragraph("TITA 静态—动态导航效率实验报告", styles["TitleCN"]))
    story.append(Paragraph(f"生成日期：2026-10-21；结果目录：{result}", styles["SubtitleCN"]))

    policy_rows = data["policy_rows"]
    astar_rows = data["astar_rows"]
    physical_summary = data["physical_summary"]
    policy_means = {}
    for policy in sorted({row["policy"] for row in policy_rows}):
        values = [row["pipeline"]["p95_ms"] for row in policy_rows if row["policy"] == policy]
        policy_means[policy] = sum(values) / len(values)
    static = {row["algorithm"]: row for row in physical_summary if row["batch"] == "static"}
    dynamic = {row["algorithm"]: row for row in physical_summary if row["batch"] == "dynamic"}
    story.append(Paragraph(
        f"直接结论：主比较只看 RL+NeuPAN、NeuPAN 和 DCT。静态 Isaac Sim 中三种完整链路均为 10/10 到达，"
        f"RL+NeuPAN 的规划 P95 为 {number(static['rl']['planner_p95_ms'], 2)} ms，NeuPAN 为 {number(static['neupan']['planner_p95_ms'], 2)} ms，DCT 为 {number(static['dct']['planner_p95_ms'], 2)} ms。"
        f"动态突发障碍批次中三种方法均为 0/3 到达，RL 检测到确认控制平均响应 {number(dynamic['rl']['dynamic_detection_to_response_mean_ms'], 1)} ms。"
        f"RL 上层本身的补充 P95 为 {number(policy_means['PPO-reference'], 4)} ms，但不把它单独等同于完整系统速度。",
        styles["CalloutCN"],
    ))

    story.append(Paragraph("一、实验范围与口径", styles["H1CN"]))
    story.append(Paragraph("本报告把实验分为三个不混合排名的层次：上层候选动作决策本地测量、A* 重规划压力测量、已有 Isaac Sim 闭环证据。当前没有把“RL + NeuPAN”冒充新的局部规划器；局部规划器性能仍由 NeuPAN、DCT 和相同控制链路决定。", styles["BodyCN"]))
    protocol = [
        ["层次", "固定内容", "改变内容", "回答的问题"],
        ["RL 上层补充", "38 维观测接口、候选动作接口、CPU 环境", "PPO-reference", "RL 上层链路本身的时延是否低于控制周期？"],
        ["A* 压力", "起点、终点、栅格生成和障碍数量", "80/160/240/320 网格；静态或两次动态重规划", "显式路径搜索随地图规模和重规划次数如何增长？"],
        ["Isaac Sim 闭环", "场景、机器人、传感器、控制器和批次协议", "NeuPAN / DCT / RL+NeuPAN", "完整执行链的到达、能耗、轨迹和端到端实时性如何？"],
    ]
    story.append(table(protocol, [31 * mm, 70 * mm, 67 * mm, 82 * mm], styles, font_size=7.4))
    story.append(Spacer(1, 5))
    story.append(Paragraph("频率定义：上层本地测量使用 2 Hz deadline（500 ms）；局部规划使用 10 Hz deadline（100 ms）。物理闭环同时保留仿真时间频率和墙钟有效频率，二者不能混为“实时”。", styles["SmallCN"]))

    story.append(Paragraph("二、测试场景", styles["H1CN"]))
    story.append(Paragraph("Isaac Sim 使用 TITA 双分支二次绕行迷宫：起点约为 (0, 0)，目标约为 (8, 0)，包含中央主障碍、上下支路障碍和边界围墙。静态批次不引入突发障碍；动态批次在运行中注入突发障碍，观察窗口为约 40 s。地图是已知解析场景，不能当作未知环境建图实验。", styles["BodyCN"]))
    scene_table = [[
        image(ROOT / "rl_runs/navigation_benchmark/maze_v2_repeats10_equal06_20261019/maze_layout.png", 118 * mm, 82 * mm),
        image(ROOT / "rl_runs/navigation_benchmark/maze_v2_sudden_obstacle_repeats3_20261019/maze_trajectories.png", 118 * mm, 82 * mm),
    ]]
    scene = Table(scene_table, colWidths=[124 * mm, 124 * mm])
    scene.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0), ("RIGHTPADDING", (0, 0), (-1, -1), 5)]))
    story.append(scene)
    story.append(Paragraph("左：静态迷宫与 A* 预验路径；右：突发障碍批次的实际轨迹叠加。动态图中曲线在观察窗内未到达目标，这正是该批次不能用于动态成功率排名的原因。", styles["SmallCN"]))

    story.append(Paragraph("三、RL 上层补充效率", styles["H1CN"]))
    story.append(Paragraph("本节只展示 PPO-reference 的上层时延，不把其他上层策略作为主比较对象。完整逐样本测量仍保存于 JSONL，feature-update 是观测构造/特征向量更新，decision 是 RL 动作选择，pipeline 是上层测量段，不包含 Isaac Sim 启动、ROS 通信、局部规划器和物理渲染。", styles["BodyCN"]))
    policy_summary_table = [["方法", "平均 P95 pipeline (ms)", "平均 P95 decision (ms)", "平均 P95 feature (ms)", "P95 推算容量 (Hz)"]]
    for policy in ["PPO-reference"]:
        group = [row for row in policy_rows if row["policy"] == policy]
        p95 = policy_means[policy]
        policy_summary_table.append([policy, number(p95, 4), number(sum(row["decision"]["p95_ms"] for row in group) / len(group), 4), number(sum(row["feature_update"]["p95_ms"] for row in group) / len(group), 4), number(1000 / p95, 1)])
    story.append(table(policy_summary_table, [43 * mm, 42 * mm, 42 * mm, 42 * mm, 42 * mm], styles, font_size=7.6))
    story.append(Spacer(1, 4))
    policy_case_table = [["场景", "障碍数", "速度 (m/s)", "特征样本", "方法", "P95 pipeline (ms)", "P99 (ms)", "deadline 违反率"]]
    for row in sorted([item for item in policy_rows if item["policy"] == "PPO-reference"], key=lambda item: item["case"]):
        policy_case_table.append([row["case"], row["obstacle_count"], number(row["obstacle_speed_mps"], 2), row["feature_samples"], row["policy"], number(row["pipeline"]["p95_ms"], 4), number(row["pipeline"]["p99_ms"], 4), percent(row["pipeline"]["deadline_miss_rate"])])
    story.append(Paragraph("逐场景结果", styles["H2CN"]))
    story.append(table(policy_case_table, [37 * mm, 18 * mm, 25 * mm, 22 * mm, 36 * mm, 33 * mm, 30 * mm, 30 * mm], styles, font_size=6.5))
    story.append(Spacer(1, 4))
    story.append(image(result / "policy_ppo_p95.png", 214 * mm, 100 * mm))
    story.append(Paragraph("本节只说明 RL 上层本身不会占满 500 ms 的上层周期；主论文比较仍然是 RL+NeuPAN、NeuPAN 和 DCT 的完整闭环结果。", styles["SmallCN"]))

    story.append(PageBreak())
    story.append(Paragraph("四、A* 静态与动态重规划压力", styles["H1CN"]))
    story.append(Paragraph(f"共 {data['measurement_counts']['astar_raw_solves']} 次 A* 求解记录：静态网格每个样本 1 次求解，动态网格每个样本连续 2 次求解。路径成功率在这些合成栅格压力测试中均为 100%，因此该部分主要解释计算负担，不代表真实传感器失效或动态避障成功率。", styles["BodyCN"]))
    astar_table = [["场景", "静态/动态", "网格", "障碍数", "每样本重规划", "样本数", "P50 (ms)", "P95 (ms)", "P99 (ms)", "路径成功率"]]
    for row in astar_rows:
        astar_table.append([row["case"], "动态" if row["dynamic"] else "静态", row["grid_size"], row["obstacle_count"], row["replan_calls_per_sample"], row["astar"]["n"], number(row["astar"]["p50_ms"], 3), number(row["astar"]["p95_ms"], 3), number(row["astar"]["p99_ms"], 3), percent(row["path_success_rate"])])
    story.append(table(astar_table, [39 * mm, 23 * mm, 20 * mm, 20 * mm, 28 * mm, 21 * mm, 25 * mm, 25 * mm, 25 * mm, 29 * mm], styles, font_size=7.1))
    story.append(Spacer(1, 5))
    story.append(image(result / "astar_p95.png", 214 * mm, 99 * mm))
    story.append(Paragraph("A* P95 从静态 80×80 的约 3.10 ms 增长到静态 240×240 的约 55.75 ms；动态 320×320 的两次重规划单次 solve P95 约 103.81 ms。动态任务的总负担还要乘以重规划次数，不能只看单次 solve。", styles["SmallCN"]))

    story.append(Paragraph("五、Isaac Sim 静态闭环", styles["H1CN"]))
    story.append(Paragraph("静态归档批次共 30 回合，每种方法 10 回合；三种方法使用同一迷宫和控制链路协议。RL+NeuPAN 与 NeuPAN 共享 NeuPAN 局部规划器，所以这一表不能被解释为 RL 单独替代局部规划器。", styles["BodyCN"]))
    static_table = [["方法", "回合数", "到达率", "平均时间 (s)", "平均轨迹 (m)", "平均机械能 (J)", "规划 P95 (ms)", "规划器 deadline 违反率", "solve/仿真秒 (Hz)", "solve/墙钟秒 (Hz)"]]
    for name in ["dct", "neupan", "rl"]:
        row = static[name]
        group = physical_groups(physical_rows)[("static", name)]
        static_table.append([name, row["n"], percent(row["success_rate"]), number(row["mean_navigation_time_s"], 2), number(row["mean_distance_m"], 3), number(row["mean_energy_j"], 1), number(row["planner_p95_ms"], 2), percent(row["planner_deadline_miss_rate"]), number(sum(effective_frequency(x, "navigation_time_s") or 0 for x in group) / len(group), 2), number(sum(effective_frequency(x, "wall_elapsed_s") or 0 for x in group) / len(group), 2)])
    story.append(table(static_table, [26 * mm, 18 * mm, 23 * mm, 28 * mm, 28 * mm, 32 * mm, 28 * mm, 31 * mm, 32 * mm, 32 * mm], styles, font_size=6.8))
    story.append(Spacer(1, 4))
    story.append(image(result / "physical_planner_p95.png", 214 * mm, 98 * mm))
    story.append(Paragraph("这里的 solve/仿真秒是 solve 次数除以导航仿真时长；solve/墙钟秒是 solve 次数除以该回合墙钟耗时。二者分别回答仿真时间和真实机器时间上的有效频率，不能把约 10 Hz 的仿真频率误写成 10 Hz 墙钟实时。", styles["SmallCN"]))

    story.append(PageBreak())
    story.append(Paragraph("六、Isaac Sim 动态突发障碍闭环", styles["H1CN"]))
    story.append(Paragraph("动态归档批次共 9 回合，每种方法 3 回合，观察窗约 40 s。三种方法均没有在该观察窗内到达目标，但没有出现新的障碍碰撞；因此本批次只用于测量检测、规划和控制响应，不能作为动态到达率排名。", styles["BodyCN"]))
    dynamic_table = [["方法", "回合数", "到达率", "平均有效距离 (m)", "平均机械能 (J)", "规划 P95 (ms)", "上层 P95 (ms)", "动态输入 (Hz)", "检测→确认控制 (ms)", "检测→转向 (ms)"]]
    for name in ["dct", "neupan", "rl"]:
        row = dynamic[name]
        dynamic_table.append([name, row["n"], percent(row["success_rate"]), number(row["mean_distance_m"], 3), number(row["mean_energy_j"], 1), number(row["planner_p95_ms"], 2), number(row["upper_p95_ms"], 3), number(row["dynamic_input_hz_mean"], 2), number(row["dynamic_detection_to_response_mean_ms"], 1), number(row["dynamic_detection_to_turn_mean_ms"], 1)])
    story.append(table(dynamic_table, [25 * mm, 17 * mm, 22 * mm, 31 * mm, 31 * mm, 27 * mm, 27 * mm, 28 * mm, 39 * mm, 34 * mm], styles, font_size=6.9))
    story.append(Spacer(1, 5))
    dynamic_detail = [["方法", "Seed", "到达", "时间 (s)", "距离 (m)", "能量 (J)", "规划 P95 (ms)", "上层 P95 (ms)", "响应 (ms)", "planner active wall Hz"]]
    for row in physical_rows:
        if row["batch"] != "dynamic":
            continue
        dynamic_detail.append([row["algorithm"], row["seed"], "是" if row["success"] else "否", number(row["navigation_time_s"], 2), number(row["distance_m"], 3), number(row["mechanical_energy_j"], 1), number(row["planner_p95_ms"], 2), number(row["upper_p95_ms"], 3), number(row["dynamic_detection_to_response_mean_ms"], 1), number(row["planner_actual_wall_hz"], 2)])
    story.append(Paragraph("动态回合级记录", styles["H2CN"]))
    story.append(table(dynamic_detail, [27 * mm, 20 * mm, 20 * mm, 25 * mm, 25 * mm, 27 * mm, 29 * mm, 29 * mm, 31 * mm, 34 * mm], styles, font_size=7.1))
    story.append(Spacer(1, 5))
    story.append(Paragraph("动态响应结论：NeuPAN 平均约 1542.0 ms，RL+NeuPAN 约 1602.1 ms，DCT 约 2176.5 ms。这个差异来自传感器检测、ROS 调度、动态重规划、控制器执行和锁步仿真共同作用，不能归因于 PPO 前向推理本身。当前动态批次也没有在障碍出现后完整重新生成空间候选集合并交给 RL 选择，因此不能作为最终“多条 A* 路径→RL 重新选路”的证明。", styles["CalloutCN"]))

    story.append(PageBreak())
    story.append(Paragraph("七、全部 Isaac Sim 回合清单", styles["H1CN"]))
    story.append(Paragraph("下表保留本报告实际使用的 39 个归档回合；上层和 A* 的逐样本原始记录另存为 JSONL，避免 PDF 表格过度膨胀。", styles["BodyCN"]))
    trial_table = [["批次", "方法", "Seed", "到达", "时间(s)", "距离(m)", "能量(J)", "墙钟(s)", "规划 P95(ms)", "上层 P95(ms)", "planner count"]]
    for row in physical_rows:
        trial_table.append([row["batch"], row["algorithm"], row["seed"], "是" if row["success"] else "否", number(row["navigation_time_s"], 2), number(row["distance_m"], 3), number(row["mechanical_energy_j"], 1), number(row["wall_elapsed_s"], 2), number(row["planner_p95_ms"], 2), number(row["upper_p95_ms"], 3), number(row["planner_count"], 0)])
    story.append(table(trial_table, [22 * mm, 24 * mm, 20 * mm, 18 * mm, 23 * mm, 23 * mm, 25 * mm, 25 * mm, 29 * mm, 27 * mm, 25 * mm], styles, font_size=6.8))

    story.append(Paragraph("八、可发表结论与不能越界的结论", styles["H1CN"]))
    conclusions = [
        ["可以支持", "当前实验支持“RL 上层决策延迟稳定且远低于 500 ms 上层周期；静态完整导航中 RL+NeuPAN 与 NeuPAN 的主要规划开销接近；动态响应约为秒级，主要瓶颈在感知—通信—重规划—执行链路”。"],
        ["不能支持", "不能把 RL 上层前向时间直接等同于完整系统时间；不能用当前 3 回合、0/3 到达的动态批次证明动态成功率优于 NeuPAN 或 DCT；不能把 DCT 适配版直接等同于完整论文级 DCT 系统。"],
        ["下一步正式论文实验", "对每个动态种子真正执行：障碍检测→A* 重新生成候选路径集合→RL 选择 path_id 与姿态/速度方案→NeuPAN→cmd_vel，并记录每个时间戳、候选路径数、选择结果、路径长度、实际轨迹、净空、碰撞、能耗、重规划次数和恢复次数。"],
    ]
    story.append(table([["类别", "结论"]] + conclusions, [34 * mm, 218 * mm], styles, font_size=7.7))

    story.append(Paragraph("九、数据文件", styles["H1CN"]))
    files = [
        "summary.json：统一机器可读汇总、测量计数和物理回合统计。",
        "policy_samples.jsonl：28 个场景/方法的统计摘要。",
        "policy_raw_samples.jsonl：56,000 个策略逐样本原始计时和 action_id。",
        "astar_samples.jsonl：6 个 A* 配置的统计摘要。",
        "astar_raw_samples.jsonl：900 个 A* 单次求解原始计时和 path_found。",
        "physical_trials.csv：39 个 Isaac Sim 回合级字段。",
        "policy_pipeline_p95.png、astar_p95.png、physical_planner_p95.png：对应图表。",
    ]
    story.extend(Paragraph(f"• {item}", styles["BodyCN"]) for item in files)

    def footer(canvas, document):
        canvas.saveState()
        canvas.setFont("CJK", 7)
        canvas.setFillColor(colors.HexColor("#64748b"))
        canvas.drawString(13 * mm, 7 * mm, "TITA navigation efficiency benchmark — 仿真数据，不代表实机安全验收")
        canvas.drawRightString(284 * mm, 7 * mm, f"第 {document.page} 页")
        canvas.restoreState()

    doc.build(story, onFirstPage=footer, onLaterPages=footer)


def write_csv_summaries(result: Path):
    data = load_json(result / "summary.json")
    policy_rows = data["policy_rows"]
    policy_output = result / "policy_summary.csv"
    with policy_output.open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["policy", "mean_p95_pipeline_ms", "mean_p95_decision_ms", "mean_p95_feature_ms", "p95_capacity_hz"])
        for policy in ["PPO-reference"]:
            group = [row for row in policy_rows if row["policy"] == policy]
            p95 = sum(row["pipeline"]["p95_ms"] for row in group) / len(group)
            writer.writerow([policy, p95, sum(row["decision"]["p95_ms"] for row in group) / len(group), sum(row["feature_update"]["p95_ms"] for row in group) / len(group), 1000 / p95])
    diagnostic_output = result / "policy_diagnostic_summary.csv"
    with diagnostic_output.open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["policy", "mean_p95_pipeline_ms", "mean_p95_decision_ms", "mean_p95_feature_ms", "p95_capacity_hz"])
        for policy in sorted({row["policy"] for row in policy_rows}):
            group = [row for row in policy_rows if row["policy"] == policy]
            p95 = sum(row["pipeline"]["p95_ms"] for row in group) / len(group)
            writer.writerow([policy, p95, sum(row["decision"]["p95_ms"] for row in group) / len(group), sum(row["feature_update"]["p95_ms"] for row in group) / len(group), 1000 / p95])
    for name, rows in [("astar_summary.csv", data["astar_rows"]), ("physical_summary.csv", data["physical_summary"])]:
        with (result / name).open("w", newline="") as stream:
            if not rows:
                continue
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--result", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if not FONT.exists():
        raise FileNotFoundError(FONT)
    pdfmetrics.registerFont(TTFont("CJK", str(FONT)))
    pdfmetrics.registerFont(TTFont("CJK-Bold", str(FONT)))
    output = args.output or args.result / "report.pdf"
    write_csv_summaries(args.result)
    make_report(args.result, output)
    print(output.resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
