from __future__ import annotations

import argparse
import json
import traceback
from pathlib import Path

from isaaclab.app import AppLauncher

parser = argparse.ArgumentParser()
parser.add_argument("--asset", required=True)
parser.add_argument("--checkpoint", required=True)
parser.add_argument("--posture-profile", type=Path, required=True)
parser.add_argument("--velocity-calibration", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--steps", type=int, default=500)
parser.add_argument("--cpu-contact-processing", action="store_true")
parser.add_argument("--physics-device", choices=("cpu", "cuda:0"), default="cpu")
parser.add_argument("--static-only", action="store_true")
parser.add_argument("--contact-challenge", action="store_true")
parser.add_argument("--second-actor-challenge", action="store_true")
AppLauncher.add_app_launcher_args(parser)
args = parser.parse_args()
simulation_app = AppLauncher(args).app

import numpy as np
import torch

from tita_uc_residual_rl.dynamic_perception import LidarPedestrianTracker
from tita_uc_residual_rl.isaac_scene_query import PhysicsDepthSensors
from tita_uc_residual_rl.isaaclab_tita_env import TitaResidualEnv, build_tita_cfg
from tita_uc_residual_rl.isaac_udp_bridge import governed_policy_command
from tita_uc_residual_rl.official_policy import FrozenOfficialTitaController, OfficialTitaActor
from tita_uc_residual_rl.posture_calibration import load_posture_calibration, posture_anchors
from tita_uc_residual_rl.velocity_calibration import load_velocity_calibration


def main():
    if args.output.exists():
        raise ValueError("output must be new")
    cfg = build_tita_cfg(args.asset, num_envs=1, terrain="flat")
    cfg.sim.device = args.physics_device
    if args.cpu_contact_processing:
        cfg.sim.disable_contact_processing = False
    cfg.sim.enable_scene_query_support = True
    cfg.physical_pedestrian_enabled = not args.static_only
    actor_x = 0.0 if args.contact_challenge else 1.5
    cfg.physical_pedestrian_initial_xyz_m = (actor_x, -0.8, 0.9)
    if args.second_actor_challenge:
        cfg.physical_pedestrian_positions_xyz_m = ((3., 3., .9), (0., -.8, .9))
    cfg.episode_length_s = args.steps * 0.02 + 10
    cfg.posture_joint_anchors = posture_anchors(load_posture_calibration(args.posture_profile))
    calibration = load_velocity_calibration(args.velocity_calibration, posture_joint_anchors=cfg.posture_joint_anchors,
                                            checkpoint_path=args.checkpoint, asset_path=args.asset)
    env = TitaResidualEnv(cfg)
    env.reset()
    actor = FrozenOfficialTitaController(OfficialTitaActor.from_checkpoint(args.checkpoint, env.device))
    actor.reset(1, env.device)
    sensors = PhysicsDepthSensors()
    tracker = LidarPedestrianTracker()
    mount = env.robot.body_names.index("radar_link")
    samples = []
    failures = 0
    peak_pedestrian_contact = 0.0
    try:
        for step in range(args.steps):
            timestamp = step * env.step_dt
            if not args.static_only:
                env.set_physical_pedestrian_target((actor_x, -0.8 + 0.15 * timestamp, 0.9),
                                                   1 if args.second_actor_challenge else 0)
            env.set_velocity_command(torch.zeros(1, 3, device=env.device))
            env.set_posture_command(torch.tensor([[0., 1., 0.]], device=env.device))
            velocity = torch.cat((env.robot.data.root_lin_vel_b[:, :2], env.robot.data.root_ang_vel_b[:, 2:3]), 1)[0].cpu().tolist()
            proprioception = env.official_proprioception(actor.previous_policy_action)
            command = governed_policy_command((0., 0., 0.), tuple(velocity), **calibration["profiles"]["MID"])
            proprioception[:, 6:9] = proprioception.new_tensor(command) * proprioception.new_tensor([2., 2., .25])
            target, _ = actor.target(proprioception, env.default_joint_target())
            env.set_base_target(target)
            _, _, terminated, truncated, _ = env.step(torch.zeros(1, 8, device=env.device))
            failures += int(terminated[0])
            peak_pedestrian_contact = max(peak_pedestrian_contact, float(env.last_step_pedestrian_contact_force[0]))
            if terminated[0] or truncated[0]:
                break
            if step % 5 == 0:
                origin = env.robot.data.body_link_pos_w[0, mount].cpu().numpy()
                scan = sensors.lidar(origin, 0., timestamp, rays=360)
                depth = sensors.gimbal_depth(origin, 0., 0., timestamp)
                people = tracker.update(scan.points_world_m[:, :2], timestamp)
                actual = env.physical_pedestrian.data.root_pos_w[0].cpu().tolist() if not args.static_only else None
                samples.append({"step": step, "time_s": timestamp, "lidar_hits": len(scan.points_world_m),
                                "lidar_bodies": sorted(set(scan.body_paths)), "depth_hits": len(depth.points_world_m),
                                "actor_xyz_m": actual, "tracked": [vars(person) for person in people],
                                "contact_body_names": env._contact_sensor.body_names,
                                "contact_forces_w": env._contact_sensor.data.net_forces_w[0].cpu().tolist(),
                                "wheel_contacts": env._wheel_contact[0].cpu().tolist()})
        errors = [abs(sample["tracked"][0]["vy"] - .15) for sample in samples if sample["time_s"] > 3 and sample["tracked"]]
        result = {"source": "real_isaac_physx_kinematic_capsule_and_surface_rays", "hard_failures": failures,
                  "contact_challenge": args.contact_challenge, "peak_pedestrian_contact_force_n": peak_pedestrian_contact,
                  "second_actor_challenge": args.second_actor_challenge,
                  "mean_tracked_vy_error_mps_after_3s": float(np.mean(errors)) if errors else None,
                  "physical_actor_seen_scans": sum(any("Pedestrian" in path for path in sample["lidar_bodies"]) for sample in samples),
                  "tracked_scans": sum(bool(sample["tracked"]) for sample in samples), "samples": samples}
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
        print(json.dumps({key: value for key, value in result.items() if key != "samples"}), flush=True)
    except Exception:
        traceback.print_exc()
        raise
    finally:
        env.close()
        simulation_app.close()


if __name__ == "__main__":
    main()
