import argparse
import json
from pathlib import Path

from isaaclab.app import AppLauncher


parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--convex-cylinders', action='store_true')
AppLauncher.add_app_launcher_args(parser)
args = parser.parse_args()
simulation_app = AppLauncher(args).app

import isaaclab.sim as sim_utils
import carb
from omni.physx.bindings._physx import SETTING_COLLISION_APPROXIMATE_CYLINDERS
from isaaclab.assets import RigidObject, RigidObjectCfg
from isaaclab.sim import SimulationContext

from tita_uc_residual_rl.experiment_provenance import snapshot_sources


def main():
    if args.output.exists():
        raise ValueError('preserve existing physical probe')
    provenance = snapshot_sources(Path(__file__).resolve().parents[1], args.output.with_suffix('.sources.tar.gz'))
    carb.settings.get_settings().set_bool(SETTING_COLLISION_APPROXIMATE_CYLINDERS, args.convex_cylinders)
    simulation = SimulationContext(sim_utils.SimulationCfg(dt=.005, device='cpu', enable_scene_query_support=True))
    ground = sim_utils.GroundPlaneCfg()
    ground.func('/World/ground', ground)
    cases = []
    for index, surface in enumerate(('plane', 'thin_primitive_box', 'solid_primitive_box', 'thin_mesh_box', 'solid_mesh_box')):
        center_x = index * 40.
        if surface != 'plane':
            depth = .25 if 'solid' in surface else 0.
            shape = sim_utils.MeshCuboidCfg if 'mesh' in surface else sim_utils.CuboidCfg
            box = shape(size=(30., 30., .01 + depth), collision_props=sim_utils.CollisionPropertiesCfg())
            box.func(f'/World/support_{index}', box, translation=(center_x, 0., (.01 - depth) / 2.))
        for shape_name, offset in (('sphere', -1.), ('cylinder', 1.)):
            properties = {'rigid_props': sim_utils.RigidBodyPropertiesCfg(),
                          'collision_props': sim_utils.CollisionPropertiesCfg(),
                          'mass_props': sim_utils.MassPropertiesCfg(mass=1.5094)}
            shape = (sim_utils.SphereCfg(radius=.0925, **properties) if shape_name == 'sphere'
                     else sim_utils.CylinderCfg(radius=.0925, height=.034, axis='Y', **properties))
            body = RigidObject(RigidObjectCfg(prim_path=f'/World/body_{index}_{shape_name}', spawn=shape,
                                             init_state=RigidObjectCfg.InitialStateCfg(pos=(center_x, offset, .3))))
            cases.append({'surface': surface, 'shape': shape_name, 'body': body, 'positions': []})
    simulation.reset()
    for step in range(600):
        simulation.step(render=False)
        for case in cases:
            case['body'].update(.005)
            if step % 20 == 0:
                case['positions'].append(case['body'].data.root_pos_w[0].cpu().tolist())
    rows = []
    for case in cases:
        height = float(case['body'].data.root_pos_w[0, 2])
        rows.append({'surface': case['surface'], 'shape': case['shape'],
                     'final_center_world_z_m': height, 'expected_center_world_z_m': .0925 if case['surface'] == 'plane' else .1025,
                     'positions_world_m': case['positions']})
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x') as stream:
        json.dump({'scope': 'Actual Isaac CPU collision primitive diagnostic; no TITA controller or navigation acceptance',
                   'convex_cylinder_approximation': args.convex_cylinders,
                   'source_provenance': provenance, 'cases': rows}, stream, indent=2)
    print(json.dumps([{key: row[key] for key in ('surface', 'shape', 'final_center_world_z_m', 'expected_center_world_z_m')} for row in rows], indent=2))
    simulation_app.close()


if __name__ == '__main__':
    main()
