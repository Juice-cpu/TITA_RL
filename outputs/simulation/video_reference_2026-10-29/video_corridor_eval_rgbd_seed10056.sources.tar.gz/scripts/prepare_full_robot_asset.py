from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as element_tree

import numpy as np
import trimesh

from tita_uc_residual_rl.asset_check import require_official_tita_urdf


def prepare_asset(source: Path, official: Path, output: Path) -> dict:
    require_official_tita_urdf(source)
    require_official_tita_urdf(official)
    if output.exists():
        raise FileExistsError(output)
    tree = element_tree.parse(source)
    baseline = element_tree.parse(official).getroot()
    baseline_joints = {joint.get("name"): joint for joint in baseline.findall("joint") if joint.get("type") != "fixed"}
    for joint in tree.getroot().findall("joint"):
        if joint.get("name") in baseline_joints:
            previous = joint.find("limit")
            if previous is not None:
                joint.remove(previous)
            joint.append(copy.deepcopy(baseline_joints[joint.get("name")].find("limit")))
    added_collisions = []
    meshes = {}
    for link in tree.getroot().findall("link"):
        existing_collision = bool(link.findall("collision"))
        for mesh in link.findall(".//mesh"):
            path = (source.resolve().parent / mesh.get("filename")).resolve()
            meshes[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
            mesh.set("filename", str(path))
        if not existing_collision:
            for visual in link.findall("visual"):
                mesh = visual.find("geometry/mesh")
                if mesh is None:
                    raise ValueError("new conservative colliders currently require explicit mesh geometry")
                bounds = np.asarray(trimesh.load(mesh.get("filename"), force="mesh", process=False).bounds)
                scale = np.fromstring(mesh.get("scale", "1 1 1"), sep=" ")
                bounds = bounds * scale
                center = bounds.mean(axis=0)
                size = bounds[1] - bounds[0]
                origin = visual.find("origin")
                collision = element_tree.SubElement(link, "collision")
                original_translation = np.fromstring(origin.get("xyz", "0 0 0") if origin is not None else "0 0 0", sep=" ")
                rotation = origin.get("rpy", "0 0 0") if origin is not None else "0 0 0"
                from tita_uc_residual_rl.collision_envelope import _origin_matrix
                offset = original_translation + _origin_matrix(np.fromstring(rotation, sep=" ")) @ center
                element_tree.SubElement(collision, "origin", xyz=" ".join(map(str, offset)), rpy=rotation)
                geometry = element_tree.SubElement(collision, "geometry")
                element_tree.SubElement(geometry, "box", size=" ".join(map(str, size)))
                added_collisions.append(link.get("name"))
    output.parent.mkdir(parents=True, exist_ok=True)
    element_tree.indent(tree, space="  ")
    tree.write(output, encoding="utf-8", xml_declaration=True)
    require_official_tita_urdf(output)
    record = {
        "source": str(source.resolve()), "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "official_limits_source": str(official.resolve()), "output": str(output.resolve()),
        "asset_sha256": hashlib.sha256(output.read_bytes()).hexdigest(), "simulation_only": True,
        "joint_contract": "official biped eight joints, no quadruped assets",
        "added_conservative_visual_bounds_colliders": added_collisions, "mesh_sha256": meshes,
        "payload": "user-provided fixed tower mass and radar mass retained",
    }
    output.with_suffix(".manifest.json").write_text(json.dumps(record, indent=2) + "\n")
    return record


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--official", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    print(json.dumps(prepare_asset(arguments.source, arguments.official, arguments.output), indent=2))
