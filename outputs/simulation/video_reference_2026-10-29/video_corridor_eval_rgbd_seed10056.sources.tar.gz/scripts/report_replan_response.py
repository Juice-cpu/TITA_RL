#!/usr/bin/env python3
"""Extract stage-level sudden-obstacle timing from navigation traces.

The current benchmark records local response events.  The report deliberately
marks missing global A* and route-selection events instead of inferring them.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
import statistics


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_RESPONSE = ROOT / "rl_runs/navigation_benchmark/maze_v2_sudden_obstacle_report_20261019/response_summary.json"


def read_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def load_timing(trial: Path) -> list[dict]:
    rows = []
    for path in sorted((trial / "timing").glob("*.jsonl")):
        rows.extend(read_jsonl(path))
    return rows


def first(rows: list[dict], event: str, predicate=None) -> dict | None:
    candidates = [row for row in rows if row.get("event") == event and (predicate is None or predicate(row))]
    return min(candidates, key=lambda row: row.get("monotonic_ns", 0), default=None)


def milliseconds(start: int | None, end: int | None) -> float | None:
    if start is None or end is None or end < start:
        return None
    return (end - start) / 1_000_000.0


def event_times(rows: list[dict], event: str, start_ns: int | None = None, end_ns: int | None = None) -> list[int]:
    values = []
    for row in rows:
        if row.get("event") != event or not isinstance(row.get("monotonic_ns"), int):
            continue
        timestamp = row["monotonic_ns"]
        if start_ns is not None and timestamp < start_ns:
            continue
        if end_ns is not None and timestamp > end_ns:
            continue
        values.append(timestamp)
    return sorted(values)


def frequency_hz(timestamps: list[int]) -> float | None:
    if len(timestamps) < 2 or timestamps[-1] <= timestamps[0]:
        return None
    return (len(timestamps) - 1) / ((timestamps[-1] - timestamps[0]) / 1e9)


def period_statistics(timestamps: list[int]) -> dict[str, float | int | None]:
    if len(timestamps) < 2:
        return {"n": len(timestamps), "mean_period_ms": None, "p50_period_ms": None, "p95_period_ms": None, "effective_hz": None}
    periods = [(second - first) / 1e6 for first, second in zip(timestamps, timestamps[1:])]
    return {
        "n": len(timestamps),
        "mean_period_ms": statistics.fmean(periods),
        "p50_period_ms": statistics.median(periods),
        "p95_period_ms": percentile(periods, 95),
        "effective_hz": frequency_hz(timestamps),
    }


def percentile(values: list[float], q: float) -> float:
    if not values:
        return float("nan")
    values = sorted(values)
    position = (len(values) - 1) * q / 100.0
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return values[lower]
    fraction = position - lower
    return values[lower] + fraction * (values[upper] - values[lower])


def trial_algorithm_seed(trial: Path) -> tuple[str, int]:
    parts = trial.name.split("_")
    algorithm = parts[-2]
    seed = int(parts[-1].replace("seed", ""))
    return algorithm, seed


def analyze_trial(trial: Path, response_summary: dict) -> dict:
    algorithm, seed = trial_algorithm_seed(trial)
    rows = load_timing(trial)
    appearance = first(rows, "obstacle_appeared")
    detection = first(rows, "lidar_first_hit")
    appearance_ns = appearance.get("monotonic_ns") if appearance else None
    detection_ns = detection.get("monotonic_ns") if detection else None
    publications = [
        row for row in rows
        if row.get("event") == "probe_scan_published"
        and row.get("source_probe", {}).get("appeared_ns") == appearance_ns
        and row.get("source_probe", {}).get("detected_ns") == detection_ns
    ]
    publications.sort(key=lambda row: row.get("monotonic_ns", 0))
    first_scan = publications[0] if publications else None
    published_stamps = {row.get("scan_stamp_ns") for row in publications}
    planner_scan = first(rows, "planner_scan_received", lambda row: row.get("scan_stamp_ns") in published_stamps)
    planner_solve = first(rows, "planner_solve", lambda row: row.get("source_scan_stamp_ns") in published_stamps)
    solve_scan_stamp = planner_solve.get("source_scan_stamp_ns") if planner_solve else None
    solve_scan = next((row for row in publications if row.get("scan_stamp_ns") == solve_scan_stamp), None)
    solve_start = planner_solve.get("start_ns") if planner_solve else None
    solve_end = planner_solve.get("end_ns") if planner_solve else None
    applied = first(rows, "control_input_applied", lambda row: row.get("planner_source", {}).get("solve_started_ns") == solve_start)
    input_ns = applied.get("monotonic_ns") if applied else None
    response = response_summary.get("algorithms", {}).get(algorithm, {})
    response_metric = response.get("metrics_ms", {}).get("measured_response_confirmed_ms", {})
    after_detection_end = max(
        [row.get("monotonic_ns", detection_ns or 0) for row in rows if row.get("event") != "clock_identity"],
        default=detection_ns,
    )
    stage_rates = {}
    for name, event in (
        ("scan_publish", "probe_scan_published"),
        ("planner_scan_receive", "planner_scan_received"),
        ("local_planner_solve", "planner_solve"),
        ("upper_inference", "upper_inference"),
        ("upper_decision_publish", "upper_decision_published"),
        ("control_input_apply", "control_input_applied"),
    ):
        timestamps = event_times(rows, event, detection_ns, after_detection_end)
        stage_rates[name] = period_statistics(timestamps)
    future_events = {row.get("event") for row in rows}
    global_replan_present = bool({"astar_started", "astar_finished", "global_replan_started", "global_replan_finished"} & future_events)
    route_selection_present = bool({"candidate_routes_published", "route_selected", "upper_route_decision"} & future_events)
    return {
        "algorithm": algorithm,
        "seed": seed,
        "trial": str(trial),
        "global_astar_replan_events_present": global_replan_present,
        "route_selection_events_present": route_selection_present,
        "clearance_event_present": "obstacle_clearance_confirmed" in future_events,
        "appearance_to_lidar_hit_ms": milliseconds(appearance_ns, detection_ns),
        "detection_to_scan_publish_ms": milliseconds(detection_ns, solve_scan.get("monotonic_ns") if solve_scan else (first_scan.get("monotonic_ns") if first_scan else None)),
        "scan_publish_to_planner_receive_ms": milliseconds(solve_scan.get("monotonic_ns") if solve_scan else (first_scan.get("monotonic_ns") if first_scan else None), planner_scan.get("monotonic_ns") if planner_scan else None),
        "planner_scan_to_local_solve_start_ms": milliseconds(planner_scan.get("monotonic_ns") if planner_scan else None, solve_start),
        "local_planner_solve_ms": milliseconds(solve_start, solve_end),
        "local_solve_to_control_apply_ms": milliseconds(solve_end, input_ns),
        "appearance_to_first_control_apply_ms": milliseconds(appearance_ns, input_ns),
        "appearance_to_physical_response_confirmed_ms": response_metric.get("mean"),
        "appearance_to_clearance_ms": None,
        "astar_replan_ms": None,
        "rl_decision_after_replan_ms": None,
        "candidate_generation_ms": None,
        "stage_rates": stage_rates,
        "response_success_count": response.get("successes"),
        "obstacle_contact_count": response.get("contacts"),
        "minimum_clearance_m": response.get("minimum_clearance_m"),
    }


def flatten_row(row: dict) -> dict:
    output = {key: value for key, value in row.items() if key != "stage_rates"}
    for stage, metrics in row["stage_rates"].items():
        for key, value in metrics.items():
            output[f"{stage}_{key}"] = value
    return output


def write_report(output: Path, batch: Path, rows: list[dict], response_summary_path: Path) -> None:
    output.mkdir(parents=True, exist_ok=False)
    flattened = [flatten_row(row) for row in rows]
    with (output / "stage_metrics.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(flattened[0]))
        writer.writeheader()
        writer.writerows(flattened)
    (output / "stage_metrics.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2) + "\n")
    algorithms = sorted({row["algorithm"] for row in rows})
    summary = {
        "batch": str(batch.resolve()),
        "response_summary": str(response_summary_path.resolve()),
        "n_trials": len(rows),
        "algorithms": algorithms,
        "global_astar_replan_events_observed": any(row["global_astar_replan_events_present"] for row in rows),
        "route_selection_events_observed": any(row["route_selection_events_present"] for row in rows),
        "clearance_events_observed": any(row["clearance_event_present"] for row in rows),
        "interpretation": "Existing batch measures local obstacle response. It does not contain a causal global A* replan or RL route-selection event.",
    }
    (output / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
    lines = [
        "# 突发障碍阶段计时记录（现有批次审计）",
        "",
        "> 重要：本文件是对已有突发障碍批次的阶段性计时审计，不把它冒充成 A* 重新规划实验。",
        "",
        "## 1. 当前实际记录到的链路",
        "",
        "障碍出现 → LiDAR 首次命中 → 扫描发布 → 局部规划器收到扫描 → NeuPAN/DCT 局部求解 → 控制输入应用 → 物理响应确认。",
        "",
        "当前批次没有记录 `A* 开始`、`A* 完成`、`候选路径集合发布`、`RL 选择 path_id` 或 `离开障碍物确认` 事件。原因是现有 probe 配置明确把突然出现的障碍排除在 A* 先验地图和路径元数据之外，所以它测量的是局部动态响应，不是全局 A* 重规划。",
        "",
        "## 2. 当前批次的阶段结果（均值）",
        "",
        "| 方法 | 出现→LiDAR (ms) | 检测→扫描发布 (ms) | 扫描→局部求解开始 (ms) | 局部求解 (ms) | 求解→控制应用 (ms) | 出现→物理响应确认 (ms) | A* 重规划 | 路径选择事件 |",
        "|---|---:|---:|---:|---:|---:|---:|---|---|",
    ]
    for algorithm in algorithms:
        group = [row for row in rows if row["algorithm"] == algorithm]
        def avg(name):
            values = [row[name] for row in group if row[name] is not None]
            return statistics.fmean(values) if values else None
        lines.append("| {} | {} | {} | {} | {} | {} | {} | {} |".format(
            algorithm,
            fmt(avg("appearance_to_lidar_hit_ms")),
            fmt(avg("detection_to_scan_publish_ms")),
            fmt(avg("planner_scan_to_local_solve_start_ms")),
            fmt(avg("local_planner_solve_ms")),
            fmt(avg("local_solve_to_control_apply_ms")),
            fmt(avg("appearance_to_physical_response_confirmed_ms")),
            "有" if any(row["global_astar_replan_events_present"] for row in group) else "无",
            "有" if any(row["route_selection_events_present"] for row in group) else "无",
        ))
    lines.extend([
        "",
        "## 3. 正式 A*+RL 实验必须新增的事件",
        "",
        "| 阶段 | 必须记录的事件 | 关键字段 |",
        "|---|---|---|",
        "| 障碍触发 | `obstacle_appeared`、`lidar_first_hit` | `replan_id`、`obstacle_id`、`monotonic_ns`、机器人位姿 |",
        "| A* 开始 | `astar_started` | `replan_id`、`map_version`、起点/终点、触发扫描时间戳 |",
        "| A* 完成 | `astar_finished` | `replan_id`、求解耗时、候选路径数、每条路径长度和是否可行 |",
        "| 候选路径发布 | `candidate_routes_published` | `route_version`、`candidate_count`、候选路径特征 |",
        "| RL 决策 | `upper_inference`、`route_selected` | `replan_id`、输入版本、`selected_path_id`、姿态档位、速度档位、推理耗时 |",
        "| 局部规划 | `planner_scan_received`、`planner_solve` | `replan_id`、`route_version`、求解耗时、输出命令 |",
        "| 命令应用 | `cmd_vel_applied` / `control_input_applied` | `replan_id`、来源求解 ID、应用时间戳、命令值 |",
        "| 离开障碍 | `obstacle_clearance_confirmed` | 障碍物后缘、安全半径、连续确认周期、当前路径误差 |",
        "",
        "## 4. 推荐的两个总时间",
        "",
        "- **算法链路响应时间**：LiDAR 首次命中 → 新 `cmd_vel` 首次应用。这个指标最适合比较 A*、RL 和局部规划器的计算链路。",
        "- **物理恢复时间**：障碍物出现 → 连续 `K` 个控制周期满足安全净空、速度/航向已经转入新路径，并且机器人越过障碍物后缘。这个指标回答机器人什么时候真正恢复通过。",
        "同时保留障碍出现→物理恢复，用于系统级体验；但不能只报告这个总时间，因为它混合了传感器延迟、ROS 通信、A*、RL、局部规划、控制器和仿真调度。",
        "",
        "## 5. 频率怎么记录",
        "",
        "对每一段都记录事件次数、首末时间、平均周期、P50/P95 周期和有效频率：扫描发布频率、A* 重规划频率、候选路径发布频率、RL 决策频率、局部规划求解频率、`cmd_vel` 应用频率、底层控制输入频率。频率要同时给出仿真时间频率和墙钟有效频率；二者不能混写。",
        "",
        "## 6. 当前结论",
        "",
        "当前数据可以说明三种链路在突发障碍后的局部感知、局部求解和控制响应大致需要多长时间，但不能说明“加入 RL 后 A* 重规划链路增加了多少时间”。要回答这个问题，必须先让障碍进入 A* 的动态地图或动态代价层，并让 A* 真正重新生成候选路径，再让 RL 选择其中一条。",
    ])
    (output / "report.md").write_text("\n".join(lines) + "\n")


def fmt(value):
    return "—" if value is None else f"{value:.2f}"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--batch", type=Path, required=True)
    parser.add_argument("--response-summary", type=Path, default=DEFAULT_RESPONSE)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(f"output exists: {args.output}")
    response_summary = json.loads(args.response_summary.read_text())
    trials = sorted(args.batch.glob("equal_cruise_*_seed*"))
    trials = [path for path in trials if path.is_dir() and (path / "timing").exists()]
    if not trials:
        raise FileNotFoundError(f"no timing trials under {args.batch}")
    rows = [analyze_trial(trial, response_summary) for trial in trials]
    write_report(args.output, args.batch, rows, args.response_summary)
    print(json.dumps({"output": str(args.output.resolve()), "trials": len(rows)}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
