import argparse
import hashlib
import json
from pathlib import Path

from tita_uc_residual_rl.navigation_acceptance_audit import audit_navigation_execution


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--reports', nargs='+', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    records = []
    for path in args.reports:
        content = path.read_bytes()
        records.append({'report': str(path.resolve()), 'sha256': hashlib.sha256(content).hexdigest(),
                        **audit_navigation_execution(json.loads(content))})
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x') as stream:
        json.dump({'audits': records, 'all_passed': all(record['status'] == 'passed' for record in records)}, stream, indent=2)
        stream.write('\n')
    print(json.dumps([{key: record[key] for key in ('report', 'status', 'failures', 'missing_evidence')} for record in records], indent=2))


if __name__ == '__main__':
    main()
