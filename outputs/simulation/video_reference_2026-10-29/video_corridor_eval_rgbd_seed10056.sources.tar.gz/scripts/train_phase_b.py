#!/usr/bin/env python3
"""Run frozen-base Phase B residual training in Isaac Lab."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

from isaaclab.app import AppLauncher

parser = argparse.ArgumentParser()
parser.add_argument("--asset", required=True)
parser.add_argument("--checkpoint", required=True)
parser.add_argument("--run-dir", type=Path, required=True)
parser.add_argument("--num-envs", type=int, default=128)
parser.add_argument("--iterations", type=int, default=2)
parser.add_argument("--rollout-steps", type=int, default=24)
parser.add_argument("--command-x", type=float, default=0.3)
parser.add_argument("--command-wz", type=float, default=0.0)
parser.add_argument("--navigation-command-curriculum", action="store_true")
parser.add_argument("--seed", type=int, default=7)
parser.add_argument("--acceleration-limit", type=float, required=True)
parser.add_argument("--residual-filter-alpha", type=float, default=0.25)
parser.add_argument(
    "--terrain", choices=("flat", "rough_warmup", "tunnel", "stairs"), default=None
)
parser.add_argument("--domain-randomization", action="store_true")
parser.add_argument("--initial-residual-checkpoint", type=Path, default=None)
parser.add_argument("--learning-rate", type=float, default=None)
parser.add_argument("--cost-budgets", type=float, nargs=4, default=None)
parser.add_argument("--initial-cost-multipliers", type=float, nargs=4, default=None)
parser.add_argument("--minimum-cost-multipliers", type=float, nargs=4, default=None)
parser.add_argument("--dual-learning-rate", type=float, default=None)
parser.add_argument("--cost-multiplier-max", type=float, default=None)
parser.add_argument("--warmup-steps", type=int, default=None)
parser.add_argument("--checkpoint-interval", type=int, default=None)
parser.add_argument("--policy-log-std", type=float, default=None)
parser.add_argument("--freeze-policy-std", action="store_true")
parser.add_argument("--posture-curriculum", action="store_true")
parser.add_argument("--fixed-posture", choices=("LOW", "MID", "HIGH"), default=None)
AppLauncher.add_app_launcher_args(parser)
args = parser.parse_args()
app_launcher = AppLauncher(args)
simulation_app = app_launcher.app

import torch  # noqa: E402

from tita_uc_residual_rl.isaaclab_tita_env import (  # noqa: E402
    HARD_REASON_NAMES,
    TitaResidualEnv,
    build_tita_cfg,
)
from tita_uc_residual_rl.official_policy import FrozenOfficialTitaController, OfficialTitaActor  # noqa: E402
from tita_uc_residual_rl.phase_b_learner import (  # noqa: E402
    PhaseBActorCritic,
    PhaseBNP3O,
    generalized_advantage,
    load_phase_b_state_dict_compatible,
)
from tita_uc_residual_rl.posture_curriculum import (  # noqa: E402
    POSTURE_NAMES,
    PostureCommandScheduler,
    PostureCurriculumConfig,
)
from tita_uc_residual_rl.stair_curriculum import StairCurriculumConfig  # noqa: E402
from tita_uc_residual_rl.stair_step_sequence import (  # noqa: E402
    STAIR_PHASE_COUNT,
    STAIR_PHASE_SETTLE,
)
from tita_uc_residual_rl.tunnel_curriculum import TunnelCurriculumConfig  # noqa: E402
from tita_uc_residual_rl.navigation_command_curriculum import (  # noqa: E402
    NavigationCommandConfig,
    NavigationCommandCurriculum,
)
from tita_uc_residual_rl.posture_calibration import load_posture_calibration, posture_anchors
from tita_uc_residual_rl.velocity_calibration import load_velocity_calibration
from tita_uc_residual_rl.calibrated_governor import BatchedCalibratedGovernor, constrain_navigation_command
from tita_uc_residual_rl.experiment_provenance import snapshot_sources
from tita_uc_residual_rl.training_contact_contract import TrainingContactContract
from tita_uc_residual_rl.navigation_command_curriculum import hold_reset_commands


def main() -> None:
    torch.manual_seed(args.seed)
    source_root = Path(__file__).resolve().parents[1]
    source_manifest = source_root / 'execution_sources.json'
    if source_manifest.exists():
        from freeze_execution_sources import verify_execution_sources
        verify_execution_sources(source_root)
    run_dir = args.run_dir.expanduser().resolve()
    if not run_dir.is_dir() or not (run_dir / "config.json").is_file():
        raise ValueError("run-dir must be initialized by scripts/prepare_rl_run.py")
    (run_dir / "checkpoints").mkdir(exist_ok=True)
    metrics_path = run_dir / "metrics.jsonl"
    run_config = json.loads((run_dir / "config.json").read_text(encoding="utf-8"))
    args.terrain = args.terrain or run_config.get("terrain", "flat")
    if metrics_path.exists() and metrics_path.stat().st_size:
        raise ValueError("run-dir already contains training metrics; create a new run to preserve checkpoints")
    if any((run_dir / "checkpoints").glob("*.pt")):
        raise ValueError("run-dir already contains checkpoints; create a new run")
    source_provenance = snapshot_sources(Path(__file__).resolve().parents[1], run_dir / "execution_sources.tar.gz")
    (run_dir / "execution_sources.json").write_text(json.dumps(source_provenance, indent=2) + "\n")
    (run_dir / "resolved_args.json").write_text(
        json.dumps(vars(args), default=str, indent=2) + "\n", encoding="utf-8",
    )
    p95_config = run_config["objective"]["p95"]
    objective_p95 = tuple(
        float(p95_config[name]) for name in ("route", "energy", "mode", "smooth")
    )
    if any(value <= 0.0 for value in objective_p95):
        raise ValueError("all frozen objective P95 values must be positive")
    constraint_config = run_config.get("constraint_optimizer", {})
    learning_rate = float(
        args.learning_rate if args.learning_rate is not None
        else run_config.get("learning_rate", 1e-4)
    )
    cost_budgets = tuple(
        args.cost_budgets if args.cost_budgets is not None
        else constraint_config.get("cost_budgets", (0.60, 0.221, 0.266, 0.212))
    )
    initial_cost_multipliers = tuple(
        args.initial_cost_multipliers if args.initial_cost_multipliers is not None
        else constraint_config.get(
            "initial_cost_multipliers",
            (
                run_config["objective"]["route_weight"],
                run_config["objective"]["energy_weight"],
                run_config["objective"]["mode_weight"],
                run_config["objective"]["smooth_weight"],
            ),
        )
    )
    minimum_cost_multipliers = tuple(
        args.minimum_cost_multipliers if args.minimum_cost_multipliers is not None
        else constraint_config.get("minimum_cost_multipliers", initial_cost_multipliers)
    )
    dual_learning_rate = float(
        args.dual_learning_rate if args.dual_learning_rate is not None
        else constraint_config.get("dual_learning_rate", 0.01)
    )
    cost_multiplier_max = float(
        args.cost_multiplier_max if args.cost_multiplier_max is not None
        else constraint_config.get("cost_multiplier_max", 2.0)
    )
    warmup_steps = int(
        args.warmup_steps if args.warmup_steps is not None
        else constraint_config.get("warmup_steps", 50)
    )
    checkpoint_interval = int(
        args.checkpoint_interval if args.checkpoint_interval is not None
        else constraint_config.get("checkpoint_interval", 5)
    )
    if warmup_steps < 0 or checkpoint_interval <= 0:
        raise ValueError("warmup steps must be non-negative and checkpoint interval positive")

    cfg = build_tita_cfg(
        args.asset,
        num_envs=args.num_envs,
        terrain=args.terrain,
        domain_randomization=args.domain_randomization,
    )
    cfg.seed = args.seed
    if run_config.get('training_physics_device') is not None:
        if run_config['training_physics_device'] not in ('cpu', 'cuda:0'):
            raise ValueError('training physics device must be cpu or cuda:0')
        cfg.sim.device = run_config['training_physics_device']
    cfg.sim.disable_contact_processing = False
    cfg.convex_cylinder_collisions = bool(run_config.get("convex_cylinder_collisions", False))
    cfg.navigation_pose_observations = bool(run_config.get("navigation_pose_observations", False))
    if run_config.get("posture_profile"):
        profile = load_posture_calibration(run_config["posture_profile"])
        cfg.posture_joint_anchors = posture_anchors(profile)
        cfg.posture_heights = tuple(profile["profiles"][name]["command_height_m"] for name in POSTURE_NAMES)
    governor_prior = None
    if run_config.get("velocity_calibration_prior"):
        governor_prior = load_velocity_calibration(
            run_config["velocity_calibration_prior"], posture_joint_anchors=cfg.posture_joint_anchors,
            checkpoint_path=args.checkpoint, asset_path=args.asset,
        )
    cfg.episode_length_s = float(run_config.get("episode_length_s", cfg.episode_length_s))
    if cfg.episode_length_s <= 0.0:
        raise ValueError("episode length must be positive")
    cfg.acceleration_limit = args.acceleration_limit
    cfg.residual_filter_alpha = args.residual_filter_alpha
    cfg.residual_limit = float(run_config.get("residual_limit", cfg.residual_limit))
    cfg.posture_scale = float(run_config.get("posture_scale", cfg.posture_scale))
    if cfg.residual_limit <= 0.0 or cfg.posture_scale <= 0.0:
        raise ValueError("residual limit and posture scale must be positive")
    cfg.enforce_acceleration_limit = True
    cfg.objective_p95 = objective_p95
    cfg.normalized_cost_clip = float(run_config.get("normalized_cost_clip", float("inf")))
    if cfg.normalized_cost_clip <= 0.0:
        raise ValueError("normalized cost clip must be positive")
    reward_config = run_config.get("reward", {})
    for name in ("navigation_linear_tracking_penalty", "navigation_yaw_tracking_penalty", "navigation_tilt_penalty", "navigation_lateral_deviation_penalty", "navigation_posture_height_penalty",
                 "navigation_stationary_hold_reward_scale", "navigation_stationary_interruption_penalty"):
        weight = float(reward_config.get(name, 0.0))
        if not math.isfinite(weight) or weight < 0:
            raise ValueError(f"{name} must be finite and non-negative")
        setattr(cfg, name, weight)
    for name in (
        "route_length_weight",
        "route_clearance_weight",
        "route_curvature_weight",
        "dynamic_obstacle_risk_weight",
        "mode_height_rate_weight",
        "mode_hold_weight",
        "mode_switch_cost_weight",
        "rapid_mode_switch_cost_weight",
        "rapid_mode_switch_window_s",
    ):
        if name in reward_config:
            setattr(cfg, name, float(reward_config[name]))
    if any(
        getattr(cfg, name) < 0.0
        for name in (
            "route_length_weight",
            "route_clearance_weight",
            "route_curvature_weight",
            "dynamic_obstacle_risk_weight",
            "mode_height_rate_weight",
            "mode_hold_weight",
            "mode_switch_cost_weight",
            "rapid_mode_switch_cost_weight",
        )
    ) or cfg.rapid_mode_switch_window_s <= 0.0:
        raise ValueError("reward weights must be non-negative and switch window positive")
    tunnel_config = run_config.get("tunnel_curriculum", {})
    if args.terrain == "tunnel":
        validated_tunnel = TunnelCurriculumConfig(
            height_range_m=tuple(tunnel_config.get("net_height_range_m", (0.34, 0.44))),
            width_range_m=tuple(tunnel_config.get("net_width_range_m", (0.40, 0.65))),
            length_range_m=tuple(tunnel_config.get("length_range_m", (0.60, 1.50))),
            start_x_m=float(tunnel_config.get("start_x_m", 0.75)),
            wall_thickness_m=float(tunnel_config.get("wall_thickness_m", 0.10)),
        )
        cfg.tunnel_height_range_m = validated_tunnel.height_range_m
        cfg.tunnel_width_range_m = validated_tunnel.width_range_m
        cfg.tunnel_length_range_m = validated_tunnel.length_range_m
        cfg.tunnel_start_x_m = validated_tunnel.start_x_m
        cfg.tunnel_wall_thickness_m = validated_tunnel.wall_thickness_m
        cfg.tunnel_preview_distance_m = float(
            tunnel_config.get("preview_distance_m", cfg.tunnel_preview_distance_m)
        )
        cfg.tunnel_clearance_buffer_m = float(
            tunnel_config.get("clearance_buffer_m", cfg.tunnel_clearance_buffer_m)
        )
        cfg.tunnel_success_reward = float(
            tunnel_config.get("success_reward", cfg.tunnel_success_reward)
        )
        if cfg.tunnel_success_reward < 0.0:
            raise ValueError("tunnel success reward must be non-negative")
        cfg.scene.env_spacing = max(
            cfg.scene.env_spacing,
            validated_tunnel.start_x_m + validated_tunnel.length_range_m[1] + 2.0,
        )
    stair_config = run_config.get("stair_curriculum", {})
    cfg.stair_support_augmentation_enabled = bool(stair_config.get("support_augmentation_enabled", False))
    cfg.stair_support_augmentation_offset_m = float(stair_config.get("support_augmentation_offset_m", 12.))
    cfg.stair_success_stable_hold_s = float(stair_config.get("success_stable_hold_s", 0.))
    if not math.isfinite(cfg.stair_success_stable_hold_s) or cfg.stair_success_stable_hold_s < 0.:
        raise ValueError("stair success hold must be finite and nonnegative")
    stair_phase_command_scales = {
        1: float(stair_config.get("step_assist_shift_command_scale", 1.0)),
        2: float(stair_config.get("step_assist_retract_command_scale", 1.0)),
        3: float(stair_config.get("step_assist_place_command_scale", 1.0)),
        4: float(stair_config.get("step_assist_retract_command_scale", 1.0)),
        5: float(stair_config.get("step_assist_place_command_scale", 1.0)),
        6: float(stair_config.get("step_assist_settle_command_scale", 1.0)),
    }
    if any(not -1.0 <= scale <= 1.0 for scale in stair_phase_command_scales.values()):
        raise ValueError("stair phase command scales must be in [-1, 1]")
    if args.terrain == "stairs":
        validated_stairs = StairCurriculumConfig(
            step_height_range_m=tuple(
                stair_config.get("step_height_range_m", (0.025, 0.045))
            ),
            tread_range_m=tuple(stair_config.get("tread_range_m", (0.55, 0.67))),
            width_range_m=tuple(stair_config.get("width_range_m", (0.90, 1.20))),
            num_steps=int(stair_config.get("num_steps", 3)),
            start_x_m=float(stair_config.get("start_x_m", 0.75)),
            landing_length_m=float(stair_config.get("landing_length_m", 0.80)),
        )
        cfg.stair_step_height_range_m = validated_stairs.step_height_range_m
        cfg.stair_tread_range_m = validated_stairs.tread_range_m
        cfg.stair_width_range_m = validated_stairs.width_range_m
        cfg.stair_num_steps = validated_stairs.num_steps
        cfg.stair_start_x_m = validated_stairs.start_x_m
        cfg.stair_landing_length_m = validated_stairs.landing_length_m
        cfg.stair_handrail_enabled = bool(stair_config.get("handrail_enabled", False))
        cfg.stair_training_corridor_enabled = bool(stair_config.get("training_corridor_enabled", False))
        cfg.stair_handrail_height_m = float(
            stair_config.get("handrail_height_m", cfg.stair_handrail_height_m)
        )
        cfg.stair_handrail_thickness_m = float(
            stair_config.get("handrail_thickness_m", cfg.stair_handrail_thickness_m)
        )
        cfg.stair_handrail_side_offset_m = float(
            stair_config.get("handrail_side_offset_m", cfg.stair_handrail_side_offset_m)
        )
        cfg.stair_handrail_post_spacing_m = float(
            stair_config.get("handrail_post_spacing_m", cfg.stair_handrail_post_spacing_m)
        )
        cfg.stair_handrail_follow_slope = bool(
            stair_config.get("handrail_follow_slope", cfg.stair_handrail_follow_slope)
        )
        if (
            cfg.stair_handrail_enabled
            and (
                cfg.stair_handrail_height_m <= 0.0
                or cfg.stair_handrail_thickness_m <= 0.0
                or cfg.stair_handrail_side_offset_m < 0.0
                or cfg.stair_handrail_post_spacing_m <= 0.0
            )
        ):
            raise ValueError("stair handrail dimensions must be positive")
        cfg.stair_preview_distance_m = float(
            stair_config.get("preview_distance_m", cfg.stair_preview_distance_m)
        )
        cfg.stair_success_reward = float(
            stair_config.get("success_reward", cfg.stair_success_reward)
        )
        cfg.stair_height_progress_reward_scale = float(
            stair_config.get(
                "height_progress_reward_scale", cfg.stair_height_progress_reward_scale
            )
        )
        cfg.stair_step_progress_reward = float(
            stair_config.get("step_progress_reward", cfg.stair_step_progress_reward)
        )
        cfg.stair_level_hold_reward_scale = float(
            stair_config.get(
                "level_hold_reward_scale", cfg.stair_level_hold_reward_scale
            )
        )
        cfg.stair_stable_hold_reward_scale = float(
            stair_config.get(
                "stable_hold_reward_scale", cfg.stair_stable_hold_reward_scale
            )
        )
        cfg.stair_approach_lift_reward_scale = float(
            stair_config.get(
                "approach_lift_reward_scale", cfg.stair_approach_lift_reward_scale
            )
        )
        cfg.stair_approach_lift_distance_m = float(
            stair_config.get(
                "approach_lift_distance_m", cfg.stair_approach_lift_distance_m
            )
        )
        cfg.stair_collision_penalty = float(
            stair_config.get("collision_penalty", cfg.stair_collision_penalty)
        )
        cfg.stair_collision_terminates = bool(
            stair_config.get("collision_terminates", cfg.stair_collision_terminates)
        )
        cfg.stair_terminate_on_success = bool(
            stair_config.get("terminate_on_success", cfg.stair_terminate_on_success)
        )
        cfg.stair_step_assist_enabled = bool(
            stair_config.get(
                "step_assist_enabled", stair_config.get("jump_assist_enabled", False)
            )
        )
        cfg.stair_approach_yaw_rad = float(
            stair_config.get("approach_yaw_rad", cfg.stair_approach_yaw_rad)
        )
        cfg.stair_approach_lead_side = str(
            stair_config.get(
                "approach_lead_side", cfg.stair_approach_lead_side
            )
        )
        cfg.stair_step_assist_trigger_distance_m = float(
            stair_config.get(
                "step_assist_trigger_distance_m",
                stair_config.get(
                    "jump_assist_trigger_distance_m",
                    cfg.stair_step_assist_trigger_distance_m,
                ),
            )
        )
        cfg.stair_step_assist_retract_steps = int(
            stair_config.get(
                "step_assist_retract_steps",
                stair_config.get(
                    "jump_assist_crouch_steps", cfg.stair_step_assist_retract_steps
                ),
            )
        )
        cfg.stair_step_assist_shift_steps = int(
            stair_config.get(
                "step_assist_shift_steps", cfg.stair_step_assist_shift_steps
            )
        )
        cfg.stair_step_assist_place_steps = int(
            stair_config.get(
                "step_assist_place_steps",
                stair_config.get(
                    "jump_assist_extension_steps", cfg.stair_step_assist_place_steps
                ),
            )
        )
        cfg.stair_step_assist_settle_steps = int(
            stair_config.get(
                "step_assist_settle_steps", cfg.stair_step_assist_settle_steps
            )
        )
        cfg.stair_step_assist_hip_retract_rad = float(
            stair_config.get(
                "step_assist_hip_retract_rad",
                stair_config.get(
                    "jump_assist_hip_crouch_rad",
                    cfg.stair_step_assist_hip_retract_rad,
                ),
            )
        )
        cfg.stair_step_assist_hip_place_rad = float(
            stair_config.get(
                "step_assist_hip_place_rad",
                stair_config.get(
                    "jump_assist_hip_extension_rad",
                    cfg.stair_step_assist_hip_place_rad,
                ),
            )
        )
        cfg.stair_step_assist_knee_retract_rad = float(
            stair_config.get(
                "step_assist_knee_retract_rad",
                stair_config.get(
                    "jump_assist_knee_crouch_rad",
                    cfg.stair_step_assist_knee_retract_rad,
                ),
            )
        )
        cfg.stair_step_assist_knee_place_rad = float(
            stair_config.get(
                "step_assist_knee_place_rad",
                stair_config.get(
                    "jump_assist_knee_extension_rad",
                    cfg.stair_step_assist_knee_place_rad,
                ),
            )
        )
        cfg.stair_step_assist_support_hip_rad = float(
            stair_config.get(
                "step_assist_support_hip_rad",
                cfg.stair_step_assist_support_hip_rad,
            )
        )
        cfg.stair_step_assist_support_knee_rad = float(
            stair_config.get(
                "step_assist_support_knee_rad",
                cfg.stair_step_assist_support_knee_rad,
            )
        )
        cfg.stair_step_assist_wheel_drive = float(
            stair_config.get(
                "step_assist_wheel_drive", cfg.stair_step_assist_wheel_drive
            )
        )
        cfg.stair_step_assist_wheel_impulse_scale = float(
            stair_config.get(
                "step_assist_wheel_impulse_scale",
                cfg.stair_step_assist_wheel_impulse_scale,
            )
        )
        cfg.stair_step_assist_event_driven = bool(
            stair_config.get(
                "step_assist_event_driven", cfg.stair_step_assist_event_driven
            )
        )
        cfg.stair_step_assist_drive_from_shift = bool(
            stair_config.get(
                "step_assist_drive_from_shift",
                cfg.stair_step_assist_drive_from_shift,
            )
        )
        cfg.stair_step_assist_brake_torque = float(
            stair_config.get(
                "step_assist_brake_torque_nm",
                cfg.stair_step_assist_brake_torque,
            )
        )
        cfg.stair_step_assist_lateral_shift_rad = float(
            stair_config.get(
                "step_assist_lateral_shift_rad",
                cfg.stair_step_assist_lateral_shift_rad,
            )
        )
        cfg.stair_step_assist_support_lateral_scale = float(
            stair_config.get(
                "step_assist_support_lateral_scale",
                cfg.stair_step_assist_support_lateral_scale,
            )
        )
        cfg.stair_step_assist_inward_hold_rad = float(
            stair_config.get(
                "step_assist_inward_hold_rad",
                cfg.stair_step_assist_inward_hold_rad,
            )
        )
        cfg.stair_residual_phase_gating = bool(
            stair_config.get(
                "residual_phase_gating", cfg.stair_residual_phase_gating
            )
        )
        cfg.stair_lead_place_hip_residual = float(
            stair_config.get("lead_place_hip_residual_rad", 0.0)
        )
        cfg.stair_lead_place_knee_residual = float(
            stair_config.get("lead_place_knee_residual_rad", 0.0)
        )
        cfg.stair_support_place_hip_residual = float(
            stair_config.get("support_place_hip_residual_rad", 0.0)
        )
        cfg.stair_support_place_knee_residual = float(
            stair_config.get("support_place_knee_residual_rad", 0.0)
        )
        cfg.stair_lead_wheel_reward = float(
            stair_config.get("lead_wheel_reward", cfg.stair_lead_wheel_reward)
        )
        cfg.stair_trail_wheel_reward = float(
            stair_config.get("trail_wheel_reward", cfg.stair_trail_wheel_reward)
        )
        cfg.stair_lead_lift_progress_reward = float(
            stair_config.get(
                "lead_lift_progress_reward",
                cfg.stair_lead_lift_progress_reward,
            )
        )
        cfg.stair_lead_unload_reward = float(
            stair_config.get(
                "lead_unload_reward", cfg.stair_lead_unload_reward
            )
        )
        cfg.stair_rolling_contact_reward_scale = float(
            stair_config.get(
                "rolling_contact_reward_scale",
                cfg.stair_rolling_contact_reward_scale,
            )
        )
        cfg.stair_single_wheel_lag_penalty = float(
            stair_config.get(
                "single_wheel_lag_penalty", cfg.stair_single_wheel_lag_penalty
            )
        )
        cfg.stair_single_wheel_grace_steps = int(
            stair_config.get(
                "single_wheel_grace_steps", cfg.stair_single_wheel_grace_steps
            )
        )
        cfg.stair_completion_height_tolerance_m = float(
            stair_config.get(
                "completion_height_tolerance_m",
                cfg.stair_completion_height_tolerance_m,
            )
        )
        cfg.stair_start_delay_steps = int(
            stair_config.get("start_delay_steps", cfg.stair_start_delay_steps)
        )
        if (
            cfg.stair_success_reward < 0.0
            or cfg.stair_height_progress_reward_scale < 0.0
            or cfg.stair_step_progress_reward < 0.0
            or cfg.stair_level_hold_reward_scale < 0.0
            or cfg.stair_stable_hold_reward_scale < 0.0
            or cfg.stair_approach_lift_reward_scale < 0.0
            or cfg.stair_approach_lift_distance_m <= 0.0
            or cfg.stair_collision_penalty < 0.0
            or not 0.0 <= cfg.stair_approach_yaw_rad < math.pi / 2.0
            or cfg.stair_approach_lead_side not in ("left", "right", "random")
            or cfg.stair_step_assist_trigger_distance_m <= 0.0
            or cfg.stair_step_assist_shift_steps <= 0
            or cfg.stair_step_assist_retract_steps <= 0
            or cfg.stair_step_assist_place_steps <= 0
            or cfg.stair_step_assist_settle_steps <= 0
            or cfg.stair_step_assist_hip_retract_rad < 0.0
            or cfg.stair_step_assist_hip_place_rad < 0.0
            or cfg.stair_step_assist_knee_retract_rad < 0.0
            or cfg.stair_step_assist_knee_place_rad < 0.0
            or cfg.stair_step_assist_support_hip_rad < 0.0
            or cfg.stair_step_assist_support_knee_rad < 0.0
            or not all(
                math.isfinite(value) and abs(value) <= cfg.residual_limit
                for value in (
                    cfg.stair_lead_place_hip_residual,
                    cfg.stair_lead_place_knee_residual,
                    cfg.stair_support_place_hip_residual,
                    cfg.stair_support_place_knee_residual,
                )
            )
            or not 0.0 <= cfg.stair_step_assist_support_lateral_scale <= 1.0
            or not math.isfinite(cfg.stair_step_assist_inward_hold_rad)
            or cfg.stair_step_assist_inward_hold_rad < 0.0
            or cfg.stair_step_assist_brake_torque < 0.0
            or cfg.stair_lead_wheel_reward < 0.0
            or cfg.stair_trail_wheel_reward < 0.0
            or cfg.stair_lead_lift_progress_reward < 0.0
            or cfg.stair_lead_unload_reward < 0.0
            or cfg.stair_rolling_contact_reward_scale < 0.0
            or cfg.stair_single_wheel_lag_penalty < 0.0
            or cfg.stair_single_wheel_grace_steps <= 0
            or cfg.stair_completion_height_tolerance_m < 0.0
            or cfg.stair_start_delay_steps < 0
        ):
            raise ValueError("stair reward scales must be non-negative")
        stair_length = (
            validated_stairs.start_x_m
            + validated_stairs.num_steps * validated_stairs.tread_range_m[1]
            + validated_stairs.landing_length_m
            + 2.0
        )
        cfg.scene.env_spacing = max(cfg.scene.env_spacing, stair_length)
        if cfg.stair_support_augmentation_enabled:
            cfg.scene.env_spacing = max(cfg.scene.env_spacing, 80.)
    env = TitaResidualEnv(cfg)
    contact_contract = TrainingContactContract(
        env.num_envs, env.device, not cfg.sim.disable_contact_processing,
        cfg.navigation_stationary_hold_reward_scale > 0.
        or cfg.navigation_stationary_interruption_penalty > 0.,
    )
    observation, _ = env.reset()
    observation = observation["policy"]
    print(
        f"[TITA-UC TRAIN] environment reset; app_running={simulation_app.is_running()}",
        flush=True,
    )
    if not args.headless:
        env.sim.set_camera_view((2.8, 2.8, 1.7), (0.0, 0.0, 0.35))
    official = FrozenOfficialTitaController(OfficialTitaActor.from_checkpoint(args.checkpoint, env.device))
    official.reset(env.num_envs, env.device)
    model = PhaseBActorCritic(
        obs_dim=observation.shape[-1],
        residual_limit=cfg.residual_limit,
        posture_scale=cfg.posture_scale,
    ).to(env.device)
    if args.initial_residual_checkpoint is not None:
        payload = torch.load(
            args.initial_residual_checkpoint.expanduser(), map_location="cpu", weights_only=True
        )
        load_phase_b_state_dict_compatible(model, payload["model_state_dict"])
        print(f"[TITA-UC TRAIN] warm-start={args.initial_residual_checkpoint}")
    if "observation_encoding" in run_config:
        requested_encoding = run_config["observation_encoding"]
        current_encoding = int(model.policy.observation_encoding_version)
        requested_version = {"legacy": 0, "bounded_robot_v1": 1, "bounded_robot_path_v2": 2}.get(requested_encoding)
        append_only_extension = (args.initial_residual_checkpoint is not None and current_encoding == 1 and requested_version == 2
                                 and payload["model_state_dict"]["policy.network.0.weight"].shape[1] == 62
                                 and observation.shape[-1] == 64)
        if args.initial_residual_checkpoint is not None and current_encoding != requested_version and not append_only_extension:
            raise ValueError("warm-start observation encoding mismatch; train a new encoder contract from scratch")
        model.configure_observation_encoding(requested_encoding)
    if "residual_linear_command_gate_mps" in run_config:
        gate_speed = float(run_config["residual_linear_command_gate_mps"])
        if not math.isfinite(gate_speed) or gate_speed < 0.:
            raise ValueError("residual linear command gate must be finite and nonnegative")
        model.policy.linear_command_gate_mps.fill_(gate_speed)
    policy_log_std = (
        args.policy_log_std
        if args.policy_log_std is not None
        else run_config.get("policy_log_std")
    )
    freeze_policy_std = bool(
        args.freeze_policy_std or run_config.get("freeze_policy_std", False)
    )
    model.policy.configure_exploration(
        policy_log_std, trainable=not freeze_policy_std
    )
    print(
        "[TITA-UC TRAIN] exploration "
        f"log_std={model.policy.log_std.detach().cpu().tolist()} "
        f"trainable={model.policy.log_std.requires_grad}"
    )
    algorithm = PhaseBNP3O(
        model,
        learning_rate=learning_rate,
        cost_multipliers=initial_cost_multipliers,
        minimum_cost_multipliers=minimum_cost_multipliers,
        cost_budgets=cost_budgets,
        dual_learning_rate=dual_learning_rate,
        cost_multiplier_max=cost_multiplier_max,
    )
    command = torch.tensor([args.command_x, 0.0, args.command_wz], device=env.device).repeat(env.num_envs, 1)
    navigation_commands = None
    if args.navigation_command_curriculum:
        navigation_commands = NavigationCommandCurriculum(
            env.num_envs, env.device, args.seed + 5100,
            NavigationCommandConfig(**run_config.get("navigation_commands", {})),
        )
    posture_config = run_config.get("posture_curriculum", {})
    posture_enabled = bool(args.posture_curriculum or posture_config.get("enabled", False))
    fixed_posture = args.fixed_posture or run_config.get("fixed_posture")
    if fixed_posture is not None and fixed_posture not in POSTURE_NAMES:
        raise ValueError("fixed posture must be LOW, MID, or HIGH")
    if posture_enabled and fixed_posture is not None:
        raise ValueError("posture curriculum and fixed posture are mutually exclusive")
    fixed_posture_index = POSTURE_NAMES.index(fixed_posture) if fixed_posture else None
    fixed_posture_command = None
    if fixed_posture_index is not None:
        fixed_posture_command = torch.nn.functional.one_hot(
            torch.full((env.num_envs,), fixed_posture_index, device=env.device), 3
        ).to(torch.float32)
    posture_scheduler = PostureCommandScheduler(
        env.num_envs,
        env.device,
        PostureCurriculumConfig(
            control_dt=env.step_dt,
            resample_time_s=float(posture_config.get("resample_time_s", 3.0)),
            transition_time_s=float(posture_config.get("transition_time_s", 1.5)),
            switch_hold_time_s=float(posture_config.get("switch_hold_time_s", 0.20)),
            switch_speed_max=float(posture_config.get("switch_speed_max_mps", 0.20)),
            switch_roll_max=float(posture_config.get("switch_roll_max_rad", 0.12)),
            switch_pitch_max=float(posture_config.get("switch_pitch_max_rad", 0.12)),
            require_execution_feedback=bool(posture_config.get("require_execution_feedback", False)),
        ),
    )
    mid_only_fraction = float(posture_config.get("mid_only_fraction", 0.10))
    low_mid_fraction = float(posture_config.get("low_mid_fraction", 0.45))
    posture_speed_limits = torch.tensor(
        posture_config.get("speed_limits_mps", (0.15, 0.30, 0.20)),
        device=env.device,
        dtype=torch.float32,
    )
    if posture_speed_limits.shape != (3,) or torch.any(posture_speed_limits <= 0.0):
        raise ValueError("posture speed limits must be a positive LOW/MID/HIGH vector")
    if not 0.0 <= mid_only_fraction <= low_mid_fraction <= 1.0:
        raise ValueError("posture curriculum fractions must satisfy 0 <= mid_only <= low_mid <= 1")

    governor = BatchedCalibratedGovernor(governor_prior["profiles"], env.num_envs, env.device, cfg.posture_feedforward_transition_s) if governor_prior else None

    def apply_governor_prior(proprioception: torch.Tensor) -> None:
        if governor is None:
            return
        measured = torch.cat((env.robot.data.root_lin_vel_b[:, :2], env.robot.data.root_ang_vel_b[:, 2:3]), dim=1)
        policy_commands = governor.command(
            env._velocity_command, measured, env._posture_command, float(env.step_dt),
        )
        proprioception[:, 6:9] = policy_commands * proprioception.new_tensor([2.0, 2.0, 0.25])

    for warmup_step in range(warmup_steps):
        if not simulation_app.is_running() and not args.headless:
            print("[TITA-UC TRAIN] Isaac Sim window closed during warm-up; stopping.")
            env.close()
            return
        env.set_velocity_command(
            torch.zeros_like(command) if cfg.stair_enabled else command
        )
        if fixed_posture_command is not None:
            env.set_posture_command(fixed_posture_command)
        else:
            env.set_posture_command(
                torch.tensor((0.0, 1.0, 0.0), device=env.device).repeat(env.num_envs, 1)
            )
        assert official.previous_policy_action is not None
        proprioception = env.official_proprioception(official.previous_policy_action)
        apply_governor_prior(proprioception)
        base_target, _ = official.target(proprioception, env.default_joint_target())
        env.set_base_target(base_target)
        with torch.no_grad():
            warmup_action = model.policy(observation)
        next_observation, _, terminated, truncated, _ = env.step(warmup_action)
        done = terminated | truncated
        official.reset_envs(done)
        if governor is not None:
            governor.reset(done)
        observation = next_observation["policy"]
    print(f"[TITA-UC TRAIN] stabilization warm-up steps={warmup_steps}")

    def save_checkpoint(iteration: int) -> Path:
        output = run_dir / "checkpoints" / f"residual_phase_b_iter_{iteration:05d}.pt"
        torch.save(
            {
                "model_state_dict": model.state_dict(),
                "execution_source_provenance": source_provenance,
                "execution_source_manifest_sha256": hashlib.sha256(source_manifest.read_bytes()).hexdigest() if source_manifest.exists() else None,
                "optimizer_state_dict": algorithm.optimizer.state_dict(),
                "constraint_state_dict": algorithm.constraint_state_dict(),
                "policy_config": {
                    "residual_limit": cfg.residual_limit,
                    "posture_scale": cfg.posture_scale,
                },
                "execution_config": {
                    "convex_cylinder_collisions": cfg.convex_cylinder_collisions,
                    "contact_processing_enabled": not cfg.sim.disable_contact_processing,
                    "physics_device": str(env.device),
                    "stationary_contact_contract": contact_contract.metadata(),
                    "asset_sha256": hashlib.sha256(Path(args.asset).read_bytes()).hexdigest(),
                    "official_checkpoint_sha256": hashlib.sha256(Path(args.checkpoint).read_bytes()).hexdigest(),
                    "residual_postures": [fixed_posture] if fixed_posture else ["MID"] if not posture_enabled or mid_only_fraction >= 1. else ["LOW", "MID"] if low_mid_fraction >= 1. else list(POSTURE_NAMES),
                    "residual_filter_alpha": cfg.residual_filter_alpha,
                    "acceleration_limit": cfg.acceleration_limit,
                    "enforce_acceleration_limit": cfg.enforce_acceleration_limit,
                    "normalized_cost_clip": cfg.normalized_cost_clip,
                    "objective_p95": list(cfg.objective_p95),
                    "posture_joint_anchors": [list(anchor) for anchor in cfg.posture_joint_anchors],
                    "posture_heights": list(cfg.posture_heights),
                    "navigation_pose_observations": cfg.navigation_pose_observations,
                    "posture_profile": run_config.get("posture_profile"),
                    "velocity_calibration_prior": run_config.get("velocity_calibration_prior"),
                },
                "training_config": run_config,
                "training_args": {name: str(value) if isinstance(value, Path) else value for name, value in vars(args).items()},
                "iteration": iteration,
            },
            output,
        )
        print(f"[TITA-UC TRAIN] checkpoint={output}")
        return output

    completed_iterations = 0
    stop_requested = False
    save_checkpoint(0)
    for iteration in range(1, args.iterations + 1):
        print(f"[TITA-UC TRAIN] starting iteration {iteration}", flush=True)
        if not simulation_app.is_running() and not args.headless:
            print("[TITA-UC TRAIN] Isaac Sim window closed; stopping training.")
            break
        buffers: dict[str, list[torch.Tensor]] = {
            name: [] for name in ("obs", "action", "log_prob", "reward", "cost", "done", "value", "cost_value")
        }
        tunnel_success_before = env.tunnel_success_count.clone()
        stair_success_before = env.stair_success_count.clone()
        tunnel_ever_exited = torch.zeros(
            env.num_envs, dtype=torch.bool, device=env.device
        )
        stair_ever_completed = torch.zeros(
            env.num_envs, dtype=torch.bool, device=env.device
        )
        base_action_max = 0.0
        hard_failures = 0
        projected_steps = 0
        hard_reason_counts = torch.zeros(
            len(HARD_REASON_NAMES), dtype=torch.long, device=env.device
        )
        velocity_joint_counts = torch.zeros(8, dtype=torch.long, device=env.device)
        velocity_state_projection_counts = torch.zeros(
            8, dtype=torch.long, device=env.device
        )
        projection_joint_counts = torch.zeros(8, dtype=torch.long, device=env.device)
        qd_absmax = torch.zeros(8, device=env.device)
        qd_preprojection_absmax = torch.zeros(8, device=env.device)
        qdd_absmax = torch.zeros(8, device=env.device)
        smooth_component_sum = torch.zeros(4, device=env.device)
        posture_mode_counts = torch.zeros(3, dtype=torch.long, device=env.device)
        posture_height_sum = torch.zeros(3, device=env.device)
        posture_height_error_sum = torch.zeros(3, device=env.device)
        posture_transition_steps = 0
        posture_switch_starts = 0
        posture_pending_steps = 0
        posture_switch_blocked_counts = torch.zeros(3, dtype=torch.long, device=env.device)
        posture_pending_state_absmax = torch.zeros(3, device=env.device)
        mode_switch_events = 0
        rapid_mode_switch_events = 0
        dynamic_obstacle_risk_sum = 0.0
        stair_local_x_max = torch.full(
            (env.num_envs,), float("-inf"), device=env.device
        )
        stair_root_z_max = torch.full_like(stair_local_x_max, float("-inf"))
        stair_verified_level_max = torch.zeros(env.num_envs, device=env.device)
        stair_wheel_level_max = torch.zeros(env.num_envs, 2, device=env.device)
        stair_lead_wheel_level_max = torch.zeros(env.num_envs, device=env.device)
        stair_trail_wheel_level_max = torch.zeros(env.num_envs, device=env.device)
        stair_lead_wheel_rise_max = torch.zeros(env.num_envs, device=env.device)
        stair_lead_unload_events = torch.zeros(
            env.num_envs, dtype=torch.long, device=env.device
        )
        stair_lead_ever_unloaded = torch.zeros(
            env.num_envs, dtype=torch.bool, device=env.device
        )
        stair_lead_reassignment_count = 0
        stair_lead_ever_reassigned = torch.zeros(
            env.num_envs, dtype=torch.bool, device=env.device
        )
        stair_raw_collision_steps = 0
        stair_collision_ever = torch.zeros(
            env.num_envs, dtype=torch.bool, device=env.device
        )
        stair_stable_ever = torch.zeros(
            env.num_envs, dtype=torch.bool, device=env.device
        )
        stair_stable_hold_steps = torch.zeros(
            env.num_envs, dtype=torch.long, device=env.device
        )
        stair_max_stable_hold_steps = torch.zeros_like(stair_stable_hold_steps)
        stair_phase_step_counts = torch.zeros(
            STAIR_PHASE_COUNT, dtype=torch.long, device=env.device
        )
        stair_phase_ever_reached = torch.zeros(
            env.num_envs, STAIR_PHASE_COUNT, dtype=torch.bool, device=env.device
        )
        previous_lead_contact = torch.where(
            env._stair_lead_is_left,
            env._wheel_contact[:, 0],
            env._wheel_contact[:, 1],
        )
        progress_fraction = (iteration - 1) / max(args.iterations - 1, 1)
        if not posture_enabled or progress_fraction < mid_only_fraction:
            posture_scheduler.set_allowed_modes((1,))
        elif progress_fraction < low_mid_fraction:
            posture_scheduler.set_allowed_modes((0, 1))
        else:
            posture_scheduler.set_allowed_modes((0, 1, 2))
        for _ in range(args.rollout_steps):
            if not simulation_app.is_running() and not args.headless:
                print("[TITA-UC TRAIN] Isaac Sim window closed during rollout; stopping.")
                stop_requested = True
                break
            step_command = command
            if _ == 0:
                print("[TITA-UC TRAIN] entering first rollout step", flush=True)
            if posture_enabled:
                gravity = env.robot.data.projected_gravity_b
                speed = torch.linalg.vector_norm(env.robot.data.root_lin_vel_b[:, :2], dim=1)
                roll = torch.atan2(gravity[:, 1], -gravity[:, 2])
                pitch = torch.atan2(
                    -gravity[:, 0],
                    torch.sqrt(torch.square(gravity[:, 1]) + torch.square(gravity[:, 2])),
                )
                execution_ready = ((env.posture_height - env.posture_target_height).abs() <= .025) & env._wheel_contact.all(dim=1)
                posture_step = posture_scheduler.step(speed, roll, pitch, execution_ready)
                pending = posture_scheduler.pending
                posture_pending_steps += int(pending.sum().item())
                posture_switch_blocked_counts += torch.stack(
                    (
                        (pending & (speed.abs() > posture_scheduler.cfg.switch_speed_max)).sum(),
                        (pending & (roll.abs() > posture_scheduler.cfg.switch_roll_max)).sum(),
                        (pending & (pitch.abs() > posture_scheduler.cfg.switch_pitch_max)).sum(),
                    )
                )
                if pending.any():
                    pending_state = torch.stack((speed.abs(), roll.abs(), pitch.abs()), dim=1)
                    posture_pending_state_absmax = torch.maximum(
                        posture_pending_state_absmax,
                        pending_state[pending].amax(dim=0),
                    )
                env.set_posture_command(posture_step.command, posture_step.phase)
                step_command = command.clone()
                commanded_speed = torch.linalg.vector_norm(step_command[:, :2], dim=1)
                mode_speed_limit = posture_step.command @ posture_speed_limits
                scale = torch.clamp(
                    mode_speed_limit / commanded_speed.clamp_min(1e-6),
                    max=1.0,
                )
                step_command[:, :2] *= scale[:, None]
                step_command[posture_step.slow_down, :2] = 0.0
                posture_transition_steps += int(posture_step.transition.sum().item())
                posture_switch_starts += int(posture_step.started.sum().item())
            elif fixed_posture_command is not None:
                env.set_posture_command(fixed_posture_command)
                step_command = command.clone()
                fixed_speed_limit = posture_speed_limits[fixed_posture_index]
                commanded_speed = torch.linalg.vector_norm(step_command[:, :2], dim=1)
                scale = torch.clamp(
                    fixed_speed_limit / commanded_speed.clamp_min(1e-6), max=1.0
                )
                step_command[:, :2] *= scale[:, None]
            if cfg.stair_enabled:
                phase_scale = torch.ones(env.num_envs, device=env.device)
                for phase_id, scale in stair_phase_command_scales.items():
                    phase_active = env._stair_phase == phase_id
                    if phase_id == STAIR_PHASE_SETTLE:
                        phase_active &= env._stair_phase_progress < 1.0
                    phase_scale = torch.where(
                        phase_active,
                        torch.full_like(phase_scale, scale),
                        phase_scale,
                    )
                settled = (
                    (env._stair_phase == STAIR_PHASE_SETTLE)
                    & (env._stair_phase_progress >= 1.0)
                )
                phase_scale[settled] = 0.0
                step_command = step_command.clone()
                step_command *= phase_scale[:, None]
            if navigation_commands is not None:
                step_command = navigation_commands.step(float(env.step_dt))
                step_command = constrain_navigation_command(
                    step_command, env._posture_command, posture_speed_limits,
                    posture_step.slow_down if posture_enabled else None,
                )
            if cfg.stair_enabled and run_config.get("straight_path_heading_gain", 0.) > 0.:
                quaternion = env.robot.data.root_quat_w
                yaw = torch.atan2(2 * (quaternion[:, 0] * quaternion[:, 3] + quaternion[:, 1] * quaternion[:, 2]),
                                  1 - 2 * (quaternion[:, 2].square() + quaternion[:, 3].square()))
                lateral = env.robot.data.root_pos_w[:, 1] - env._environment_origins()[:, 1]
                correction = -float(run_config["straight_path_heading_gain"]) * yaw - float(run_config.get("straight_path_lateral_gain", .8)) * lateral
                moving = torch.linalg.vector_norm(step_command[:, :2], dim=1) > 1e-5
                step_command[:, 2] = torch.where(moving, correction.clamp(-.3, .3), 0.)
            if posture_enabled and posture_scheduler.cfg.require_execution_feedback:
                step_command[posture_step.slow_down] = 0.0
            if cfg.stair_enabled and stair_config.get("stop_after_completion", False):
                completed = env.stair_traversed if cfg.stair_success_stable_hold_s > 0. else env.stair_completed
                step_command[completed] = 0.
            if cfg.stair_enabled:
                step_command = hold_reset_commands(step_command, env.episode_length_buf, cfg.stair_start_delay_steps)
            env.set_velocity_command(step_command)
            observation = env._get_observations()["policy"]
            assert official.previous_policy_action is not None
            proprioception = env.official_proprioception(official.previous_policy_action)
            apply_governor_prior(proprioception)
            base_target, base_action = official.target(proprioception, env.default_joint_target())
            env.set_base_target(base_target)
            action, log_prob, value, cost_value = model.act(observation)
            stair_phase_before_step = env._stair_phase.clone()
            stair_lead_is_left_before_step = env._stair_lead_is_left.clone()
            if cfg.stair_enabled:
                stair_local_x = (
                    env.robot.data.root_pos_w[:, 0] - env._environment_origins()[:, 0]
                )
                stair_local_x_max = torch.maximum(stair_local_x_max, stair_local_x)
                stair_root_z_max = torch.maximum(
                    stair_root_z_max, env.robot.data.root_pos_w[:, 2]
                )
                stair_verified_level_max = torch.maximum(
                    stair_verified_level_max, env._verified_stair_level()
                )
                wheel_levels, _, _ = env._wheel_stair_state()
                stair_wheel_level_max = torch.maximum(
                    stair_wheel_level_max, wheel_levels
                )
                stair_lead_wheel_level_max = torch.maximum(
                    stair_lead_wheel_level_max,
                    torch.where(
                        stair_lead_is_left_before_step,
                        wheel_levels[:, 0],
                        wheel_levels[:, 1],
                    ),
                )
                stair_trail_wheel_level_max = torch.maximum(
                    stair_trail_wheel_level_max,
                    torch.where(
                        stair_lead_is_left_before_step,
                        wheel_levels[:, 1],
                        wheel_levels[:, 0],
                    ),
                )
            next_observation, reward, terminated, truncated, _ = env.step(action)
            contact_contract.observe(env._wheel_contact, float(env.step_dt))
            tunnel_ever_exited |= env.tunnel_success_count > tunnel_success_before
            stair_ever_completed |= env.stair_success_count > stair_success_before
            done = terminated | truncated
            if cfg.stair_enabled:
                stair_raw_collision_steps += int(env._collision.sum().item())
                stair_collision_ever |= env._collision
                stair_stable = env.stair_stable
                stair_stable_ever |= stair_stable
                stair_stable_hold_steps = torch.where(
                    stair_stable,
                    stair_stable_hold_steps + 1,
                    torch.zeros_like(stair_stable_hold_steps),
                )
                stair_max_stable_hold_steps = torch.maximum(
                    stair_max_stable_hold_steps, stair_stable_hold_steps
                )
                stair_lead_reassignment_count += int(
                    env._stair_lead_reassigned.sum().item()
                )
                stair_lead_ever_reassigned |= env._stair_lead_reassigned
                phase_ids = stair_phase_before_step.clamp(
                    0, STAIR_PHASE_COUNT - 1
                )
                stair_phase_step_counts += phase_ids.bincount(
                    minlength=STAIR_PHASE_COUNT
                )
                stair_phase_ever_reached.scatter_(
                    1, phase_ids[:, None], True
                )
                wheel_axis_z = env.robot.data.body_pos_w[
                    :, env._wheel_body_ids, 2
                ]
                lead_axis_z = torch.where(
                    stair_lead_is_left_before_step,
                    wheel_axis_z[:, 0],
                    wheel_axis_z[:, 1],
                )
                lead_reference_z = torch.where(
                    stair_lead_is_left_before_step,
                    env._stair_wheel_axis_reference_z[:, 0],
                    env._stair_wheel_axis_reference_z[:, 1],
                )
                stair_lead_wheel_rise_max = torch.maximum(
                    stair_lead_wheel_rise_max,
                    torch.where(
                        done | (stair_phase_before_step == 0),
                        torch.zeros_like(lead_axis_z),
                        (lead_axis_z - lead_reference_z).clamp_min(0.0),
                    ),
                )
                lead_contact = torch.where(
                    stair_lead_is_left_before_step,
                    env._wheel_contact[:, 0],
                    env._wheel_contact[:, 1],
                )
                lead_unloaded = (
                    (stair_phase_before_step == 1) & ~lead_contact & ~done
                )
                stair_lead_unload_events += (
                    previous_lead_contact & lead_unloaded
                ).long()
                stair_lead_ever_unloaded |= lead_unloaded
                previous_lead_contact = lead_contact
            posture_indices = env._posture_command.argmax(dim=1)
            posture_mode_counts += posture_indices.bincount(minlength=3)
            mode_switch_events += int(env.posture_switch_event.sum().item())
            rapid_mode_switch_events += int(env.rapid_posture_switch_event.sum().item())
            dynamic_obstacle_risk_sum += float(env.dynamic_obstacle_risk.sum().item())
            posture_error = torch.abs(env.posture_height - env.posture_target_height)
            for posture_index in range(3):
                posture_mask = posture_indices == posture_index
                posture_height_sum[posture_index] += env.posture_height[posture_mask].sum()
                posture_height_error_sum[posture_index] += posture_error[posture_mask].sum()
            buffers["obs"].append(observation)
            buffers["action"].append(action)
            buffers["log_prob"].append(log_prob)
            buffers["reward"].append(reward)
            buffers["cost"].append(env.soft_costs.clone())
            buffers["done"].append(done)
            buffers["value"].append(value)
            buffers["cost_value"].append(cost_value)
            hard_failures += int(terminated.sum().item())
            projected_steps += int(env.projected.sum().item())
            hard_reason_counts += env.hard_reason_flags.sum(0)
            velocity_joint_counts += env.velocity_violation_flags.sum(0)
            velocity_state_projection_counts += (
                env.velocity_state_projection_flags.sum(0)
            )
            projection_joint_counts += env.projection_joint_flags.sum(0)
            qd_absmax = torch.maximum(qd_absmax, env.joint_velocity_absmax())
            qd_preprojection_absmax = torch.maximum(
                qd_preprojection_absmax,
                env.preprojection_joint_velocity_absmax(),
            )
            qdd_absmax = torch.maximum(qdd_absmax, env.joint_acceleration_absmax())
            smooth_component_sum += env.smooth_components.sum(0)
            base_action_max = max(base_action_max, float(base_action.abs().max()))
            official.reset_envs(done)
            if governor is not None:
                governor.reset(done)
            if navigation_commands is not None:
                navigation_commands.reset(done)
            if posture_enabled:
                posture_scheduler.reset(done)
            observation = next_observation["policy"]

        if stop_requested:
            break

        with torch.no_grad():
            last_reward_value = model.reward_value(observation).squeeze(-1)
            last_cost_value = model.cost_value(observation)
        tensors = {name: torch.stack(values) for name, values in buffers.items()}
        reward_advantage, reward_return = generalized_advantage(
            tensors["reward"], tensors["value"], last_reward_value, tensors["done"], 0.99, 0.95
        )
        cost_advantage, cost_return = generalized_advantage(
            tensors["cost"], tensors["cost_value"], last_cost_value, tensors["done"], 0.99, 0.95
        )
        stats = algorithm.update(
            tensors["obs"], tensors["action"], tensors["log_prob"],
            reward_advantage, reward_return, cost_advantage, cost_return,
            observed_cost_mean=tensors["cost"].mean(dim=(0, 1)),
        )
        metric = {
            "iteration": iteration,
            "stationary_hold_duration_mean_s": float(env._navigation_stationary_hold_s.mean()),
            "stationary_hold_duration_max_s": float(env._navigation_stationary_hold_s.max()),
            "stationary_hold_accepted_envs": int((env._navigation_stationary_hold_s >= 1.).sum()),
            "both_wheels_contact_envs": int(env._wheel_contact.all(1).sum()),
            "requested_stationary_envs": int(((torch.linalg.vector_norm(env._velocity_command[:, :2], dim=1) <= .005)
                                               & (env._velocity_command[:, 2].abs() <= .005)).sum()),
            "contact_processing_enabled": not cfg.sim.disable_contact_processing,
            "stationary_contact_contract": contact_contract.metadata(),
            "physics_device": str(env.device),
            "rollout_policy_checkpoint_iteration": iteration - 1,
            "updated_checkpoint_iteration": iteration,
            "reward_mean": float(tensors["reward"].mean()),
            "cost_route": float(tensors["cost"][..., 0].mean()),
            "cost_energy": float(tensors["cost"][..., 1].mean()),
            "cost_mode": float(tensors["cost"][..., 2].mean()),
            "cost_smooth": float(tensors["cost"][..., 3].mean()),
            "smooth_component_mean": (
                smooth_component_sum / (args.rollout_steps * env.num_envs)
            ).tolist(),
            "smooth_component_names": [
                "joint_target_change", "residual_rate",
                "acceleration_ratio", "soft_contact_term"
            ],
            "hard_failures": hard_failures,
            "projection_fraction": projected_steps / (args.rollout_steps * env.num_envs),
            "hard_reason_counts": hard_reason_counts.tolist(),
            "hard_reason_names": list(HARD_REASON_NAMES),
            "velocity_joint_counts": velocity_joint_counts.tolist(),
            "velocity_state_projection_counts": velocity_state_projection_counts.tolist(),
            "terrain": args.terrain,
            "navigation_command_curriculum": args.navigation_command_curriculum,
            "command_x": args.command_x,
            "command_wz": args.command_wz,
            "domain_randomization": args.domain_randomization,
            "projection_joint_counts": projection_joint_counts.tolist(),
            "qd_absmax": qd_absmax.tolist(),
            "qd_preprojection_absmax": qd_preprojection_absmax.tolist(),
            "qdd_absmax": qdd_absmax.tolist(),
            "acceleration_limit": args.acceleration_limit,
            "residual_filter_alpha": args.residual_filter_alpha,
            "policy_log_std": model.policy.log_std.detach().cpu().tolist(),
            "policy_std_trainable": model.policy.log_std.requires_grad,
            "posture_curriculum": posture_enabled,
            "fixed_posture": fixed_posture,
            "posture_mode_counts": posture_mode_counts.tolist(),
            "posture_mode_names": list(POSTURE_NAMES),
            "posture_height_mean_m": (
                posture_height_sum / posture_mode_counts.clamp_min(1)
            ).tolist(),
            "posture_height_abs_error_mean_m": (
                posture_height_error_sum / posture_mode_counts.clamp_min(1)
            ).tolist(),
            "posture_transition_steps": posture_transition_steps,
            "posture_switch_starts": posture_switch_starts,
            "posture_pending_steps": posture_pending_steps,
            "posture_switch_blocked_counts": posture_switch_blocked_counts.tolist(),
            "posture_switch_blocked_names": ["speed", "roll", "pitch"],
            "posture_pending_state_absmax": posture_pending_state_absmax.tolist(),
            "mode_switch_events": mode_switch_events,
            "rapid_mode_switch_events": rapid_mode_switch_events,
            "dynamic_obstacle_risk_mean": dynamic_obstacle_risk_sum / (args.rollout_steps * env.num_envs),
            "objective_p95": list(objective_p95),
            "tunnel_dimensions_min_m": (
                env.tunnel_dimensions.amin(dim=0).tolist() if cfg.tunnel_enabled else None
            ),
            "tunnel_dimensions_max_m": (
                env.tunnel_dimensions.amax(dim=0).tolist() if cfg.tunnel_enabled else None
            ),
            "tunnel_exit_count": int(tunnel_ever_exited.sum().item()),
            "tunnel_success_total": int(
                (env.tunnel_success_count - tunnel_success_before).sum().item()
            ),
            "stair_dimensions_min_m": (
                env.stair_dimensions.amin(dim=0).tolist() if cfg.stair_enabled else None
            ),
            "stair_dimensions_max_m": (
                env.stair_dimensions.amax(dim=0).tolist() if cfg.stair_enabled else None
            ),
            "stair_completion_count": int(stair_ever_completed.sum().item()),
            "stair_success_total": int(
                (env.stair_success_count - stair_success_before).sum().item()
            ),
            "stair_local_x_max_minmax_m": (
                [stair_local_x_max.min().item(), stair_local_x_max.max().item()]
                if cfg.stair_enabled else None
            ),
            "stair_root_z_max_minmax_m": (
                [stair_root_z_max.min().item(), stair_root_z_max.max().item()]
                if cfg.stair_enabled else None
            ),
            "stair_verified_level_histogram": (
                stair_verified_level_max.long().bincount(
                    minlength=cfg.stair_num_steps + 1
                ).tolist()
                if cfg.stair_enabled else None
            ),
            "stair_left_wheel_level_histogram": (
                stair_wheel_level_max[:, 0].long().bincount(
                    minlength=cfg.stair_num_steps + 1
                ).tolist()
                if cfg.stair_enabled else None
            ),
            "stair_right_wheel_level_histogram": (
                stair_wheel_level_max[:, 1].long().bincount(
                    minlength=cfg.stair_num_steps + 1
                ).tolist()
                if cfg.stair_enabled else None
            ),
            "stair_lead_wheel_level_histogram": (
                stair_lead_wheel_level_max.long().bincount(
                    minlength=cfg.stair_num_steps + 1
                ).tolist()
                if cfg.stair_enabled else None
            ),
            "stair_trail_wheel_level_histogram": (
                stair_trail_wheel_level_max.long().bincount(
                    minlength=cfg.stair_num_steps + 1
                ).tolist()
                if cfg.stair_enabled else None
            ),
            "stair_lead_wheel_rise_max_minmax_m": (
                [
                    stair_lead_wheel_rise_max.min().item(),
                    stair_lead_wheel_rise_max.max().item(),
                ]
                if cfg.stair_enabled else None
            ),
            "stair_lead_unload_event_count": (
                int(stair_lead_unload_events.sum().item())
                if cfg.stair_enabled else 0
            ),
            "stair_lead_unloaded_env_count": (
                int(stair_lead_ever_unloaded.sum().item())
                if cfg.stair_enabled else 0
            ),
            "stair_lead_reassignment_count": (
                stair_lead_reassignment_count if cfg.stair_enabled else 0
            ),
            "stair_lead_reassigned_env_count": (
                int(stair_lead_ever_reassigned.sum().item())
                if cfg.stair_enabled else 0
            ),
            "stair_raw_collision_steps": (
                stair_raw_collision_steps if cfg.stair_enabled else 0
            ),
            "stair_collision_env_count": (
                int(stair_collision_ever.sum().item())
                if cfg.stair_enabled else 0
            ),
            "stair_stable_env_count": (
                int(stair_stable_ever.sum().item()) if cfg.stair_enabled else 0
            ),
            "stair_max_stable_hold_steps_minmax": (
                [
                    int(stair_max_stable_hold_steps.min().item()),
                    int(stair_max_stable_hold_steps.max().item()),
                ]
                if cfg.stair_enabled else None
            ),
            "stair_phase_step_counts": (
                stair_phase_step_counts.tolist() if cfg.stair_enabled else None
            ),
            "stair_phase_env_counts": (
                stair_phase_ever_reached.sum(dim=0).tolist()
                if cfg.stair_enabled else None
            ),
            "stair_phase_names": [
                "approach",
                "shift_to_trail",
                "lead_retract",
                "lead_place",
                "trail_retract",
                "trail_place",
                "settle",
            ],
            "stair_phase_command_scales": stair_phase_command_scales,
            "base_action_absmax": base_action_max,
            **stats.__dict__,
        }
        with metrics_path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(metric, sort_keys=True) + "\n")
        print("[TITA-UC TRAIN] " + json.dumps(metric, sort_keys=True))
        completed_iterations = iteration
        if iteration % checkpoint_interval == 0:
            save_checkpoint(iteration)

    if completed_iterations == 0 or completed_iterations % checkpoint_interval != 0:
        save_checkpoint(completed_iterations)
    env.close()


if __name__ == "__main__":
    try:
        main()
    finally:
        simulation_app.close()
