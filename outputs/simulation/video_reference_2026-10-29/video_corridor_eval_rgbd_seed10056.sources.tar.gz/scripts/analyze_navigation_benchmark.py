#!/usr/bin/env python3
"""Recompute maze pilot metrics from immutable completed physical run traces."""

import argparse
import hashlib
import json
from pathlib import Path
import sys

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))
from analyze_motion_chain import audit_planner_clock
from run_navigation_benchmark import draw_scene, write_json
from tita_uc_residual_rl.navigation_benchmark import competing_branch_comparison, executed_geometry_features, path_comparison, protocol_speed_cap, summarize_physical_run, truncate_at_goal_region, path_length
from tita_uc_residual_rl.navigation_maze import load_maze, scene_digest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("runs", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    results, skipped = [], []
    contracts = set()
    physical_contracts = set()
    configurations = set()
    for batch in args.runs:
        batch = batch.resolve()
        config = json.loads((batch / "benchmark_config.json").read_text())
        configurations.add(json.dumps(config, sort_keys=True))
        scene = load_maze(batch / "navigation_scene.json")
        paths = json.loads((batch / "reference_paths.json").read_text())
        branch_file = batch / "branch_reference_paths.json"
        branches = json.loads(branch_file.read_text()) if branch_file.exists() else None
        manifest = json.loads((batch / "benchmark_manifest.json").read_text())
        contracts.add((scene_digest(batch / "navigation_scene.json"), manifest["checkpoint_sha256"], manifest["normalization_sha256"]))
        for invocation in sorted(batch.glob("*.invocation.json")):
            label = invocation.name.removesuffix(".invocation.json")
            directory = batch / label
            if not (directory / "evaluation/evaluation_summary.json").exists():
                skipped.append({"run": str(directory), "reason": "no completed physical evaluation; retained as failed deployment evidence"})
                continue
            evaluation = json.loads((directory / "evaluation/evaluation_summary.json").read_text())
            if not evaluation.get("complete") or len(evaluation.get("episodes", [])) != 1:
                skipped.append({"run": str(directory), "reason": "incomplete physical evaluation; retained in planned-trial denominator"})
                continue
            physical_contracts.add(tuple(hashlib.sha256((directory / name).read_bytes()).hexdigest() for name in ("posture_calibration.json", "velocity_governor_calibration.json", "upper_normalization.json")))
            if load_maze(directory / "navigation_scene.json") != scene:
                raise ValueError("physical collision scene differs from the benchmark scene")
            protocol = next(name for name in config["protocols"] if label.startswith(name + "_"))
            algorithm, seed = label[len(protocol) + 1:].rsplit("_seed", 1)
            motion = json.loads((directory / "motion_profile.json").read_text())
            if (motion["posture_vmax_mps"] != config["posture_vmax_mps"]
                    or motion["benchmark_max_linear_speed_mps"] != protocol_speed_cap(config, protocol, algorithm)):
                raise ValueError("physical motion profile differs from the declared speed contract")
            planner = [json.loads(line) for line in (directory / "planner_trace.jsonl").read_text().splitlines() if line.strip()]
            selected_paths = [row["points"] for row in planner if row["event"] == "path"]
            if not selected_paths:
                skipped.append({"run": str(directory), "reason": "no selected plan available for independent path metrics"})
                continue
            reference = selected_paths[0]
            result = summarize_physical_run(directory, reference, config, protocol, algorithm)
            rows = [json.loads(line) for line in (directory / "control_trace.jsonl").read_text().splitlines() if line.strip()]
            audit_file = directory / "independent_audit.json"
            audit = json.loads(audit_file.read_text()) if audit_file.exists() else {"synchronization_passed": False}
            solve_times = [row["solve_wall_s"] for row in planner if row["event"] == "solve"]
            common_reference = paths["MID"]["xy_m"]
            common_length = path_length(truncate_at_goal_region(common_reference, scene["goal_xy_m"], config["goal_tolerance_m"]))
            result.update(seed=int(seed), action_reward_audit_passed=audit["synchronization_passed"],
                          planner_clock_audit=audit_planner_clock(rows),
                          actual_path_geometry=executed_geometry_features(scene, rows),
                          planner_solve_wall_p95_s=float(np.percentile(solve_times, 95)) if solve_times else None,
                          comparison_to_common_mid_preflight_reference=path_comparison(result["trajectory_xy_m"], common_reference),
                          common_reference_efficiency_success_only=common_length / result["distance_m"] if result["success"] else None)
            result["solver_real_time_10hz_p95_passed"] = bool(solve_times and result["planner_solve_wall_p95_s"] <= 0.1)
            if branches:
                result.update(competing_branch_comparison(result["trajectory_xy_m"], branches))
            result["path_overlap_to_first_plan"] = result["comparison_to_first_selected_plan"]["symmetric_path_overlap"]
            result["path_overlap_to_common_reference"] = result["comparison_to_common_mid_preflight_reference"]["symmetric_path_overlap"]
            result["path_overlap_to_closest_branch"] = result.get("comparison_to_closest_branch", {}).get("symmetric_path_overlap")
            results.append(result)
    if len(contracts) != 1 or len(configurations) != 1 or len(physical_contracts) > 1:
        raise ValueError("cannot merge different scenes, protocols, checkpoints or normalizations")
    combinations = [(result["protocol"], result["algorithm"], result["seed"]) for result in results]
    if len(combinations) != len(set(combinations)):
        raise ValueError("duplicate protocol/algorithm/seed; select one reviewed repeat explicitly")
    pairwise = []
    for index, first in enumerate(results):
        for second in results[index + 1:]:
            if (first["protocol"], first["seed"]) == (second["protocol"], second["seed"]):
                pairwise.append({"protocol": first["protocol"], "seed": first["seed"], "algorithms": [first["algorithm"], second["algorithm"]], **path_comparison(first["trajectory_xy_m"], second["trajectory_xy_m"])})
    write_json(output / "comparison_summary.json", {"simulation_only": True, "pilot_only": True, "results": results, "skipped_incomplete_runs": skipped, "pairwise_path_overlap": pairwise, "common_physical_profile_sha256": list(next(iter(physical_contracts))) if physical_contracts else None, "source_batches": [str(batch.resolve()) for batch in args.runs]})
    draw_scene(scene, paths, output / "maze_trajectories.png", results)
    write_json(output / "benchmark_config.json", config)
    write_json(output / "navigation_scene.json", scene)
    write_json(output / "reference_paths.json", paths)
    if branches:
        write_json(output / "branch_reference_paths.json", branches)
        write_json(output / "maze_geometry_audit.json", json.loads((batch / "maze_geometry_audit.json").read_text()))
    columns = ["protocol", "algorithm", "seed", "success", "selected_branch", "navigation_time_s", "distance_m", "mechanical_energy_j", "energy_j_per_m", "path_overlap_to_first_plan", "path_overlap_to_common_reference", "path_overlap_to_closest_branch", "path_efficiency_success_only", "reference_relative_time_efficiency_success_only", "speed_cap_mps", "desired_speed_max_mps", "measured_speed_max_mps", "measured_speed_exceedance_fraction", "measured_speed_max_after_5s_mps", "measured_speed_exceedance_fraction_after_5s", "planner_solve_wall_p95_s", "command_cap_passed", "action_reward_audit_passed"]
    import csv
    with (output / "comparison_metrics.csv").open("x") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(results)
    print(json.dumps([{key: result[key] for key in columns} for result in results], ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
