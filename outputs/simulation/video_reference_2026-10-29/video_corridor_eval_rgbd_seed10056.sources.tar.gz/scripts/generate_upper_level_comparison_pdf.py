#!/usr/bin/env python3
"""Generate a reproducible PDF comparison for the two upper-level studies."""

from __future__ import annotations

import argparse
import csv
import json
import math
import shutil
import sys
from dataclasses import asdict
from datetime import date
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Rectangle
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    Image,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

ROOT = Path(__file__).resolve().parents[1]
ISAAC_PRELIMINARY = Path(
    "/home/ky/Documents/Codex/2026-10-17/01a11a97-ce63-7a80-b8b4-91bef9bdc293/work/isaac_upper_v4"
)
FONT_PATH = "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc"
pdfmetrics.registerFont(TTFont("CJK", FONT_PATH))

import importlib.util


_SCENE_SPEC = importlib.util.spec_from_file_location(
    "three_route_scene", ROOT / "tita_uc_residual_rl" / "three_route_scene.py"
)
if _SCENE_SPEC is None or _SCENE_SPEC.loader is None:
    raise RuntimeError("unable to load three_route_scene.py")
_SCENE_MODULE = importlib.util.module_from_spec(_SCENE_SPEC)
sys.modules[_SCENE_SPEC.name] = _SCENE_MODULE
_SCENE_SPEC.loader.exec_module(_SCENE_MODULE)
ThreeRouteSceneConfig = _SCENE_MODULE.ThreeRouteSceneConfig
three_route_boxes = _SCENE_MODULE.three_route_boxes


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def finite_values(values: list[float]) -> np.ndarray:
    return np.asarray([float(v) for v in values if math.isfinite(float(v))], dtype=float)


def bootstrap_ci(values: list[float], seed: int = 20261020, samples: int = 10_000) -> tuple[float, float]:
    clean = finite_values(values)
    if not len(clean):
        return (float("nan"), float("nan"))
    if len(clean) == 1:
        return (float(clean[0]), float(clean[0]))
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, len(clean), size=(samples, len(clean)))
    means = clean[indices].mean(axis=1)
    return (float(np.percentile(means, 2.5)), float(np.percentile(means, 97.5)))


def stat(values: list[float], seed: int) -> dict[str, float | int | None]:
    clean = finite_values(values)
    if not len(clean):
        return {"n": 0, "mean": None, "std": None, "ci95_low": None, "ci95_high": None}
    low, high = bootstrap_ci(clean.tolist(), seed=seed)
    return {
        "n": int(len(clean)),
        "mean": float(np.mean(clean)),
        "std": float(np.std(clean, ddof=1)) if len(clean) > 1 else 0.0,
        "ci95_low": low,
        "ci95_high": high,
    }


def fmt(value: float | None, digits: int = 2) -> str:
    if value is None or not math.isfinite(float(value)):
        return "NA"
    return f"{float(value):.{digits}f}"


def fmt_stat(item: dict[str, Any], digits: int = 2) -> str:
    if item.get("mean") is None:
        return "NA"
    return (
        f"{fmt(item['mean'], digits)} ± {fmt(item['std'], digits)} "
        f"(95% CI {fmt(item['ci95_low'], digits)}–{fmt(item['ci95_high'], digits)})"
    )


def method_label(method: str) -> str:
    return {
        "shortest_rule": "Shortest Rule",
        "enumerated_argmin": "Formula-Argmin",
        "categorical_ppo": "Categorical PPO",
        "formula": "Formula-Argmin",
        "bc": "BC-only",
        "ppo": "PPO-reference",
    }.get(method, method)


def load_toy(root: Path) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    files = sorted((root / "toy_repeats").glob("evaluate_seed*.json"))
    for path in files:
        payload = read_json(path)
        seed = int(payload["seed"])
        for method, method_payload in payload["methods"].items():
            summary = method_payload["summary"]
            row = {
                "source": str(path),
                "repeat": seed,
                "method": method,
                "success_rate": float(summary["success_rate"]),
                "hard_violation_rate": float(summary["hard_violation_rate"]),
                "collision_rate": float(summary["collision_rate"]),
            }
            for key in (
                "elapsed_s",
                "distance_m",
                "mechanical_energy_j",
                "mechanical_cot",
                "minimum_lateral_clearance_m",
                "minimum_overhead_margin_m",
            ):
                row[key] = float(summary[key]["mean"])
            row["decision_latency_p50_ms"] = float(summary["decision_latency_ms"]["p50"])
            row["decision_latency_p95_ms"] = float(summary["decision_latency_ms"]["p95"])
            row["decision_latency_max_ms"] = float(summary["decision_latency_ms"]["max"])
            row["switches"] = float(summary["switches"]["mean"])
            rows.append(row)
    return rows, {"files": [str(path) for path in files]}


def load_toy_route_choices(root: Path) -> dict[str, Any]:
    path = root / "toy_route_choices_detailed.json"
    return read_json(path) if path.exists() else {}


def load_isaac_repeat(root: Path) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    directories = {
        "isaac_formula_goal0_repeat5": "formula",
        "isaac_bc_goal0_repeat5": "bc",
        "isaac_ppo_goal0_repeat5": "ppo",
    }
    for directory_name, method in directories.items():
        directory = root / directory_name
        summary_path = directory / "evaluation" / "evaluation_summary.json"
        if not summary_path.exists():
            continue
        payload = read_json(summary_path)
        for episode in payload.get("episodes", []):
            rows.append(
                {
                    "source": str(summary_path),
                    "repeat": int(episode.get("episode_id", len(rows))),
                    "method": method,
                    "success": bool(episode.get("success", False)),
                    "hard_failure": bool(episode.get("hard_failure", False)),
                    "elapsed_s": float(episode.get("elapsed_s", float("nan"))),
                    "distance_m": float(episode.get("distance_m", float("nan"))),
                    "mechanical_energy_j": float(episode.get("energy_j", float("nan"))),
                    "objective_J": float(episode.get("J", float("nan"))),
                }
            )
    return rows, {"directories": [str(root / name) for name in directories]}


def load_preliminary_isaac() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for path in sorted(ISAAC_PRELIMINARY.glob("eval_*/evaluation/evaluation_summary.json")):
        directory = path.parent.parent
        manifest = read_json(directory / "run_manifest.json")
        payload = read_json(path)
        episode = payload.get("episodes", [{}])[0]
        name = directory.name
        if name.startswith("eval_enumeration"):
            method = "formula"
        elif name.startswith("eval_bc_only"):
            method = "bc"
        elif name.startswith("eval_reference"):
            method = "ppo"
        else:
            continue
        rows.append(
            {
                "source": str(path),
                "run": name,
                "goal_y_m": float(manifest.get("goal", [0.0, 0.0])[1]),
                "method": method,
                "success": bool(episode.get("success", False)),
                "elapsed_s": float(episode.get("elapsed_s", float("nan"))),
                "distance_m": float(episode.get("distance_m", float("nan"))),
                "mechanical_energy_j": float(episode.get("energy_j", float("nan"))),
            }
        )
    return rows


def draw_toy_scene(path: Path) -> None:
    cfg = ThreeRouteSceneConfig()
    fig, ax = plt.subplots(figsize=(10, 5.6), dpi=180)
    route_colors = {"LOW": "#2c7fb8", "MID": "#41ab5d", "HIGH": "#d95f0e"}
    route_specs = cfg.routes()
    labels = ["P1: LOW / shortest", "P2: MID / medium", "P3: HIGH / open"]
    for route, label, posture in zip(route_specs, labels, ("LOW", "MID", "HIGH")):
        points = np.asarray(route.points)
        ax.plot(points[:, 0], points[:, 1], color=route_colors[posture], linewidth=3.0, label=label, zorder=4)
        ax.fill_between(
            [cfg.corridor_start_x_m, cfg.corridor_end_x_m],
            route.center_y_m - route.width_m / 2,
            route.center_y_m + route.width_m / 2,
            color=route_colors[posture], alpha=0.10, zorder=1,
        )
        ax.text(cfg.corridor_start_x_m + 0.10, route.center_y_m + route.width_m / 2 + 0.12,
                f"{posture}: L={route.length_m:.2f} m", color=route_colors[posture], fontsize=9)
    for box in three_route_boxes((0.0, 0.0), cfg):
        x, y, _ = box.center
        sx, sy, _ = box.size
        ax.add_patch(Rectangle((x - sx / 2, y - sy / 2), sx, sy,
                               facecolor="#555555", edgecolor="#222222", alpha=0.36, zorder=2))
    ax.scatter([cfg.start_x_m, cfg.goal_x_m], [0.0, 0.0], s=80, c=["#111111", "#8b0000"], zorder=6)
    ax.annotate("start", (cfg.start_x_m, 0.0), xytext=(0.1, 0.35), fontsize=9)
    ax.annotate("goal", (cfg.goal_x_m, 0.0), xytext=(cfg.goal_x_m - 0.4, 0.35), fontsize=9)
    ax.set_title("Toy three-candidate upper-level scene")
    ax.set_xlabel("x / m")
    ax.set_ylabel("y / m")
    ax.set_aspect("equal", adjustable="box")
    ax.grid(alpha=0.22)
    ax.legend(loc="lower left", fontsize=8)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def copy_isaac_scene(path: Path, target: Path) -> Path | None:
    candidates = [
        path / "isaac_formula_goal0_repeat5" / "navigation.preview.jpg",
        path / "isaac_formula_goal0_probe2" / "navigation.preview.jpg",
        Path("/home/ky/Documents/Codex/2026-10-17/01a11a97-ce63-7a80-b8b4-91bef9bdc293/work/isaac_upper_v4/eval_reference_seed11_yp060/navigation.preview.jpg"),
    ]
    for candidate in candidates:
        if candidate.exists():
            shutil.copy2(candidate, target)
            return target
    return None


def draw_bar_chart(path: Path, rows: list[dict[str, Any]], metric: str, title: str, ylabel: str, isaac: bool = False) -> None:
    methods = ["formula", "bc", "ppo"] if isaac else ["shortest_rule", "enumerated_argmin", "categorical_ppo"]
    labels = [method_label(method) for method in methods]
    means, errors = [], []
    for method in methods:
        values = [float(row[metric]) for row in rows if row["method"] == method and math.isfinite(float(row[metric]))]
        means.append(float(np.mean(values)) if values else float("nan"))
        errors.append(float(np.std(values, ddof=1)) if len(values) > 1 else 0.0)
    fig, ax = plt.subplots(figsize=(8.2, 4.2), dpi=180)
    bars = ax.bar(labels, means, yerr=errors, capsize=4, color=["#377eb8", "#4daf4a", "#e41a1c"])
    ax.set_title(title)
    ax.set_ylabel(ylabel)
    ax.grid(axis="y", alpha=0.25)
    for bar, value in zip(bars, means):
        if math.isfinite(value):
            ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height(), f"{value:.2f}", ha="center", va="bottom", fontsize=8)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)


def make_table(data: list[list[Any]], widths: list[float] | None = None, header: bool = True) -> Table:
    table = Table(data, colWidths=widths, repeatRows=1 if header else 0)
    style = [
        ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#999999")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold" if header else "Helvetica"),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#eaf0f6") if header else colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 7.4),
        ("FONTNAME", (0, 0), (-1, -1), "CJK"),
        ("LEFTPADDING", (0, 0), (-1, -1), 4),
        ("RIGHTPADDING", (0, 0), (-1, -1), 4),
    ]
    table.setStyle(TableStyle(style))
    return table


def build_pdf(output_root: Path, pdf_path: Path) -> dict[str, Any]:
    output_root.mkdir(parents=True, exist_ok=True)
    assets = output_root / "report_assets"
    assets.mkdir(parents=True, exist_ok=True)
    toy_rows, toy_sources = load_toy(output_root)
    toy_route_choices = load_toy_route_choices(output_root)
    isaac_rows, isaac_sources = load_isaac_repeat(output_root)
    preliminary_rows = load_preliminary_isaac()

    toy_scene = assets / "toy_three_route_scene.png"
    draw_toy_scene(toy_scene)
    isaac_scene = copy_isaac_scene(output_root, assets / "isaac_scene.png")
    toy_time = assets / "toy_time.png"
    toy_energy = assets / "toy_energy.png"
    isaac_time = assets / "isaac_time.png"
    isaac_energy = assets / "isaac_energy.png"
    draw_bar_chart(toy_time, toy_rows, "elapsed_s", "Toy repeated evaluation: arrival time", "time / s")
    draw_bar_chart(toy_energy, toy_rows, "mechanical_energy_j", "Toy repeated evaluation: mechanical energy", "energy / J")
    if isaac_rows:
        draw_bar_chart(isaac_time, isaac_rows, "elapsed_s", "Isaac Sim repeated evaluation: arrival time", "time / s", isaac=True)
        draw_bar_chart(isaac_energy, isaac_rows, "mechanical_energy_j", "Isaac Sim repeated evaluation: mechanical energy", "energy / J", isaac=True)

    all_summary: dict[str, Any] = {
        "generated_on": str(date.today()),
        "output_root": str(output_root.resolve()),
        "toy_sources": toy_sources,
        "toy_route_choices_source": str(output_root / "toy_route_choices_detailed.json"),
        "toy_route_choices": toy_route_choices.get("aggregates", {}),
        "isaac_repeat_sources": isaac_sources,
        "toy_rows": toy_rows,
        "isaac_repeat_rows": isaac_rows,
        "preliminary_isaac_rows": preliminary_rows,
        "toy_stats": {},
        "isaac_repeat_stats": {},
    }
    toy_metrics = [
        "success_rate", "hard_violation_rate", "collision_rate", "elapsed_s", "distance_m",
        "mechanical_energy_j", "mechanical_cot", "minimum_lateral_clearance_m",
        "minimum_overhead_margin_m", "decision_latency_p50_ms", "decision_latency_p95_ms",
        "decision_latency_max_ms", "switches",
    ]
    for method in ("shortest_rule", "enumerated_argmin", "categorical_ppo"):
        method_rows = [row for row in toy_rows if row["method"] == method]
        all_summary["toy_stats"][method] = {
            metric: stat([float(row[metric]) for row in method_rows], 20261020 + index)
            for index, metric in enumerate(toy_metrics)
        }
    isaac_metrics = ["success", "hard_failure", "elapsed_s", "distance_m", "mechanical_energy_j", "objective_J"]
    for method in ("formula", "bc", "ppo"):
        method_rows = [row for row in isaac_rows if row["method"] == method]
        all_summary["isaac_repeat_stats"][method] = {
            "success_rate": stat([float(row["success"]) for row in method_rows], 20261100),
            "hard_failure_rate": stat([float(row["hard_failure"]) for row in method_rows], 20261101),
            **{
                metric: stat([float(row[metric]) for row in method_rows], 20261110 + index)
                for index, metric in enumerate(isaac_metrics[2:])
            },
        }

    (output_root / "comparison_summary.json").write_text(json.dumps(all_summary, indent=2, ensure_ascii=False), encoding="utf-8")
    with (output_root / "toy_repeat_metrics.csv").open("w", newline="", encoding="utf-8") as handle:
        if toy_rows:
            writer = csv.DictWriter(handle, fieldnames=sorted(toy_rows[0]))
            writer.writeheader()
            writer.writerows(toy_rows)
    with (output_root / "isaac_repeat_metrics.csv").open("w", newline="", encoding="utf-8") as handle:
        if isaac_rows:
            writer = csv.DictWriter(handle, fieldnames=sorted(isaac_rows[0]))
            writer.writeheader()
            writer.writerows(isaac_rows)

    styles = getSampleStyleSheet()
    for style_name in ("BodyText", "Title", "Heading2"):
        styles[style_name].fontName = "CJK"
    styles.add(ParagraphStyle(name="Small", parent=styles["BodyText"], fontName="CJK", fontSize=8.2, leading=10.5, spaceAfter=4))
    styles.add(ParagraphStyle(name="Tiny", parent=styles["BodyText"], fontName="CJK", fontSize=7.0, leading=8.5, spaceAfter=2))
    styles.add(ParagraphStyle(name="TitleCenter", parent=styles["Title"], fontName="CJK", alignment=TA_CENTER, fontSize=19, leading=23, spaceAfter=12))
    styles.add(ParagraphStyle(name="H2x", parent=styles["Heading2"], fontName="CJK", fontSize=13, leading=16, spaceBefore=8, spaceAfter=6))

    doc = SimpleDocTemplate(str(pdf_path), pagesize=A4, rightMargin=1.35 * cm, leftMargin=1.35 * cm,
                            topMargin=1.35 * cm, bottomMargin=1.35 * cm)
    story: list[Any] = []
    story.append(Paragraph("上层路径—姿态—速度决策实验比较报告", styles["TitleCenter"]))
    story.append(Paragraph("Isaac Sim 物理闭环与当前仓库 toy 接口级实验的协议核对、五次重复实验和结果解释", styles["Heading2"]))
    story.append(Spacer(1, 0.2 * cm))
    story.append(Paragraph(f"生成日期：{date.today()}。本报告暂不包含完整感知—决策—控制系统的第三层比较。", styles["Small"]))
    story.append(Paragraph("核心结论：两组实验不能直接把 PPO 的数值排名拼在一起。Isaac Sim 物理实验与 toy 实验的候选路径、动力学、能耗定义、训练分布和随机化协议不同；此外，原 Isaac 结果还使用了不同横向目标位置和不等样本数。因此，PPO 在一组数据中较优、在另一组中较差并不矛盾，首先说明的是实验协议不一致。", styles["BodyText"]))
    story.append(Spacer(1, 0.25 * cm))
    story.append(Paragraph("报告使用的数据", styles["H2x"]))
    story.append(Paragraph(f"toy 五次重复：{len(toy_rows)} 个方法—重复汇总行，原始文件位于 {output_root / 'toy_repeats'}。Isaac 五回合批次：{len(isaac_rows)} 个 episode 行，原始文件位于 {output_root} 下的 isaac_*_goal0_repeat5 目录。", styles["Small"]))

    story.append(Paragraph("1. 两次实验的场景", styles["H2x"]))
    story.append(Paragraph("Isaac Sim 场景是带真实 TITA 机器人、官方底层策略、ROS/NeuPAN 闭环、传感器接口、姿态高度层和机械能统计的物理仿真。三条候选路线对应低、中、高姿态层，局部规划与底层控制会改变真实执行轨迹。当前公平复测固定目标为 (x, y)=(8.0, 0.0) m。", styles["Small"]))
    story.append(Paragraph("toy 场景是同一上层接口的确定性三路线几何抽象：P1 是短而窄、低姿态可通过的路线；P2 是中等长度和中等顶部净空的路线；P3 是更长但更宽、顶部开放的路线。toy 中的机械能、时间和安全量是接口级 surrogate，不是 Isaac Sim 关节动力学量。", styles["Small"]))
    story.append(Image(str(toy_scene), width=17.8 * cm, height=9.8 * cm))
    story.append(Paragraph("图 1：toy 三候选路线场景。路线颜色分别表示 LOW、MID、HIGH 候选；灰色块为几何障碍/顶棚抽象。", styles["Tiny"]))
    if isaac_scene:
        story.append(Image(str(isaac_scene), width=17.8 * cm, height=9.6 * cm))
        story.append(Paragraph("图 2：Isaac Sim 物理闭环场景截图，来自已完成的 Formula-Argmin 探针/正式批次。", styles["Tiny"]))

    story.append(PageBreak())
    story.append(Paragraph("2. 为什么 PPO 的结果方向相反", styles["H2x"]))
    reasons = [
        "原 Isaac 结果的目标位置不同：y=-0.45、+0.60、+0.75 m；不同横向目标对应不同路线长度、姿态可行域和控制难度。toy 结果则在其自己的随机三路线分布上评估。",
        "原 Isaac 表中 Formula-Argmin/BC-only 为 3 个样本，而 PPO-reference 为 6 个样本；不同样本数量和不同目标难度的混合均值不是同一分布下的公平排名。",
        "Isaac PPO 是物理闭环、固定归一化、固定安全门和底层控制器下得到的策略；toy PPO checkpoint 不一定与 toy 环境当前的候选几何、归一化或目标权重完全匹配。",
        "Formula-Argmin 在 toy 中直接枚举并最小化与 toy 生成器一致的显式目标函数，因此它在该接口级环境中具有结构性优势；PPO 的 100% 到达率和 0% 硬约束违反率说明它更安全，但不说明它在时间/能耗目标上已充分训练。",
        "PPO 在 toy 中可能选择更保守的低速或更宽路径，导致时间、能耗上升；这属于安全—效率权衡，而不是“算法失效”。",
    ]
    for reason in reasons:
        story.append(Paragraph("• " + reason, styles["Small"]))
    story.append(Paragraph("原 Isaac 结果的逐目标事实核对", styles["H2x"]))
    preliminary_table = [["方法", "goal y / m", "时间 / s", "轨迹 / m", "机械能 / J"]]
    for row in preliminary_rows:
        preliminary_table.append([method_label(row["method"]), f"{row['goal_y_m']:+.2f}", f"{row['elapsed_s']:.2f}", f"{row['distance_m']:.3f}", f"{row['mechanical_energy_j']:.1f}"])
    story.append(make_table(preliminary_table, widths=[3.7 * cm, 2.2 * cm, 2.6 * cm, 2.6 * cm, 3.0 * cm]))
    story.append(Paragraph("从逐目标结果可以看到，Formula-Argmin 在 y=+0.60 m 的机械能低于 PPO-reference，而 BC-only 在 y=+0.75 m 也低于 PPO-reference；因此原 Isaac 总均值中 PPO 的优势不能被解释为对每一个目标都占优。", styles["Small"]))

    story.append(Paragraph("3. 复测协议", styles["H2x"]))
    story.append(Paragraph("Isaac Sim 五回合复测固定 goal_y=0.0、同一机器人 URDF、同一官方底层策略、同一 NeuPAN、同一姿态/速度标定、同一冻结归一化和同一仿真场景，只替换上层策略：Formula-Argmin、BC-only、PPO-reference。每种方法运行 5 个 evaluation episode，记录成功、硬失败、到达时间、实际轨迹和机械能。", styles["Small"]))
    story.append(Paragraph("toy 五次重复使用 seed=11、22、33、44、55；每个 seed 对 Shortest Rule、Formula-Argmin 和 Categorical PPO 各运行 108 个 test episodes。每个 seed 的汇总值再作为五次重复样本，避免把同一批 108 个 episode 误当成五个独立实验。", styles["Small"]))
    story.append(Paragraph("统计格式：表中数值为五次重复的均值 ± 样本标准差；括号内为对五个重复均值进行 10,000 次 bootstrap 得到的 95% percentile confidence interval。成功率和违反率也按每次重复的比例进行同样汇总。", styles["Small"]))

    story.append(Paragraph("4. toy 五次重复结果", styles["H2x"]))
    toy_table = [["方法", "到达率", "硬约束违反率", "时间 / s", "能耗 / J", "决策 P95 / ms", "横向净空 / m"]]
    for method in ("shortest_rule", "enumerated_argmin", "categorical_ppo"):
        stats = all_summary["toy_stats"].get(method, {})
        toy_table.append([
            method_label(method),
            fmt_stat(stats.get("success_rate", {}), 3),
            fmt_stat(stats.get("hard_violation_rate", {}), 3),
            fmt_stat(stats.get("elapsed_s", {}), 2),
            fmt_stat(stats.get("mechanical_energy_j", {}), 2),
            fmt_stat(stats.get("decision_latency_p95_ms", {}), 3),
            fmt_stat(stats.get("minimum_lateral_clearance_m", {}), 3),
        ])
    story.append(make_table(toy_table, widths=[2.2 * cm, 2.55 * cm, 2.55 * cm, 2.45 * cm, 2.45 * cm, 2.65 * cm, 2.65 * cm]))
    story.append(Spacer(1, 0.2 * cm))
    story.append(Image(str(toy_time), width=15.8 * cm, height=8.0 * cm))
    story.append(Image(str(toy_energy), width=15.8 * cm, height=8.0 * cm))
    if toy_route_choices:
        story.append(Paragraph("toy 自主选路：按锁定路线分组", styles["H2x"]))
        story.append(Paragraph("P1/P2/P3 分别对应 LOW/20 cm、MID/30 cm、HIGH/40 cm。路线分组使用进入 route lock 后的路线；若一开始没有可行动作，记为‘无路线’。表中的实际轨迹、时间和能耗均来自同一组 episode。", styles["Small"]))
        route_table = [["方法", "锁定路线", "回合数", "到达率", "时间 / s", "实际轨迹 / m", "名义路线 / m", "机械能 / J", "切换次数"]]
        route_names = {"0": "P1 LOW", "1": "P2 MID", "2": "P3 HIGH"}
        for method in ("shortest_rule", "enumerated_argmin", "categorical_ppo"):
            groups = toy_route_choices.get("aggregates", {}).get(method, {}).get("by_locked_route", {})
            for route in ("0", "1", "2"):
                group = groups.get(route, {})
                if not group.get("n"):
                    continue
                route_table.append([
                    method_label(method), route_names[route], str(group["n"]),
                    f"{100.0 * group['success_rate']:.1f}%", fmt(group["mean_elapsed_s"], 2),
                    fmt(group["mean_distance_m"], 3), fmt(group["mean_route_length_m"], 3),
                    fmt(group["mean_mechanical_energy_j"], 2), fmt(group["mean_switches"], 2),
                ])
            no_route = toy_route_choices.get("aggregates", {}).get(method, {}).get("no_route_count", 0)
            if no_route:
                route_table.append([method_label(method), "无路线", str(no_route), "0.0%", "0.00", "0.000", "NA", "0.00", "NA"])
        story.append(make_table(route_table, widths=[2.5 * cm, 2.2 * cm, 1.4 * cm, 1.7 * cm, 1.8 * cm, 2.0 * cm, 2.0 * cm, 2.1 * cm, 1.8 * cm]))

    story.append(PageBreak())
    story.append(Paragraph("5. Isaac Sim 五回合结果", styles["H2x"]))
    if isaac_rows:
        isaac_table = [["方法", "到达率", "硬失败率", "时间 / s", "轨迹 / m", "机械能 / J"]]
        for method in ("formula", "bc", "ppo"):
            stats = all_summary["isaac_repeat_stats"].get(method, {})
            isaac_table.append([
                method_label(method),
                fmt_stat(stats.get("success_rate", {}), 3),
                fmt_stat(stats.get("hard_failure_rate", {}), 3),
                fmt_stat(stats.get("elapsed_s", {}), 2),
                fmt_stat(stats.get("distance_m", {}), 3),
                fmt_stat(stats.get("mechanical_energy_j", {}), 1),
            ])
        story.append(make_table(isaac_table, widths=[2.7 * cm, 2.7 * cm, 2.7 * cm, 3.0 * cm, 3.0 * cm, 3.4 * cm]))
        story.append(Spacer(1, 0.2 * cm))
        story.append(Image(str(isaac_time), width=15.8 * cm, height=8.0 * cm))
        story.append(Image(str(isaac_energy), width=15.8 * cm, height=8.0 * cm))
    else:
        story.append(Paragraph("Isaac 五回合正式 JSON 尚未全部出现；本报告保留了场景图、原始预备结果和复测协议，但不会用缺失数据填充数值。", styles["Small"]))

    story.append(PageBreak())
    story.append(Paragraph("附录 A：五次重复的逐批次数据", styles["H2x"]))
    story.append(Paragraph("下表保留每次 toy 重复的汇总值。每行对应一个 seed 下的 108 个 test episodes；它不是把 108 个 episode 当作独立重复。", styles["Small"]))
    toy_repeat_table = [["seed", "方法", "到达率", "违反率", "时间 / s", "轨迹 / m", "能耗 / J", "P95 / ms"]]
    for row in sorted(toy_rows, key=lambda item: (item["repeat"], item["method"])):
        toy_repeat_table.append([
            str(row["repeat"]), method_label(row["method"]), f"{row['success_rate']:.3f}",
            f"{row['hard_violation_rate']:.3f}", f"{row['elapsed_s']:.2f}",
            f"{row['distance_m']:.3f}", f"{row['mechanical_energy_j']:.2f}",
            f"{row['decision_latency_p95_ms']:.3f}",
        ])
    story.append(make_table(toy_repeat_table, widths=[1.2 * cm, 3.0 * cm, 2.0 * cm, 2.0 * cm, 2.0 * cm, 2.0 * cm, 2.2 * cm, 2.0 * cm]))
    story.append(Spacer(1, 0.3 * cm))
    story.append(Paragraph("Isaac Sim 每个 episode 的原始结果", styles["Small"]))
    isaac_repeat_table = [["episode", "方法", "成功", "硬失败", "时间 / s", "轨迹 / m", "机械能 / J", "J"]]
    for row in sorted(isaac_rows, key=lambda item: (item["method"], item["repeat"])):
        isaac_repeat_table.append([
            str(row["repeat"]), method_label(row["method"]), "是" if row["success"] else "否",
            "是" if row["hard_failure"] else "否", f"{row['elapsed_s']:.2f}",
            f"{row['distance_m']:.3f}", f"{row['mechanical_energy_j']:.1f}", f"{row['objective_J']:.4f}",
        ])
    story.append(make_table(isaac_repeat_table, widths=[1.3 * cm, 3.0 * cm, 1.5 * cm, 1.8 * cm, 2.2 * cm, 2.2 * cm, 2.6 * cm, 2.2 * cm]))

    story.append(Paragraph("6. 指标和频率的解释", styles["H2x"]))
    story.append(Paragraph("本报告把‘频率’拆成三类：仿真/控制频率是 Isaac 时间戳中控制步之间的频率；局部规划频率是 NeuPAN 或 DCTP 每次生成控制命令的周期倒数；上层决策频率是 RL/Formula 每次重新选择候选执行方案的周期倒数。它们不能混成一个数字。toy 里的 decision latency 只表示上层函数调用延迟，不能代表 NeuPAN、物理仿真或机器人执行频率。", styles["Small"]))
    story.append(Paragraph("本批次已可靠记录的上层指标包括到达率、硬约束违反率、时间、实际轨迹、机械能、净空和上层决策延迟。CPU/GPU/内存占用如果没有在三种方法中使用统一采样器和相同窗口采集，就不应在论文中补填或推断。", styles["Small"]))

    story.append(Paragraph("7. 结论与限制", styles["H2x"]))
    conclusions = [
        "当前结果支持的结论是：Formula-Argmin 在 toy 接口环境中最符合显式目标函数，PPO 在该 toy checkpoint 上安全但效率较差；原 Isaac 预备实验中 PPO 的综合机械能较好，但该结论受到目标位置和样本数不一致的影响。",
        "本次固定 goal_y=0.0 的五回合 Isaac 复测中，PPO-reference 的平均机械能低于 Formula-Argmin 和 BC-only；因此可以表述为‘在该物理闭环协议下 PPO 的平均机械能更低’，但不能推广为 PPO 在所有路径和所有场景都更优。",
        "论文主比较应保留同一候选路径集合、同一底层局部规划器、同一传感器和同一安全门；第三层完整系统比较等上层感知—决策部署完成后再做。",
        "当前 toy 与 Isaac 的机械能单位不具备跨环境可比性，报告只在各自实验内比较，不把 12 J 与 2,000 J 放在同一排行榜中。",
    ]
    for item in conclusions:
        story.append(Paragraph("• " + item, styles["Small"]))
    story.append(Paragraph("复现文件", styles["H2x"]))
    for path in (
        output_root / "comparison_summary.json",
        output_root / "toy_repeat_metrics.csv",
        output_root / "isaac_repeat_metrics.csv",
        output_root / "toy_route_choices_detailed.json",
        output_root / "report_assets" / "toy_three_route_scene.png",
        output_root / "report_assets" / "isaac_scene.png",
    ):
        if path.exists():
            story.append(Paragraph(str(path.resolve()), styles["Tiny"]))

    doc.build(story)
    return all_summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--pdf", type=Path, required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    build_pdf(args.output_root.resolve(), args.pdf.resolve())
    print(args.pdf.resolve())


if __name__ == "__main__":
    main()
