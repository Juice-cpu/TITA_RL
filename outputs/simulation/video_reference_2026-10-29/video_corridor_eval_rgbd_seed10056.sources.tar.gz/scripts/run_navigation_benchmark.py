#!/usr/bin/env python3
"""Prepare or execute the two simulation-only maze comparison protocols."""

from __future__ import annotations

import argparse
from datetime import datetime
import hashlib
import importlib.util
import json
import os
import signal
from pathlib import Path
import subprocess
import sys
import time
from zoneinfo import ZoneInfo

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
SANDBOX = Path("/home/ky/neupan_tita_sandbox")
sys.path.insert(0, str(ROOT))
from tita_uc_residual_rl.navigation_benchmark import executed_geometry_features, path_comparison, protocol_speed_cap, summarize_physical_run
from tita_uc_residual_rl.navigation_maze import audit_competing_routes, box_distance_xy, load_maze, route_geometry_features, scene_digest


DEFAULT_CHECKPOINT = Path("/home/ky/Documents/Codex/2026-10-17/01a11a97-ce63-7a80-b8b4-91bef9bdc293/work/isaac_upper_v4/formal_reference_seed22/training/upper_policy_last.pt")
DEFAULT_NORMALIZATION = Path("/home/ky/Documents/Codex/2026-10-17/01a11a97-ce63-7a80-b8b4-91bef9bdc293/outputs/Isaac正式训练冻结归一化_v2_2026-10-18.json")


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def run_bounded(command, stream, environment, timeout_s):
    process = subprocess.Popen(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, env=environment, start_new_session=True)
    try:
        return process.wait(timeout=timeout_s)
    except (subprocess.TimeoutExpired, KeyboardInterrupt):
        os.killpg(process.pid, signal.SIGINT)
        try:
            process.wait(timeout=90)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
        raise


def reference_paths(scene, branch=None):
    source = SANDBOX / "ros2_ws/src/neupan_tita_sim/neupan_tita_sim/planning_core.py"
    specification = importlib.util.spec_from_file_location("benchmark_planning_core", source)
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    resolution = scene["map_resolution_m"]
    min_x, max_x, min_y, max_y = scene["bounds_xy_m"]
    width = round((max_x - min_x) / resolution) + 1
    height = round((max_y - min_y) / resolution) + 1
    grid_x, grid_y = np.meshgrid(min_x + np.arange(width) * resolution, min_y + np.arange(height) * resolution)
    points = np.column_stack((grid_x.flatten(), grid_y.flatten()))
    start = (round((scene["start_xy_m"][0] - min_x) / resolution), round((scene["start_xy_m"][1] - min_y) / resolution))
    goal = (round((scene["goal_xy_m"][0] - min_x) / resolution), round((scene["goal_xy_m"][1] - min_y) / resolution))
    paths = {}
    for layer_index, posture in enumerate(("LOW", "MID", "HIGH")):
        blocked = np.zeros(len(points), dtype=bool)
        for box in scene["boxes"]:
            bottom = box["center"][2] - box["size"][2] / 2
            if box["kind"] == "roof" and scene["posture_envelope_height_m"][layer_index] < bottom:
                continue
            blocked |= box_distance_xy(points, box) <= scene["planning_inflation_m"]
        if branch is not None:
            partition = scene["competing_routes"]["partition_y_m"]
            if branch not in ("north", "south"):
                raise ValueError("unknown branch constraint")
            blocked |= points[:, 1] < partition - 1e-8 if branch == "north" else points[:, 1] > partition + 1e-8
        if blocked[start[1] * width + start[0]] or blocked[goal[1] * width + goal[0]]:
            raise ValueError(f"{posture}: start or goal blocked, refusing nearest-free relocation")
        cells = module.astar_search(blocked.tolist(), width, height, start, goal)
        if not cells:
            raise ValueError(f"maze has no {posture} route")
        simplified = module.simplify_path(cells, blocked.tolist(), width)
        path = [[min_x + cell[0] * resolution, min_y + cell[1] * resolution] for cell in simplified]
        paths[posture] = {"xy_m": path, "features": route_geometry_features(scene, path, layer_index)}
    return paths


def draw_scene(scene, paths, output, results=None):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import Circle, Rectangle

    plt.rcParams.update({"font.family": "Noto Sans CJK JP", "axes.unicode_minus": False})
    figure, axis = plt.subplots(figsize=(13, 10))
    for box in scene["boxes"]:
        lower = np.asarray(box["center"][:2]) - np.asarray(box["size"][:2]) / 2
        roof = box["kind"] == "roof"
        axis.add_patch(Rectangle(lower, *box["size"][:2], facecolor="#e5ad44" if roof else "#5c7589", alpha=0.65 if roof else 0.95, hatch="//" if roof else None))
        if roof:
            underside = box["center"][2] - box["size"][2] / 2
            axis.text(*box["center"][:2], f"已知低顶棚\n下表面 {underside:.2f} m", ha="center", va="center", fontsize=8)
    contract = scene.get("competing_routes")
    if contract:
        for branch, label, color in [("north", "北侧路线 A", "#0891b2"), ("south", "南侧路线 B", "#a855f7")]:
            points = np.asarray(reference_paths(scene, branch)["MID"]["xy_m"])
            length = np.linalg.norm(np.diff(points, axis=0), axis=1).sum()
            axis.plot(*points.T, "--o", color=color, linewidth=2.3, markersize=4, label=f"{label}：{length:.2f} m（A* 预检）")
            anchor = contract["branches"][branch]["visibility_anchor_xy_m"]
            axis.plot([anchor[0], scene["goal_xy_m"][0]], [anchor[1], scene["goal_xy_m"][1]], ":", color=color, alpha=0.55)
        axis.plot([scene["start_xy_m"][0], scene["goal_xy_m"][0]], [scene["start_xy_m"][1], scene["goal_xy_m"][1]], ":", color="#ef4444", label="被主障碍挡住的起终点直线")
        for name, label in [("central_island", "主障碍"), ("north_branch_blocker", "北支路障碍"), ("south_branch_blocker", "南支路障碍")]:
            box = next(box for box in scene["boxes"] if box["name"] == name)
            axis.text(*box["center"][:2], label, ha="center", va="center", color="white", fontsize=10, rotation=90)
    else:
        for posture, style in [("LOW", "--"), ("MID", ":")]:
            points = np.asarray(paths[posture]["xy_m"])
            axis.plot(*points.T, style, alpha=0.7, label=f"{posture} 预检 A*（不是实测轨迹）")
    if results:
        for result in results:
            points = np.asarray(result["trajectory_xy_m"])
            axis.plot(*points.T, linewidth=1.8, label=f"{result['protocol']} / {result['algorithm']}：{result['navigation_time_s']:.2f}s / {'到达' if result['success'] else '失败'}")
    axis.add_patch(Circle(scene["start_xy_m"], scene["footprint_radius_m"], fill=False, edgecolor="#008b86"))
    axis.scatter(*scene["start_xy_m"], s=70, color="#008b86", label="起点 / 名义平面包络")
    axis.scatter(*scene["goal_xy_m"], marker="*", s=180, color="#d56545", label="目标；到达容差 0.35 m")
    min_x, max_x, min_y, max_y = scene["bounds_xy_m"]
    axis.set(xlim=(min_x - 0.4, max_x + 0.4), ylim=(min_y - 0.4, max_y + 0.4), xlabel="世界坐标 x（m）", ylabel="世界坐标 y（m）", title="TITA 双分支二次绕行迷宫" if contract else "TITA 交错迷宫")
    axis.set_aspect("equal")
    axis.grid(alpha=0.15)
    axis.legend(loc="upper left", bbox_to_anchor=(1.01, 1), fontsize=8)
    figure.text(0.06, 0.035, "地图 / 路线净空来自已知场景几何；LiDAR 为仿真射线；平地坡度与粗糙度为解析值，不是感知估计。", fontsize=10, color="#8f5424")
    figure.tight_layout(rect=(0, 0.07, 1, 1))
    figure.savefig(output, dpi=160)
    plt.close(figure)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--config", type=Path, default=ROOT / "configs/navigation_benchmark_v2.json")
    parser.add_argument("--checkpoint", type=Path, default=DEFAULT_CHECKPOINT)
    parser.add_argument("--normalization", type=Path, default=DEFAULT_NORMALIZATION)
    parser.add_argument("--protocols", nargs="+", choices=("safe_baselines", "equal_cruise"), default=["safe_baselines", "equal_cruise"])
    parser.add_argument("--algorithms", nargs="+", choices=("neupan", "dct", "rl"), default=["neupan", "dct", "rl"])
    parser.add_argument("--seeds", nargs="+", type=int, default=[22])
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--record-video", action="store_true")
    parser.add_argument("--measure-timing", action="store_true")
    parser.add_argument("--sudden-obstacle-config", type=Path)
    parser.add_argument("--wall-timeout-s", type=float, default=900)
    args = parser.parse_args()
    if args.sudden_obstacle_config is not None and not args.measure_timing:
        raise ValueError("sudden obstacle experiments require --measure-timing")
    output = args.output.resolve()
    if output.exists():
        raise FileExistsError("use a new output directory; evidence is never overwritten")
    output.mkdir(parents=True)
    config = json.loads(args.config.read_text())
    scene_file = (args.config.parent / config["scene"]).resolve()
    scene = load_maze(scene_file)
    if scene["goal_xy_m"] != [8.0, 0.0] or scene["start_xy_m"] != [0.0, 0.0]:
        raise ValueError("current benchmark launcher requires start (0,0), goal (8,0)")
    paths = reference_paths(scene)
    if scene.get("competing_routes"):
        branches = {branch: reference_paths(scene, branch) for branch in ("north", "south")}
        audit = audit_competing_routes(scene, branches)
        write_json(output / "branch_reference_paths.json", branches)
        write_json(output / "maze_geometry_audit.json", audit)
        if not audit["passed"]:
            raise ValueError(f"maze topology audit failed: {audit['errors']}")
    profile_source = (args.config.parent / config.get("motion_profile", "isaac_navigation_motion_v5_p0_lockstep.json")).resolve()
    base_profile = json.loads(profile_source.read_text())
    if base_profile["posture_vmax_mps"] != config["posture_vmax_mps"]:
        raise ValueError("benchmark speed contract and physical posture caps differ")
    governor_path = (profile_source.parent / base_profile["governor_calibration"]).resolve()
    write_json(output / "reference_paths.json", paths)
    write_json(output / "benchmark_config.json", config)
    write_json(output / "navigation_scene.json", scene)
    draw_scene(scene, paths, output / "maze_layout.png")
    dct_root = ROOT / "third_party/DCT"
    dune_root = SANDBOX / "vendor/NeuPAN"
    upstream = {}
    for name, repository in [("DCT", dct_root), ("NeuPAN", dune_root)]:
        upstream[name] = {
            "commit": subprocess.check_output(["git", "-C", str(repository), "rev-parse", "HEAD"], text=True).strip(),
            "working_tree": subprocess.check_output(["git", "-C", str(repository), "status", "--short"], text=True),
            "source_sha256": {str(path.relative_to(repository)): hashlib.sha256(path.read_bytes()).hexdigest() for path in repository.rglob("*.py") if ".git" not in path.parts},
        }
    manifest = {
        "created_at": datetime.now(ZoneInfo("America/Los_Angeles")).isoformat(),
        "simulation_only": True, "scene_sha256": scene_digest(scene_file),
        "checkpoint_sha256": hashlib.sha256(args.checkpoint.read_bytes()).hexdigest(),
        "normalization_sha256": hashlib.sha256(args.normalization.read_bytes()).hexdigest(),
        "upstream": upstream, "information_contract": scene["information_contract"],
        "dct_mode": config["dct_mode"], "scope": config["scope"],
        "rl_scope": config["rl_checkpoint_mode"], "formal_seeds": config["physical_seeds"],
        "actual_seeds": args.seeds, "prepare_only": args.prepare_only,
        "common_contract_sha256": {
            str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in [
                ROOT / "configs/isaac_navigation_postures.json",
                governor_path,
                profile_source,
                ROOT / "tita_rl_official/tita_example_10000.pt",
                SANDBOX / "ros2_ws/src/neupan_tita_sim/config/models/tita_urdf_mixed_5000.pth",
            ]
        },
    }
    write_json(output / "benchmark_manifest.json", manifest)
    print(f"Prepared maze: {output / 'maze_layout.png'}", flush=True)
    if args.prepare_only:
        return 0
    results, errors = [], []
    for protocol in args.protocols:
        for seed in args.seeds:
            for algorithm in args.algorithms:
                label = f"{protocol}_{algorithm}_seed{seed}"
                cap = protocol_speed_cap(config, protocol, algorithm)
                profile = dict(base_profile)
                planner_source = SANDBOX / "ros2_ws/src/neupan_tita_sim/config/tita_planner_isaac_motion_v5.yaml"
                planner = planner_source.read_text().replace("ref_speed: 0.35", f"ref_speed: {cap}").replace("max_speed: [0.35, 0.30]", f"max_speed: [{cap}, 0.30]")
                planner_path = output / f"{label}.planner.yaml"
                planner_path.write_text(planner)
                profile.update(planner_config=str(planner_path), governor_calibration=str(governor_path), benchmark_max_linear_speed_mps=cap, scope=f"maze benchmark pilot: {protocol}/{algorithm}; not an accepted replacement profile")
                profile_path = output / f"{label}.motion.json"
                write_json(profile_path, profile)
                run_dir = output / label
                command = ["bash", str(SANDBOX / "scripts/run_isaac_hmap_neupan_closed_loop.sh"),
                    "--run-output-dir", str(run_dir), "--headless", "--domain-id", "187", "--real-time-factor", "0",
                    "--steps", str(int(config["episode_timeout_s"] / 0.02) + 250), "--episode-length-s", str(config["episode_timeout_s"]),
                    "--evaluation-episodes", "1", "--training-seed", str(seed),
                    "--upper-policy", "ppo" if algorithm == "rl" else "fixed_mid_max",
                    "--upper-checkpoint", str(args.checkpoint), "--upper-normalization-file", str(args.normalization),
                    "--motion-profile", str(profile_path), "--navigation-scene-file", str(scene_file),
                    "--navigation-algorithm", "dct" if algorithm == "dct" else "neupan", "--record-diagnostics"]
                if args.record_video:
                    command += ["--record-video", "--video-label", f"MAZE / {protocol} / {algorithm} / cap {cap:.2f} mps / frozen policies"]
                write_json(output / f"{label}.invocation.json", {"command": command, "maximum_speed_mps": cap})
                print(f"Running {label}, command cap {cap:.2f} m/s", flush=True)
                started = time.monotonic()
                environment = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
                if args.measure_timing:
                    environment["TITA_TIMING_DIR"] = str(run_dir / "timing")
                    environment["PYTHONPATH"] = str(ROOT) + os.pathsep + environment.get("PYTHONPATH", "")
                if args.sudden_obstacle_config is not None:
                    from tita_uc_residual_rl.sudden_obstacle import load_sudden_obstacle
                    probe_config = load_sudden_obstacle(args.sudden_obstacle_config)
                    probe_path = run_dir.parent / f"{label}.sudden_obstacle.json"
                    write_json(probe_path, probe_config)
                    environment["TITA_SUDDEN_OBSTACLE_CONFIG"] = str(probe_path)
                with (output / f"{label}.launcher.log").open("x") as stream:
                    try:
                        returncode = run_bounded(command, stream, environment, args.wall_timeout_s)
                        if returncode:
                            raise RuntimeError(f"launcher exit status {returncode}")
                        planner_rows = [json.loads(line) for line in (run_dir / "planner_trace.jsonl").read_text().splitlines() if line.strip()]
                        selected_paths = [row["points"] for row in planner_rows if row["event"] == "path"]
                        if not selected_paths:
                            raise ValueError("planner did not record a selected path")
                        result = summarize_physical_run(run_dir, selected_paths[0], config, protocol, algorithm)
                        audit_command = [sys.executable, str(SANDBOX / "scripts/audit_isaac_training.py"), str(run_dir / "evaluation"), "--output", str(run_dir / "independent_audit.json")]
                        audit = subprocess.run(audit_command, capture_output=True, text=True)
                        if audit.returncode:
                            raise RuntimeError(f"action/reward audit failed: {audit.stderr or audit.stdout}")
                        result.update(seed=seed, wall_elapsed_s=time.monotonic() - started, action_reward_audit_passed=True)
                        sys.path.insert(0, str(ROOT / "scripts"))
                        from analyze_motion_chain import audit_planner_clock
                        physical_rows = [json.loads(line) for line in (run_dir / "control_trace.jsonl").read_text().splitlines() if line.strip()]
                        result["planner_clock_audit"] = audit_planner_clock(physical_rows)
                        result["actual_path_geometry"] = executed_geometry_features(scene, physical_rows)
                        solve_times = [row["solve_wall_s"] for row in planner_rows if row["event"] == "solve"]
                        result["planner_solve_wall_p95_s"] = float(np.percentile(solve_times, 95)) if solve_times else None
                        result["comparison_to_common_mid_preflight_reference"] = path_comparison(result["trajectory_xy_m"], paths["MID"]["xy_m"])
                        results.append(result)
                        print(f"  completed: success={result['success']}, time={result['navigation_time_s']:.2f}s, distance={result['distance_m']:.2f}m", flush=True)
                    except (OSError, ValueError, RuntimeError, KeyError, subprocess.TimeoutExpired) as error:
                        errors.append({"label": label, "error": str(error), "run_dir": str(run_dir)})
                        print(f"  failed: {error}", flush=True)
                write_json(output / "comparison_summary.json", {"simulation_only": True, "pilot_only": True, "results": results, "errors": errors})
    pairwise = []
    for first_index, first in enumerate(results):
        for second in results[first_index + 1:]:
            if first["seed"] == second["seed"] and first["protocol"] == second["protocol"]:
                pairwise.append({"protocol": first["protocol"], "seed": first["seed"], "algorithms": [first["algorithm"], second["algorithm"]], **path_comparison(first["trajectory_xy_m"], second["trajectory_xy_m"])})
    write_json(output / "comparison_summary.json", {"simulation_only": True, "pilot_only": True, "results": results, "errors": errors, "pairwise_path_overlap": pairwise})
    draw_scene(scene, paths, output / "maze_trajectories.png", results)
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
