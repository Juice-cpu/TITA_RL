#!/usr/bin/env python3
"""Run the upper joint policy inside Isaac Sim with vendor NeuPAN enabled.

The script intentionally fails closed: a missing NeuPAN dependency or planner
initialization error is fatal.  It does not silently fall back to pure
pursuit, which keeps this run distinct from the simulator-independent proxy
validation.
"""

from __future__ import annotations

import argparse
import hashlib
from dataclasses import asdict, replace
import json
import math
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from isaaclab.app import AppLauncher


parser = argparse.ArgumentParser()
parser.add_argument("--asset", required=True)
parser.add_argument("--checkpoint", required=True)
parser.add_argument("--upper-policy", type=Path)
parser.add_argument("--upper-ppo", action="store_true")
parser.add_argument("--upper-cost-prior", action="store_true")
parser.add_argument("--analytic-baseline", action="store_true")
parser.add_argument("--train-upper", action="store_true")
parser.add_argument("--upper-output", type=Path)
parser.add_argument("--episodes", type=int, default=1)
parser.add_argument("--candidate-count", type=int, choices=(1, 2, 3), default=3)
parser.add_argument("--simplify-global-paths", action="store_true")
parser.add_argument("--physical-perception", action="store_true")
parser.add_argument("--convex-cylinders", action="store_true")
parser.add_argument("--rendered-camera", action="store_true")
parser.add_argument("--record-camera-video", action="store_true")
parser.add_argument("--record-external-video", action="store_true")
parser.add_argument("--sensor-debug", action="store_true")
parser.add_argument("--smooth-commands", action="store_true")
parser.add_argument("--transition-cost-probe", type=Path)
parser.add_argument("--mode-conditioned-neupan", action="store_true")
parser.add_argument("--geometry-calibration", type=Path)
parser.add_argument("--dune-audit", type=Path)
parser.add_argument("--neupan-yaml", type=Path, required=True)
parser.add_argument("--vendor-root", type=Path, required=True)
parser.add_argument("--low-residual-checkpoint", type=Path, default=None)
parser.add_argument("--high-residual-checkpoint", type=Path)
parser.add_argument("--high-geometry-calibration", type=Path)
parser.add_argument("--high-step-validation", type=Path, nargs="+")
parser.add_argument("--posture-profile", type=Path, default=None)
parser.add_argument("--velocity-calibration", type=Path, default=None)
parser.add_argument("--terrain", choices=("flat", "tunnel", "stairs", "mixed"), default="flat")
parser.add_argument("--navigation-scene", type=Path)
parser.add_argument("--stair-height", type=float, default=.01)
parser.add_argument("--stair-width", type=float, default=1.3)
parser.add_argument("--stair-start", type=float, default=1.2)
parser.add_argument("--stair-count", type=int, default=1)
parser.add_argument("--stair-landing", type=float, default=5.)
parser.add_argument("--tunnel-height-range", type=float, nargs=2, default=None)
parser.add_argument("--tunnel-width-range", type=float, nargs=2, default=None)
parser.add_argument("--tunnel-length-range", type=float, nargs=2, default=None)
parser.add_argument("--tunnel-start-x", type=float, default=None)
parser.add_argument("--steps", type=int, default=250)
parser.add_argument("--seed", type=int, default=11)
parser.add_argument("--upper-period-steps", type=int, default=10)
parser.add_argument("--local-period-steps", type=int, default=5)
parser.add_argument("--goal-x", type=float, default=5.5)
parser.add_argument("--goal-y", type=float, default=0.0)
parser.add_argument("--dynamic-pedestrian", action="store_true")
parser.add_argument("--pedestrian-scenario", type=Path)
parser.add_argument("--pedestrian-motion-margin-m", type=float, default=0.)
parser.add_argument("--static-pedestrian-center-filter", action="store_true")
parser.add_argument("--observed-shuttle-prediction", action="store_true")
parser.add_argument("--bind-mode-motion-hold", action="store_true")
parser.add_argument("--wait-risk-horizon-s", type=float, default=5.)
parser.add_argument("--observed-shuttle-plateau-gate", action="store_true")
parser.add_argument('--observed-shuttle-astar-cost', action='store_true')
parser.add_argument('--observed-shuttle-neupan-flow', action='store_true')
parser.add_argument("--pedestrian-x-offset", type=float, default=2.0)
parser.add_argument("--pedestrian-y-offset", type=float, default=0.0)
parser.add_argument("--pedestrian-vy", type=float, default=0.15)
parser.add_argument("--max-vx", type=float, default=0.15)
parser.add_argument("--min-vx", type=float, default=None)
parser.add_argument("--max-wz", type=float, default=0.30)
parser.add_argument("--navigation-progress-timeout-s", type=float, default=60.)
parser.add_argument("--output", type=Path, required=True)
AppLauncher.add_app_launcher_args(parser)
args = parser.parse_args()
if args.static_pedestrian_center_filter and (not args.physical_perception or args.navigation_scene is None):
    parser.error('static pedestrian center filtering requires physical perception and an authored navigation scene')
if args.observed_shuttle_prediction and not (args.physical_perception and args.static_pedestrian_center_filter):
    parser.error('observed shuttle prediction requires physical perception and static interior-center filtering')
if args.bind_mode_motion_hold and not (args.observed_shuttle_prediction and args.geometry_calibration):
    parser.error('mode motion hold binding requires the explicit observed predictor and calibrated execution geometry')
if args.observed_shuttle_plateau_gate and not args.observed_shuttle_prediction:
    parser.error('motion plateau gate requires observed shuttle prediction')
if args.observed_shuttle_astar_cost and not args.observed_shuttle_prediction:
    parser.error('observed A* cost requires explicit observed shuttle prediction')
if args.observed_shuttle_neupan_flow and not args.observed_shuttle_prediction:
    parser.error('observed NeuPAN point flow requires explicit causal shuttle prediction')
if not math.isfinite(args.wait_risk_horizon_s) or args.wait_risk_horizon_s < 5.:
    parser.error('wait risk horizon must be finite and at least five seconds')
if args.wait_risk_horizon_s != 5. and not args.geometry_calibration:
    parser.error('extended wait risk horizon requires calibrated execution geometry')
if args.rendered_camera or args.record_external_video:
    args.enable_cameras = True
simulation_app = AppLauncher(args).app

import numpy as np  # noqa: E402
import torch  # noqa: E402
import yaml
import omni.timeline  # noqa: E402
import omni.usd  # noqa: E402

from tita_uc_residual_rl.isaaclab_tita_env import (  # noqa: E402
    HARD_REASON_NAMES,
    TitaResidualEnv,
    build_tita_cfg,
)
from tita_uc_residual_rl.joint_navigation import (  # noqa: E402
    GridScene,
    AStarConfig,
    AStarPlanner,
    IsaacJointFeedback,
    IsaacJointNavigationAdapter,
    JointLinearQPolicy,
    JointSafetyConfig,
    NeuPANBridge,
    Pedestrian,
    Pose2D,
    PostureSpec,
    nominal_pedestrian_clearance,
    fused_navigation_obstacles,
)
from tita_uc_residual_rl.official_policy import (  # noqa: E402
    FrozenOfficialTitaController,
    OfficialTitaActor,
)
from tita_uc_residual_rl.pedestrian_tracks import load_pedestrian_tracks
from tita_uc_residual_rl.experiment_provenance import input_hashes, snapshot_sources
from tita_uc_residual_rl.collision_envelope import UrdfCollisionEnvelope
from tita_uc_residual_rl.live_clearance_guard import LiveClearanceGuard, swept_ceiling_height
from tita_uc_residual_rl.navigation_command_limiter import MODE_COMMAND_LIMITS, limit_mode_navigation_command, curvature_preserving_command
from tita_uc_residual_rl.isaac_prior_scene import release_verified_riser_inflation
from tita_uc_residual_rl.stair_arrival_guard import StairArrivalGuard
from tita_uc_residual_rl.path_tracking_feedback import signed_path_tracking_error
from tita_uc_residual_rl.navigation_progress import NavigationProgressGuard
from tita_uc_residual_rl.phase_b_learner import (  # noqa: E402
    PhaseBActorCritic,
    load_phase_b_state_dict_compatible,
)
from tita_uc_residual_rl.posture_calibration import load_posture_calibration, posture_anchors
from tita_uc_residual_rl.velocity_calibration import load_velocity_calibration, blend_governor_parameters
from tita_uc_residual_rl.isaac_udp_bridge import governed_policy_command
from tita_uc_residual_rl.dynamic_perception import LidarPedestrianTracker
from tita_uc_residual_rl.isaac_scene_query import PhysicsDepthSensors
from tita_uc_residual_rl.geometry_calibration import load_geometry_calibration, calibrated_posture_specs, validate_planner_enclosure, validate_dune_audit
from tita_uc_residual_rl.mode_execution import ModeExecutionGuard
from tita_uc_residual_rl.mode_transition_calibration import load_transition_costs
from tita_uc_residual_rl.mode_conditioned_neupan import ModeConditionedNeuPANBridge, mode_solver_limits
from tita_uc_residual_rl.joint_ppo import JointPPOPolicy, FEATURE_CONTRACT, WAIT_ACTION_CONTRACT
from tita_uc_residual_rl.isaac_prior_scene import calibrated_prior_scene, fuse_observed_ceiling
from tita_uc_residual_rl.joint_reward import JointRewardWeights, joint_reward_terms, navigation_terminal_outcome
from tita_uc_residual_rl.route_continuity import route_change_distance
from tita_uc_residual_rl.navigation_command_limiter import MODE_COMMAND_LIMITS
from tita_uc_residual_rl.path_heading_guard import PathHeadingGuard
from tita_uc_residual_rl.goal_arrival import GoalArrivalGuard
from tita_uc_residual_rl.execution_contract import residual_training_scope, validate_high_specialist
from tita_uc_residual_rl.step_validation import load_validated_step_limits
from tita_uc_residual_rl.pedestrian_scene_validation import authored_pedestrian_obstacles, ground_height_at_xy, validate_pedestrian_trajectories, validate_pedestrian_tracks
from tita_uc_residual_rl.rendered_depth import depth_image_scan


def yaw_from_quaternion(quaternion: torch.Tensor) -> float:
    w, x, y, z = [float(value) for value in quaternion]
    return math.atan2(2.0 * (w * z + x * y), 1.0 - 2.0 * (y * y + z * z))


def make_world_scene(
    start_xy: tuple[float, float],
    goal_xy: tuple[float, float],
    terrain: str,
    tunnel_height_m: float | None = None,
) -> GridScene:
    resolution = 0.25
    origin = (start_xy[0] - 1.0, start_xy[1] - 2.5)
    width, height = 36, 24
    occupancy = np.zeros((height, width), dtype=bool)
    ceiling = np.full((height, width), 2.2, dtype=float)
    steps = np.zeros((height, width), dtype=float)
    start_cell = (int(math.floor((start_xy[0] - origin[0]) / resolution)), int(math.floor((start_xy[1] - origin[1]) / resolution)))
    if terrain == "tunnel":
        x0 = max(0, start_cell[0] + 3); x1 = min(width, x0 + 7)
        ceiling[:, x0:x1] = float(tunnel_height_m if tunnel_height_m is not None else 0.50)
        occupancy[:, x0:x1] = True
        occupancy[start_cell[1], x0:x1] = False
    elif terrain == "stairs":
        x0 = max(0, start_cell[0] + 4); x1 = min(width, x0 + 8)
        occupancy[:, x0:x1] = True
        occupancy[start_cell[1], x0:x1] = False
        steps[start_cell[1], x0:x1] = 0.08
    return GridScene(occupancy, ceiling, steps, resolution, origin)


def main() -> None:
    if args.output.exists():
        raise ValueError("evaluation output must be new")
    frozen_manifest = ROOT / "execution_sources.json"
    if frozen_manifest.exists():
        from freeze_execution_sources import verify_execution_sources
        verify_execution_sources(ROOT)
    source_provenance = snapshot_sources(ROOT, args.output.with_suffix(".sources.tar.gz"), args.vendor_root)
    artifacts = input_hashes({name: getattr(args, name) for name in (
        "asset", "checkpoint", "upper_policy", "low_residual_checkpoint", "posture_profile",
        "velocity_calibration", "geometry_calibration", "neupan_yaml", "pedestrian_scenario", "dune_audit",
        "high_residual_checkpoint", "high_geometry_calibration", "navigation_scene", "transition_cost_probe")})
    artifacts.update(input_hashes({f"step_validation_{index}": path for index, path in enumerate(args.high_step_validation or [])}))
    if frozen_manifest.exists():
        artifacts.update(input_hashes({"execution_source_manifest": frozen_manifest}))
    planner_configuration = yaml.safe_load(args.neupan_yaml.read_text())
    dune_checkpoint = planner_configuration.get("pan", {}).get("dune_checkpoint")
    if dune_checkpoint:
        artifacts.update(input_hashes({"dune_checkpoint": dune_checkpoint}))
    scenario_tracks = load_pedestrian_tracks(args.pedestrian_scenario) if args.pedestrian_scenario else ()
    scenario_people = tuple(track.state_at(0.) for track in scenario_tracks)
    if scenario_people:
        args.dynamic_pedestrian = True
    if args.steps <= 0 or args.upper_period_steps <= 0:
        raise ValueError("steps and upper-period-steps must be positive")
    if args.max_vx <= 0.0 or args.max_wz <= 0.0:
        raise ValueError("max-vx and max-wz must be positive")
    if not math.isfinite(args.pedestrian_motion_margin_m) or args.pedestrian_motion_margin_m < 0.:
        raise ValueError('pedestrian motion margin must be finite and nonnegative')
    min_vx = -args.max_vx if args.min_vx is None else float(args.min_vx)
    if min_vx > args.max_vx:
        raise ValueError("min-vx must not exceed max-vx")
    if not all(math.isfinite(value) for value in (
        args.goal_x, args.goal_y, args.pedestrian_x_offset,
        args.pedestrian_y_offset, args.pedestrian_vy, min_vx, args.max_vx, args.max_wz,
    )):
        raise ValueError("goal, pedestrian track, and velocity bounds must be finite")
    if not args.neupan_yaml.exists() or not args.vendor_root.exists():
        raise FileNotFoundError("NeuPAN vendor path/config does not exist")
    if args.train_upper and (not args.upper_ppo or args.upper_output is None):
        raise ValueError("upper training requires PPO and an explicit output checkpoint")
    if args.upper_output is not None and args.upper_output.exists():
        raise ValueError("upper output checkpoint must be new")
    if args.record_camera_video and not args.rendered_camera:
        raise ValueError("camera video requires actual rendered RGBD observations")
    if args.episodes < 1 or args.episodes > 1 and not args.train_upper:
        raise ValueError("multiple episodes are reserved for explicit training")
    if args.upper_ppo:
        policy = JointPPOPolicy.load(args.upper_policy, training=args.train_upper) if args.upper_policy else JointPPOPolicy(seed=args.seed, training=args.train_upper, cost_prior=args.upper_cost_prior)
        if args.upper_cost_prior:
            policy.model.cost_prior = True
    else:
        if args.upper_policy is None:
            raise ValueError("a frozen upper policy is required for evaluation")
        policy = JointLinearQPolicy.load(args.upper_policy)
    if args.analytic_baseline:
        if not args.upper_ppo:
            raise ValueError("analytic baseline requires the joint PPO action interface")
        policy.use_analytic_baseline()
    controller = NeuPANBridge(args.neupan_yaml, args.vendor_root)
    if controller.backend != "vendor":
        raise RuntimeError(f"NeuPAN vendor initialization failed: {controller.init_error}")
    cfg = build_tita_cfg(args.asset, num_envs=1, terrain="stairs" if args.terrain == "mixed" else args.terrain)
    cfg.convex_cylinder_collisions = args.convex_cylinders
    if args.navigation_scene is not None:
        from tita_uc_residual_rl.navigation_maze import load_maze, validate_execution_terrain
        maze = load_maze(args.navigation_scene)
        validate_execution_terrain(maze, args.terrain, [args.goal_x, args.goal_y],
                                   calibrated=args.geometry_calibration is not None,
                                   stair_start_m=args.stair_start, stair_width_m=args.stair_width,
                                   stair_count=args.stair_count, stair_landing_m=args.stair_landing)
        cfg.three_route_enabled = True
        cfg.navigation_scene_file = str(args.navigation_scene.resolve())
    if args.terrain == "mixed":
        if args.geometry_calibration is None:
            raise ValueError("mixed terrain requires calibrated full-body geometry")
        cfg.tunnel_enabled = True
    if cfg.stair_enabled:
        cfg.stair_step_height_range_m = (args.stair_height, args.stair_height)
        cfg.stair_width_range_m = (args.stair_width, args.stair_width)
        cfg.stair_tread_range_m = (.6, .6)
        cfg.stair_start_x_m = args.stair_start
        cfg.stair_num_steps = args.stair_count
        cfg.stair_landing_length_m = args.stair_landing
        cfg.stair_training_corridor_enabled = args.navigation_scene is None
        cfg.stair_step_assist_enabled = False
        cfg.stair_terminate_on_success = False
        cfg.stair_success_stable_hold_s = 1.
    cfg.seed = args.seed
    if args.rendered_camera:
        if not args.physical_perception:
            raise ValueError("rendered depth integration requires physical perception")
        cfg.rendered_inspection_camera_enabled = True
        cfg.sim.render_interval = 20
    if args.record_external_video:
        cfg.rendered_external_camera_enabled = True
        cfg.sim.render_interval = 20
    if args.geometry_calibration is not None:
        cfg.tunnel_terminate_on_success = False
    if args.physical_perception:
        if args.geometry_calibration is None:
            raise ValueError("physical perception requires full-body geometry calibration")
        cfg.sim.device = "cpu"
        cfg.sim.disable_contact_processing = False
        cfg.sim.enable_scene_query_support = True
        cfg.physical_pedestrian_enabled = args.dynamic_pedestrian
        cfg.physical_pedestrian_initial_xyz_m = (args.pedestrian_x_offset, args.pedestrian_y_offset, .9)
        cfg.physical_pedestrian_positions_xyz_m = tuple((person.x, person.y, .9) for person in scenario_people)
    cfg.navigation_goal_xy_m = (args.goal_x, args.goal_y)
    cfg.navigation_terminate_on_goal = False
    if args.posture_profile is not None:
        posture_profile = load_posture_calibration(args.posture_profile)
        cfg.posture_joint_anchors = posture_anchors(posture_profile)
        cfg.posture_heights = tuple(posture_profile["profiles"][name]["command_height_m"] for name in ("LOW", "MID", "HIGH"))
    cfg.episode_length_s = max(20.0, args.steps * 0.02 + 2.0)
    residual_payload = None
    execution_config = {}
    if args.low_residual_checkpoint is not None:
        residual_payload = torch.load(args.low_residual_checkpoint, map_location="cpu", weights_only=True)
        policy_config = residual_payload.get("policy_config", {})
        cfg.residual_limit = float(policy_config.get("residual_limit", cfg.residual_limit))
        cfg.posture_scale = float(policy_config.get("posture_scale", cfg.posture_scale))
        execution_config = dict(residual_payload.get("execution_config", {}))
        actual_scope = residual_training_scope(residual_payload)
        if execution_config.get("residual_postures", actual_scope) != actual_scope:
            execution_config["legacy_scope_metadata_corrected"] = execution_config["residual_postures"]
        execution_config["residual_postures"] = actual_scope
        for key, source in (("asset_sha256", args.asset), ("official_checkpoint_sha256", args.checkpoint)):
            if key in execution_config and execution_config[key] != hashlib.sha256(Path(source).read_bytes()).hexdigest():
                raise ValueError(f"residual execution {key} mismatch")
        training_config_path = args.low_residual_checkpoint.resolve().parents[1] / "config.json"
        if training_config_path.is_file():
            training_config = json.loads(training_config_path.read_text(encoding="utf-8"))
            for name in ("residual_filter_alpha", "acceleration_limit", "normalized_cost_clip"):
                execution_config.setdefault(name, training_config.get(name, getattr(cfg, name)))
            execution_config.setdefault("enforce_acceleration_limit", True)
            if "p95" in training_config.get("objective", {}):
                execution_config.setdefault("objective_p95", [
                    training_config["objective"]["p95"][name]
                    for name in ("route", "energy", "mode", "smooth")
                ])
        for name in ("residual_filter_alpha", "acceleration_limit", "enforce_acceleration_limit",
                     "normalized_cost_clip", "objective_p95", "posture_joint_anchors", "posture_heights", "navigation_pose_observations"):
            if name in execution_config:
                setattr(cfg, name, execution_config[name])
    high_payload = None
    high_execution = None
    step_limits = None
    if args.high_residual_checkpoint is not None:
        if args.low_residual_checkpoint is None or args.high_geometry_calibration is None or not args.high_step_validation:
            raise ValueError("a HIGH specialist requires a foundation, geometry and independent step validation")
        high_payload = torch.load(args.high_residual_checkpoint, map_location="cpu", weights_only=True)
        high_execution = validate_high_specialist(execution_config, high_payload)
        step_limits = load_validated_step_limits(args.high_step_validation, args.asset, args.checkpoint,
                                                args.high_residual_checkpoint, args.velocity_calibration,
                                                convex_cylinder_collisions=cfg.convex_cylinder_collisions)
    elif args.high_geometry_calibration is not None or args.high_step_validation:
        raise ValueError("HIGH execution evidence cannot be used without its exact controller")
    if cfg.tunnel_enabled:
        if args.tunnel_height_range is not None:
            cfg.tunnel_height_range_m = tuple(args.tunnel_height_range)
        if args.tunnel_width_range is not None:
            cfg.tunnel_width_range_m = tuple(args.tunnel_width_range)
        if args.tunnel_length_range is not None:
            cfg.tunnel_length_range_m = tuple(args.tunnel_length_range)
        if args.tunnel_start_x is not None:
            cfg.tunnel_start_x_m = float(args.tunnel_start_x)
    velocity_calibration = None
    if args.velocity_calibration is None and execution_config.get("velocity_calibration_prior"):
        args.velocity_calibration = Path(execution_config["velocity_calibration_prior"])
    if args.velocity_calibration is not None:
        if args.low_residual_checkpoint is not None and not execution_config.get("velocity_calibration_prior"):
            raise ValueError("frozen-controller velocity calibration cannot be combined with an uncalibrated residual")
        velocity_calibration = load_velocity_calibration(
            args.velocity_calibration, posture_joint_anchors=cfg.posture_joint_anchors,
            checkpoint_path=args.checkpoint, asset_path=args.asset,
        )
    env = TitaResidualEnv(cfg)
    obs, _ = env.reset()
    timeline = omni.timeline.get_timeline_interface()
    timeline.pause(); timeline.commit()
    requested_end = max(2.0, args.steps * float(env.step_dt) + 1.0)
    stage = omni.usd.get_context().get_stage()
    if stage is None:
        raise RuntimeError("Isaac USD stage is unavailable after reset")
    time_codes_per_second = float(stage.GetTimeCodesPerSecond())
    stage.SetStartTimeCode(0.0)
    stage.SetEndTimeCode(max(float(stage.GetEndTimeCode()), requested_end * time_codes_per_second))
    timeline.set_start_time(0.0)
    timeline.set_end_time(requested_end)
    timeline.set_looping(True)
    timeline.play(start_timecode=0.0, end_timecode=requested_end * time_codes_per_second, looping=True)
    timeline.commit()

    actor = OfficialTitaActor.from_checkpoint(args.checkpoint, device=env.device)
    base = FrozenOfficialTitaController(actor)
    base.reset(env.num_envs, env.device)
    low_residual = None
    high_residual = None
    if args.low_residual_checkpoint is not None:
        payload = residual_payload
        policy_config = payload.get("policy_config", {})
        low_residual = PhaseBActorCritic(
            obs_dim=obs["policy"].shape[-1],
            residual_limit=float(policy_config.get("residual_limit", cfg.residual_limit)),
            posture_scale=float(policy_config.get("posture_scale", cfg.posture_scale)),
        ).to(env.device)
        load_phase_b_state_dict_compatible(low_residual, payload["model_state_dict"])
        low_residual.eval()
    if high_payload is not None:
        high_configuration = high_payload["policy_config"]
        high_residual = PhaseBActorCritic(obs_dim=high_payload["model_state_dict"]["policy.network.0.weight"].shape[1], residual_limit=high_configuration["residual_limit"],
                                         posture_scale=high_configuration["posture_scale"]).to(env.device)
        load_phase_b_state_dict_compatible(high_residual, high_payload["model_state_dict"])
        high_residual.eval()

    posture_specs = (
        PostureSpec("LOW", float(cfg.posture_heights[0]), 0.08, 0.03, 0.55),
        PostureSpec("MID", float(cfg.posture_heights[1]), 0.14, 0.06, 0.85),
        PostureSpec("HIGH", float(cfg.posture_heights[2]), 0.20, 0.10, 1.05),
    )
    geometry_report = None
    planner_enclosure_margin_m = None
    if args.geometry_calibration is not None:
        geometry_report = load_geometry_calibration(args.geometry_calibration, args.asset, args.checkpoint, cfg.posture_joint_anchors, args.low_residual_checkpoint,
                                                  required_postures=("LOW", "MID") if high_payload is not None else ("LOW", "MID", "HIGH"),
                                                  required_support_height_m=args.stair_height * args.stair_count if cfg.stair_enabled else 0.,
                                                  velocity_calibration_path=args.velocity_calibration,
                                                  convex_cylinder_collisions=cfg.convex_cylinder_collisions)
        if high_payload is not None:
            high_geometry = load_geometry_calibration(args.high_geometry_calibration, args.asset, args.checkpoint,
                                                     cfg.posture_joint_anchors, args.high_residual_checkpoint, required_postures=("HIGH",),
                                                     required_support_height_m=args.stair_height * args.stair_count if cfg.stair_enabled else 0.,
                                                     velocity_calibration_path=args.velocity_calibration,
                                                     convex_cylinder_collisions=cfg.convex_cylinder_collisions)
            geometry_report["profiles"]["HIGH"] = high_geometry["profiles"]["HIGH"]
        posture_specs = calibrated_posture_specs(geometry_report)
        if step_limits is not None:
            posture_specs = (*posture_specs[:2], replace(posture_specs[2], max_step_m=step_limits.max_step_m,
                                                        vmax_mps=max(step_limits.speeds_mps), allowed_speeds_mps=step_limits.speeds_mps))
        planner_enclosure_margin_m = validate_planner_enclosure(geometry_report, controller.planner.robot.vertices.T)
        if args.dune_audit is None or dune_checkpoint is None:
            raise ValueError("full-body navigation requires a checkpoint and polygon bound DUNE audit")
        validate_dune_audit(args.dune_audit, dune_checkpoint, controller.planner.robot.vertices.T)
    if args.mode_conditioned_neupan:
        if not geometry_report:
            raise ValueError('mode-specific NeuPAN requires calibrated full-body execution bounds')
        controller = ModeConditionedNeuPANBridge(args.neupan_yaml, args.vendor_root,
            mode_solver_limits(posture_specs, geometry_report['profiles'], args.max_wz))
        validate_planner_enclosure(geometry_report, controller.planner.robot.vertices.T)
    initial_root = env.robot.data.root_pos_w[0, :2].detach().cpu().numpy()
    initial_xy = (float(initial_root[0]), float(initial_root[1]))
    scene = make_world_scene(
        initial_xy,
        (args.goal_x, args.goal_y),
        args.terrain,
        float(sum(cfg.tunnel_height_range_m) / 2.0) if args.terrain == "tunnel" else None,
    )
    if geometry_report:
        scene = calibrated_prior_scene(env, initial_xy, (args.goal_x, args.goal_y), geometry_report,
                                       planner_vertices_xy_m=controller.planner.robot.vertices.T,
                                       minimum_obstacle_clearance_m=float(planner_configuration["adjust"]["d_min"]))
    safety = JointSafetyConfig(geometry_lookahead_m=1.0, timed_dynamic_safety=True, staged_mode_switches=True,
                               transition_position_margin_m=.15, stationary_restart_prediction=True,
                               moving_speed_prediction=True, execution_timing_prediction=True,
                               risk_priced_wait=True, observed_shuttle_prediction=args.observed_shuttle_prediction,
                               wait_risk_horizon_s=args.wait_risk_horizon_s) if geometry_report else JointSafetyConfig()
    if geometry_report and args.upper_ppo:
        policy.configure_risk_priced_wait(args.upper_period_steps * float(env.step_dt))
    if geometry_report and args.smooth_commands:
        safety = replace(safety,
            braking_decelerations_mps2=tuple(MODE_COMMAND_LIMITS[name][0] for name in ('LOW', 'MID', 'HIGH')),
            braking_filter_times_s=tuple(MODE_COMMAND_LIMITS[name][2] for name in ('LOW', 'MID', 'HIGH')),
            braking_reaction_time_s=.30 + (args.upper_period_steps + args.local_period_steps) * float(env.step_dt))
    if args.transition_cost_probe:
        transition_costs = load_transition_costs(args.transition_cost_probe,
            {'asset': args.asset, 'checkpoint': args.checkpoint, 'residual': args.low_residual_checkpoint,
             'high_residual': args.high_residual_checkpoint, 'velocity_calibration': args.velocity_calibration},
            cfg.convex_cylinder_collisions, str(env.device))
        safety = replace(safety, expected_transition_costs_s=transition_costs)
    adapter = IsaacJointNavigationAdapter(policy, controller, posture_specs, safety=safety)
    observed_neupan_flows = {}
    if args.observed_shuttle_neupan_flow:
        from tita_uc_residual_rl.observed_neupan_flow import install_observed_neupan_flow
        observed_neupan_flows = install_observed_neupan_flow(controller)
    observed_neupan_flow_records = []
    observed_neupan_flow_calls = {mode: 0 for mode in observed_neupan_flows}
    astar_config = AStarConfig(candidate_count=args.candidate_count, diverse_routes=args.navigation_scene is not None,
                               simplify_paths=args.simplify_global_paths, observed_shuttle_cost=args.observed_shuttle_astar_cost)
    adapter.astar = AStarPlanner(astar_config)
    mode_guard = ModeExecutionGuard() if geometry_report else None
    if args.bind_mode_motion_hold:
        safety = replace(safety, minimum_mode_motion_hold_s=mode_guard.transition_s)
        adapter.safety = safety
    path_heading_guard = PathHeadingGuard() if geometry_report and args.navigation_scene else None
    live_clearance_guard = LiveClearanceGuard() if geometry_report else None
    live_envelope = UrdfCollisionEnvelope(args.asset, include_visual_geometry=True) if geometry_report else None
    live_body_height = None
    live_clearance_brake_steps = 0
    completed_riser_inflation_released = False
    camera_video_writer = None
    external_video_writer = None
    external_camera_frames = 0
    external_camera_image = None
    external_video_path = args.output.with_name(args.output.stem + ".external.mp4") if args.record_external_video else None
    if external_video_path is not None and external_video_path.exists():
        raise ValueError("external execution video must be new")
    camera_video_path = args.output.with_name(args.output.stem + ".camera.mp4") if args.record_camera_video else None
    if camera_video_path is not None and camera_video_path.exists():
        raise ValueError("camera video output must be new")
    sensors = PhysicsDepthSensors() if args.physical_perception else None
    static_solid_boxes = ()
    static_map_origin_xy_m = None
    if args.static_pedestrian_center_filter:
        origin_xy = env._environment_origins()[0, :2].detach().cpu().numpy()
        static_map_origin_xy_m = origin_xy.tolist()
        static_solid_boxes = tuple(tuple(np.r_[np.asarray(box['center'][:2]) + origin_xy, box['center'][2]] - np.asarray(box['size']) / 2.)
            + tuple(np.r_[np.asarray(box['center'][:2]) + origin_xy, box['center'][2]] + np.asarray(box['size']) / 2.)
            for box in maze['boxes'] if box['kind'] == 'wall')
    tracker = LidarPedestrianTracker(motion_margin_m=args.pedestrian_motion_margin_m,
        static_solid_boxes_xyz_m=static_solid_boxes,
        observed_shuttle_prediction=args.observed_shuttle_prediction,
        observed_shuttle_plateau_gate=args.observed_shuttle_plateau_gate) if sensors else None
    radar_index = env.robot.body_names.index("radar_link") if sensors else None
    observed_people = ()
    observed_points = np.empty((0, 2))
    observed_velocities = np.empty((0, 2))
    sensor_records = []
    episode_results = []
    upper_updates = []
    upper_reward = 0.0
    episode_index = 0
    episode_start_step = 0
    episode_start_distance = 0.0
    last_switch_time = -100.0
    reward_totals = {}
    observed_ceiling_points = 0
    risk = 0.0
    physical_pedestrian_contact_steps = 0
    peak_physical_pedestrian_contact_force_n = 0.0
    contact_feedback_steps = 0
    rendered_camera_frames = 0
    last_rgb_image = None
    overspeed_brake_steps = 0
    previous_decision = None
    previous_path = None
    pedestrians = scenario_people or ((Pedestrian(
        initial_xy[0] + args.pedestrian_x_offset, initial_xy[1] + args.pedestrian_y_offset,
        0.0, args.pedestrian_vy,
    ),) if args.dynamic_pedestrian else ())
    pedestrian_scene_validation = None
    if sensors and pedestrians:
        try:
            pedestrian_scene_validation = (validate_pedestrian_tracks if scenario_tracks else validate_pedestrian_trajectories)(
                scenario_tracks or pedestrians, authored_pedestrian_obstacles(env), args.steps * float(env.step_dt),
                args.stair_height * args.stair_count if cfg.stair_enabled else 0.)
        except ValueError as exc:
            args.output.write_text(json.dumps({"evaluation_status": "invalid_pedestrian_scenario", "success": False,
                                              "runtime_error": str(exc), "input_artifacts": artifacts,
                                              "execution_source_provenance": source_provenance}, indent=2))
            env.close()
            simulation_app.close()
            raise
    selected_postures: list[str] = []
    switch_count = 0
    planner_calls = 0
    planner_latencies: list[float] = []
    lidar_points = 0
    terminated = 0
    hard_reason_counts = np.zeros(len(HARD_REASON_NAMES), dtype=int)
    path_versions: list[int] = []
    collision_diagnostics: list[dict[str, object]] = []
    raw_commands: list[list[float]] = []
    limited_commands: list[list[float]] = []
    trajectory: list[dict[str, object]] = []
    sensor_frames = []
    decision_events = []
    stair_hold_started = False
    stair_arrival_guard = StairArrivalGuard()
    stair_execution_settled = False
    stair_stationary_steps = 0
    stair_hold_started_s = None
    execution_timeout_events = []
    navigation_progress_guard = NavigationProgressGuard(maximum_wait_s=args.navigation_progress_timeout_s)
    goal_arrival_guard = GoalArrivalGuard(tolerance_m=cfg.navigation_goal_tolerance_m, braking_entry_margin_m=.08)
    completed_steps = 0
    success = False
    terminal_root_position = None
    runtime_error = None
    safe_wait = False
    safe_wait_steps = 0
    safe_wait_decisions = 0
    pedestrian_overlap_steps = 0
    pedestrian_min_clearance = float("inf")
    traveled_distance_m = 0.0
    governor_parameters = dict(velocity_calibration["profiles"]["MID"]) if velocity_calibration else None
    command = torch.zeros((1, 3), device=env.device)
    posture_command = torch.nn.functional.one_hot(torch.ones(1, dtype=torch.long, device=env.device), 3).float()

    try:
        for step in range(args.steps * args.episodes):
            switched_this_step = False
            rapid_switch_this_step = False
            path_switched_this_step = False
            local_step = step - episode_start_step
            simulation_time = local_step * float(env.step_dt)
            if args.record_external_video and local_step % 5 == 0:
                camera_target = env.robot.data.root_pos_w.clone()
                camera_target[:, 2] = .3
                env.external_execution_camera.set_world_poses_from_view(camera_target + camera_target.new_tensor([[-2.5, -3., 2.5]]), camera_target)
            if cfg.stair_enabled and stair_execution_settled and not completed_riser_inflation_released:
                last_riser = float(env._environment_origins()[0, 0]) + cfg.stair_start_x_m + (cfg.stair_num_steps - 1) * float(env.stair_dimensions[0, 1])
                footprint = np.vstack([profile["footprint_vertices_xy_m"] for profile in geometry_report["profiles"].values()]
                                      + [controller.planner.robot.vertices.T])
                inflation_extent = float(np.abs(footprint[:, 0]).max()) + float(planner_configuration["adjust"]["d_min"]) + 1.5 * scene.resolution_m
                scene = release_verified_riser_inflation(scene, True, last_riser, cfg.wheel_radius + .03, inflation_extent)
                completed_riser_inflation_released = True
            root = env.robot.data.root_pos_w[0].detach().cpu().numpy().copy()
            posture_height_before = float(env.posture_height[0])
            wheel_contacts_before = env._wheel_contact[0].detach().cpu().tolist()
            stair_feedback_before = None
            if cfg.stair_enabled:
                stair_feedback_before = {
                    "traversed": bool(env.stair_traversed[0]),
                    "stationary_accepted": bool(env.stair_stationary_accepted[0]),
                    "wheel_levels": env._wheel_stair_state()[0][0].detach().cpu().tolist(),
                    "wheel_axis_positions_m": env.robot.data.body_pos_w[0, env._wheel_body_ids].detach().cpu().tolist(),
                    "wheel_ground_reference_z_m": env._stair_wheel_axis_reference_z[0].detach().cpu().tolist(),
                    "posture_target_height_m": float(env.posture_target_height[0]),
                    "root_velocity_world_mps": env.robot.data.root_lin_vel_w[0].detach().cpu().tolist(),
                }
            if local_step % 500 == 0:
                print(json.dumps({"navigation_progress": {"episode": episode_index, "step": local_step,
                                                          "position_xyz_m": root.tolist(), "posture_height_m": posture_height_before,
                                                          "wheel_contacts": wheel_contacts_before}}), flush=True)
            measured_velocity = env.robot.data.root_lin_vel_b[0].detach().cpu().tolist()
            measured_yaw_rate = float(env.robot.data.root_ang_vel_b[0, 2])
            yaw = yaw_from_quaternion(env.robot.data.root_quat_w[0].detach().cpu())
            people = (tuple(track.state_at(simulation_time) for track in scenario_tracks) if scenario_tracks else
                tuple(Pedestrian(person.x + person.vx * simulation_time, person.y + person.vy * simulation_time,
                                 person.vx, person.vy, person.radius_m) for person in pedestrians))
            oracle_people = people
            gravity = env.robot.data.projected_gravity_b[0].detach().cpu().numpy()
            roll = math.atan2(gravity[1], -gravity[2])
            pitch = math.atan2(-gravity[0], math.hypot(gravity[1], gravity[2]))
            if sensors:
                if pedestrians:
                    for actor_index, person in enumerate(people):
                        env.set_physical_pedestrian_target((person.x, person.y, .9 + ground_height_at_xy(env, (person.x, person.y))), actor_index)
                    oracle_people = tuple(Pedestrian(float(actor.data.root_pos_w[0, 0]), float(actor.data.root_pos_w[0, 1]),
                                                     0., 0., person.radius_m)
                                          for actor, person in zip(env.physical_pedestrians, pedestrians))
                if local_step % 5 == 0:
                    sensor_origin = env.robot.data.body_link_pos_w[0, radar_index].detach().cpu().numpy()
                    scan = sensors.lidar(sensor_origin, yaw, simulation_time, rays=360)
                    depth = sensors.gimbal_depth(sensor_origin, yaw, .1, simulation_time)
                    if args.rendered_camera:
                        camera = env.inspection_camera.data
                        depth = depth_image_scan(camera.output["distance_to_image_plane"][0].detach().cpu().numpy(),
                                                 camera.intrinsic_matrices[0].detach().cpu().numpy(), camera.pos_w[0].detach().cpu().numpy(),
                                                 camera.quat_w_ros[0].detach().cpu().numpy(), simulation_time)
                        last_rgb_image = camera.output["rgb"][0, :, :, :3].detach().cpu().numpy().copy()
                        if args.record_camera_video:
                            import cv2
                            if camera_video_writer is None:
                                image_height, image_width = last_rgb_image.shape[:2]
                                camera_video_writer = cv2.VideoWriter(str(camera_video_path), cv2.VideoWriter_fourcc(*"mp4v"),
                                                                      1. / (5. * float(env.step_dt)), (image_width, image_height))
                                if not camera_video_writer.isOpened():
                                    raise RuntimeError("cannot open actual RGB camera video encoder")
                            camera_video_writer.write(cv2.cvtColor(last_rgb_image, cv2.COLOR_RGB2BGR))
                        rendered_camera_frames += 1
                    observed_points = scan.points_world_m[:, :2]
                    observed_people = tracker.update(observed_points, simulation_time, scan_height_m=float(sensor_origin[2]))
                    observed_velocities = tracker.point_velocities(observed_points)
                    if args.sensor_debug:
                        sensor_frames.append({"episode": episode_index, "time_s": simulation_time,
                                              "points_xy_m": observed_points.tolist(), "body_paths": list(scan.body_paths),
                                              "tracks": [asdict(person) for person in observed_people]})
                    if geometry_report:
                        footprint_extent = np.abs(np.vstack([profile["footprint_vertices_xy_m"] for profile in geometry_report["profiles"].values()])).max(0) + .05
                        scene, detected_ceiling_points = fuse_observed_ceiling(scene, depth, float(env._environment_origins()[0, 2]), footprint_extent, observed_people)
                        observed_ceiling_points += detected_ceiling_points
                    sensor_records.append({"step": step, "episode": episode_index, "lidar_hits": len(observed_points),
                                           "observation_time_s": simulation_time,
                                           "motion_track_observations": [{"identifier": track.identifier, "observations": track.observations,
                                               "last_seen_s": track.last_seen_s} for track in tracker.tracks],
                                           "depth_hits": len(depth.points_world_m), "tracks": [asdict(person) for person in observed_people],
                                           "motion_context": [asdict(context) for context in tracker.motion_context()],
                                           "static_center_filter": {"enabled": args.static_pedestrian_center_filter,
                                               "scan_height_m": float(sensor_origin[2]),
                                               "candidate_detections": tracker.last_circle_detections,
                                               "rejected_centers_xy_m": tracker.last_rejected_static_centers_xy_m}})
                    if local_step % 250 == 0:
                        sensor_records[-1]["debug"] = {"origin_xyz_m": sensor_origin.tolist(), "points_xyz_m": scan.points_world_m.tolist(),
                                                        "body_paths": list(scan.body_paths)}
                    lidar_points += len(observed_points)
                people = observed_people
            if observed_neupan_flows:
                observed_contexts = tracker.motion_context()
                for flow in observed_neupan_flows.values():
                    flow.update(people, observed_contexts, simulation_time)
            if mode_guard:
                mode_guard.observe(simulation_time, float(env.posture_height[0]), cfg.posture_heights[mode_guard.mode],
                                   math.hypot(*measured_velocity[:2]), roll, pitch, bool(env._wheel_contact[0].all()))
                if mode_guard.advance(simulation_time):
                    switched_this_step = True
                    rapid_switch_this_step = simulation_time - last_switch_time < 10.
                    last_switch_time = simulation_time
                    switch_count += 1
                    posture_command = torch.nn.functional.one_hot(torch.tensor([mode_guard.mode], device=env.device), 3).float()
                    selected_postures.append(("LOW", "MID", "HIGH")[mode_guard.mode])
            clearance = nominal_pedestrian_clearance(
                Pose2D(float(root[0]), float(root[1]), yaw),
                np.asarray(geometry_report["profiles"][("LOW", "MID", "HIGH")[mode_guard.mode]]["footprint_vertices_xy_m"]) if geometry_report else controller.planner.robot.vertices.T,
                oracle_people,
            )
            pedestrian_min_clearance = min(pedestrian_min_clearance, clearance)
            pedestrian_overlap_steps += int(clearance < 0.0)
            decision_ready = ((mode_guard is None or (mode_guard.pending_mode is None
                              and (mode_guard.ready or previous_decision is None)))
                              and not (stair_hold_started and not stair_execution_settled))
            if local_step % args.upper_period_steps == 0 and decision_ready and not goal_arrival_guard.braking:
                if args.train_upper and policy.last_transition is not None:
                    policy.finish_transition(upper_reward, False)
                    upper_reward = 0.0
                gravity = env.robot.data.projected_gravity_b[0].detach().cpu().tolist()
                roll = math.atan2(gravity[1], -gravity[2])
                pitch = math.atan2(-gravity[0], math.hypot(gravity[1], gravity[2]))
                feedback = IsaacJointFeedback(
                    Pose2D(float(root[0]), float(root[1]), yaw), (args.goal_x, args.goal_y), scene, people,
                    roll_rad=roll, pitch_rad=pitch,
                    measured_speed_mps=math.hypot(*measured_velocity[:2]),
                    obstacle_points_xy_m=observed_points if sensors else None,
                    obstacle_velocities_xy_mps=observed_velocities if sensors else None,
                    mode_switch_allowed=mode_guard.may_switch(simulation_time) if mode_guard else True,
                    executed_posture_index=mode_guard.mode if mode_guard else None,
                    pedestrian_motion_context=tracker.motion_context() if tracker else (),
                    previous_path=previous_path,
                )
                decision, (vx, wz), observation = adapter.step(feedback)
                decision_events.append({"episode": episode_index, "time_s": simulation_time,
                                        "navigation_cost_summary": adapter.last_navigation_cost_summary,
                                        "pose_xy_m": root[:2].tolist(), "actual_posture": ("LOW", "MID", "HIGH")[mode_guard.mode] if mode_guard else None,
                                        "decision": asdict(decision), "valid_actions": observation.valid_actions.tolist(),
                                        "action_features": observation.action_features.tolist(),
                                        "candidates": [{"id": path.path_id, "length_m": path.length_m,
                                                        "continuation_of_path_id": path.continuation_of_path_id,
                                                        "start_recovery": asdict(path.start_recovery) if path.start_recovery else None,
                                                        "points_xy_m": path.points_xy_m.tolist()} for path in observation.paths]})
                risk = observation.pedestrian_risk
                if decision.valid:
                    risk = float(observation.action_features[decision.action_id, 8])
                elif safety.risk_priced_wait and decision.reason == 'ppo_safe_wait':
                    risk = float(observation.action_features[-1, 8])
                safe_wait = not decision.valid
                safe_wait_decisions += int(safe_wait)
                if decision.valid:
                    route_change_m = route_change_distance(previous_path, observation.paths[decision.path_index], root[:2])
                    path_switched_this_step = route_change_m > .35
                    decision_events[-1]['route_change'] = {'distance_m': route_change_m,
                        'threshold_m': .35, 'lookahead_m': 3., 'switched': path_switched_this_step,
                        'candidate_index_is_not_route_identity': True}
                    previous_decision = decision
                    previous_path = observation.paths[decision.path_index]
                    planner_latencies.append(controller.last_latency_ms)
                    if mode_guard:
                        previous_mode = mode_guard.mode
                        mode_guard.request(decision.posture_index, simulation_time)
                        applied_mode = mode_guard.mode
                    else:
                        previous_mode = int(posture_command.argmax(dim=1)[0])
                        applied_mode = decision.posture_index
                    if applied_mode != previous_mode:
                        switched_this_step = True
                        rapid_switch_this_step = simulation_time - last_switch_time < 10.
                        switch_count += 1
                        last_switch_time = simulation_time
                    posture_command = torch.nn.functional.one_hot(torch.tensor([applied_mode], device=env.device), 3).float()
                    selected_postures.append(("LOW", "MID", "HIGH")[applied_mode])
                planner_calls += 1
                path_versions.append(observation.replan_id)
            elif safe_wait:
                vx, wz = 0.0, 0.0
            elif local_step % args.local_period_steps == 0:
                if previous_path is None or previous_decision is None:
                    raise RuntimeError("planner state was not initialized")
                points, velocities = fused_navigation_obstacles(people,
                    observed_points if sensors else None, observed_velocities if sensors else None)
                if getattr(env.cfg, "navigation_lidar", None) is not None:
                    hits = env._navigation_lidar.data.ray_hits_w[0, :, :2].detach().cpu().numpy()
                    lidar = hits[np.isfinite(hits).all(axis=1)]
                    points = lidar if points is None else np.vstack((points, lidar))
                    static_velocities = np.zeros_like(lidar)
                    velocities = static_velocities if velocities is None else np.vstack((velocities, static_velocities))
                    lidar_points += len(lidar)
                vx, wz = controller.command(Pose2D(float(root[0]), float(root[1]), yaw), previous_path, points, velocities, adapter.current_speed_mps)
                planner_latencies.append(controller.last_latency_ms)
            safe_wait_steps += int(safe_wait)
            for mode, flow in observed_neupan_flows.items():
                if flow.calls != observed_neupan_flow_calls[mode]:
                    observed_neupan_flow_records.append({'episode': episode_index, 'step': step,
                        'mode_solver': mode, 'summary': flow.last_summary})
                    observed_neupan_flow_calls[mode] = flow.calls
            active_posture_index = int(posture_command.argmax(dim=1)[0])
            active_posture = ("LOW", "MID", "HIGH")[active_posture_index]
            if (cfg.stair_enabled and not stair_hold_started
                    and stair_arrival_guard.observe(simulation_time, bool(env.stair_traversed[0]), all(wheel_contacts_before))):
                if not stair_hold_started:
                    stair_hold_started_s = simulation_time
                stair_hold_started = True
            if stair_hold_started and not stair_execution_settled:
                stair_stationary_steps = stair_stationary_steps + 1 if bool(env.stair_stationary_accepted[0]) else 0
                stair_execution_settled = stair_stationary_steps * float(env.step_dt) >= 1.
            raw_commands.append([float(vx), float(wz)])
            limited_commands.append([0.0, 0.0] if safe_wait else [float(np.clip(vx, min_vx, args.max_vx)), float(np.clip(wz, -args.max_wz, args.max_wz))])
            if geometry_report:
                mode_speed_limit = posture_specs[active_posture_index].vmax_mps
                chosen_speed_limit = min(mode_speed_limit, adapter.current_speed_mps) if not safe_wait else mode_speed_limit
                yaw_limit = min(args.max_wz, geometry_report["profiles"][active_posture].get("validated_yaw_rate_radps", .20))
                target_velocity, target_yaw_rate = curvature_preserving_command(limited_commands[-1], chosen_speed_limit, yaw_limit)
                if path_heading_guard and not safe_wait:
                    target_velocity, target_yaw_rate = path_heading_guard.apply(
                        Pose2D(float(root[0]), float(root[1]), yaw), previous_path,
                        [target_velocity, target_yaw_rate], math.hypot(*measured_velocity[:2]), scene.recovery_geometry,
                        reference_heading_rad=controller.last_status.get('reference_heading_rad'))
                if args.smooth_commands:
                    limited_commands[-1] = limit_mode_navigation_command([float(command[0, 0]), float(command[0, 2])],
                                                                        [target_velocity, target_yaw_rate], active_posture, float(env.step_dt))
                else:
                    limited_commands[-1] = [float(np.clip(target_velocity, float(command[0, 0]) - .30 * env.step_dt, float(command[0, 0]) + .30 * env.step_dt)),
                                            float(np.clip(target_yaw_rate, float(command[0, 2]) - .60 * env.step_dt, float(command[0, 2]) + .60 * env.step_dt))]
                if safe_wait and decision.reason != "ppo_safe_wait":
                    limited_commands[-1] = [0., 0.]
            overspeed_brake = bool(geometry_report and math.hypot(*measured_velocity[:2]) > posture_specs[active_posture_index].vmax_mps + .05)
            overspeed_brake_steps += int(overspeed_brake)
            if overspeed_brake:
                limited_commands[-1] = [0., 0.]
            if mode_guard and (not mode_guard.ready or mode_guard.pending_mode is not None):
                limited_commands[-1] = [0., 0.]
            if goal_arrival_guard.braking:
                limited_commands[-1] = [0., 0.]
            if stair_hold_started and not stair_execution_settled:
                limited_commands[-1] = [0., 0.]
            if live_clearance_guard:
                body_points = live_envelope.points_world(env.robot.body_names, env.robot.data.body_link_pos_w[0].detach().cpu().numpy(),
                                                        env.robot.data.body_link_quat_w[0].detach().cpu().numpy())
                ground = float(env._environment_origins()[0, 2] + env._stair_support_height()[0])
                live_body_height = float(max(points[:, 2].max() for points in body_points.values()) - ground)
                velocity_world = env.robot.data.root_lin_vel_w[0, :2].detach().cpu().numpy()
                ceiling_preview = swept_ceiling_height(scene, root[:2], velocity_world)
                if live_clearance_guard.update(simulation_time, live_body_height, ceiling_preview):
                    limited_commands[-1] = [0., 0.]
                    live_clearance_brake_steps += 1
            command = torch.tensor([[limited_commands[-1][0], 0.0, limited_commands[-1][1]]], device=env.device, dtype=torch.float32)
            env.set_velocity_command(command)
            transition_phase = mode_guard.command_phase(simulation_time, float(env.step_dt)) if mode_guard else 0.
            if high_residual is not None and active_posture == "HIGH":
                transition_phase = 0.
            env.set_posture_command(posture_command, command.new_tensor([[transition_phase]]))
            if cfg.navigation_pose_observations and previous_path is not None:
                env.set_path_pose_error(command.new_tensor([signed_path_tracking_error(previous_path.points_xy_m, root[:2], yaw, heading_lookahead_m=.25)]))
            obs = env._get_observations()
            with torch.no_grad():
                proprioception = env.official_proprioception(base.previous_policy_action)
                if velocity_calibration is not None:
                    governor_parameters = blend_governor_parameters(
                        governor_parameters,
                        velocity_calibration["profiles"][active_posture],
                        min(float(env.step_dt) / cfg.posture_feedforward_transition_s, 1.0),
                    )
                    policy_command = governed_policy_command(
                        tuple(float(value) for value in command[0].detach().cpu()),
                        (measured_velocity[0], measured_velocity[1], measured_yaw_rate),
                        **governor_parameters,
                    )
                    proprioception[:, 6:9] = proprioception.new_tensor(policy_command) * proprioception.new_tensor([2.0, 2.0, 0.25])
                base_target, _ = base.target(proprioception, env.default_joint_target())
                env.set_base_target(base_target)
                action = torch.zeros(1, 8, device=env.device)
                if low_residual is not None and (active_posture in execution_config.get("residual_postures", ["LOW"])
                                                                         or high_residual is not None and active_posture == "HIGH"):
                    selected_residual = high_residual if high_residual is not None and active_posture == "HIGH" else low_residual
                    selected_configuration = high_payload["policy_config"] if selected_residual is high_residual else residual_payload["policy_config"]
                    cfg.residual_limit = selected_configuration["residual_limit"]
                    cfg.posture_scale = selected_configuration["posture_scale"]
                    action = selected_residual.policy(obs["policy"][:, :selected_residual.policy.network[0].in_features])
            obs, _, done, truncated, _ = env.step(action)
            if args.record_external_video and local_step % 5 == 0:
                import cv2
                external_camera_image = env.external_execution_camera.data.output["rgb"][0, :, :, :3].detach().cpu().numpy().copy()
                if external_video_writer is None:
                    image_height, image_width = external_camera_image.shape[:2]
                    external_video_writer = cv2.VideoWriter(str(external_video_path), cv2.VideoWriter_fourcc(*"mp4v"),
                                                           1. / (5. * float(env.step_dt)), (image_width, image_height))
                    if not external_video_writer.isOpened():
                        raise RuntimeError("cannot open actual external camera video encoder")
                external_video_writer.write(cv2.cvtColor(external_camera_image, cv2.COLOR_RGB2BGR))
                external_camera_frames += 1
            contact_feedback_steps += int(bool(env._wheel_contact[0].any()))
            if sensors and local_step >= 150 and not contact_feedback_steps:
                raise RuntimeError("wheel-contact feedback remained zero for three simulated seconds")
            pedestrian_contact_force = float(env.last_step_pedestrian_contact_force[0]) if cfg.physical_pedestrian_enabled else 0.0
            physical_pedestrian_contact_steps += int(pedestrian_contact_force > 1.)
            peak_physical_pedestrian_contact_force_n = max(peak_physical_pedestrian_contact_force_n, pedestrian_contact_force)
            terminal_position = env.last_transition_root_position[0].detach().cpu().numpy().copy()
            current_position = terminal_position[:2]
            goal_distance = float(np.linalg.norm(current_position - np.asarray([args.goal_x, args.goal_y])))
            arrival_velocity = env.robot.data.root_lin_vel_b[0].detach().cpu().tolist()
            arrival_yaw_rate = float(env.robot.data.root_ang_vel_b[0, 2])
            arrival_gravity = env.robot.data.projected_gravity_b[0].detach().cpu().tolist()
            arrival_roll = math.atan2(arrival_gravity[1], -arrival_gravity[2])
            arrival_pitch = math.atan2(-arrival_gravity[0], math.hypot(arrival_gravity[1], arrival_gravity[2]))
            reached = goal_arrival_guard.observe(
                simulation_time, goal_distance, math.hypot(*arrival_velocity[:2]), arrival_yaw_rate,
                arrival_roll, arrival_pitch, bool(env._wheel_contact[0].all()),
                (mode_guard is None or mode_guard.ready and mode_guard.pending_mode is None)
                and abs(float(env.posture_height[0]) - cfg.posture_heights[active_posture_index]) <= .025)
            execution_timeout_reason = None
            if navigation_progress_guard.observe(simulation_time, float(np.linalg.norm(current_position - np.asarray([args.goal_x, args.goal_y])))) and not reached:
                execution_timeout_reason = "navigation_no_progress_timeout"
            if mode_guard and mode_guard.execution_timed_out(simulation_time):
                execution_timeout_reason = "posture_execution_timeout"
            if stair_hold_started_s is not None and not stair_execution_settled and simulation_time - stair_hold_started_s >= 24.:
                execution_timeout_reason = "stair_stationary_execution_timeout"
            if execution_timeout_reason:
                execution_timeout_events.append({"episode": episode_index, "step": step, "reason": execution_timeout_reason})
                reached = False
            progress = float(np.linalg.norm(root[:2] - np.asarray([args.goal_x, args.goal_y])) - np.linalg.norm(current_position - np.asarray([args.goal_x, args.goal_y])))
            power = float(env.last_step_energy[0]) / float(env.step_dt)
            horizon = local_step + 1 >= args.steps
            reached, terminal_failure, episode_end = navigation_terminal_outcome(
                reached, bool(done[0]), bool(truncated[0]), execution_timeout_reason is not None,
                clearance, pedestrian_contact_force, horizon)
            terms = joint_reward_terms(progress, float(env.step_dt), float(env.last_step_distance[0]), power, risk,
                                       clearance, roll, pitch, switched_this_step, rapid_switch_this_step,
                                       path_switched_this_step, reached, terminal_failure)
            upper_reward += sum(terms.values())
            for name, value in terms.items():
                reward_totals[name] = reward_totals.get(name, 0.0) + value
            traveled_distance_m += float(env.last_step_distance[0].detach().cpu())
            completed_steps += 1
            terminal = bool(done[0]) or bool(truncated[0]) or execution_timeout_reason is not None
            success = reached
            trajectory.append({
                "step": step,
                "episode": episode_index,
                "upper_reward_terms": terms,
                "decision_dynamic_risk": risk,
                "decision_dynamic_risk_source": "selected_motion" if decision.valid else "selected_wait_contingency" if safety.risk_priced_wait else "legacy_route_summary",
                "planner_status": dict(controller.last_status),
                "root_position_before": root.tolist(),
                "measured_velocity_before": measured_velocity,
                "yaw_before_rad": yaw,
                "measured_yaw_rate_before_radps": measured_yaw_rate,
                "goal_feedback_after": {
                    "time_s": simulation_time,
                    "root_position_world_m": terminal_position.tolist(),
                    "planar_speed_mps": math.hypot(*arrival_velocity[:2]),
                    "yaw_rate_radps": arrival_yaw_rate,
                    "roll_rad": arrival_roll,
                    "pitch_rad": arrival_pitch,
                    "wheel_contacts": env._last_transition_wheel_contacts[0].detach().cpu().tolist(),
                    "posture_height_m": float(env._last_transition_posture_height[0]),
                    "posture_target_height_m": float(cfg.posture_heights[active_posture_index]),
                },
                "command": limited_commands[-1],
                "posture": active_posture,
                "posture_transition_phase": transition_phase,
                "signed_path_error_before": env._path_pose_error[0].detach().cpu().tolist() if cfg.navigation_pose_observations else None,
                "safe_wait": safe_wait,
                "path_heading_guard": dict(path_heading_guard.last_status, applied_this_step=not safe_wait) if path_heading_guard else None,
                "mode_execution_ready": mode_guard.ready if mode_guard else None,
                "pending_posture": ("LOW", "MID", "HIGH")[mode_guard.pending_mode] if mode_guard and mode_guard.pending_mode is not None else None,
                "selected_path_index": previous_decision.path_index if previous_decision is not None else None,
                "selected_speed_ratio": previous_decision.speed_ratio if previous_decision is not None else None,
                "stair_hold_started": stair_hold_started,
                "stair_execution_settled": stair_execution_settled,
                "stair_feedback_before": stair_feedback_before,
                "execution_timeout_reason": execution_timeout_reason,
                "overspeed_brake": overspeed_brake,
                "live_clearance_brake": live_clearance_guard.braking if live_clearance_guard else False,
                "live_body_height_m": live_body_height,
                "posture_height_before_m": posture_height_before,
                "wheel_contacts_before": wheel_contacts_before,
                "posture_height_m": float(env._last_transition_posture_height[0]),
                "wheel_contacts": env._last_transition_wheel_contacts[0].detach().cpu().tolist(),
                "physical_pedestrian_contact_force_n": pedestrian_contact_force,
                "roll_rad": roll,
                "pitch_rad": pitch,
                "nominal_pedestrian_clearance_m": clearance if oracle_people else None,
                "pedestrians_xy_m": [[person.x, person.y] for person in people],
                "pedestrian_observed_velocities_xy_mps": [[person.vx, person.vy] for person in people],
                "pedestrian_actor_xy_m": [[person.x, person.y] for person in oracle_people],
                "terminated": bool(done[0]),
                "truncated": bool(truncated[0]),
            })
            terminated += int(bool(done[0]) or bool(truncated[0]))
            if local_step % 500 == 0:
                print(json.dumps({'execution_progress': {key: trajectory[-1].get(key) for key in (
                    'step', 'episode', 'root_position_before', 'yaw_before_rad', 'measured_velocity_before',
                    'measured_yaw_rate_before_radps', 'planner_status', 'path_heading_guard', 'command',
                    'safe_wait', 'selected_path_index', 'selected_speed_ratio', 'signed_path_error_before')}}), flush=True)
            hard_reason_counts += env.hard_reason_flags[0].detach().cpu().numpy().astype(int)
            if bool(env.hard_reason_flags[0].any()):
                collision_context = {
                    name: float(value[0].detach().cpu())
                    if value.dtype.is_floating_point
                    else bool(value[0].detach().cpu()) if value.dtype == torch.bool else int(value[0].detach().cpu())
                    for name, value in env.collision_context.items()
                }
                diagnostic = {
                    "step": step,
                    "root_position": terminal_position.tolist(),
                    "posture": active_posture,
                    "posture_height_m": float(env._last_transition_posture_height[0]),
                    "posture_target_height_m": float(cfg.posture_heights[active_posture_index]),
                    "hard_reasons": [name for name, flag in zip(HARD_REASON_NAMES, env.hard_reason_flags[0].detach().cpu().tolist()) if flag],
                    "soft_contact_force": float(env.soft_contact_force[0].detach().cpu()),
                    "collision_context": collision_context,
                    "contact_body_name": env._contact_sensor.body_names[collision_context["peak_body_index"]] if bool(env.collision_event[0]) else None,
                    "tunnel_dimensions_m": env.tunnel_dimensions[0].detach().cpu().tolist() if args.terrain == "tunnel" else None,
                    "raw_command": raw_commands[-1] if raw_commands else None,
                    "limited_command": limited_commands[-1] if limited_commands else None,
                    "replan_id": path_versions[-1] if path_versions else None,
                }
                collision_diagnostics.append(diagnostic)
            if episode_end:
                success = bool(reached) and not terminal and clearance >= 0.0 and pedestrian_contact_force <= 1.
                terminal_root_position = terminal_position.tolist()
                episode_results.append({"episode": episode_index, "success": success, "hard_failure": bool(done[0]),
                                        "nominal_overlap": clearance < 0.0, "horizon": horizon,
                                        "execution_timeout_reason": execution_timeout_reason,
                                        "steps": local_step + 1, "path_length_m": traveled_distance_m - episode_start_distance})
                if args.train_upper:
                    policy.finish_transition(upper_reward, True)
                    upper_reward = 0.0
                    upper_updates.append(policy.update())
                    args.upper_output.parent.mkdir(parents=True, exist_ok=True)
                    checkpoint_metadata = {"backend": "real_isaac_sim_vendor_neupan", "episode_results": episode_results,
                                           "asset_sha256": hashlib.sha256(Path(args.asset).read_bytes()).hexdigest(),
                                           "reward_weights": asdict(JointRewardWeights()), "seed": args.seed,
                                           "input_artifacts": artifacts, "execution_source_provenance": source_provenance,
                                           "invocation": sys.argv, "independent_acceptance_passed": False}
                    policy.save(args.upper_output, checkpoint_metadata)
                    policy.save(args.upper_output.with_name(args.upper_output.stem + f".episode_{episode_index:04d}.pt"),
                                checkpoint_metadata)
                    print(json.dumps({"episode_result": episode_results[-1], "upper_update": upper_updates[-1]}), flush=True)
                episode_index += 1
                if episode_index >= args.episodes:
                    break
                obs, _ = env.reset()
                if geometry_report:
                    scene = calibrated_prior_scene(env, initial_xy, (args.goal_x, args.goal_y), geometry_report,
                                                   planner_vertices_xy_m=controller.planner.robot.vertices.T,
                                                   minimum_obstacle_clearance_m=float(planner_configuration["adjust"]["d_min"]))
                base.reset(1, env.device)
                if tracker:
                    tracker.reset()
                observed_people = ()
                observed_points = np.empty((0, 2))
                observed_velocities = np.empty((0, 2))
                adapter = IsaacJointNavigationAdapter(policy, controller, posture_specs, safety=safety)
                if path_heading_guard:
                    path_heading_guard.reset()
                controller.reset()
                adapter.astar = AStarPlanner(astar_config)
                mode_guard = ModeExecutionGuard() if geometry_report else None
                live_clearance_guard = LiveClearanceGuard() if geometry_report else None
                completed_riser_inflation_released = False
                posture_command = torch.tensor([[0., 1., 0.]], device=env.device)
                governor_parameters = dict(velocity_calibration["profiles"]["MID"]) if velocity_calibration else None
                previous_decision = None
                previous_path = None
                episode_start_step = step + 1
                episode_start_distance = traveled_distance_m
                contact_feedback_steps = 0
                last_switch_time = -100.0
                stair_hold_started = False
                stair_arrival_guard = StairArrivalGuard()
                stair_execution_settled = False
                stair_stationary_steps = 0
                stair_hold_started_s = None
                navigation_progress_guard = NavigationProgressGuard(maximum_wait_s=args.navigation_progress_timeout_s)
                goal_arrival_guard = GoalArrivalGuard(tolerance_m=cfg.navigation_goal_tolerance_m, braking_entry_margin_m=.08)
    except Exception as exc:
        runtime_error = f"{type(exc).__name__}: {exc}"
        raise
    finally:
        if camera_video_writer is not None:
            camera_video_writer.release()
        if external_video_writer is not None:
            external_video_writer.release()
        external_image_path = None
        if external_camera_image is not None:
            from PIL import Image
            external_image_path = args.output.with_name(args.output.stem + ".external.png")
            Image.fromarray(external_camera_image).save(external_image_path)
        camera_image_path = None
        if last_rgb_image is not None:
            from PIL import Image
            camera_image_path = args.output.with_name(args.output.stem + ".camera.png")
            Image.fromarray(last_rgb_image).save(camera_image_path)
        result = {
            "execution_source_provenance": source_provenance,
            "input_artifacts": artifacts,
            "planner_enclosure_margin_m": planner_enclosure_margin_m,
            "invocation": sys.argv,
            "runtime_versions": {"python": sys.version, "torch": str(torch.__version__), "numpy": np.__version__,
                                 "physics_device": str(env.device), "physics_step_s": float(cfg.sim.dt), "control_step_s": float(env.step_dt)},
            "backend": controller.backend,
            "convex_cylinder_collisions": cfg.convex_cylinder_collisions,
            "neupan_yaml": str(args.neupan_yaml.resolve()),
            "neupan_mode_constraints": controller.limits if args.mode_conditioned_neupan else None,
            "neupan_robot_vertices_xy_m": controller.planner.robot.vertices.T.tolist(),
            "observation_sources": {
                "terrain": "exact_authored_prior_with_full_body_inflation" if geometry_report else "authored_grid_not_sensor_mapping",
                "pedestrians": "physical_capsule_lidar_kalman_tracks" if sensors else "synthetic_constant_velocity_tracks_not_physical_actors",
                "lidar_enabled": sensors is not None or getattr(env.cfg, "navigation_lidar", None) is not None,
                "gimbal": "rendered_RGBD_at_supplied_camera_mount_no_motor_model" if args.rendered_camera else "steerable_physx_depth_rays_not_RGB_or_motor_model" if sensors else "disabled",
            },
            "rendered_camera_frames": rendered_camera_frames,
            "mode_motion_hold_binding": {"enabled": args.bind_mode_motion_hold,
                "contract": "tita.mode_guard_command_hold.v1" if args.bind_mode_motion_hold else None,
                "minimum_command_hold_s": mode_guard.transition_s if mode_guard is not None else None,
                "scope": "Existing mandatory guard holds forward/yaw commands at zero before readiness; physical coasting is not assumed zero and remains covered by braking plus transition-position inflation"},
            "observed_shuttle_prediction": {"enabled": args.observed_shuttle_prediction,
                "local_neupan_flow_enabled": args.observed_shuttle_neupan_flow,
                "local_neupan_flow_contract": 'tita.observed_shuttle_neupan_additive_flow.v1' if args.observed_shuttle_neupan_flow else None,
                "global_astar_cost_enabled": args.observed_shuttle_astar_cost,
                "global_astar_cost_contract": 'tita.observed_shuttle_astar_cost_envelope.v1' if args.observed_shuttle_astar_cost else None,
                "contract": "tita.observed_shuttle_forecast.v1" if args.observed_shuttle_prediction else None,
                "motion_plateau_gate": args.observed_shuttle_plateau_gate,
                "motion_plateau_contract": "tita.observed_closed_motion_plateaus.v1" if args.observed_shuttle_plateau_gate else None,
                "forecast_contexts": sum(context['shuttle_prediction'] is not None for row in sensor_records for context in row['motion_context']),
                "minimum_extra_uncertainty_radius_m": .35, "maximum_forecast_horizon_s": 15.,
                "scope": "Empirical observed spatial-lane periodic hypothesis, not identity reidentification or an arbitrary human-motion safety bound; unsupported cases retain restart tubes"},
            "observed_neupan_flow_records": observed_neupan_flow_records,
            "pedestrian_static_center_filter": {"enabled": args.static_pedestrian_center_filter,
                "navigation_origin_xy_m": static_map_origin_xy_m,
                "static_solid_boxes_xyz_m": static_solid_boxes, "interior_guard_m": .01,
                "detections_rejected": sum(len(row['static_center_filter']['rejected_centers_xy_m']) for row in sensor_records),
                "raw_lidar_points_removed_from_vendor": False, "actor_labels_or_future_waypoints_used": False,
                "scope": "Reject fitted pedestrian centers strictly inside known solid wall volumes at the measured lidar height; not online SLAM or a general semantic classifier"},
            "external_execution_camera": {"frames": external_camera_frames,
                                          "video": str(external_video_path) if external_video_writer is not None else None,
                                          "image": str(external_image_path) if external_image_path else None,
                                          "scope": "Actual third-person Isaac camera frames during this physical execution; visualization-only, not a policy observation or replay"},
            "overspeed_brake_steps": overspeed_brake_steps,
            "live_clearance_brake_steps": live_clearance_brake_steps,
            "mode_command_limits": MODE_COMMAND_LIMITS if args.smooth_commands else None,
            "completed_riser_inflation_released": completed_riser_inflation_released,
            "camera_rgb_image": str(camera_image_path) if camera_image_path else None,
            "camera_rgb_video": str(camera_video_path) if camera_video_writer is not None else None,
            "camera_rgb_video_scope": "Actual Isaac RGB sensor frames; not trajectory replay or external-view animation" if camera_video_writer is not None else None,
            "physics_device": str(env.device),
            "geometry_calibration": str(args.geometry_calibration),
            "upper_policy_type": "masked_independent_path_mode_speed_ppo" if args.upper_ppo else "proxy_pretrained_tabular_q",
            "upper_trained_here": args.train_upper,
            "upper_cost_prior": policy.model.cost_prior if args.upper_ppo else False,
            "upper_policy_temperature": policy.model.policy_temperature if args.upper_ppo else None,
            "analytic_baseline_without_learned_actor": args.analytic_baseline,
            "episode_results": episode_results,
            "upper_updates": upper_updates,
            "upper_reward_totals": reward_totals,
            "upper_reward_weights": asdict(JointRewardWeights()),
            "upper_safety_config": asdict(safety),
            "braking_risk_model": {
                "uses_current_executed_mode": True,
                "command_acceleration_and_filter_binding": bool(geometry_report and args.smooth_commands),
                "scope": "Nominal command-level horizon with reaction and filter tail; not a measured physical worst-case stopping certificate",
                "pedestrian_model": "Observed stationary restart and moving speed-interval model" if safety.moving_speed_prediction else "Observed CV with stationary restart" if safety.stationary_restart_prediction else "Observed constant-velocity prediction",
                "command_settling_delay_enabled": safety.execution_timing_prediction,
                "physical_worst_case_timing_certificate": False,
            },
            "path_switch_reward_contract": {
                "method": "symmetric_sampled_spatial_distance_between_projected_forward_route_suffixes",
                "threshold_m": .35, "lookahead_m": 3., "sampling_spacing_m": .05,
                "candidate_index_is_not_route_identity": True,
                "scope": "Spatial continuity penalty, not a topological homotopy or global optimality certificate",
            },
            "path_heading_execution_guard": {
                "enabled": path_heading_guard is not None,
                "configuration": asdict(path_heading_guard.config) if path_heading_guard else None,
                "method": "observed_stop_then_latched_vendor_yaw_with_separate_translation_alarm_inside_certified_body_volume",
                "heading_target_source": "same_stock_vendor_ref_state_list_horizon_no_separate_path_lookahead",
                "vendor_velocity_never_replaced_by_a_different_planner": True,
                "scope": "Empirical command-level stop/turn hysteresis, not a worst-case drift bound; actual tracking requires independent physics acceptance",
            },
            "global_path_continuation": {
                "enabled": geometry_report is not None,
                "method": "revalidated_remaining_previous_astar_route_plus_fresh_astar_alternatives_within_original_candidate_budget",
                "maximum_connector_m": .5,
                "connector_lookahead_m": .25,
                "stable_vendor_reference_identity": True,
                "dynamic_risk_and_geometry_masks_reapplied_each_upper_cycle": True,
                "forced_continuation_or_minimum_route_dwell": False,
                "scope": "Optional candidate continuity, not a replacement for Astar, vendor NeuPAN, or a global optimality proof",
            },
            "global_start_recovery": {
                "method": "continuous_circumscribed_body_plus_d_min_exact_swept_disk_connector_no_raster_carving",
                "maximum_connector_length_m": adapter.astar.config.start_recovery_distance_m,
                "geometry": asdict(scene.recovery_geometry) if scene.recovery_geometry else None,
                "certified_candidate_events": sum(any(path.get('start_recovery') for path in event['candidates']) for event in decision_events),
                "unexplained_occupancy_recovery": False,
                "mode_transition_geometry_checks_unchanged": True,
            },
            "upper_observation_contract": FEATURE_CONTRACT,
            "upper_wait_action_contract": WAIT_ACTION_CONTRACT if safety.risk_priced_wait else None,
            "upper_action_risk_cost_period_s": policy.model.wait_cost_step_s if args.upper_ppo and policy.model.risk_cost_per_decision else None,
            "upper_action_risk_cost_scope": "Same risk weight and actual upper decision interval as integrated RL reward; forecast risk is not charged as whole remaining-route exposure",
            "upper_wait_action_scope": "Risk-priced stationary contingency with nominal braking-position uncertainty; unavoidable stop remains a fallback, not a safety certificate",
            "upper_route_execution_features": {
                "columns_32_to_35": ["spatial_route_change_m_divided_by_3", "route_change_greater_than_0.35m",
                                      "absolute_heading_error_divided_by_pi", "nominal_initial_turn_time_divided_by_60s"],
                "heading_lookahead_m": .25,
                "nominal_turn_rate_radps": .2,
                "cost_prior": "existing_navigation_time_and_path_switch_weights_applied_to_observed_route_execution_cost",
                "scope": "Observed current pose and previous accepted path only; nominal turn time is not a physical worst-case bound",
            },
            "upper_feature_migration": policy.feature_migration if args.upper_ppo else None,
            "contact_processing_enabled": not cfg.sim.disable_contact_processing,
            "transition_cost_scope": "Empirical directed time-cost estimates; execution release still requires live feedback. The lower delay bound is the recorded minimum_mode_motion_hold_s, through the empirical maximum, not a certified physical worst-case bound.",
            "pedestrian_prediction_contract": {
                "motion_model": "observed_moving_speed_interval_and_stationary_restart_segment" if safety.moving_speed_prediction else "moving_CV_and_stationary_restart_segment" if safety.stationary_restart_prediction else "constant_velocity",
                "stationary_restart_prediction_enabled": safety.stationary_restart_prediction,
                "moving_speed_prediction_enabled": safety.moving_speed_prediction,
                "command_settling_delay_enabled": safety.execution_timing_prediction,
                "command_delay_uses_current_executed_mode_measured_speed_and_mode_limiter_constants": safety.execution_timing_prediction,
                "command_delay_is_physical_worst_case_bound": False,
                "stationary_restart_axis_uses_only_past_sensor_velocities": safety.stationary_restart_prediction,
                "stationary_restart_axis_sources": ["track_observed_peak", "scene_observed_dominant_axis"] if safety.stationary_restart_prediction else [],
                "observed_axis_history_window_s": 30.,
                "scene_axis_minimum_fraction": .85,
                "stationary_restart_allows_both_directions_and_any_activation_delay_within_horizon": safety.stationary_restart_prediction,
                "unknown_motion_axis_falls_back_to_CV_with_existing_margin": True,
                "arbitrary_unobserved_direction_changes_covered": False,
                "time_evaluation": "continuous_segment_closest_approach",
                "switch_delay_interval": "actual_guard_minimum_to_directed_empirical_transition_cost" if safety.minimum_mode_motion_hold_s else "zero_to_directed_empirical_transition_cost",
                "delay_grid_max_spacing_s": .5,
                "delay_grid_clearance_inflation": "robot_speed_times_half_actual_delay_grid_spacing",
                "prediction_is_collision_certificate": False,
            },
            "astar_config": asdict(astar_config),
            "sensor_records": sensor_records,
            "observed_ceiling_points": observed_ceiling_points,
            "physical_pedestrian_contact_steps": physical_pedestrian_contact_steps,
            "pedestrian_scene_validation": pedestrian_scene_validation,
            "peak_physical_pedestrian_contact_force_n": peak_physical_pedestrian_contact_force_n,
            "neupan_init_error": controller.init_error,
            "steps": args.steps,
            "completed_steps": completed_steps,
            "elapsed_simulation_s": completed_steps * float(env.step_dt),
            "goal_xy_m": [args.goal_x, args.goal_y],
            "goal_acceptance": {"criterion": "continuous_stopped_supported_settled_hold", **asdict(goal_arrival_guard)},
            "path_length_m": traveled_distance_m,
            "peak_measured_planar_speed_mps": max((
                math.hypot(*sample["measured_velocity_before"][:2]) for sample in trajectory
            ), default=0.0),
            "mean_absolute_forward_tracking_error_mps": float(np.mean([
                abs(sample["measured_velocity_before"][0] - sample["command"][0])
                for sample in trajectory
            ])) if trajectory else None,
            "seed": args.seed,
            "success": success and not pedestrian_overlap_steps and not hard_reason_counts.any() and not physical_pedestrian_contact_steps,
            "evaluation_status": "runtime_error" if runtime_error else "hard_failure" if hard_reason_counts.any() else "nominal_pedestrian_overlap" if pedestrian_overlap_steps else "execution_timeout" if execution_timeout_events else "success" if success else "horizon_only",
            "execution_timeout_events": execution_timeout_events,
            "nominal_pedestrian_overlap_steps": pedestrian_overlap_steps,
            "nominal_clearance_logging_contract": "tita.actual_actor_nominal_clearance.v1",
            "minimum_nominal_pedestrian_clearance_m": pedestrian_min_clearance if args.dynamic_pedestrian else None,
            "runtime_error": runtime_error,
            "execution_config": execution_config,
            "foundation_command_gate": residual_payload.get("command_gate_metadata") if residual_payload else None,
            "foundation_baseline": residual_payload.get("baseline_metadata") if residual_payload else None,
            "posture_profile": str(args.posture_profile) if args.posture_profile else None,
            "velocity_calibration": str(args.velocity_calibration) if args.velocity_calibration else None,
            "velocity_calibration_scope": "frozen_base_prior_residual_requires_validation" if args.low_residual_checkpoint and velocity_calibration else "frozen_controller" if velocity_calibration else None,
            "low_residual_checkpoint": str(args.low_residual_checkpoint),
            "high_residual_checkpoint": str(args.high_residual_checkpoint) if args.high_residual_checkpoint else None,
            "high_execution_config": high_execution,
            "high_command_gate": high_payload.get("command_gate_metadata") if high_payload else None,
            "validated_step_limits": asdict(step_limits) if step_limits else None,
            "stair_execution_settled": stair_execution_settled,
            "stair_config": {"height_m": args.stair_height, "width_m": args.stair_width, "start_x_m": args.stair_start,
                             "count": args.stair_count, "landing_m": args.stair_landing} if cfg.stair_enabled else None,
            "terrain": args.terrain,
            "navigation_scene": str(args.navigation_scene.resolve()) if args.navigation_scene else None,
            "dynamic_pedestrian": args.dynamic_pedestrian,
            "pedestrian_track": {
                "scenario": str(args.pedestrian_scenario) if args.pedestrian_scenario else None,
                "scenario_sha256": hashlib.sha256(args.pedestrian_scenario.read_bytes()).hexdigest() if args.pedestrian_scenario else None,
                "actors": [asdict(person) for person in pedestrians],
                "motion_models": ["closed_piecewise_linear" if track.repeat else
                                  "finite_waypoints_then_stationary" if track.waypoints else
                                  "constant_velocity" for track in scenario_tracks],
                "physical_actor_driver": "continuous_position_targets_for_collidable_kinematic_capsules",
                "future_waypoints_passed_to_policy": False,
                "additional_motion_margin_m": args.pedestrian_motion_margin_m,
                "tracked_uncertainty_boundaries_fused_with_raw_lidar": True,
                "motion_history_features": "observed_nearest_track_velocity_dwell_move_age_and_last_motion_only_no_script_phase",
                "x_offset_m": args.pedestrian_x_offset,
                "y_offset_m": args.pedestrian_y_offset,
                "vy_mps": args.pedestrian_vy,
            } if args.dynamic_pedestrian else None,
            "velocity_gate_mps": {"min_vx": min_vx, "max_vx": args.max_vx, "max_wz": args.max_wz},
            "upper_decisions": planner_calls,
            "safe_wait_decisions": safe_wait_decisions,
            "safe_wait_steps": safe_wait_steps,
            "neupan_calls": len(planner_latencies),
            "posture_switches": switch_count,
            "selected_postures": selected_postures,
            "path_versions": path_versions,
            "mean_neupan_latency_ms": float(np.mean(planner_latencies)) if planner_latencies else 0.0,
            "p95_neupan_latency_ms": float(np.percentile(planner_latencies, 95)) if planner_latencies else 0.0,
            "lidar_points": lidar_points,
            "terminated_or_truncated": terminated,
            "hard_reason_counts": dict(zip(HARD_REASON_NAMES, hard_reason_counts.tolist())),
            "tunnel_config": {
                "height_range_m": list(cfg.tunnel_height_range_m),
                "width_range_m": list(cfg.tunnel_width_range_m),
                "length_range_m": list(cfg.tunnel_length_range_m),
                "start_x_m": float(cfg.tunnel_start_x_m),
            } if args.terrain == "tunnel" else None,
            "collision_diagnostics": collision_diagnostics,
            "raw_commands": raw_commands,
            "limited_commands": limited_commands,
            "trajectory": trajectory,
            "sensor_frames": sensor_frames,
            "decision_events": decision_events,
            "terminal_root_position_before_last_step": terminal_root_position,
            "final_root_position": env.robot.data.root_pos_w[0].detach().cpu().tolist(),
            "final_root_position_is_auto_reset_state": bool(trajectory and (trajectory[-1]["terminated"] or trajectory[-1]["truncated"])),
        }
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
        print(json.dumps({key: value for key, value in result.items()
                          if key not in ("trajectory", "raw_commands", "limited_commands", "sensor_frames", "decision_events")},
                         indent=2, ensure_ascii=False), flush=True)
        env.close()


if __name__ == "__main__":
    try:
        main()
    except Exception as exception:
        import traceback
        traceback.print_exc()
        if not args.output.exists():
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(json.dumps({"evaluation_status": "initialization_error", "success": False,
                                              "runtime_error": f"{type(exception).__name__}: {exception}",
                                              "invocation": sys.argv}, indent=2))
        raise
    finally:
        simulation_app.close()
