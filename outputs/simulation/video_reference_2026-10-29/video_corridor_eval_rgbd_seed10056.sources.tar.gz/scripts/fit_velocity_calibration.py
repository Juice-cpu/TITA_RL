#!/usr/bin/env python3
"""Fit an explicit Isaac velocity calibration from a raw-response probe."""

import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from tita_uc_residual_rl.velocity_calibration import fit_angular_calibration, fit_velocity_calibration

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("report", type=Path)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--max-abs-velocity", type=float, default=0.4)
parser.add_argument("--yaw-report", type=Path, default=None)
args = parser.parse_args()
result = fit_velocity_calibration(json.loads(args.report.read_text()), max_abs_velocity=args.max_abs_velocity)
if args.yaw_report is not None:
    result = fit_angular_calibration(result, json.loads(args.yaw_report.read_text()))
args.output.parent.mkdir(parents=True, exist_ok=True)
args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
