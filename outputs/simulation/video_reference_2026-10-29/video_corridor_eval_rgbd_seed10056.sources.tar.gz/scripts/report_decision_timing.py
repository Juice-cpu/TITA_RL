#!/usr/bin/env python3
"""Report measured upper inference, transport, application and wall-clock rates."""

from __future__ import annotations

import argparse
import csv
import hashlib
import html
import json
from pathlib import Path
import shutil
import sys

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tita_uc_residual_rl.realtime_metrics import analyze_timing_directory, timing_statistics


LABELS = {
    "upper_inference_ms": "上层RL单次推理",
    "decision_callback_to_publish_ms": "上层回调开始→动作发布",
    "decision_publish_to_gate_ms": "动作发布→安全gate接收",
    "decision_publish_to_apply_ms": "动作发布→底层控制输入应用",
    "observation_snapshot_to_apply_ms": "最近状态快照→控制输入应用",
    "boundary_ready_to_apply_ms": "执行边界反馈就绪→控制输入应用",
    "lower_actor_ms": "底层actor推理（CUDA同步计时）",
    "local_planning_ms": "NeuPAN局部规划",
}
RATES = {"upper_application": ("上层动作生效", 2),
         "fresh_local_planning": ("新局部规划", 10),
         "lower_control_input": ("底层控制输入", 50)}


def write_csv(path, rows):
    with path.open("x", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def render_figure(summary, output):
    plt.rcParams.update({"font.family": "Noto Sans CJK JP", "axes.unicode_minus": False,
                         "axes.spines.top": False, "axes.spines.right": False})
    figure, axes = plt.subplots(1, 2, figsize=(15, 7), gridspec_kw={"width_ratios": [1.5, 1]})
    keys = ["upper_inference_ms", "decision_callback_to_publish_ms", "decision_publish_to_apply_ms",
            "observation_snapshot_to_apply_ms", "boundary_ready_to_apply_ms"]
    positions = np.arange(len(keys))
    for offset, statistic, label, color in [(-0.19, "mean", "平均", "#4282a8"), (0.19, "p95", "P95", "#249d8a")]:
        values = [summary["metrics"][key][statistic] for key in keys]
        bars = axes[0].bar(positions + offset, values, width=0.35, label=label, color=color)
        axes[0].bar_label(bars, labels=[f"{value:.2f}" for value in values], padding=4, fontsize=9)
    axes[0].set_xticks(positions, ["RL推理", "上层回调\n至发布", "发布\n至应用", "最近快照\n至应用", "边界就绪\n至应用"])
    axes[0].set_yscale("log")
    axes[0].set_ylim(0.1, 2000)
    axes[0].set_ylabel("墙钟耗时 / ms（对数坐标）")
    axes[0].set_title("计算快，不等于整条链路低延迟", loc="left", pad=20)
    axes[0].legend(loc="upper left")
    rate_names = list(RATES)
    nominal = [RATES[name][1] for name in rate_names]
    measured = [np.mean([trial["wall_effective_hz"][name] for trial in summary["trials"]]) for name in rate_names]
    for offset, values, label, color in [(-0.19, nominal, "仿真时间设定", "#b8cbdc"),
                                        (0.19, measured, "实测墙钟有效频率", "#da8b4b")]:
        bars = axes[1].bar(np.arange(3) + offset, values, width=0.35, label=label, color=color)
        axes[1].bar_label(bars, labels=[f"{value:.2f}" for value in values], padding=4, fontsize=10)
    axes[1].set_xticks(np.arange(3), [RATES[name][0] for name in rate_names])
    axes[1].set_yscale("log")
    axes[1].set_ylim(0.3, 100)
    axes[1].set_ylabel("Hz（对数坐标）")
    axes[1].set_title("锁步运行并未达到墙钟1:1实时", loc="left", pad=20)
    axes[1].legend(loc="upper left")
    for axis in axes:
        axis.grid(axis="y", alpha=0.15)
        axis.set_axisbelow(True)
    figure.suptitle(f"RL全链路计时实测｜{len(summary['trials'])}个新回合 / {len(summary['decisions'])}次上层决策", fontsize=21, x=0.065, ha="left")
    figure.text(0.065, 0.125, "同机CLOCK_MONOTONIC；按episode / decision / UDP包序号逐条关联；包含冷启动决策，不挑选最快样本。", fontsize=11)
    figure.text(0.065, 0.082, "“应用”指仿真控制器读取并设置姿态/速度输入，不是机械动作完成；最近快照可能是暂停期间重复采样的状态。", fontsize=10)
    figure.text(0.065, 0.038, "边界就绪→应用包含发布、调度和等待，更接近新物理状态可用后的实际决策延迟。埋点与CUDA同步会带来测量开销。", fontsize=10)
    figure.tight_layout(rect=(0.025, 0.18, 0.99, 0.91), w_pad=3)
    figure.savefig(output / "decision_timing.png", dpi=160)
    plt.close(figure)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--batch", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    comparison = json.loads((args.batch / "comparison_summary.json").read_text())
    if comparison["errors"] or not comparison["results"]:
        raise ValueError("batch has missing/failed trials; retain and investigate before reporting")
    trials, decisions = [], []
    for result in comparison["results"]:
        if result["algorithm"] != "rl" or not result["success"] or not result["complete"]:
            raise ValueError("this report expects completed frozen-RL timing trials")
        if not result["action_reward_audit_passed"] or not result["planner_clock_audit"]["passed"]:
            raise ValueError("physical action or planner synchronization audit failed")
        directory = Path(result["directory"])
        trial = analyze_timing_directory(directory / "timing")
        transitions = [json.loads(line) for line in (directory / "evaluation/transition_audit.jsonl").read_text().splitlines() if line.strip()]
        if len(transitions) != len(trial["decisions"]) or trial["control_samples"] != len(trial["duration_samples"]["lower_actor_ms"]):
            raise ValueError("measured decisions/control samples do not match physical execution")
        if not np.isclose(trial["active_navigation_sim_s"], result["navigation_time_s"]):
            raise ValueError("timing duration differs from physical navigation duration")
        trial.update(seed=result["seed"], directory=str(directory),
                     launcher_and_postrun_wall_s=result["wall_elapsed_s"])
        trials.append(trial)
        for ordinal, decision in enumerate(trial["decisions"]):
            decisions.append({"seed": result["seed"], "first_decision_in_trial": ordinal == 0, **decision})
    metrics = {name: timing_statistics([row[name] for row in decisions])
               for name in decisions[0] if name.endswith("_ms")}
    for name in ("lower_actor_ms", "local_planning_ms"):
        metrics[name] = timing_statistics([value for trial in trials for value in trial["duration_samples"][name]])
    warm = [row["boundary_ready_to_apply_ms"] for row in decisions if not row["first_decision_in_trial"]]
    summary = {"simulation_only": True, "new_measurement": True, "batch": str(args.batch.resolve()),
               "scope": "Three frozen-RL episodes, shared .6m/s cap, existing lockstep execution; not hardware or a nonblocking deadline test.",
               "latency_endpoint": "First actual use as simulation actor input, not mechanical posture settling or motor bus actuation.",
               "instrumentation": "Opt-in JSONL sidecars; lower GPU inference explicitly synchronized. All reported durations include instrumentation effects.",
               "metrics": metrics, "decisions": decisions, "trials": trials,
               "boundary_latency_excluding_first_decision_per_trial_ms": timing_statistics(warm)}
    args.output.mkdir(parents=True, exist_ok=False)
    source_directory = args.output / "analysis_sources"
    source_directory.mkdir()
    sources = [Path(__file__).resolve(), ROOT / "tita_uc_residual_rl/realtime_metrics.py", ROOT / "tita_realtime_trace.py",
               ROOT / "scripts/run_tita_residual_lab.py", ROOT / "scripts/run_navigation_benchmark.py",
               ROOT / "tita_uc_residual_rl/isaac_udp_bridge.py"]
    companion = Path("/home/ky/neupan_tita_sandbox/ros2_ws/src/neupan_tita_sim/neupan_tita_sim")
    sources.extend(companion / name for name in ("upper_level_online_ppo.py", "upper_level_shadow.py", "isaac_udp_bridge_node.py", "cmd_vel_gate.py", "isaac_neupan.py"))
    summary["sha256_sources"] = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in sources}
    for path in sources:
        shutil.copyfile(path, source_directory / path.name)
    summary["sha256_timing_inputs"] = {str(path): hashlib.sha256(path.read_bytes()).hexdigest()
                                       for trial in trials for path in (Path(trial["directory"]) / "timing").glob("*.jsonl")}
    with (args.output / "decision_timing_summary.json").open("x") as stream:
        json.dump(summary, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    write_csv(args.output / "per_decision_timing.csv", decisions)
    table = [{"metric": name, "label": label, **metrics[name]} for name, label in LABELS.items()]
    write_csv(args.output / "latency_summary.csv", table)
    trial_rows = [{"seed": trial["seed"], "decisions": len(trial["decisions"]),
                   "simulated_navigation_s": trial["active_navigation_sim_s"],
                   "active_navigation_wall_s": trial["active_navigation_wall_s"],
                   "active_navigation_rtf": trial["active_navigation_rtf"],
                   **{name + "_wall_hz": value for name, value in trial["wall_effective_hz"].items()}}
                  for trial in trials]
    write_csv(args.output / "per_trial_wall_rates.csv", trial_rows)
    render_figure(summary, args.output)
    markdown = ["| 指标 | 次数 | 平均 ms | P50 ms | P95 ms | P99 ms | 最慢 ms |",
                "|---|---:|---:|---:|---:|---:|---:|"]
    for row in table:
        markdown.append(f"| {row['label']} | {row['n']} | {row['mean']:.3f} | {row['p50']:.3f} | {row['p95']:.3f} | {row['p99']:.3f} | {row['max']:.3f} |")
    (args.output / "latency_summary.md").write_text("\n".join(markdown) + "\n")
    table_html = "".join("<tr><td>" + html.escape(row["label"]) + "</td><td>" + str(row["n"]) + "</td>" + "".join(f"<td>{row[name]:.3f}</td>" for name in ("mean", "p50", "p95", "p99", "max")) + "</tr>" for row in table)
    (args.output / "index.html").write_text(f"""<!doctype html><meta charset="utf-8"><title>RL决策实时计时</title>
<style>body{{max-width:1400px;margin:30px auto;font:16px/1.8 sans-serif;padding:20px;color:#203747}}img{{width:100%}}table{{border-collapse:collapse;width:100%}}td,th{{text-align:left;padding:10px;border-bottom:1px solid #ddd}}.note{{background:#fff2e7;padding:20px}}</style>
<h1>RL决策链路：真实测量，不以设定周期替代耗时</h1><p>{len(trials)}个新仿真回合，{len(decisions)}次上层决策；同机单调时钟，保留首个冷启动决策。</p>
<img src="decision_timing.png"><table><tr><th>指标</th><th>次数</th><th>平均ms</th><th>P50</th><th>P95</th><th>P99</th><th>最慢</th></tr>{table_html}</table>
<p class="note">应用终点是仿真底层控制输入被设置，不是机械动作完成。锁步会暂停物理；最新快照可能是相同边界状态的重复采样。应同时查看“边界就绪到应用”以及活动段墙钟频率。原30回合与此次3回合不混合统计。</p>
<p>机器可读数据：decision_timing_summary.json、per_decision_timing.csv、per_trial_wall_rates.csv。源码快照：analysis_sources/。</p>""")
    print("\n".join(markdown))
    print(json.dumps(trial_rows, indent=2))
    print("Report:", args.output.resolve())


if __name__ == "__main__":
    main()
