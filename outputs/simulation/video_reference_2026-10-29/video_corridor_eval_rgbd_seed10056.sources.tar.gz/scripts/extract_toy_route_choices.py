#!/usr/bin/env python3
"""Re-run toy evaluation while retaining route/action choices per episode."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from tita_uc_residual_rl.upper_level_experiment import calibrate_rule_references
from tita_uc_residual_rl.upper_level_objective import (
    EnumeratedObjectivePolicy,
    ShortestRoutePolicy,
    timed_decision,
)
from tita_uc_residual_rl.upper_level_policy import LearnedUpperPolicy, load_upper_checkpoint
from tita_uc_residual_rl.upper_level_toy_env import UpperLevelToyEnv
from tita_uc_residual_rl.upper_level_types import (
    POSTURE_NAMES,
    ROUTE_HEIGHTS_CM,
    SPEED_RATIOS,
    UpperObjectiveWeights,
    decode_action,
)


METHODS = ("shortest_rule", "enumerated_argmin", "categorical_ppo")
METHOD_LABELS = {
    "shortest_rule": "Shortest Rule",
    "enumerated_argmin": "Formula-Argmin",
    "categorical_ppo": "Categorical PPO",
}


def route_label(route_index: int | None) -> str | None:
    if route_index is None:
        return None
    return f"P{route_index + 1}-{POSTURE_NAMES[route_index]}-{ROUTE_HEIGHTS_CM[route_index]}cm"


def collect_method(seed: int, episodes: int, checkpoint: Path | None, normalization, method: str) -> list[dict]:
    weights = UpperObjectiveWeights()
    env = UpperLevelToyEnv(
        num_envs=1,
        seed=seed,
        split="test",
        normalization=normalization,
        weights=weights,
    )
    if method == "shortest_rule":
        policy = ShortestRoutePolicy()
    elif method == "enumerated_argmin":
        policy = EnumeratedObjectivePolicy(normalization, weights)
    else:
        if checkpoint is None:
            raise ValueError("PPO route extraction requires --checkpoint")
        model, _ = load_upper_checkpoint(checkpoint)
        policy = LearnedUpperPolicy(model, deterministic=True)

    rows: list[dict] = []
    while len(rows) < episodes:
        initial_observation = None
        actions: list[int] = []
        routes: list[int] = []
        latencies: list[float] = []
        locked_route: int | None = None

        while True:
            observation = env.observation(0)
            if initial_observation is None:
                initial_observation = observation
            decision, latency_ms = timed_decision(policy, observation)
            env.add_decision_latency(0, latency_ms)
            action_id = int(decision.action_id)
            actions.append(action_id)
            latencies.append(float(latency_ms))
            if 0 <= action_id < 9:
                route_index, _ = decode_action(action_id)
                routes.append(route_index)

            _, _, done, information, _ = env.step(np.asarray([action_id]))
            next_observation = env.observation(0)
            if next_observation.route_locked:
                locked_route = int(next_observation.current_route)

            if not done[0]:
                continue

            metrics = env.episode_metrics(0, method, bool(information[0].get("success", False)))
            final_route = routes[-1] if routes else None
            selected_route = locked_route if locked_route is not None else final_route
            route_lengths = [float(route.remaining_length_m) for route in initial_observation.routes]
            rows.append(
                {
                    "seed": int(seed),
                    "episode": int(metrics.episode),
                    "method": method,
                    "method_label": METHOD_LABELS[method],
                    "success": bool(metrics.success),
                    "collision": bool(metrics.collision),
                    "hard_violation": bool(metrics.hard_violation),
                    "elapsed_s": float(metrics.elapsed_s),
                    "distance_m": float(metrics.distance_m),
                    "mechanical_energy_j": float(metrics.mechanical_energy_j),
                    "mechanical_cot": float(metrics.mechanical_cot),
                    "switches": int(metrics.switches),
                    "minimum_lateral_clearance_m": float(metrics.minimum_lateral_clearance_m),
                    "minimum_overhead_margin_m": float(metrics.minimum_overhead_margin_m),
                    "initial_route": routes[0] if routes else None,
                    "locked_route": selected_route,
                    "final_route": final_route,
                    "route_sequence": routes,
                    "unique_routes": sorted(set(routes)),
                    "action_sequence": actions,
                    "unique_actions": sorted(set(actions)),
                    "route_switches": sum(a != b for a, b in zip(routes, routes[1:])),
                    "initial_route_length_m": route_lengths[routes[0]] if routes else None,
                    "locked_route_length_m": route_lengths[selected_route] if selected_route is not None else None,
                    "route_lengths_m": route_lengths,
                    "decision_latency_p95_ms": float(np.percentile(latencies, 95)) if latencies else None,
                    "speed_ratios": [float(SPEED_RATIOS[action % 3]) for action in actions if 0 <= action < 9],
                }
            )
            env.reset((0,))
            break
    return rows


def summarize(group: list[dict]) -> dict:
    def mean(name: str):
        values = [float(row[name]) for row in group if row[name] is not None and np.isfinite(float(row[name]))]
        return float(np.mean(values)) if values else None

    def rate(name: str):
        return float(np.mean([bool(row[name]) for row in group])) if group else None

    return {
        "n": len(group),
        "success_rate": rate("success"),
        "hard_violation_rate": rate("hard_violation"),
        "mean_elapsed_s": mean("elapsed_s"),
        "mean_distance_m": mean("distance_m"),
        "mean_mechanical_energy_j": mean("mechanical_energy_j"),
        "mean_mechanical_cot": mean("mechanical_cot"),
        "mean_switches": mean("switches"),
        "mean_route_length_m": mean("locked_route_length_m"),
        "mean_decision_latency_p95_ms": mean("decision_latency_p95_ms"),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--episodes", type=int, default=108)
    parser.add_argument("--seeds", type=int, nargs="+", default=[11, 22, 33, 44, 55])
    parser.add_argument("--calibration-episodes", type=int, default=128)
    args = parser.parse_args()

    normalization = calibrate_rule_references(seed=20261009, episodes=args.calibration_episodes)
    rows: list[dict] = []
    for seed in args.seeds:
        for method in METHODS:
            print(f"collect seed={seed} method={method}", flush=True)
            rows.extend(collect_method(seed, args.episodes, args.checkpoint, normalization, method))

    aggregates = {}
    for method in METHODS:
        method_rows = [row for row in rows if row["method"] == method]
        aggregates[method] = {
            "overall": summarize(method_rows),
            "by_locked_route": {
                str(route): summarize([row for row in method_rows if row["locked_route"] == route])
                for route in range(3)
            },
            "route_counts_locked": {
                str(route): sum(row["locked_route"] == route for row in method_rows)
                for route in range(3)
            },
            "no_route_count": sum(row["locked_route"] is None for row in method_rows),
        }

    payload = {
        "protocol": {
            "episodes_per_seed": args.episodes,
            "seeds": args.seeds,
            "split": "test",
            "grouping": "locked route; initial and action sequences retained per episode",
            "routes": {str(i): route_label(i) for i in range(3)},
        },
        "rows": rows,
        "aggregates": aggregates,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"wrote {args.output}")


if __name__ == "__main__":
    main()
