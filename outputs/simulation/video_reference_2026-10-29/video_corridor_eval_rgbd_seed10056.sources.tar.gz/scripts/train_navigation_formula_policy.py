#!/usr/bin/env python3
"""Train and evaluate a PPO scorer for independent path/mode candidates.

Training and evaluation use a synthetic formula-based proxy, not Isaac Sim or
measured TITA dynamics.  The resulting checkpoints are research artifacts and
must not be connected to actuation without physical calibration and safety
validation.
"""

from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import asdict, dataclass
import json
from pathlib import Path
import random
import time

import numpy as np
import torch
from torch import nn

from tita_uc_residual_rl.formula_training_env import (
    PATH_CAPACITY,
    SCENARIO_FAMILIES,
    FormulaEpisode,
    default_formula_config,
    sample_formula_batch,
)
from tita_uc_residual_rl.navigation_formula import decode_action, enumerate_best
from tita_uc_residual_rl.navigation_formula_policy import (
    FormulaActorCritic,
    load_formula_checkpoint,
    save_formula_checkpoint,
)


@dataclass(frozen=True)
class FormulaPPOConfig:
    learning_rate: float = 0.0003
    gamma: float = 1.0
    clip_ratio: float = 0.20
    entropy_coefficient: float = 0.01
    value_coefficient: float = 0.5
    epochs: int = 4
    mini_batches: int = 4
    maximum_gradient_norm: float = 1.0


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )


def _stack(episodes: list[FormulaEpisode], device: torch.device):
    observations = torch.as_tensor(
        np.stack([episode.features for episode in episodes]), dtype=torch.float32, device=device
    )
    masks = torch.as_tensor(
        np.stack([episode.action_mask for episode in episodes]), dtype=torch.bool, device=device
    )
    reward_matrix = np.zeros((len(episodes), 28), dtype=np.float32)
    objective_matrix = np.full((len(episodes), 28), np.inf, dtype=np.float32)
    for index, episode in enumerate(episodes):
        for evaluation in episode.evaluations:
            if evaluation.feasible:
                reward_matrix[index, evaluation.action_id] = float(evaluation.reward)
                objective_matrix[index, evaluation.action_id] = float(evaluation.objective)
    rewards = torch.as_tensor(reward_matrix, dtype=torch.float32, device=device)
    objectives = torch.as_tensor(objective_matrix, dtype=torch.float32, device=device)
    return observations, masks, rewards, objectives


def ppo_update(
    model: FormulaActorCritic,
    optimizer: torch.optim.Optimizer,
    config: FormulaPPOConfig,
    observations: torch.Tensor,
    masks: torch.Tensor,
    actions: torch.Tensor,
    old_log_probabilities: torch.Tensor,
    advantages: torch.Tensor,
    returns: torch.Tensor,
) -> dict[str, float]:
    count = observations.shape[0]
    flat_advantages = (advantages - advantages.mean()) / (advantages.std(unbiased=False) + 1e-8)
    batch_size = max(1, count // config.mini_batches)
    totals = torch.zeros(4, dtype=torch.float32, device=observations.device)
    updates = 0
    for _ in range(config.epochs):
        permutation = torch.randperm(count, device=observations.device)
        for start in range(0, count, batch_size):
            indices = permutation[start : start + batch_size]
            distribution, value = model.distribution(observations[indices], masks[indices])
            new_log_probability = distribution.log_prob(actions[indices])
            ratio = torch.exp(new_log_probability - old_log_probabilities[indices])
            unclipped = ratio * flat_advantages[indices]
            clipped = ratio.clamp(1.0 - config.clip_ratio, 1.0 + config.clip_ratio) * flat_advantages[indices]
            policy_loss = -torch.minimum(unclipped, clipped).mean()
            value_loss = 0.5 * torch.square(value - returns[indices]).mean()
            entropy = distribution.entropy().mean()
            loss = policy_loss + config.value_coefficient * value_loss - config.entropy_coefficient * entropy
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), config.maximum_gradient_norm)
            optimizer.step()
            totals += torch.stack((policy_loss.detach(), value_loss.detach(), entropy.detach(), ratio.mean().detach()))
            updates += 1
    values = (totals / max(1, updates)).cpu().tolist()
    return dict(zip(("policy_loss", "value_loss", "entropy", "ratio_mean"), values))


@torch.inference_mode()
def evaluate_model(
    model: FormulaActorCritic,
    *,
    seed: int,
    episodes: int,
    config,
    device: torch.device,
) -> dict[str, object]:
    generator = np.random.default_rng(seed)
    action_counts: Counter[int] = Counter()
    path_counts: Counter[int] = Counter()
    posture_counts: Counter[int] = Counter()
    speed_counts: Counter[int] = Counter()
    family_metrics: dict[str, dict[str, list[float]]] = {
        family: {"regret": [], "oracle_match": [], "success": []}
        for family in SCENARIO_FAMILIES
    }
    argmin_selection_ms: list[float] = []
    policy_selection_ms: list[float] = []
    oracle_objectives: list[float] = []
    policy_objectives: list[float] = []
    policy_rewards: list[float] = []
    oracle_times: list[float] = []
    policy_times: list[float] = []
    oracle_lengths: list[float] = []
    policy_lengths: list[float] = []
    oracle_energies: list[float] = []
    policy_energies: list[float] = []
    oracle_matches = 0
    successes = 0
    evaluated = 0
    model.eval()

    for episode in sample_formula_batch(
        generator, episodes, config, split="test", path_capacity=model.path_capacity
    ):
        argmin_started = time.perf_counter_ns()
        oracle = enumerate_best(episode.evaluations)
        argmin_selection_ms.append((time.perf_counter_ns() - argmin_started) / 1e6)
        if oracle is None:
            continue
        observation = torch.as_tensor(episode.features, dtype=torch.float32, device=device).unsqueeze(0)
        mask = torch.as_tensor(episode.action_mask, dtype=torch.bool, device=device).unsqueeze(0)
        policy_started = time.perf_counter_ns()
        selected_action, _, _, _ = model.act(observation, mask, deterministic=True)
        policy_selection_ms.append((time.perf_counter_ns() - policy_started) / 1e6)
        action_id = int(selected_action.item())
        selected = episode.evaluations[action_id]
        regret = max(0.0, float(selected.objective) - float(oracle.objective))
        match = action_id == oracle.action_id
        success = bool(selected.feasible and selected.reward is not None)
        oracle_matches += int(match)
        successes += int(success)
        evaluated += 1
        action_counts[action_id] += 1
        path_index, posture_index, speed_index = decode_action(action_id, len(episode.paths))
        path_counts[path_index] += 1
        posture_counts[posture_index] += 1
        speed_counts[speed_index] += 1
        family_metrics[episode.family]["regret"].append(regret)
        family_metrics[episode.family]["oracle_match"].append(float(match))
        family_metrics[episode.family]["success"].append(float(success))
        oracle_objectives.append(float(oracle.objective))
        policy_objectives.append(float(selected.objective))
        policy_rewards.append(float(selected.reward))
        oracle_times.append(float(oracle.time_s))
        policy_times.append(float(selected.time_s))
        oracle_lengths.append(float(oracle.length_m))
        policy_lengths.append(float(selected.length_m))
        oracle_energies.append(float(oracle.energy_j))
        policy_energies.append(float(selected.energy_j))

    def average(values: list[float]) -> float | None:
        return float(np.mean(values)) if values else None

    def timing(values: list[float]) -> dict[str, float]:
        return {
            "mean_ms": float(np.mean(values)),
            "p50_ms": float(np.percentile(values, 50)),
            "p95_ms": float(np.percentile(values, 95)),
            "max_ms": float(np.max(values)),
        }

    per_family = {
        family: {
            "episodes": len(values["regret"]),
            "mean_regret": average(values["regret"]),
            "oracle_action_match_rate": average(values["oracle_match"]),
            "feasible_action_rate": average(values["success"]),
        }
        for family, values in family_metrics.items()
    }
    return {
        "episodes": evaluated,
        "oracle_action_match_rate": oracle_matches / max(1, evaluated),
        "feasible_action_rate": successes / max(1, evaluated),
        "mean_objective_regret": average([policy - oracle for policy, oracle in zip(policy_objectives, oracle_objectives)]),
        "mean_oracle_objective": average(oracle_objectives),
        "mean_policy_objective": average(policy_objectives),
        "mean_policy_reward": average(policy_rewards),
        "mean_oracle_time_s": average(oracle_times),
        "mean_policy_time_s": average(policy_times),
        "mean_oracle_length_m": average(oracle_lengths),
        "mean_policy_length_m": average(policy_lengths),
        "mean_oracle_energy_j": average(oracle_energies),
        "mean_policy_energy_j": average(policy_energies),
        "relative_time_efficiency": (
            average(oracle_times) / max(average(policy_times), 1e-9)
            if policy_times else None
        ),
        "relative_path_efficiency": (
            average(oracle_lengths) / max(average(policy_lengths), 1e-9)
            if policy_lengths else None
        ),
        "relative_energy_efficiency": (
            average(oracle_energies) / max(average(policy_energies), 1e-9)
            if policy_energies else None
        ),
        "selected_action_counts": {str(key): action_counts[key] for key in sorted(action_counts)},
        "selected_path_counts": {str(key): path_counts[key] for key in sorted(path_counts)},
        "selected_posture_counts": {("LOW", "MID", "HIGH")[key]: posture_counts[key] for key in range(3)},
        "selected_speed_counts": {("0.4", "0.7", "1.0")[key]: speed_counts[key] for key in range(3)},
        "per_family": per_family,
        "selection_latency": {
            "formula_argmin": timing(argmin_selection_ms),
            "ppo_forward": timing(policy_selection_ms),
            "scope": "candidate selection only; excludes route generation, prediction, sensing, planner and control",
        },
    }


def train_seed(
    *,
    run_dir: Path,
    seed: int,
    iterations: int,
    batch_size: int,
    validation_episodes: int,
    validation_interval: int,
    test_episodes: int,
    device: torch.device,
    ppo_config: FormulaPPOConfig,
) -> dict[str, object]:
    run_dir.mkdir(parents=True, exist_ok=False)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    generator = np.random.default_rng(seed)
    formula_config = default_formula_config()
    model = FormulaActorCritic(PATH_CAPACITY).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=ppo_config.learning_rate)
    write_json(
        run_dir / "config.json",
        {
            "seed": seed,
            "algorithm": "masked categorical PPO contextual-bandit fine-tuning",
            "action_contract": "3 spatial paths x 3 independent postures x 3 speed ratios + safe stop",
            "scenario_families": list(SCENARIO_FAMILIES),
            "iterations": iterations,
            "batch_size": batch_size,
            "validation_episodes": validation_episodes,
            "validation_interval": validation_interval,
            "ppo": asdict(ppo_config),
            "formula_config": asdict(formula_config),
            "evidence_scope": "synthetic formula proxy only; not Isaac or hardware calibration",
        },
    )
    metric_path = run_dir / "training_metrics.jsonl"
    best_validation: tuple[float, float] | None = None
    started = time.perf_counter()
    for iteration in range(1, iterations + 1):
        episodes = sample_formula_batch(
            generator, batch_size, formula_config, split="train", path_capacity=PATH_CAPACITY
        )
        observations, masks, reward_matrix, objective_matrix = _stack(episodes, device)
        with torch.no_grad():
            actions, old_log_probabilities, values, entropies = model.act(
                observations, masks, deterministic=False
            )
            rewards = reward_matrix.gather(1, actions[:, None]).squeeze(1)
            returns = rewards
            advantages = returns - values
        stats = ppo_update(
            model,
            optimizer,
            ppo_config,
            observations,
            masks,
            actions,
            old_log_probabilities,
            advantages,
            returns,
        )
        record: dict[str, object] = {
            "iteration": iteration,
            "samples": iteration * batch_size,
            "sampled_reward_mean": float(rewards.mean().item()),
            "sampled_objective_mean": float(-rewards.mean().item()),
            "sampled_argmin_match_rate": float(np.mean([int(action.item()) == episode.oracle_action for action, episode in zip(actions, episodes)])),
            "sampled_entropy_mean": float(entropies.mean().item()),
            **stats,
        }
        if iteration % validation_interval == 0 or iteration == iterations:
            validation = evaluate_model(
                model,
                seed=seed + 900_000,
                episodes=validation_episodes,
                config=formula_config,
                device=device,
            )
            record["validation"] = validation
            key = (
                float(validation["mean_objective_regret"]),
                -float(validation["oracle_action_match_rate"]),
            )
            if best_validation is None or key < best_validation:
                best_validation = key
                save_formula_checkpoint(
                    run_dir / "formula_policy_best.pt",
                    model,
                    formula_config,
                    optimizer_state=optimizer.state_dict(),
                    metadata={"seed": seed, "iteration": iteration, "validation": validation},
                )
        with metric_path.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(record, ensure_ascii=False, sort_keys=True, allow_nan=False) + "\n")

    save_formula_checkpoint(
        run_dir / "formula_policy_last.pt",
        model,
        formula_config,
        optimizer_state=optimizer.state_dict(),
        metadata={"seed": seed, "iteration": iterations},
    )
    best_model, restored_config, _ = load_formula_checkpoint(
        run_dir / "formula_policy_best.pt", device=str(device)
    )
    test = evaluate_model(
        best_model,
        seed=seed + 1_900_000,
        episodes=test_episodes,
        config=restored_config,
        device=device,
    )
    argmin_reference = evaluate_argmin(
        seed=seed + 1_900_000,
        episodes=test_episodes,
        config=restored_config,
        path_capacity=PATH_CAPACITY,
    )
    write_json(
        run_dir / "evaluation_test.json",
        {
            "seed": seed,
            "checkpoint": "formula_policy_best.pt",
            "test_seed": seed + 1_900_000,
            "formula_argmin_reference": argmin_reference,
            "ppo": test,
            "scope": "held-out synthetic proxy scenarios; no physics or online perception",
        },
    )
    summary = {
        "seed": seed,
        "iterations": iterations,
        "batch_size": batch_size,
        "samples": iterations * batch_size,
        "elapsed_wall_s": time.perf_counter() - started,
        "best_validation_regret": best_validation[0] if best_validation else None,
        "best_validation_argmin_match": -best_validation[1] if best_validation else None,
        "test_argmin_match_rate": test["oracle_action_match_rate"],
        "test_mean_objective_regret": test["mean_objective_regret"],
        "test_posture_counts": test["selected_posture_counts"],
        "test_checkpoint": "formula_policy_best.pt",
    }
    write_json(run_dir / "training_summary.json", summary)
    return summary


def evaluate_argmin(*, seed: int, episodes: int, config, path_capacity: int) -> dict[str, object]:
    generator = np.random.default_rng(seed)
    posture_counts: Counter[int] = Counter()
    path_counts: Counter[int] = Counter()
    speed_counts: Counter[int] = Counter()
    family_metrics = {family: {"regret": [], "success": []} for family in SCENARIO_FAMILIES}
    selection_times: list[float] = []
    objectives: list[float] = []
    times: list[float] = []
    lengths: list[float] = []
    energies: list[float] = []
    evaluated = 0
    for episode in sample_formula_batch(generator, episodes, config, split="test", path_capacity=path_capacity):
        started = time.perf_counter_ns()
        selected = enumerate_best(episode.evaluations)
        selection_times.append((time.perf_counter_ns() - started) / 1e6)
        if selected is None:
            continue
        path_index, posture_index, speed_index = decode_action(selected.action_id, len(episode.paths))
        posture_counts[posture_index] += 1
        path_counts[path_index] += 1
        speed_counts[speed_index] += 1
        family_metrics[episode.family]["regret"].append(0.0)
        family_metrics[episode.family]["success"].append(float(selected.feasible))
        objectives.append(float(selected.objective))
        times.append(float(selected.time_s))
        lengths.append(float(selected.length_m))
        energies.append(float(selected.energy_j))
        evaluated += 1
    return {
        "episodes": evaluated,
        "oracle_action_match_rate": 1.0,
        "feasible_action_rate": 1.0,
        "mean_objective_regret": 0.0,
        "mean_objective": float(np.mean(objectives)),
        "mean_time_s": float(np.mean(times)),
        "mean_length_m": float(np.mean(lengths)),
        "mean_energy_j": float(np.mean(energies)),
        "selected_path_counts": {str(key): path_counts[key] for key in sorted(path_counts)},
        "selected_posture_counts": {("LOW", "MID", "HIGH")[key]: posture_counts[key] for key in range(3)},
        "selected_speed_counts": {("0.4", "0.7", "1.0")[key]: speed_counts[key] for key in range(3)},
        "per_family": {
            family: {
                "episodes": len(values["regret"]),
                "mean_regret": float(np.mean(values["regret"])) if values["regret"] else None,
                "feasible_action_rate": float(np.mean(values["success"])) if values["success"] else None,
            }
            for family, values in family_metrics.items()
        },
        "selection_latency": {
            "formula_argmin": {
                "mean_ms": float(np.mean(selection_times)),
                "p50_ms": float(np.percentile(selection_times, 50)),
                "p95_ms": float(np.percentile(selection_times, 95)),
                "max_ms": float(np.max(selection_times)),
            },
            "scope": "enumeration only; excludes route generation, prediction, sensing, planner and control",
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seeds", nargs="+", type=int, default=(11, 22, 33))
    parser.add_argument("--iterations", type=int, default=180)
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument("--validation-episodes", type=int, default=240)
    parser.add_argument("--validation-interval", type=int, default=20)
    parser.add_argument("--test-episodes", type=int, default=1200)
    parser.add_argument("--device", default="cpu")
    args = parser.parse_args()
    if min(args.iterations, args.batch_size, args.validation_episodes, args.validation_interval, args.test_episodes) <= 0:
        raise ValueError("training and validation sizes must be positive")
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    torch.set_num_threads(1)
    device = torch.device(args.device)
    ppo_config = FormulaPPOConfig()
    write_json(
        output / "run_manifest.json",
        {
            "created_at_local": time.strftime("%Y-%m-%d %H:%M:%S %z"),
            "seeds": args.seeds,
            "algorithm": "PPO contextual-bandit fine-tuning of independent path/posture/speed scorer",
            "action_count": PATH_CAPACITY * 9 + 1,
            "scenario_families": list(SCENARIO_FAMILIES),
            "training_proxy": True,
            "isaac_sim_used": False,
            "low_level_controller_trained": False,
            "online_dynamic_obstacles": False,
            "device": str(device),
        },
    )
    summaries = []
    for seed in args.seeds:
        print(f"Training seed {seed} ({args.iterations} updates x {args.batch_size} scenarios)", flush=True)
        summaries.append(
            train_seed(
                run_dir=output / f"seed_{seed}",
                seed=seed,
                iterations=args.iterations,
                batch_size=args.batch_size,
                validation_episodes=args.validation_episodes,
                validation_interval=args.validation_interval,
                test_episodes=args.test_episodes,
                device=device,
                ppo_config=ppo_config,
            )
        )
    write_json(output / "training_summary.json", {"seeds": summaries})
    print(json.dumps({"seeds": summaries}, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
