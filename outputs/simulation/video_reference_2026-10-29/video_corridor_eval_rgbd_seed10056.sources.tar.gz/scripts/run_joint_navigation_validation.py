#!/usr/bin/env python3
"""Train and validate the joint path/posture/speed upper policy.

This command is the simulator-independent online contract test.  It exercises
the same A* candidate versioning, action mask, pedestrian prediction and
NeuPAN adapter used by the Isaac/ROS bridge.  Vendor NeuPAN is reported only
when its optional dependencies initialize successfully.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from tita_uc_residual_rl.joint_navigation import evaluate_policy, results_summary, train_policy


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--episodes", type=int, default=240)
    parser.add_argument("--eval-episodes", type=int, default=8)
    parser.add_argument("--seed", type=int, default=11)
    parser.add_argument("--neupan-yaml", type=Path, default=None)
    parser.add_argument("--vendor-root", type=Path, default=None)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "outputs" / "joint_navigation_validation")
    args = parser.parse_args()
    if args.episodes <= 0 or args.eval_episodes <= 0:
        raise SystemExit("episodes must be positive")
    policy = train_policy(args.episodes, args.seed)
    results = evaluate_policy(policy, args.eval_episodes, args.neupan_yaml, args.vendor_root)
    summary = results_summary(results)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    policy_path = args.output_dir / "joint_q_policy.json"
    report_path = args.output_dir / "joint_navigation_summary.json"
    policy.save(policy_path)
    report_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"policy": str(policy_path), "report": str(report_path), **summary}, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
