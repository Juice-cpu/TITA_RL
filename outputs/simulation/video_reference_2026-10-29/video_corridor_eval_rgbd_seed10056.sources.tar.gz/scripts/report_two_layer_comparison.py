#!/usr/bin/env python3
"""Build a reproducible two-layer navigation comparison report.

The first layer is deliberately restricted to fixed-path local-controller
comparison.  The second layer is reported separately because the available
upper-level Isaac evidence uses the frozen lower controller but is not yet a
single registered experiment with the same three spatial A* candidates for
every policy.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path
import statistics
from typing import Any

import numpy as np

from tita_uc_residual_rl.navigation_maze import box_distance_xy, load_maze


DEFAULT_LAYER1 = Path("rl_runs/navigation_benchmark/maze_v2_repeats10_equal06_20261019")
DEFAULT_TIMING = Path("rl_runs/navigation_benchmark/maze_v2_rl_timing3_measured_20261019")
DEFAULT_UPPER_ISAAC = Path(
    "/home/ky/Documents/Codex/2026-10-17/01a11a97-ce63-7a80-b8b4-91bef9bdc293/work/isaac_upper_v4"
)
DEFAULT_UPPER_TOY = Path("/home/ky/neupan_tita_sandbox/outputs/upper_level")


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text())


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def percentile(values: list[float], value: float) -> float | None:
    if not values:
        return None
    return float(np.percentile(np.asarray(values, dtype=float), value))


def scalar_stats(values: list[float]) -> dict[str, float | int | None]:
    clean = [float(value) for value in values if math.isfinite(float(value))]
    if not clean:
        return {"n": 0, "mean": None, "sd": None, "p50": None, "p95": None, "p99": None, "max": None}
    return {
        "n": len(clean),
        "mean": float(np.mean(clean)),
        "sd": float(statistics.stdev(clean)) if len(clean) > 1 else 0.0,
        "p50": percentile(clean, 50),
        "p95": percentile(clean, 95),
        "p99": percentile(clean, 99),
        "max": float(np.max(clean)),
    }


def circular_error(actual: float, reference: float) -> float:
    return abs(math.atan2(math.sin(actual - reference), math.cos(actual - reference)))


def yaw_from_quaternion(quaternion: list[float]) -> float:
    w, x, y, z = (float(value) for value in quaternion)
    return math.atan2(2.0 * (w * z + x * y), 1.0 - 2.0 * (y * y + z * z))


def nearest_polyline_error(point: np.ndarray, reference: np.ndarray) -> tuple[float, float, float]:
    if len(reference) < 2:
        raise ValueError("reference path requires at least two points")
    starts = reference[:-1]
    vectors = np.diff(reference, axis=0)
    lengths_squared = np.sum(vectors * vectors, axis=1)
    offsets = point[None, :] - starts
    fractions = np.clip(
        np.sum(offsets * vectors, axis=1) / np.maximum(lengths_squared, 1e-20), 0.0, 1.0
    )
    projections = starts + fractions[:, None] * vectors
    distances = np.linalg.norm(point[None, :] - projections, axis=1)
    index = int(np.argmin(distances))
    vector = vectors[index]
    length = math.sqrt(float(lengths_squared[index]))
    signed_lateral = float(vector[0] * (point[1] - projections[index, 1]) - vector[1] * (point[0] - projections[index, 0])) / max(length, 1e-12)
    tangent = math.atan2(float(vector[1]), float(vector[0]))
    return float(distances[index]), abs(signed_lateral), tangent


def path_length(points: np.ndarray) -> float:
    if len(points) < 2:
        return 0.0
    return float(np.linalg.norm(np.diff(points, axis=0), axis=1).sum())


def trial_metrics(run_dir: Path) -> dict[str, Any]:
    manifest = read_json(run_dir / "run_manifest.json")
    scene_path = run_dir / "navigation_scene.json"
    scene = load_maze(scene_path)
    planner_rows = read_jsonl(run_dir / "planner_trace.jsonl")
    control_rows = read_jsonl(run_dir / "control_trace.jsonl")
    path_events = [row for row in planner_rows if row.get("event") == "path"]
    solve_rows = [row for row in planner_rows if row.get("event") == "solve"]
    if not path_events:
        raise ValueError(f"missing selected path in {run_dir}")
    reference = np.asarray(path_events[0]["points"], dtype=float)
    positions = np.asarray([row["position"][:2] for row in control_rows], dtype=float)
    periods = np.diff([float(row["sim_time_s"]) for row in control_rows])
    dt = float(np.median(periods)) if len(periods) else 0.02

    tracking = [nearest_polyline_error(point, reference) for point in positions]
    lateral = [item[1] for item in tracking]
    centerline = [item[0] for item in tracking]
    heading_errors = []
    measured_speed = []
    desired_speed = []
    measured_yaw_rate = []
    desired_yaw_rate = []
    for row, item in zip(control_rows, tracking):
        yaw = yaw_from_quaternion(row["quaternion_wxyz"])
        heading_errors.append(circular_error(yaw, item[2]))
        measured_speed.append(float(row["linear_b"][0]))
        desired_speed.append(float(row["desired"][0]))
        measured_yaw_rate.append(float(row["angular_b"][2]))
        desired_yaw_rate.append(float(row["desired"][2]))

    speed_acceleration = np.diff(np.asarray(measured_speed), prepend=measured_speed[0]) / max(dt, 1e-12)
    yaw_acceleration = np.diff(np.asarray(measured_yaw_rate), prepend=measured_yaw_rate[0]) / max(dt, 1e-12)
    speed_deltas = np.diff(np.asarray(measured_speed))

    obstacle_clearance = []
    footprint_radius = float(scene["footprint_radius_m"])
    for point in positions:
        wall_distances = [
            float(box_distance_xy(point[None, :], box)[0]) - footprint_radius
            for box in scene["boxes"]
            if box["kind"] == "wall"
        ]
        if wall_distances:
            obstacle_clearance.append(min(wall_distances))

    hard_failure = any(any(bool(value) for value in row.get("hard_reasons", [])) for row in control_rows)
    evaluation = read_json(run_dir / "evaluation" / "evaluation_summary.json")
    episode = evaluation.get("episodes", [{}])[0]
    solve_times = [float(row["solve_wall_s"]) for row in solve_rows]
    sim_times = [float(row["sim_time_s"]) for row in control_rows]
    directory_name = run_dir.name
    algorithm = (
        "rl" if "_rl_" in f"_{directory_name}_" else
        "dct" if "_dct_" in f"_{directory_name}_" else
        "neupan" if "_neupan_" in f"_{directory_name}_" else
        manifest.get("navigation_algorithm", manifest.get("policy", "unknown"))
    )
    result = {
        "algorithm": algorithm,
        "seed": manifest.get("policy_seed"),
        "run_dir": str(run_dir.resolve()),
        "success": bool(episode.get("success", False)),
        "hard_failure": hard_failure,
        "planned_path_length_m": path_length(reference),
        "executed_path_length_m": path_length(positions),
        "navigation_time_s": float(episode.get("elapsed_s", sim_times[-1] if sim_times else 0.0)),
        "planning_success": bool(path_events and solve_rows),
        "planner_solve_ms": scalar_stats([value * 1000.0 for value in solve_times]),
        "planner_timeout_100ms_count": int(sum(value > 0.100 for value in solve_times)),
        "planner_solve_count": len(solve_times),
        "control_period_ms": scalar_stats([value * 1000.0 for value in periods.tolist()]),
        "sim_control_frequency_hz": float(1.0 / dt) if dt > 0 else None,
        "tracking_error_m": scalar_stats(centerline),
        "lateral_error_m": scalar_stats(lateral),
        "heading_error_rad": scalar_stats(heading_errors),
        "minimum_obstacle_clearance_m": float(min(obstacle_clearance)) if obstacle_clearance else None,
        "speed_tracking_error_mps": scalar_stats([abs(a - b) for a, b in zip(desired_speed, measured_speed)]),
        "angular_speed_tracking_error_rps": scalar_stats([abs(a - b) for a, b in zip(desired_yaw_rate, measured_yaw_rate)]),
        "maximum_abs_acceleration_mps2": float(np.max(np.abs(speed_acceleration))) if len(speed_acceleration) else None,
        "maximum_abs_angular_speed_rps": float(np.max(np.abs(measured_yaw_rate))) if measured_yaw_rate else None,
        "maximum_abs_angular_acceleration_rps2": float(np.max(np.abs(yaw_acceleration))) if len(yaw_acceleration) else None,
        "speed_smoothness_mean_delta_mps": float(np.mean(np.abs(speed_deltas))) if len(speed_deltas) else 0.0,
        "speed_smoothness_rms_delta_mps": float(np.sqrt(np.mean(speed_deltas * speed_deltas))) if len(speed_deltas) else 0.0,
        "mechanical_energy_j": float(episode.get("energy_j", float("nan"))),
        "energy_j_per_m": float(episode.get("energy_j", float("nan"))) / max(path_length(positions), 1e-12),
        "source_scope": "Isaac Sim trace replay; geometry clearance uses the registered static scene oracle",
    }
    return result


def aggregate_trials(trials: list[dict[str, Any]]) -> dict[str, Any]:
    scalar_keys = [
        "navigation_time_s", "planned_path_length_m", "executed_path_length_m", "minimum_obstacle_clearance_m",
        "sim_control_frequency_hz", "maximum_abs_acceleration_mps2", "maximum_abs_angular_speed_rps",
        "maximum_abs_angular_acceleration_rps2", "speed_smoothness_mean_delta_mps", "speed_smoothness_rms_delta_mps",
        "mechanical_energy_j", "energy_j_per_m",
    ]
    aggregate: dict[str, Any] = {"trials": len(trials), "success_rate": float(np.mean([item["success"] for item in trials])) if trials else None,
                                 "hard_failure_rate": float(np.mean([item["hard_failure"] for item in trials])) if trials else None,
                                 "planning_success_rate": float(np.mean([item["planning_success"] for item in trials])) if trials else None}
    for key in scalar_keys:
        aggregate[key] = scalar_stats([float(item[key]) for item in trials if item[key] is not None and math.isfinite(float(item[key]))])
    for key in ("planner_solve_ms", "control_period_ms", "tracking_error_m", "lateral_error_m", "heading_error_rad", "speed_tracking_error_mps", "angular_speed_tracking_error_rps"):
        aggregate[key] = {
            field: scalar_stats([float(item[key][field]) for item in trials if item[key].get(field) is not None])
            for field in ("mean", "p50", "p95", "p99", "max")
        }
    aggregate["planner_timeout_100ms_count"] = int(sum(item["planner_timeout_100ms_count"] for item in trials))
    aggregate["planner_solve_count"] = int(sum(item["planner_solve_count"] for item in trials))
    return aggregate


def load_timing_summary(path: Path) -> dict[str, Any] | None:
    summary = path / "decision_timing_summary.json"
    return read_json(summary) if summary.exists() else None


def upper_isaac_summary(root: Path) -> dict[str, Any]:
    if not root.exists():
        return {"available": False, "reason": "Isaac upper-level evidence directory not found"}
    rows: list[dict[str, Any]] = []
    for evaluation in sorted(root.glob("*/evaluation/evaluation_summary.json")):
        directory = evaluation.parent.parent
        manifest = read_json(directory / "run_manifest.json")
        summary = read_json(evaluation)
        episode = summary.get("episodes", [{}])[0]
        policy = str(manifest.get("policy", summary.get("policy", "unknown")))
        name = directory.name
        if "retry" in name and name != "eval_enumeration_ym045_retry6":
            continue
        if name.startswith("eval_enumeration_ym045") and name != "eval_enumeration_ym045_retry6":
            continue
        rows.append({
            "run": name,
            "method": "Formula-Argmin" if policy == "enumeration" else ("BC-only" if "bc_only" in name else "PPO-reference"),
            "policy": policy,
            "goal_y_m": float(manifest.get("goal", [0.0, 0.0])[1]),
            "success": bool(episode.get("success", False)),
            "hard_failure": bool(episode.get("hard_failure", False)),
            "elapsed_s": episode.get("elapsed_s"),
            "executed_path_length_m": episode.get("distance_m"),
            "mechanical_energy_j": episode.get("energy_j"),
            "objective_J": episode.get("J"),
            "action_trace": str(directory / "control_trace.jsonl"),
        })
    return {
        "available": bool(rows),
        "scope": "preliminary Isaac upper-level study; frozen lower stack, but not yet the final same-three-spatial-candidates protocol",
        "runs": rows,
    }


def upper_toy_summary(root: Path) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    for seed_dir in sorted(root.glob("model_v2_seed*")):
        for path in sorted(seed_dir.glob("eval_*.json")):
            data = read_json(path)
            episodes = data.get("episodes_data", [])
            for episode in episodes:
                rows.append({"seed": seed_dir.name, "method": data.get("method"), "source": str(path), **episode})
    return {
        "available": bool(rows),
        "scope": "simulator-independent upper-level toy environment; not an Isaac physical result",
        "episodes": rows,
    }


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    keys = sorted({key for row in rows for key in row})
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def fmt(value: Any, digits: int = 3) -> str:
    if value is None:
        return "—"
    if isinstance(value, bool):
        return "是" if value else "否"
    if isinstance(value, (int, float)):
        return f"{value:.{digits}f}"
    return str(value)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--layer1", type=Path, default=DEFAULT_LAYER1)
    parser.add_argument("--timing", type=Path, default=DEFAULT_TIMING)
    parser.add_argument("--upper-isaac", type=Path, default=DEFAULT_UPPER_ISAAC)
    parser.add_argument("--upper-toy", type=Path, default=DEFAULT_UPPER_TOY)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    trial_rows = []
    for run_dir in sorted(args.layer1.glob("equal_cruise_*_seed*")):
        if not (run_dir / "control_trace.jsonl").exists():
            continue
        trial_rows.append(trial_metrics(run_dir))
    layer1 = {
        "scope": "Layer 1: fixed selected global path and fixed MID policy; compare local execution only",
        "included_algorithms": ["neupan", "dct"],
        "excluded_from_local_ranking": "rl, because RL changes the upper decision and therefore belongs to Layer 2",
        "trials": trial_rows,
        "by_algorithm": {algorithm: aggregate_trials([row for row in trial_rows if row["algorithm"] == algorithm]) for algorithm in ("neupan", "dct", "rl")},
    }
    timing = load_timing_summary(args.timing)
    upper = {"isaac": upper_isaac_summary(args.upper_isaac), "toy": upper_toy_summary(args.upper_toy)}
    report = {
        "simulation_only": True,
        "created_from_existing_traces": True,
        "layer1": layer1,
        "timing": timing,
        "layer2": {
            "status": "preliminary_only",
            "required_final_protocol": "same candidate path set × same NeuPAN × only upper decision policy changes",
            "isaac_preliminary": upper["isaac"],
            "toy_reference": upper["toy"],
            "formula_residual_status": "not physically evaluated in the registered same-candidate Isaac protocol",
        },
    }
    (args.output / "two_layer_comparison.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    write_csv(args.output / "layer1_trial_metrics.csv", trial_rows)

    lines = [
        "# 两层导航比较复算报告",
        "",
        "本报告只使用已有的 Isaac Sim/上层试验日志进行复算，不覆盖原始结果。第三层完整系统比较未纳入。",
        "",
        "## 第一层：固定路径局部规划器",
        "",
        "NeuPAN 与 DCT 在相同起点、终点、静态场景、固定 MID 动作和同一条选定 A* 路径下比较；RL 不作为第一层局部规划器排名对象。",
        "",
        "| 方法 | 回合数 | 到达率 | 规划成功率 | 规划耗时均值/P95 ms | 100 ms 超时 | 实际路径 m | 跟踪误差均值 m | 最小障碍净空 m | 机械能 J/m |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for algorithm, label in (("neupan", "NeuPAN"), ("dct", "DCT-core")):
        aggregate = layer1["by_algorithm"][algorithm]
        solve = aggregate["planner_solve_ms"]
        tracking = aggregate["tracking_error_m"]["mean"]
        lines.append(
            "| {label} | {n} | {success:.1%} | {planning:.1%} | {solve_mean}/{solve_p95} | {timeouts} | {distance} | {tracking} | {clearance} | {energy} |".format(
                label=label,
                n=aggregate["trials"],
                success=aggregate["success_rate"],
                planning=aggregate["planning_success_rate"],
                solve_mean=fmt(solve["mean"]["mean"], 2),
                solve_p95=fmt(solve["p95"]["mean"], 2),
                timeouts=aggregate["planner_timeout_100ms_count"],
                distance=fmt(aggregate["executed_path_length_m"]["mean"], 3),
                tracking=fmt(tracking["mean"], 4),
                clearance=fmt(aggregate["minimum_obstacle_clearance_m"]["mean"], 3),
                energy=fmt(aggregate["energy_j_per_m"]["mean"], 2),
            )
        )
    lines.extend([
        "",
        "说明：控制周期来自仿真时间戳；墙钟频率只在带 sidecar 计时的 RL 回合中测得，不能反推 NeuPAN/DCT 的实机端到端频率。CPU/GPU/内存未在这批原始日志中形成可比的统一采样，故不填伪造数值。",
        "",
        "## 第二层：上层路径—姿态—速度决策",
        "",
        "当前已有的 `isaac_upper_v4` 是冻结下层控制器上的预备上层研究，包含 Formula-Argmin/枚举、BC-only 和 PPO-reference；但其目标扰动与动作选择不能替代最终的“同一组三条空间 A* 候选路径、只替换上层决策器”注册协议。因此以下数据只能标为 preliminary，不能作为最终 RL 优越性结论。",
        "",
        "最终协议必须固定 `P1/P2/P3`、NeuPAN、传感器、机器人、安全门和随机种子，只改变 `Shortest`、`Formula-Argmin`、`PPO/RL`、`Formula+RL residual`；动作记录必须保存 `(path_id, posture_schedule, speed_schedule)`。",
        "",
        "### 已有 Isaac Sim 预备结果",
        "",
        "| 方法 | 回合数 | 到达率 | 到达时间均值 s | 实际轨迹均值 m | 机械能均值 J |",
        "|---|---:|---:|---:|---:|---:|",
    ])
    isaac_rows = upper["isaac"].get("runs", [])
    for method in ("Formula-Argmin", "BC-only", "PPO-reference"):
        rows = [row for row in isaac_rows if row["method"] == method]
        if not rows:
            continue
        lines.append(
            "| {method} | {n} | {success:.1%} | {time:.2f} | {distance:.3f} | {energy:.1f} |".format(
                method=method,
                n=len(rows),
                success=float(np.mean([row["success"] for row in rows])),
                time=float(np.mean([row["elapsed_s"] for row in rows])),
                distance=float(np.mean([row["executed_path_length_m"] for row in rows])),
                energy=float(np.mean([row["mechanical_energy_j"] for row in rows])),
            )
        )
    lines.extend([
        "",
        "这些 Isaac 数字来自不同目标横向偏置（−0.45、+0.60、+0.75 m）的预备研究，不能直接等同于同一三候选空间路径集合上的最终比较。",
        "",
        "### 上层 toy 环境参考",
        "",
        "| 方法 | 样本数 | 到达率 | 硬约束违反率 | 时间均值 s | 机械能均值 J |",
        "|---|---:|---:|---:|---:|---:|",
    ])
    toy_rows = upper["toy"].get("episodes", [])
    for method in ("shortest", "enumeration", "ppo"):
        rows = [row for row in toy_rows if row["method"] == method]
        if not rows:
            continue
        lines.append(
            "| {method} | {n} | {success:.1%} | {hard:.1%} | {time:.2f} | {energy:.2f} |".format(
                method=method,
                n=len(rows),
                success=float(np.mean([row["success"] for row in rows])),
                hard=float(np.mean([row["hard_violation"] for row in rows])),
                time=float(np.mean([row["elapsed_s"] for row in rows])),
                energy=float(np.mean([row["mechanical_energy_j"] for row in rows])),
            )
        )
    lines.extend([
        "",
        "toy 结果仅验证上层策略接口与目标函数，不是机器人物理闭环结果；不能把 toy 中 PPO 的成本与 Isaac Sim 的机械能直接混合比较。",
        "",
        "## 复现文件",
        "",
        f"- JSON：`{(args.output / 'two_layer_comparison.json').resolve()}`",
        f"- 第一层逐回合 CSV：`{(args.output / 'layer1_trial_metrics.csv').resolve()}`",
        f"- 第一层图和原始复算：`{(args.output.parent / 'layer1_recomputed').resolve()}`",
        f"- 实时性复算：`{(args.output.parent / 'timing_recomputed').resolve()}`",
    ])
    (args.output / "two_layer_comparison.md").write_text("\n".join(lines) + "\n")
    print(args.output / "two_layer_comparison.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
