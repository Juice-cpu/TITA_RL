#!/usr/bin/env python3
"""Diagnose aligned simulation commands without treating gate output as planner input."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

from analyze_motion_quality import load_trace, motion_arrays, window_metrics


def layer_metrics(commands, steps, times, yaw_deadband=0.02):
    commands = np.asarray(commands, dtype=float)
    if commands.ndim != 2 or commands.shape[1] != 3 or not np.isfinite(commands).all():
        raise ValueError("command layers require finite three-component samples")
    consecutive = np.diff(steps) == 1
    delta_time = np.diff(times)[consecutive]
    if np.any(delta_time <= 0):
        raise ValueError("physical sample times must increase")
    rates = np.diff(commands, axis=0)[consecutive] / delta_time[:, None]
    reversals = 0
    previous_sign = 0
    for index, yaw in enumerate(commands[:, 2]):
        if index and not consecutive[index - 1]:
            previous_sign = 0
        sign = int(np.sign(yaw)) if abs(yaw) > yaw_deadband else 0
        if sign:
            reversals += int(previous_sign != 0 and sign != previous_sign)
            previous_sign = sign
    return {
        "samples": len(commands),
        "forward_mean_mps": float(commands[:, 0].mean()),
        "forward_std_mps": float(commands[:, 0].std()),
        "yaw_mean_radps": float(commands[:, 2].mean()),
        "yaw_std_radps": float(commands[:, 2].std()),
        "yaw_rms_radps": float(np.sqrt(np.mean(commands[:, 2] ** 2))),
        "yaw_reversals": reversals,
        "yaw_saturated_fraction_at_0p30_radps": float(np.mean(np.abs(commands[:, 2]) >= 0.299)),
        "forward_rate_rms_mps2": float(np.sqrt(np.mean(rates[:, 0] ** 2))) if len(rates) else None,
        "yaw_rate_of_change_rms_radps2": float(np.sqrt(np.mean(rates[:, 2] ** 2))) if len(rates) else None,
    }


def diagnose_rows(rows, *, warmup_s=5.0, straight_x=(2.9, 5.1)):
    arrays = motion_arrays(rows)
    if not np.all(np.diff(arrays["step"]) == 1):
        raise ValueError("diagnostics require contiguous physical control steps")
    if len({row["episode_id"] for row in rows}) != 1:
        raise ValueError("diagnostics require one episode; do not combine reset boundaries")
    windows = {
        "all_samples": np.ones(len(rows), dtype=bool),
        "after_warmup": arrays["time"] >= warmup_s,
        "matched_straight_segment": ((arrays["time"] >= warmup_s)
                                     & (arrays["position"][:, 0] > straight_x[0])
                                     & (arrays["position"][:, 0] < straight_x[1])),
    }
    results = {}
    for name, selected in windows.items():
        if selected.sum() < 2:
            results[name] = {"available": False, "reason": "fewer than two samples"}
            continue
        selected_rows = [row for row, included in zip(rows, selected) if included]
        steps, times = arrays["step"][selected], arrays["time"][selected]
        layers = {}
        for layer in ("planner_raw", "gate_output", "requested", "desired", "policy_command"):
            commands = [((row.get("command_trace") or {}).get(layer)
                         if layer in ("planner_raw", "gate_output") else row.get(layer))
                        for row in selected_rows]
            if all(command is not None for command in commands):
                layers[layer] = layer_metrics(commands, steps, times)
            else:
                layers[layer] = {"available": False, "reason": "not recorded; never infer planner input from requested"}
        recorded = [row for row in selected_rows
                    if (row.get("command_trace") or {}).get("planner_raw") is not None
                    and (row.get("command_trace") or {}).get("gate_output") is not None]
        changed = [not np.allclose(row["command_trace"]["planner_raw"],
                                   row["command_trace"]["gate_output"], atol=1e-6, rtol=0)
                   for row in recorded]
        results[name] = {
            "motion": window_metrics(arrays, selected),
            "layers": layers,
            "gate_changed_fraction": float(np.mean(changed)) if changed else None,
            "safety_override_samples": sum(bool(row.get("safety_override")) for row in selected_rows),
            "stale_command_samples": sum(row.get("command_stale") is True for row in selected_rows),
            "action_ids": sorted({row["action_id"] for row in selected_rows}),
        }
    return results


def planner_timing(path):
    if not path.exists():
        return {"available": False}
    records = load_trace(path)
    solves = [row for row in records if row["event"] == "solve"]
    source_steps = np.array([row["source_feedback_sequence"] for row in solves])
    lag = np.array([row["publish_feedback_sequence"] - row["source_feedback_sequence"] for row in solves])
    return {
        "solves": len(solves),
        "path_resets": sum(row["event"] == "path" for row in records),
        "source_interval_steps_median": float(np.median(np.diff(source_steps))) if len(solves) > 1 else None,
        "source_interval_steps_max": int(np.max(np.diff(source_steps))) if len(solves) > 1 else None,
        "publication_lag_steps_median": float(np.median(lag)) if len(solves) else None,
        "publication_lag_steps_max": int(np.max(lag)) if len(solves) else None,
        "scope": "feedback sequence lag; feedback and odometry are separate ROS subscriptions, not an exact solver-input timestamp",
    }


def audit_planner_clock(rows):
    if not any(row.get("planner_source") is not None for row in rows):
        return {"available": False, "reason": "planner source acknowledgement was not recorded"}
    errors = []
    ages = []
    for row in rows:
        source = row.get("planner_source")
        sequence = source.get("sequence") if isinstance(source, dict) else None
        episode = source.get("episode_id") if isinstance(source, dict) else None
        age = row["control_step"] - 1 - sequence if type(sequence) is int else None
        if (type(episode) is not int or episode != row["episode_id"]
                or age is None or not 0 <= age < 5 or row.get("command_stale") is not False):
            errors.append(row["control_step"])
        if age is not None:
            ages.append(age)
    return {"available": True, "passed": not errors, "samples": len(rows),
            "invalid_steps": errors, "max_source_age_steps": max(ages) if ages else None,
            "criterion": "same-episode nonfuture source, age 0..4 physics steps, nonstale UDP command"}


def reference_tracking(rows, points, selected):
    points = np.asarray(points, dtype=float)
    segments = np.diff(points, axis=0)
    lengths_squared = np.sum(segments ** 2, axis=1)
    valid = lengths_squared > 1e-12
    if not valid.any():
        raise ValueError("reference path has no nonzero-length segments")
    starts, segments, lengths_squared = points[:-1][valid], segments[valid], lengths_squared[valid]
    positions = np.array([row["position"][:2] for row, included in zip(rows, selected) if included])
    offsets = positions[:, None, :] - starts[None, :, :]
    projection = np.clip(np.sum(offsets * segments[None, :, :], axis=2) / lengths_squared, 0, 1)
    distances = np.linalg.norm(offsets - projection[:, :, None] * segments[None, :, :], axis=2)
    nearest = np.argmin(distances, axis=1)
    errors = distances[np.arange(len(positions)), nearest]
    quaternion = np.array([row["quaternion_wxyz"] for row, included in zip(rows, selected) if included])
    quaternion = quaternion / np.linalg.norm(quaternion, axis=1, keepdims=True)
    yaw = np.arctan2(2 * (quaternion[:, 0] * quaternion[:, 3] + quaternion[:, 1] * quaternion[:, 2]),
                     1 - 2 * (quaternion[:, 2] ** 2 + quaternion[:, 3] ** 2))
    heading = np.arctan2(segments[nearest, 1], segments[nearest, 0])
    heading_error = np.arctan2(np.sin(yaw - heading), np.cos(yaw - heading))
    return {"cross_track_rms_m": float(np.sqrt(np.mean(errors ** 2))),
            "cross_track_max_m": float(np.max(errors)),
            "heading_error_rms_rad": float(np.sqrt(np.mean(heading_error ** 2))),
            "scope": "distance and heading to selected polyline; not robot swept-volume clearance"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_directory", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    directory = arguments.run_directory.resolve()
    trace = directory / "control_trace.jsonl"
    result = {
        "simulation_only": True,
        "trace_sha256": hashlib.sha256(trace.read_bytes()).hexdigest(),
        "definitions": {"warmup_s": 5.0, "straight_segment_world_x_m": [2.9, 5.1],
                        "yaw_reversal_deadband_radps": 0.02,
                        "scope": "command-chain diagnosis, not collision certification or policy training"},
        "windows": diagnose_rows(load_trace(trace)),
        "planner_clock_audit": audit_planner_clock(load_trace(trace)),
        "planner_timing": planner_timing(directory / "planner_trace.jsonl"),
    }
    planner_trace = directory / "planner_trace.jsonl"
    paths = [record for record in load_trace(planner_trace) if record["event"] == "path"] if planner_trace.exists() else []
    if len(paths) == 1:
        rows = load_trace(trace)
        arrays = motion_arrays(rows)
        selected = ((arrays["time"] >= 5.0) & (arrays["position"][:, 0] > 2.9)
                    & (arrays["position"][:, 0] < 5.1))
        if selected.sum() >= 2:
            result["windows"]["matched_straight_segment"]["reference_tracking"] = reference_tracking(
                rows, paths[0]["points"], selected,
            )
    arguments.output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    middle = result["windows"]["matched_straight_segment"]
    print(json.dumps({"middle": middle, "planner_timing": result["planner_timing"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
