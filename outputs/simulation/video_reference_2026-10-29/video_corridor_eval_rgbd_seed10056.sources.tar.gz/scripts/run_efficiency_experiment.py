#!/usr/bin/env python3
"""Run and report static-to-dynamic navigation efficiency measurements."""

from __future__ import annotations

import argparse
import csv
from dataclasses import asdict
import importlib.util
import json
from pathlib import Path
import statistics
import time

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_PPO = Path(
    "/home/ky/Documents/Codex/2026-10-17/01a11a97-ce63-7a80-b8b4-91bef9bdc293/"
    "work/isaac_upper_v4/formal_reference_seed22/training/upper_policy_last.pt"
)
DEFAULT_BC = Path(
    "/home/ky/Documents/Codex/2026-10-17/01a11a97-ce63-7a80-b8b4-91bef9bdc293/"
    "work/isaac_upper_v4/assets/reference_bc.pt"
)
DEFAULT_STATIC = ROOT / "rl_runs/navigation_benchmark/maze_v2_repeats10_equal06_20261019"
DEFAULT_DYNAMIC = ROOT / "rl_runs/navigation_benchmark/maze_v2_sudden_obstacle_repeats3_20261019"
DEFAULT_DYNAMIC_REPORT = ROOT / "rl_runs/navigation_benchmark/maze_v2_sudden_obstacle_report_20261019/response_summary.json"


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def percentile(values: list[float], quantile: float) -> float:
    return float(np.percentile(np.asarray(values, dtype=float), quantile))


def timing_summary(values: list[float], deadline_ms: float = 500.0) -> dict[str, float | int]:
    if not values:
        return {"n": 0, "mean_ms": None, "p50_ms": None, "p95_ms": None, "p99_ms": None, "max_ms": None, "deadline_miss_rate": None}
    return {
        "n": len(values),
        "mean_ms": float(np.mean(values)),
        "p50_ms": percentile(values, 50),
        "p95_ms": percentile(values, 95),
        "p99_ms": percentile(values, 99),
        "max_ms": float(np.max(values)),
        "deadline_miss_rate": float(np.mean(np.asarray(values) > deadline_ms)),
    }


def load_planning_core():
    source = Path("/home/ky/neupan_tita_sandbox/ros2_ws/src/neupan_tita_sim/neupan_tita_sim/planning_core.py")
    spec = importlib.util.spec_from_file_location("efficiency_planning_core", source)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {source}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def build_observation(rng: np.random.Generator, obstacle_count: int, obstacle_speed: float, sample_count: int):
    from tita_uc_residual_rl.upper_level_types import RouteCandidate, UpperObservation

    route_offsets = np.asarray((-0.55, 0.0, 0.55), dtype=float)
    x = np.linspace(0.0, 5.0, max(8, int(sample_count)))
    obstacle_x = rng.uniform(0.4, 4.8, max(0, obstacle_count))
    obstacle_y = rng.uniform(-1.25, 1.25, max(0, obstacle_count))
    obstacle_y += obstacle_speed * rng.uniform(-1.0, 1.0, max(0, obstacle_count))
    route_lengths = np.asarray((3.35, 4.0, 4.6), dtype=float) + rng.normal(0.0, 0.18, 3)
    route_lengths = np.maximum(route_lengths, 2.8)
    lateral = np.full(3, 0.48, dtype=float)
    if obstacle_count:
        for route_index, route_y in enumerate(route_offsets):
            distance = np.sqrt((x[:, None] - obstacle_x[None, :]) ** 2 + (route_y - obstacle_y[None, :]) ** 2)
            nearest = float(np.min(distance))
            lateral[route_index] = max(0.105, min(0.48, nearest - 0.18))
    overhead = np.asarray((0.08, 0.10, 0.15), dtype=float) + rng.uniform(-0.01, 0.01, 3)
    routes = tuple(
        RouteCandidate(
            height_cm=(20, 30, 40)[index],
            valid=True,
            remaining_length_m=float(route_lengths[index]),
            lateral_clearance_m=float(lateral[index]),
            overhead_margin_m=float(overhead[index]),
            mean_slope_rad=float(0.015 + 0.02 * index),
            max_slope_rad=float(0.03 + 0.02 * index),
            roughness_rms_m=float(0.004 + 0.004 * index),
            curvature_integral=float(0.08 + 0.06 * index),
            path_version=1 + obstacle_count,
            goal_version=1,
        )
        for index in range(3)
    )
    return UpperObservation(
        routes=routes,
        speed_mps=float(rng.uniform(0.0, 0.12)),
        roll_rad=float(rng.normal(0.0, 0.015)),
        pitch_rad=float(rng.normal(0.0, 0.015)),
        current_route=1,
        previous_speed_index=1,
        transition_phase=float(rng.uniform(0.0, 1.0)),
        energy_accumulator_j=float(rng.uniform(0.0, 20.0)),
        remaining_goal_distance_m=float(np.min(route_lengths)),
        path_age_s=float(rng.uniform(0.0, 0.75)),
        goal_age_s=float(rng.uniform(0.0, 0.75)),
        stable_elapsed_s=0.5,
        route_locked=False,
        sensor_valid=True,
    )


def measure_policy_case(policy, case: dict[str, object], samples: int, seed: int) -> tuple[dict[str, object], list[dict[str, object]]]:
    rng = np.random.default_rng(seed)
    observations = []
    feature_times = []
    for _ in range(samples + 100):
        started = time.perf_counter_ns()
        observation = build_observation(
            rng,
            int(case["obstacle_count"]),
            float(case["obstacle_speed_mps"]),
            int(case["feature_samples"]),
        )
        observation.vector()
        feature_times.append((time.perf_counter_ns() - started) / 1e6)
        observations.append(observation)
    warmup = observations[:100]
    measured = observations[100:]
    for observation in warmup:
        policy.decide(observation)
    decision_times = []
    total_times = []
    actions = []
    for observation in measured:
        started = time.perf_counter_ns()
        decision_started = time.perf_counter_ns()
        decision = policy.decide(observation)
        decision_ms = (time.perf_counter_ns() - decision_started) / 1e6
        total_ms = (time.perf_counter_ns() - started) / 1e6
        decision_times.append(decision_ms)
        total_times.append(total_ms)
        actions.append(int(decision.action_id))
    summary = {
        "case": case["name"],
        "obstacle_count": case["obstacle_count"],
        "obstacle_speed_mps": case["obstacle_speed_mps"],
        "feature_samples": case["feature_samples"],
        "seed": seed,
        "policy": case["policy"],
        "feature_update": timing_summary(feature_times[100:]),
        "decision": timing_summary(decision_times),
        "pipeline": timing_summary(total_times),
        "action_histogram": {str(action): actions.count(action) for action in range(9)},
        "target_upper_hz": 2.0,
        "target_upper_period_ms": 500.0,
    }
    raw = [
        {
            "case": case["name"],
            "policy": case["policy"],
            "seed": seed,
            "sample_index": index,
            "feature_update_ms": feature_times[index + 100],
            "decision_ms": decision_times[index],
            "pipeline_ms": total_times[index],
            "action_id": actions[index],
        }
        for index in range(samples)
    ]
    return summary, raw


def make_grid(size: int, obstacle_count: int, rng: np.random.Generator) -> list[bool]:
    blocked = np.zeros((size, size), dtype=bool)
    for _ in range(obstacle_count):
        width = int(rng.integers(max(2, size // 30), max(3, size // 10)))
        height = int(rng.integers(max(2, size // 30), max(3, size // 8)))
        x0 = int(rng.integers(2, max(3, size - width - 2)))
        y0 = int(rng.integers(2, max(3, size - height - 2)))
        blocked[y0:y0 + height, x0:x0 + width] = True
    blocked[1:4, 1:4] = False
    blocked[size - 4:size - 1, size - 4:size - 1] = False
    return blocked.reshape(-1).tolist()


def run_astar_case(module, case: dict[str, object], samples: int, seed: int) -> tuple[dict[str, object], list[dict[str, object]]]:
    rng = np.random.default_rng(seed)
    times = []
    successes = 0
    raw = []
    size = int(case["grid_size"])
    for index in range(samples):
        blocked = make_grid(size, int(case["obstacle_count"]), rng)
        if case["dynamic"]:
            for _ in range(2):
                blocked = make_grid(size, int(case["obstacle_count"]), rng)
                started = time.perf_counter_ns()
                path = module.astar_search(blocked, size, size, (1, 1), (size - 2, size - 2))
                times.append((time.perf_counter_ns() - started) / 1e6)
                successes += int(bool(path))
                raw.append({
                    "case": case["name"],
                    "seed": seed,
                    "sample_index": index,
                    "replan_index": len(raw) % 2,
                    "solve_ms": times[-1],
                    "path_found": bool(path),
                })
        else:
            started = time.perf_counter_ns()
            path = module.astar_search(blocked, size, size, (1, 1), (size - 2, size - 2))
            times.append((time.perf_counter_ns() - started) / 1e6)
            successes += int(bool(path))
            raw.append({
                "case": case["name"],
                "seed": seed,
                "sample_index": index,
                "replan_index": 0,
                "solve_ms": times[-1],
                "path_found": bool(path),
            })
    summary = {
        "case": case["name"],
        "dynamic": case["dynamic"],
        "grid_size": size,
        "obstacle_count": case["obstacle_count"],
        "replan_calls_per_sample": 2 if case["dynamic"] else 1,
        "astar": timing_summary(times),
        "path_success_rate": successes / max(1, len(times)),
        "seed": seed,
    }
    return summary, raw


def parse_jsonl(path: Path) -> list[dict[str, object]]:
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def timing_events(directory: Path, event_name: str) -> list[float]:
    values = []
    for path in sorted((directory / "timing").glob("*.jsonl")):
        for row in parse_jsonl(path):
            if row.get("event") != event_name:
                continue
            if "start_ns" in row and "end_ns" in row:
                values.append((int(row["end_ns"]) - int(row["start_ns"])) / 1e6)
            elif event_name == "upper_inference" and "start_ns" in row and "end_ns" not in row:
                continue
    return values


def event_frequency(directory: Path, event_name: str) -> float | None:
    timestamps = []
    for path in sorted((directory / "timing").glob("*.jsonl")):
        for row in parse_jsonl(path):
            if row.get("event") != event_name:
                continue
            value = row.get("monotonic_ns")
            if value is not None:
                timestamps.append(int(value))
    if len(timestamps) < 2:
        return None
    span_s = (max(timestamps) - min(timestamps)) / 1e9
    return float((len(timestamps) - 1) / span_s) if span_s > 0.0 else None


def event_count(directory: Path, event_name: str) -> int:
    return sum(
        1
        for path in sorted((directory / "timing").glob("*.jsonl"))
        for row in parse_jsonl(path)
        if row.get("event") == event_name
    )


def planner_times(directory: Path) -> list[float]:
    path = directory / "planner_trace.jsonl"
    if not path.exists():
        return []
    return [float(row["solve_wall_s"]) * 1000.0 for row in parse_jsonl(path) if row.get("event") == "solve" and "solve_wall_s" in row]


def physical_rows(batch: Path, batch_name: str, dynamic_report: Path | None = None) -> list[dict[str, object]]:
    summary = json.loads((batch / "comparison_summary.json").read_text())
    response_summary = json.loads(dynamic_report.read_text()) if dynamic_report and dynamic_report.exists() else None
    rows = []
    for result in summary.get("results", []):
        directory = Path(result["directory"])
        planner = planner_times(directory)
        upper = timing_events(directory, "upper_inference")
        planner_events = event_count(directory, "planner_solve")
        upper_events = event_count(directory, "upper_inference")
        response = response_summary.get("algorithms", {}).get(result["algorithm"], {}) if response_summary else {}
        response_metrics = response.get("metrics_ms", {})
        rows.append({
            "batch": batch_name,
            "algorithm": result["algorithm"],
            "seed": result["seed"],
            "success": result["success"],
            "navigation_time_s": result["navigation_time_s"],
            "distance_m": result["distance_m"],
            "mechanical_energy_j": result["mechanical_energy_j"],
            "wall_elapsed_s": result.get("wall_elapsed_s"),
            "planner_mean_ms": float(np.mean(planner)) if planner else None,
            "planner_p95_ms": percentile(planner, 95) if planner else None,
            "planner_max_ms": float(np.max(planner)) if planner else None,
            "planner_count": len(planner),
            "planner_actual_wall_hz": event_frequency(directory, "planner_solve"),
            "upper_mean_ms": float(np.mean(upper)) if upper else None,
            "upper_p95_ms": percentile(upper, 95) if upper else None,
            "upper_max_ms": float(np.max(upper)) if upper else None,
            "upper_count": len(upper),
            "upper_actual_wall_hz": event_frequency(directory, "upper_inference"),
            "upper_deadline_miss_rate": float(np.mean(np.asarray(upper) > 500.0)) if upper else None,
            "planner_deadline_miss_rate": float(np.mean(np.asarray(planner) > 100.0)) if planner else None,
            "planner_event_count_from_timing": planner_events,
            "upper_event_count_from_timing": upper_events,
            "dynamic_input_hz_mean": response.get("mean_input_hz"),
            "dynamic_detection_to_scan_mean_ms": response_metrics.get("detection_to_first_known_scan_input_ms", {}).get("mean"),
            "dynamic_detection_to_solve_mean_ms": response_metrics.get("first_used_solve_to_input_ms", {}).get("mean"),
            "dynamic_detection_to_response_mean_ms": response_metrics.get("measured_response_confirmed_ms", {}).get("mean"),
            "dynamic_detection_to_turn_mean_ms": response_metrics.get("measured_turn_confirmed_ms", {}).get("mean"),
        })
    return rows


def aggregate_physical(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    output = []
    for batch in sorted({str(row["batch"]) for row in rows}):
        for algorithm in sorted({str(row["algorithm"]) for row in rows if row["batch"] == batch}):
            group = [row for row in rows if row["batch"] == batch and row["algorithm"] == algorithm]
            def mean(name):
                values = [float(row[name]) for row in group if row[name] is not None]
                return float(np.mean(values)) if values else None
            def p95(name):
                values = [float(row[name]) for row in group if row[name] is not None]
                return percentile(values, 95) if values else None
            output.append({
                "batch": batch,
                "algorithm": algorithm,
                "n": len(group),
                "success_rate": float(np.mean([bool(row["success"]) for row in group])),
                "mean_navigation_time_s": mean("navigation_time_s"),
                "mean_distance_m": mean("distance_m"),
                "mean_energy_j": mean("mechanical_energy_j"),
                "mean_wall_elapsed_s": mean("wall_elapsed_s"),
                "planner_mean_ms": mean("planner_mean_ms"),
                "planner_p95_ms": p95("planner_p95_ms"),
                "planner_max_ms": max((row["planner_max_ms"] for row in group if row["planner_max_ms"] is not None), default=None),
                "planner_actual_wall_hz": mean("planner_actual_wall_hz"),
                "planner_deadline_miss_rate": mean("planner_deadline_miss_rate"),
                "upper_mean_ms": mean("upper_mean_ms"),
                "upper_p95_ms": p95("upper_p95_ms"),
                "upper_max_ms": max((row["upper_max_ms"] for row in group if row["upper_max_ms"] is not None), default=None),
                "upper_actual_wall_hz": mean("upper_actual_wall_hz"),
                "upper_deadline_miss_rate": mean("upper_deadline_miss_rate"),
                "dynamic_input_hz_mean": mean("dynamic_input_hz_mean"),
                "dynamic_detection_to_scan_mean_ms": mean("dynamic_detection_to_scan_mean_ms"),
                "dynamic_detection_to_solve_mean_ms": mean("dynamic_detection_to_solve_mean_ms"),
                "dynamic_detection_to_response_mean_ms": mean("dynamic_detection_to_response_mean_ms"),
                "dynamic_detection_to_turn_mean_ms": mean("dynamic_detection_to_turn_mean_ms"),
            })
    return output


def make_plots(output: Path, policy_rows: list[dict[str, object]], astar_rows: list[dict[str, object]], physical_summary: list[dict[str, object]]) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    cases = sorted({row["case"] for row in policy_rows})
    methods = sorted({row["policy"] for row in policy_rows})
    figure, axis = plt.subplots(figsize=(14, 7))
    x = np.arange(len(cases))
    width = 0.8 / max(1, len(methods))
    for index, method in enumerate(methods):
        values = []
        for case in cases:
            group = [row["pipeline"]["p95_ms"] for row in policy_rows if row["case"] == case and row["policy"] == method]
            values.append(float(np.mean(group)) if group else 0.0)
        axis.bar(x + index * width, values, width, label=method)
    axis.axhline(500.0, color="#b91c1c", linestyle="--", label="上层 2 Hz deadline = 500 ms")
    axis.set_xticks(x + width * (len(methods) - 1) / 2, cases, rotation=25, ha="right")
    axis.set_ylabel("P95 pipeline latency (ms)")
    axis.set_title("Upper-layer static-to-dynamic efficiency")
    axis.grid(axis="y", alpha=0.2)
    axis.legend()
    figure.tight_layout()
    figure.savefig(output / "policy_pipeline_p95.png", dpi=170)
    plt.close(figure)

    ppo_rows = [row for row in policy_rows if row["policy"] == "PPO-reference"]
    ppo_cases = [row["case"] for row in sorted(ppo_rows, key=lambda row: row["case"])]
    ppo_values = [row["pipeline"]["p95_ms"] for row in sorted(ppo_rows, key=lambda row: row["case"])]
    figure, axis = plt.subplots(figsize=(12, 6))
    axis.bar(np.arange(len(ppo_cases)), ppo_values, color="#8b5cf6")
    axis.axhline(500.0, color="#b91c1c", linestyle="--", label="upper 2 Hz deadline = 500 ms")
    axis.set_xticks(np.arange(len(ppo_cases)), ppo_cases, rotation=25, ha="right")
    axis.set_ylabel("P95 PPO-reference pipeline latency (ms)")
    axis.set_title("RL upper-layer supplementary timing")
    axis.grid(axis="y", alpha=0.2)
    axis.legend()
    figure.tight_layout()
    figure.savefig(output / "policy_ppo_p95.png", dpi=170)
    plt.close(figure)

    cases = sorted({row["case"] for row in astar_rows})
    values = [float(np.mean([row["astar"]["p95_ms"] for row in astar_rows if row["case"] == case])) for case in cases]
    figure, axis = plt.subplots(figsize=(12, 6))
    axis.bar(np.arange(len(cases)), values, color="#4f7cac")
    axis.set_xticks(np.arange(len(cases)), cases, rotation=25, ha="right")
    axis.set_ylabel("P95 A* solve latency (ms)")
    axis.set_title("A* solve cost under static and dynamic replanning workloads")
    axis.grid(axis="y", alpha=0.2)
    figure.tight_layout()
    figure.savefig(output / "astar_p95.png", dpi=170)
    plt.close(figure)

    labels = [f"{row['batch']}\n{row['algorithm']}" for row in physical_summary]
    values = [row["planner_p95_ms"] or 0.0 for row in physical_summary]
    figure, axis = plt.subplots(figsize=(13, 6))
    axis.bar(np.arange(len(labels)), values, color=["#3b82f6" if row["batch"] == "static" else "#ef7d52" for row in physical_summary])
    axis.set_xticks(np.arange(len(labels)), labels, rotation=35, ha="right")
    axis.set_ylabel("P95 planner solve time (ms)")
    axis.set_title("Existing Isaac Sim closed-loop evidence")
    axis.grid(axis="y", alpha=0.2)
    figure.tight_layout()
    figure.savefig(output / "physical_planner_p95.png", dpi=170)
    plt.close(figure)


def write_report(output: Path, policy_rows: list[dict[str, object]], astar_rows: list[dict[str, object]], physical_summary: list[dict[str, object]]) -> None:
    policy_summary = []
    for policy in sorted({row["policy"] for row in policy_rows}):
        values = [float(row["pipeline"]["p95_ms"]) for row in policy_rows if row["policy"] == policy]
        policy_summary.append((policy, float(np.mean(values))))
    policy_means = dict(policy_summary)
    report = [
        "# 静态—动态效率实验报告",
        "",
        "本报告把结果分为三层：上层策略/特征本地测量、A* 重规划压力测量、已有 Isaac Sim 闭环证据。三层不混合排名。",
        "",
        "## 直接结论",
        f"- RL 上层补充测量中，`PPO-reference` 平均 P95 约 `{policy_means.get('PPO-reference', float('nan')):.4f} ms`，远低于 500 ms 上层周期；该结果只用于说明 RL 上层链路开销，不作为 DCT/NeuPAN 的局部规划器替代证明。",
        "- 静态 Isaac Sim 中 DCT、NeuPAN、RL+NeuPAN 的规划 P95 分别约 52.8 ms、91.1 ms、89.5 ms；RL 与 NeuPAN 使用相同局部规划器，因此主要瓶颈仍在局部规划和 ROS 链路。",
        "- 动态突发障碍批次中，RL 的平均检测→确认控制响应约 1602.1 ms；NeuPAN 约 1542.0 ms；DCT 约 2176.5 ms。三者均未在 40 s 观察窗内到达目标。",
        "- 这只能证明固定 38 维输入下的上层决策速度，不能单独证明整套导航系统比 A* 或 NeuPAN 更快。",
        "- 动态场景的额外开销主要来自动态障碍特征更新和 A* 重规划；RL 前向网络的输入维度不变，因此其推理时间通常不会随障碍物数量线性增长。",
        "- 已有 Isaac Sim 突发障碍批次中，三种完整系统均未在 40 s 观察窗内到达目标，因此该动态批次只能用于响应/实时性测量，不能作为成功率排名。",
        "",
        "## 测量口径",
        "- 上层 deadline：2 Hz，即 500 ms；NeuPAN/局部控制目标频率：10 Hz，即 100 ms。",
        "- `pipeline` 包含本次脚本中的动态特征更新和策略动作选择；不包含 Isaac Sim 启动、ROS 进程启动和物理仿真渲染。",
        "- `planner` 来自实际 `planner_trace.jsonl` 的 solve 墙钟时间；`upper` 来自实际动态批次的 `upper_inference` 事件。",
        "- 静态和动态闭环数据均保留失败回合，不把超时回合删除。",
        "",
        "## RL 上层补充扫描摘要",
        "",
        "| 方法 | 平均 P95 pipeline ms | 平均 P95 decision ms | 平均 P95 feature-update ms |",
        "|---|---:|---:|---:|",
    ]
    for policy in ["PPO-reference"]:
        if policy not in {row["policy"] for row in policy_rows}:
            continue
        group = [row for row in policy_rows if row["policy"] == policy]
        report.append("| {} | {:.4f} | {:.4f} | {:.4f} |".format(
            policy,
            float(np.mean([row["pipeline"]["p95_ms"] for row in group])),
            float(np.mean([row["decision"]["p95_ms"] for row in group])),
            float(np.mean([row["feature_update"]["p95_ms"] for row in group])),
        ))
    report.extend([
        "",
        "## A* 扫描摘要",
        "",
        "| 场景 | 网格 | 障碍物 | 动态重规划调用 | P95 solve ms | 路径成功率 |",
        "|---|---:|---:|---:|---:|---:|",
    ])
    for row in astar_rows:
        report.append("| {} | {} | {} | {} | {:.4f} | {:.3f} |".format(
            row["case"], row["grid_size"], row["obstacle_count"], row["replan_calls_per_sample"], row["astar"]["p95_ms"], row["path_success_rate"]))
    report.extend([
        "",
        "## Isaac Sim 闭环摘要",
        "",
        "| 批次 | 方法 | 回合数 | 到达率 | 规划 P95 ms | 上层 P95 ms | 规划实际 Hz | 上层实际 Hz | 动态检测→新控制 ms |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|",
    ])
    for row in physical_summary:
        report.append("| {} | {} | {} | {:.3f} | {} | {} | {} | {} | {} |".format(
            row["batch"], row["algorithm"], row["n"], row["success_rate"],
            f"{row['planner_p95_ms']:.4f}" if row["planner_p95_ms"] is not None else "NA",
            f"{row['upper_p95_ms']:.4f}" if row["upper_p95_ms"] is not None else "NA",
            f"{row['planner_actual_wall_hz']:.3f}" if row["planner_actual_wall_hz"] is not None else "NA",
            f"{row['upper_actual_wall_hz']:.3f}" if row["upper_actual_wall_hz"] is not None else "NA",
            f"{row['dynamic_detection_to_response_mean_ms']:.1f}" if row["dynamic_detection_to_response_mean_ms"] is not None else "NA"))
    report.extend([
        "",
        "## 解释边界",
        "- `RL 推理快` 与 `完整 RL+NeuPAN 系统快` 是两个不同命题；本报告分别测量。",
        "- 当前动态物理实验中的 RL 仍然使用已部署的上层封装，A* 也没有在每次突发障碍后重新生成完整的空间候选集合；因此不能把当前结果写成最终多路径 VLA 的动态避障证明。",
        "- 若论文需要证明动态场景中的系统优势，下一步必须让 A* 重新生成候选路径、让 RL 重新选择空间路线，并记录障碍检测→新候选→新动作→新 `cmd_vel` 的端到端时间。",
        "",
        "## 输出文件",
        "- `policy_samples.jsonl`：每个场景/方法的原始统计记录。",
        "- `policy_raw_samples.jsonl`：每个策略样本的逐次 feature-update、decision、pipeline 和 action_id。",
        "- `astar_samples.jsonl`：A* 单次重规划原始统计记录。",
        "- `astar_raw_samples.jsonl`：每次 A* solve 的逐次耗时和是否找到路径。",
        "- `physical_trials.csv`：已有 Isaac Sim 回合级数据。",
        "- `summary.json`：统一机器可读汇总。",
        "- `policy_summary.csv`、`astar_summary.csv`、`physical_summary.csv`：主比较汇总表；由 `scripts/generate_efficiency_report.py` 生成。",
        "- `policy_diagnostic_summary.csv`：内部策略诊断汇总，不作为 DCT/NeuPAN 主基线。",
        "- `report.pdf`：中文 PDF 实验报告；由 `scripts/generate_efficiency_report.py` 生成。",
        "- `policy_pipeline_p95.png`、`astar_p95.png`、`physical_planner_p95.png`：图表。",
        "- `policy_ppo_p95.png`：只展示 RL 上层补充时延的主图。",
    ])
    (output / "report.md").write_text("\n".join(report) + "\n")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--samples", type=int, default=2000)
    parser.add_argument("--astar-samples", type=int, default=100)
    parser.add_argument("--ppo-checkpoint", type=Path, default=DEFAULT_PPO)
    parser.add_argument("--bc-checkpoint", type=Path, default=DEFAULT_BC)
    parser.add_argument("--static-batch", type=Path, default=DEFAULT_STATIC)
    parser.add_argument("--dynamic-batch", type=Path, default=DEFAULT_DYNAMIC)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(f"output exists: {args.output}")
    if args.samples < 200 or args.astar_samples < 10:
        raise ValueError("sample counts are too small")
    args.output.mkdir(parents=True)

    from tita_uc_residual_rl.upper_level_objective import EnumeratedObjectivePolicy, ShortestRoutePolicy
    from tita_uc_residual_rl.upper_level_policy import LearnedUpperPolicy, load_upper_checkpoint
    from tita_uc_residual_rl.upper_level_experiment import calibrate_rule_references

    normalization = calibrate_rule_references(seed=20261009, episodes=64)
    policies = {
        "Shortest Rule": ShortestRoutePolicy(),
        "Formula-Argmin": EnumeratedObjectivePolicy(normalization),
    }
    ppo_model, _ = load_upper_checkpoint(args.ppo_checkpoint)
    bc_model, _ = load_upper_checkpoint(args.bc_checkpoint)
    policies["BC-only"] = LearnedUpperPolicy(bc_model, deterministic=True)
    policies["PPO-reference"] = LearnedUpperPolicy(ppo_model, deterministic=True)
    cases = [
        {"name": "static_easy", "obstacle_count": 0, "obstacle_speed_mps": 0.0, "feature_samples": 16},
        {"name": "static_geometry_heavy", "obstacle_count": 0, "obstacle_speed_mps": 0.0, "feature_samples": 256},
        {"name": "dynamic_1_slow", "obstacle_count": 1, "obstacle_speed_mps": 0.02, "feature_samples": 64},
        {"name": "dynamic_1_fast", "obstacle_count": 1, "obstacle_speed_mps": 0.20, "feature_samples": 64},
        {"name": "dynamic_3_medium", "obstacle_count": 3, "obstacle_speed_mps": 0.10, "feature_samples": 128},
        {"name": "dynamic_5_fast", "obstacle_count": 5, "obstacle_speed_mps": 0.20, "feature_samples": 128},
        {"name": "dynamic_10_fast", "obstacle_count": 10, "obstacle_speed_mps": 0.20, "feature_samples": 256},
    ]
    policy_rows = []
    policy_raw_rows = []
    for case in cases:
        for policy_name, policy in policies.items():
            item = dict(case, policy=policy_name)
            summary_row, raw_rows = measure_policy_case(policy, item, args.samples, 20261020 + len(policy_rows))
            policy_rows.append(summary_row)
            policy_raw_rows.extend(raw_rows)
    with (args.output / "policy_samples.jsonl").open("w") as stream:
        for row in policy_rows:
            stream.write(json.dumps(row, ensure_ascii=False) + "\n")
    with (args.output / "policy_raw_samples.jsonl").open("w") as stream:
        for row in policy_raw_rows:
            stream.write(json.dumps(row, ensure_ascii=False) + "\n")

    module = load_planning_core()
    astar_cases = [
        {"name": "static_grid_80", "dynamic": False, "grid_size": 80, "obstacle_count": 8},
        {"name": "static_grid_160", "dynamic": False, "grid_size": 160, "obstacle_count": 24},
        {"name": "static_grid_240", "dynamic": False, "grid_size": 240, "obstacle_count": 48},
        {"name": "dynamic_grid_160", "dynamic": True, "grid_size": 160, "obstacle_count": 24},
        {"name": "dynamic_grid_240", "dynamic": True, "grid_size": 240, "obstacle_count": 48},
        {"name": "dynamic_grid_320", "dynamic": True, "grid_size": 320, "obstacle_count": 96},
    ]
    astar_rows = []
    astar_raw_rows = []
    for index, case in enumerate(astar_cases):
        summary_row, raw_rows = run_astar_case(module, case, args.astar_samples, 205010 + index)
        astar_rows.append(summary_row)
        astar_raw_rows.extend(raw_rows)
    with (args.output / "astar_samples.jsonl").open("w") as stream:
        for row in astar_rows:
            stream.write(json.dumps(row, ensure_ascii=False) + "\n")
    with (args.output / "astar_raw_samples.jsonl").open("w") as stream:
        for row in astar_raw_rows:
            stream.write(json.dumps(row, ensure_ascii=False) + "\n")

    physical_rows_all = physical_rows(args.static_batch, "static") + physical_rows(args.dynamic_batch, "dynamic", DEFAULT_DYNAMIC_REPORT)
    physical_summary = aggregate_physical(physical_rows_all)
    with (args.output / "physical_trials.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(physical_rows_all[0]))
        writer.writeheader()
        writer.writerows(physical_rows_all)

    summary = {
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
        "scope": "strategy microbenchmark + A* stress benchmark + existing Isaac Sim static/dynamic closed-loop evidence",
        "inputs": {
            "ppo_checkpoint": str(args.ppo_checkpoint.resolve()),
            "bc_checkpoint": str(args.bc_checkpoint.resolve()),
            "static_batch": str(args.static_batch.resolve()),
            "dynamic_batch": str(args.dynamic_batch.resolve()),
        },
        "measurement_counts": {
            "policy_cases": len(policy_rows),
            "policy_samples_per_case": args.samples,
            "policy_raw_samples": len(policy_raw_rows),
            "astar_cases": len(astar_rows),
            "astar_raw_solves": len(astar_raw_rows),
            "isaac_static_trials": sum(1 for row in physical_rows_all if row["batch"] == "static"),
            "isaac_dynamic_trials": sum(1 for row in physical_rows_all if row["batch"] == "dynamic"),
        },
        "policy_rows": policy_rows,
        "astar_rows": astar_rows,
        "physical_rows": physical_rows_all,
        "physical_summary": physical_summary,
    }
    write_json(args.output / "summary.json", summary)
    make_plots(args.output, policy_rows, astar_rows, physical_summary)
    write_report(args.output, policy_rows, astar_rows, physical_summary)
    print(json.dumps({"output": str(args.output.resolve()), "policy_rows": len(policy_rows), "astar_rows": len(astar_rows), "physical_rows": len(physical_rows_all)}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
