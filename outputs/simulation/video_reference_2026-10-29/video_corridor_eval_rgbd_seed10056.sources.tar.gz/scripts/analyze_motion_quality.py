#!/usr/bin/env python3
"""Compare recorded physical motion without running or retraining either policy."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np


def load_trace(path):
    with Path(path).open() as stream:
        rows = [json.loads(line) for line in stream if line.strip()]
    if not rows:
        raise ValueError(f"empty trace: {path}")
    return rows


def motion_arrays(rows):
    quaternion = np.array([row["quaternion_wxyz"] for row in rows], dtype=float)
    quaternion /= np.linalg.norm(quaternion, axis=1, keepdims=True)
    pitch = np.degrees(np.arcsin(np.clip(
        2 * (quaternion[:, 0] * quaternion[:, 2] - quaternion[:, 3] * quaternion[:, 1]),
        -1, 1,
    )))
    return {
        "time": np.array([row["sim_time_s"] for row in rows]),
        "step": np.array([row["control_step"] for row in rows]),
        "position": np.array([row["position"] for row in rows]),
        "velocity": np.array([row["linear_b"][0] for row in rows]),
        "pitch": pitch,
        "pitch_rate": np.degrees([row["angular_b"][1] for row in rows]),
        "policy_forward": np.array([row["policy_command"][0] for row in rows]),
        "yaw_rate": np.array([row["angular_b"][2] for row in rows]),
        "desired_yaw": np.array([row["desired"][2] for row in rows]),
    }


def window_metrics(arrays, selected):
    indices = np.flatnonzero(selected)
    if len(indices) < 2:
        raise ValueError("motion quality window has fewer than two physical samples")
    velocity = arrays["velocity"][selected]
    consecutive = np.diff(arrays["step"][selected]) == 1
    deltas = np.diff(arrays["policy_forward"][selected])[consecutive]
    mean_velocity = float(np.mean(velocity))
    metrics = {
        "samples": int(len(indices)),
        "first_time_s": float(arrays["time"][indices[0]]),
        "last_time_s": float(arrays["time"][indices[-1]]),
        "forward_mean_mps": mean_velocity,
        "forward_std_mps": float(np.std(velocity)),
        "forward_coefficient_of_variation": float(np.std(velocity) / max(abs(mean_velocity), 1e-12)),
        "pitch_std_deg": float(np.std(arrays["pitch"][selected])),
        "body_pitch_rate_rms_degps": float(np.sqrt(np.mean(arrays["pitch_rate"][selected] ** 2))),
        "actor_forward_step_delta_rms": float(np.sqrt(np.mean(deltas ** 2))) if len(deltas) else None,
        "reverse_fraction_below_minus_0p01_mps": float(np.mean(velocity < -0.01)),
    }
    if "yaw_rate" in arrays and "desired_yaw" in arrays:
        yaw = arrays["yaw_rate"][selected]
        desired = arrays["desired_yaw"][selected]
        metrics.update({
            "body_yaw_rate_rms_radps": float(np.sqrt(np.mean(yaw ** 2))),
            "desired_yaw_rate_rms_radps": float(np.sqrt(np.mean(desired ** 2))),
            "yaw_tracking_error_rms_radps": float(np.sqrt(np.mean((yaw - desired) ** 2))),
        })
    return metrics


def analyze_run(directory, warmup_s=5.0, straight_x=(2.9, 5.1)):
    directory = Path(directory).resolve()
    trace = directory / "control_trace.jsonl"
    rows = load_trace(trace)
    arrays = motion_arrays(rows)
    if not np.all(np.diff(arrays["step"]) == 1):
        raise ValueError(f"non-contiguous physical control trace: {trace}")
    summary = json.loads((directory / "evaluation/evaluation_summary.json").read_text())
    if not summary["complete"] or len(summary["episodes"]) != 1:
        raise ValueError("comparison requires exactly one completed evaluation episode")
    manifest = json.loads((directory / "run_manifest.json").read_text())
    settled = arrays["time"] >= warmup_s
    straight = settled & (arrays["position"][:, 0] > straight_x[0]) & (arrays["position"][:, 0] < straight_x[1])
    return {
        "directory": str(directory),
        "trace_sha256": hashlib.sha256(trace.read_bytes()).hexdigest(),
        "policy_seed": manifest["policy_seed"],
        "goal": manifest["goal"],
        "checkpoint_hashes": sorted(digest for source, digest in manifest["hashes"].items()
                                    if Path(source).suffix in (".pt", ".pth")),
        "normalization_sha256": hashlib.sha256((directory / "upper_normalization.json").read_bytes()).hexdigest(),
        "episode": summary["episodes"][0],
        "all_samples": window_metrics(arrays, np.ones(len(rows), dtype=bool)),
        "after_warmup": window_metrics(arrays, settled),
        "matched_straight_segment": window_metrics(arrays, straight),
    }


def validate_comparison(before, after):
    if before["policy_seed"] != after["policy_seed"] or before["goal"] != after["goal"]:
        raise ValueError("navigation comparisons must match policy seed and goal")
    if not before["checkpoint_hashes"] or before["checkpoint_hashes"] != after["checkpoint_hashes"]:
        raise ValueError("navigation comparisons must use the same frozen checkpoint contents")
    if before["normalization_sha256"] != after["normalization_sha256"]:
        raise ValueError("navigation comparisons must use identical frozen normalization")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--before", type=Path, required=True)
    parser.add_argument("--after", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    before = analyze_run(arguments.before)
    after = analyze_run(arguments.after)
    validate_comparison(before, after)
    output = {
        "simulation_only": True,
        "scope": "execution-chain comparison with the same frozen upper policy; not new PPO training or hardware validation",
        "definitions": {
            "warmup_s": 5.0,
            "straight_segment_world_x_m": [2.9, 5.1],
            "jitter": "RMS of consecutive actor forward-command differences; no skipped-sample differences",
            "pitch_rate": "measured body-frame y angular velocity, not differentiated render poses",
            "energy": "simulator joint mechanical-energy proxy, not battery electrical consumption",
            "reverse": "fraction of sampled physical body vx below -0.01 m/s",
        },
        "before": before, "after": after,
    }
    arguments.output.write_text(json.dumps(output, indent=2, allow_nan=False) + "\n")
    for label, result in (("before", before), ("after", after)):
        print(label, json.dumps({"episode": result["episode"], "settled": result["after_warmup"],
                                 "straight": result["matched_straight_segment"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
