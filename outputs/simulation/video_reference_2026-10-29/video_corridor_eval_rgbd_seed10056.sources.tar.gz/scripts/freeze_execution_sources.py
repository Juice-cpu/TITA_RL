from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def verify_execution_sources(destination):
    destination = Path(destination)
    manifest = json.loads((destination / 'execution_sources.json').read_text())
    if manifest.get('schema') != 'tita.frozen_execution_sources.v1' or not manifest.get('files_sha256'):
        raise ValueError('missing immutable execution source manifest')
    for name, expected in manifest['files_sha256'].items():
        path = destination / name
        if not path.resolve().is_relative_to(destination.resolve()):
            raise ValueError('source manifest path escapes execution root')
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError(f'frozen source mismatch: {name}')
    return manifest


def freeze_execution_sources(repository, vendor_root, destination):
    repository, vendor_root, destination = map(Path, (repository, vendor_root, destination))
    if destination.exists():
        raise ValueError('execution source destination must be new')
    sources = [(source.relative_to(repository), source)
               for directory in ('scripts', 'tita_uc_residual_rl')
               for source in sorted((repository / directory).rglob('*.py'))]
    sources.extend((source.relative_to(repository), source) for source in sorted(repository.glob('*.py')))
    calibration = repository / 'assets/tita_tower/calibration'
    sources.extend((source.relative_to(repository), source) for source in sorted(calibration.rglob('*.json')))
    sources.extend((Path('vendor/NeuPAN') / source.relative_to(vendor_root), source)
                   for source in sorted((vendor_root / 'neupan').rglob('*.py')))
    if not sources or not (calibration / 'real_posture_seeds_20261011.json').exists():
        raise ValueError('execution source or default posture calibration is missing')
    destination.mkdir(parents=True)
    hashes = {}
    for name, source in sources:
        content = source.read_bytes()
        target = destination / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream:
            stream.write(content)
        target.chmod(0o444)
        hashes[name.as_posix()] = hashlib.sha256(content).hexdigest()
    manifest = {'schema': 'tita.frozen_execution_sources.v1', 'files_sha256': hashes}
    with (destination / 'execution_sources.json').open('x') as stream:
        json.dump(manifest, stream, indent=2)
    (destination / 'execution_sources.json').chmod(0o444)
    verify_execution_sources(destination)
    return manifest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repository', required=True, type=Path)
    parser.add_argument('--vendor-root', required=True, type=Path)
    parser.add_argument('--destination', required=True, type=Path)
    args = parser.parse_args()
    manifest = freeze_execution_sources(args.repository, args.vendor_root, args.destination)
    print(json.dumps({'destination': str(args.destination), 'files': len(manifest['files_sha256'])}))


if __name__ == '__main__':
    main()
