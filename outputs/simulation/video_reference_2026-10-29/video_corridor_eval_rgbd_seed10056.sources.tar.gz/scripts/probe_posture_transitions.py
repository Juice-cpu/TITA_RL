from __future__ import annotations

import argparse
import json
from pathlib import Path

from isaaclab.app import AppLauncher

parser = argparse.ArgumentParser()
parser.add_argument("--asset", required=True)
parser.add_argument("--checkpoint", required=True)
parser.add_argument("--residual-checkpoint", type=Path, required=True)
parser.add_argument("--high-residual-checkpoint", type=Path)
parser.add_argument("--velocity-calibration", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--support-height", type=float, default=.01)
parser.add_argument("--support-offset", type=float, default=.5)
parser.add_argument("--corridor-width", type=float, default=1.3)
parser.add_argument("--seed", type=int, default=2221)
parser.add_argument("--hold-steps", type=int, default=800)
parser.add_argument("--physics-device", choices=("cpu", "cuda:0"), default="cpu")
parser.add_argument("--convex-cylinders", action="store_true")
parser.add_argument("--mode-schedule", nargs="+", choices=("LOW", "MID", "HIGH"), default=("MID", "HIGH", "LOW", "MID"))
parser.add_argument("--strict-stationary", action="store_true")
parser.add_argument("--guarded-schedule", action="store_true")
AppLauncher.add_app_launcher_args(parser)
args = parser.parse_args()
simulation_app = AppLauncher(args).app

import torch

from tita_uc_residual_rl.calibrated_governor import BatchedCalibratedGovernor
from tita_uc_residual_rl.execution_contract import validate_high_specialist
from tita_uc_residual_rl.experiment_provenance import input_hashes, snapshot_sources
from tita_uc_residual_rl.isaaclab_tita_env import HARD_REASON_NAMES, TitaResidualEnv, build_tita_cfg
from tita_uc_residual_rl.official_policy import FrozenOfficialTitaController, OfficialTitaActor
from tita_uc_residual_rl.phase_b_learner import PhaseBActorCritic, load_phase_b_state_dict_compatible
from tita_uc_residual_rl.stair_step_sequence import stair_stationary_state
from tita_uc_residual_rl.velocity_calibration import load_velocity_calibration
from tita_uc_residual_rl.guarded_posture_probe import GuardedPostureSchedule


def main():
    if args.output.exists() or args.hold_steps < 500 or not 0. < args.support_height <= .1:
        raise ValueError("new output, at least 500 hold steps, and positive support height required")
    provenance = snapshot_sources(Path(__file__).resolve().parents[1], args.output.with_suffix(".sources.tar.gz"))
    artifacts = input_hashes({"asset": args.asset, "checkpoint": args.checkpoint,
                             "residual": args.residual_checkpoint, "high_residual": args.high_residual_checkpoint,
                             "velocity_calibration": args.velocity_calibration})
    payload = torch.load(args.residual_checkpoint, map_location="cpu", weights_only=True)
    high_payload = torch.load(args.high_residual_checkpoint, map_location="cpu", weights_only=True) if args.high_residual_checkpoint else None
    execution = payload["execution_config"]
    if high_payload:
        validate_high_specialist(execution, high_payload)
    cfg = build_tita_cfg(args.asset, num_envs=4, terrain="stairs")
    cfg.sim.device = args.physics_device
    cfg.convex_cylinder_collisions = args.convex_cylinders
    cfg.sim.disable_contact_processing = False
    cfg.navigation_pose_observations = execution.get("navigation_pose_observations", False)
    for field in ("residual_filter_alpha", "acceleration_limit", "enforce_acceleration_limit", "normalized_cost_clip",
                  "objective_p95", "posture_joint_anchors", "posture_heights"):
        setattr(cfg, field, execution[field])
    cfg.residual_limit = payload["policy_config"]["residual_limit"]
    cfg.posture_scale = payload["policy_config"]["posture_scale"]
    cfg.stair_support_augmentation_enabled = True
    cfg.stair_support_augmentation_offset_m = args.support_offset
    cfg.stair_start_x_m = 12.
    cfg.stair_step_height_range_m = (args.support_height, args.support_height)
    cfg.stair_tread_range_m = (.6, .6)
    cfg.stair_width_range_m = (args.corridor_width, args.corridor_width)
    cfg.stair_num_steps = 1
    cfg.stair_landing_length_m = 8.
    cfg.stair_step_assist_enabled = False
    cfg.stair_training_corridor_enabled = True
    cfg.stair_terminate_on_success = False
    cfg.scene.env_spacing = 80.
    maximum_steps = 1200 * len(args.mode_schedule) if args.guarded_schedule else args.hold_steps * len(args.mode_schedule)
    cfg.episode_length_s = maximum_steps * .02 + 5.
    cfg.seed = args.seed
    env = TitaResidualEnv(cfg)
    env.reset()
    base = FrozenOfficialTitaController(OfficialTitaActor.from_checkpoint(args.checkpoint, env.device))
    base.reset(env.num_envs, env.device)
    policies = []
    for document in (payload, high_payload):
        if document is None:
            policies.append(None)
        else:
            policy = PhaseBActorCritic(obs_dim=document["model_state_dict"]["policy.network.0.weight"].shape[1], residual_limit=document["policy_config"]["residual_limit"],
                                      posture_scale=document["policy_config"]["posture_scale"]).to(env.device)
            load_phase_b_state_dict_compatible(policy, document["model_state_dict"])
            policy.eval()
            policies.append(policy)
    calibration = load_velocity_calibration(args.velocity_calibration, posture_joint_anchors=cfg.posture_joint_anchors,
                                            checkpoint_path=args.checkpoint, asset_path=args.asset)
    governor = BatchedCalibratedGovernor(calibration["profiles"], env.num_envs, env.device, cfg.posture_feedforward_transition_s)
    schedule = tuple(("LOW", "MID", "HIGH").index(mode) for mode in args.mode_schedule)
    protocol = GuardedPostureSchedule(schedule, env.num_envs, env.device, dt_s=float(env.step_dt)) if args.guarded_schedule else None
    failed = torch.zeros(env.num_envs, dtype=torch.bool, device=env.device)
    hard_failed = torch.zeros_like(failed)
    simulator_truncated = torch.zeros_like(failed)
    hold = torch.zeros(env.num_envs, dtype=torch.long, device=env.device)
    accepted = torch.zeros((len(schedule), env.num_envs), dtype=torch.bool, device=env.device)
    accepted_at_stage_end = torch.zeros_like(accepted)
    physical_hold = torch.zeros_like(hold)
    first_continuous_hold_s = torch.full(accepted.shape, float("nan"), device=env.device)
    reasons = torch.zeros((env.num_envs, len(HARD_REASON_NAMES)), dtype=torch.long, device=env.device)
    samples = []
    completed_steps = 0
    try:
        for step in range(maximum_steps):
            stage, stage_step = divmod(step, args.hold_steps)
            mode = schedule[min(stage, len(schedule) - 1)]
            if stage_step == 0:
                hold.zero_()
                physical_hold.zero_()
            modes = torch.nn.functional.one_hot(torch.full((env.num_envs,), mode, device=env.device), 3).float()
            command = torch.zeros((env.num_envs, 3), device=env.device)
            phase = min((stage_step + 1) * float(env.step_dt) / 6., 1.) if stage > 0 and stage_step < 300 else 0.
            if policies[1] is not None and mode == 2:
                phase = 0.
            phase_values = command.new_full((env.num_envs, 1), phase)
            if protocol is not None:
                modes = torch.nn.functional.one_hot(protocol.modes, 3).float()
                phase_values = protocol.phase[:, None]
                if policies[1] is not None:
                    phase_values[protocol.modes == 2] = 0.
            env.set_posture_command(modes, phase_values)
            env.set_velocity_command(command)
            measured = torch.cat((env.robot.data.root_lin_vel_b[:, :2], env.robot.data.root_ang_vel_b[:, 2:3]), 1)
            policy_command = governor.command(command, measured, modes, float(env.step_dt))
            selected = policies[1] if policies[1] is not None and mode == 2 else policies[0]
            selected_payload = high_payload if selected is policies[1] else payload
            cfg.residual_limit = selected_payload["policy_config"]["residual_limit"]
            cfg.posture_scale = selected_payload["policy_config"]["posture_scale"]
            if protocol is not None:
                cfg.residual_limit = max(item["policy_config"]["residual_limit"] * item["policy_config"]["posture_scale"]
                                         for item in (payload, high_payload) if item is not None)
                cfg.posture_scale = 1.
            with torch.no_grad():
                proprioception = env.official_proprioception(base.previous_policy_action)
                proprioception[:, 6:9] = policy_command * policy_command.new_tensor([2., 2., .25])
                target, _ = base.target(proprioception, env.default_joint_target())
                env.set_base_target(target)
                observation = env._get_observations()["policy"]
                action = selected.policy(observation[:, :selected.policy.network[0].in_features])
                if protocol is not None and policies[1] is not None:
                    high_indices = protocol.modes == 2
                    for active, actor in ((high_indices, policies[1]), (~high_indices, policies[0])):
                        action[active] = actor.policy(observation[active, :actor.policy.network[0].in_features])
            _, _, done, truncated, _ = env.step(action)
            reasons += env.hard_reason_flags.long()
            hard_failed |= env.hard_reason_flags.any(1)
            simulator_truncated |= truncated
            failed |= done | truncated
            stable = stair_stationary_state(~failed, env._collision, env.robot.data.root_lin_vel_w,
                                            env.robot.data.projected_gravity_b, env._wheel_contact,
                                            env.posture_height - env.posture_target_height)
            if args.strict_stationary:
                stable &= torch.linalg.vector_norm(env.robot.data.root_lin_vel_w[:, :2], dim=1) <= .03
                stable &= env.robot.data.root_ang_vel_b[:, 2].abs() <= .05
            if protocol is not None:
                protocol.observe(stable, failed)
                accepted = protocol.accepted_duration.isfinite()
                accepted_at_stage_end = accepted.clone()
                first_continuous_hold_s = protocol.accepted_duration.clone()
                hold = (protocol.hold / float(env.step_dt)).long()
            else:
                physical_hold = torch.where(stable, physical_hold + 1, torch.zeros_like(physical_hold))
                first_hold = (physical_hold * float(env.step_dt) >= 1.) & first_continuous_hold_s[stage].isnan()
                first_continuous_hold_s[stage, first_hold] = (stage_step + 1) * float(env.step_dt)
                stable &= stage_step >= 300
                hold = torch.where(stable, hold + 1, torch.zeros_like(hold))
                accepted[stage] |= hold * float(env.step_dt) >= 1.
                if stage_step == args.hold_steps - 1:
                    accepted_at_stage_end[stage] = hold * float(env.step_dt) >= 1.
            if step % 25 == 0:
                samples.append({"step": step, "mode": ("LOW", "MID", "HIGH")[mode] if protocol is None else
                                [("LOW", "MID", "HIGH")[index] for index in modes.argmax(1).cpu().tolist()],
                                "phase": phase if protocol is None else phase_values[:, 0].cpu().tolist(),
                                "posture_height_m": env.posture_height.cpu().tolist(),
                                "local_position_xyz_m": (env.robot.data.root_pos_w - env._environment_origins()).cpu().tolist(),
                                "wheel_contacts": env._wheel_contact.cpu().tolist(), "hold_steps": hold.cpu().tolist(),
                                "linear_velocity_world_mps": env.robot.data.root_lin_vel_w.cpu().tolist(),
                                "angular_velocity_body_radps": env.robot.data.root_ang_vel_b.cpu().tolist(),
                                "projected_gravity_body": env.robot.data.projected_gravity_b.cpu().tolist(),
                                "stationary_now": stable.cpu().tolist(),
                                "failed": failed.cpu().tolist()})
            completed_steps = step + 1
            if step % 400 == 0:
                print(json.dumps(samples[-1]), flush=True)
            if failed.all() or protocol is not None and protocol.done.all():
                break
        report = {"schema": "tita.real_isaac_posture_transition_probe.v1", "simulation_only": True,
                  "diagnostic_not_navigation_acceptance": True, "seed": args.seed,
                  "execution_source_provenance": provenance, "input_artifacts": artifacts,
                  "physics_device": str(env.device), "contact_processing_enabled": True,
                  "convex_cylinder_collisions": cfg.convex_cylinder_collisions,
                  "navigation_pose_observations": cfg.navigation_pose_observations,
                  "support_height_m": args.support_height, "support_offset_m": args.support_offset,
                  "corridor_width_m": args.corridor_width, "completed_steps": completed_steps,
                  "mode_schedule": list(args.mode_schedule), "hold_steps_per_mode": args.hold_steps,
                  "strict_goal_speed_and_yaw_thresholds": args.strict_stationary,
                  "guarded_schedule": args.guarded_schedule,
                  "guarded_stage_timeout_per_env": protocol.timed_out.cpu().tolist() if protocol is not None else None,
                  "first_continuous_one_second_hold_after_command_s": [
                      [None if not torch.isfinite(value) else float(value) for value in row]
                      for row in first_continuous_hold_s.cpu()],
                  "one_second_stationary_accepted_per_mode_and_env": accepted.cpu().tolist(),
                  "one_second_stationary_accepted_at_stage_end": accepted_at_stage_end.cpu().tolist(),
                  "passed": bool(accepted_at_stage_end.all() and not failed.any()),
                  "hard_failure_per_env": hard_failed.cpu().tolist(),
                  "simulator_truncated_per_env": simulator_truncated.cpu().tolist(),
                  "terminated_or_truncated_per_env": failed.cpu().tolist(), "hard_reason_names": HARD_REASON_NAMES,
                  "hard_reason_counts_per_env": reasons.cpu().tolist(), "samples": samples}
        with args.output.open("x") as stream:
            stream.write(json.dumps(report, indent=2) + "\n")
        print(json.dumps({key: value for key, value in report.items() if key != "samples"}), flush=True)
    finally:
        env.close()
        simulation_app.close()


if __name__ == "__main__":
    main()
