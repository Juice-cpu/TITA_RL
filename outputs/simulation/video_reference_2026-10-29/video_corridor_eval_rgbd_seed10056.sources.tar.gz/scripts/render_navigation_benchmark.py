#!/usr/bin/env python3
"""Render reviewed benchmark plots and a local, offline Chinese dashboard."""

import argparse
import html
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("review", type=Path)
    parser.add_argument("--rl-video", type=Path)
    parser.add_argument("--dct-video", type=Path)
    parser.add_argument("--velocity-audit", type=Path)
    args = parser.parse_args()
    directory = args.review.resolve()
    summary = json.loads((directory / "comparison_summary.json").read_text())
    results = summary["results"]
    if not results:
        raise ValueError("cannot render an empty physical evaluation")
    successes = sum(result["success"] for result in results)
    failures = len(summary.get("skipped_incomplete_runs", summary.get("errors", [])))
    audit_count = sum(result["action_reward_audit_passed"] and result["planner_clock_audit"]["passed"] for result in results)
    count_note = f"{successes}/{len(results)} 个已完成回合到达；同步审计 {audit_count}/{len(results)} 通过；另有 {failures} 个未完成回合。"
    safe_caps = sorted({result["speed_cap_mps"] for result in results if result["protocol"] == "safe_baselines" and result["algorithm"] != "rl"})
    cruise_caps = sorted({result["speed_cap_mps"] for result in results if result["protocol"] == "equal_cruise"})
    cap_note = f"一档基线上限 {safe_caps} m/s；统一二档上限 {cruise_caps} m/s；均是命令权限，不是实际速度硬限幅或安全认证。"
    velocity_section = ""
    if args.velocity_audit:
        velocity_audit = json.loads(args.velocity_audit.read_text())
        velocity_errors = "".join(f"<li>{html.escape(error)}</li>" for error in velocity_audit["errors"])
        velocity_section = f'<section class="warning"><h2>独立起停验收：{"通过" if velocity_audit["passed"] else "未通过"}</h2><ul>{velocity_errors}</ul><p>到达目标不替代起停验收。原始起停审计：<code>{html.escape(str(args.velocity_audit.resolve()))}</code>。未通过时不得宣称一档已经安全。</p></section>'
    plt.rcParams.update({"font.family": "Noto Sans CJK JP", "axes.unicode_minus": False, "axes.spines.top": False, "axes.spines.right": False, "figure.facecolor": "#f7fafc", "savefig.facecolor": "#f7fafc"})
    figure, axes = plt.subplots(1, 3, figsize=(16, 6))
    algorithms = ["neupan", "dct", "rl"]
    names = ["NeuPAN", "DCT-core", "RL + NeuPAN"]
    for protocol_index, (protocol, label, color) in enumerate([
        ("safe_baselines", "实验一：基线一档 / RL 可二档", "#d8875a"),
        ("equal_cruise", "实验二：统一二档上限", "#068b88"),
    ]):
        selected = [[result for result in results if result["protocol"] == protocol and result["algorithm"] == algorithm] for algorithm in algorithms]
        for axis, field, title, unit in [
            (axes[0], "navigation_time_s", "回合耗时（含失败）", "仿真时间（s）"),
            (axes[1], "mechanical_energy_j", "机械能消耗 ↓", "绝对关节机械功积分（J）"),
            (axes[2], "energy_j_per_m", "单位距离机械能 ↓", "J / m"),
        ]:
            values = [float(np.mean([result[field] for result in group])) if group else np.nan for group in selected]
            positions = np.arange(3) + (protocol_index - 0.5) * 0.35
            bars = axis.bar(positions, values, width=0.32, color=color, label=label)
            axis.bar_label(bars, labels=[f"{value:.2f}" if np.isfinite(value) else "未完成" for value in values], padding=4, fontsize=9)
            axis.set_xticks(np.arange(3), names, fontsize=10)
            axis.set_title(title, loc="left", pad=15)
            axis.set_ylabel(unit)
            axis.grid(axis="y", alpha=0.15)
            axis.set_axisbelow(True)
            axis.set_ylim(0, max(result[field] for result in results) * 1.20)
    figure.suptitle("迷宫导航 · 物理冒烟｜不是正式算法排名", fontsize=19, x=0.055, ha="left")
    axes[0].legend(loc="upper left", bbox_to_anchor=(0, -0.13), fontsize=10, frameon=False)
    figure.text(0.055, 0.08, count_note + " 多种子时柱高为组内均值，逐回合值见表格。", fontsize=10, color="#475569")
    figure.text(0.055, 0.035, cap_note, fontsize=9, color="#9a5a22")
    figure.tight_layout(rect=(0.025, 0.19, 0.995, 0.92))
    figure.savefig(directory / "benchmark_metrics.png", dpi=160)
    plt.close(figure)
    rows = []
    for protocol in ("safe_baselines", "equal_cruise"):
        for algorithm in algorithms:
            for result in (result for result in results if result["protocol"] == protocol and result["algorithm"] == algorithm):
                comparison = result.get("comparison_to_closest_branch", result["comparison_to_common_mid_preflight_reference"])
                overlap = comparison["symmetric_path_overlap"] * 100
                efficiency = result["path_efficiency_success_only"]
                efficiency_label = f"{efficiency * 100:.2f}%" if efficiency is not None else "—"
                rows.append(f"<tr><td>{'实验一' if protocol == 'safe_baselines' else '实验二'}</td><td>{html.escape(names[algorithms.index(algorithm)])} / seed {result['seed']}</td><td>{result['speed_cap_mps']:.2f}</td><td>{result['navigation_time_s']:.2f}</td><td>{result['distance_m']:.3f}</td><td>{result['mechanical_energy_j']:.2f}</td><td>{overlap:.2f}%</td><td>{efficiency_label}</td><td>{'到达' if result['success'] else '失败'}</td></tr>")
    videos = []
    for label, path in [("RL + NeuPAN / 二档上限", args.rl_video), ("DCT 导航核心 / 一档上限", args.dct_video)]:
        if path:
            if not path.is_file():
                raise FileNotFoundError(path)
            episode = json.loads((path.parent / "evaluation/evaluation_summary.json").read_text())["episodes"][0]
            in_table = any(Path(result["directory"]).resolve() == path.parent.resolve() for result in results)
            note = "录像对应表格中的原始回合。" if in_table else "录像为额外复跑，不替换表格中的原始回合。"
            videos.append(f'<section><h2>{label}</h2><video controls preload="metadata" src="{html.escape(str(path.resolve()))}"></video><p>真实 Isaac 渲染，按仿真时间 1× 原速播放；本次 {episode["elapsed_s"]:.2f} s。{note}</p></section>')
    document = f"""<!doctype html>
<html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>TITA 导航基准 · 迷宫首轮结果</title>
<style>body{{margin:0;background:#f4f7fa;color:#142235;font:16px/1.7 system-ui,sans-serif}}main{{max-width:1240px;margin:auto;padding:36px 24px}}h1{{font-size:32px;margin:0}}h2{{font-size:23px}}.subtitle{{color:#64748b}}section{{background:white;border:1px solid #e0e8ef;border-radius:16px;padding:24px;margin:22px 0}}.warning{{border-left:5px solid #d39748;background:#fff8ec}}img,video{{display:block;width:100%;height:auto;border-radius:10px}}table{{width:100%;border-collapse:collapse;font-size:14px}}th,td{{padding:10px 8px;text-align:left;border-bottom:1px solid #e4ebf1}}.scroll{{overflow-x:auto}}code{{background:#edf2f7;padding:2px 5px}}li{{margin:6px 0}}</style>
<main><h1>TITA｜迷宫导航基准</h1><p class="subtitle">NeuPAN · DCT navigation-core · 冻结 RL + NeuPAN｜两组速度协议｜物理仿真冒烟</p>
<section class="warning"><strong>回合结果不等于算法胜负或安全认证。</strong><ul><li>{count_note}</li><li>{cap_note}</li><li>实验一是不等速度权限的系统对照；实验二统一最大速度权限，安全减速仍然有效。</li><li>RL 沿用冻结模型；新版物理速度映射不等于重新训练。分支参考线也不是新学到的路线动作。</li><li>DCT 未部署视觉语义过滤与接触穿越；只比较上游导航核心的刚性迷宫消融模式。</li></ul></section>
<section><h2>场景与实际轨迹</h2><img src="maze_trajectories.png"><p>虚线为离线 A* 几何参考；实线为实际执行轨迹。双分支场景还保留各分支的参考重合度，避免把另一条合法路线当作跟踪失败。地图及净空由已知几何生成，非在线感知。</p></section>
<section><h2>两组对照指标</h2><img src="benchmark_metrics.png"><div class="scroll"><table><thead><tr><th>协议</th><th>算法</th><th>命令上限 m/s</th><th>耗时 s</th><th>距离 m</th><th>机械能 J</th><th>参考重合度</th><th>路径效率</th><th>状态</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div><p>重合度：以 0.05 m 弧长采样，在 0.20 m 容差内的双向中心线覆盖均值；效率：共同到达容差下，参考 A* 路长 / 实际距离，不是认证最短路 SPL。</p></section>
{velocity_section}
{''.join(videos)}
<section><h2>信息来源与下一步</h2><ul><li>三层地图、侧向/顶部余量：场景碰撞盒与名义机器人包络计算，保留来源字段；开阔顶部余量截断为 0.50 m。</li><li>坡度/粗糙度：对解析水平地面采样得到零，未实现地形感知。</li><li>局部避障：Isaac 水平 LiDAR 射线；状态为刚体真值；能量为关节绝对机械功，不是电池电耗。</li><li>下一阶段先验证新速度下起停与转弯，再冻结训练/留出划分并进行多种子复核；未启动新训练。</li></ul><p>完整证据：同目录 <code>comparison_summary.json</code>、<code>comparison_metrics.csv</code>；复现及限制见项目 <code>docs/NAVIGATION_MAZE_BENCHMARK_CN.md</code>。</p></section></main></html>"""
    (directory / "index.html").write_text(document)
    print(directory / "index.html")


if __name__ == "__main__":
    main()
