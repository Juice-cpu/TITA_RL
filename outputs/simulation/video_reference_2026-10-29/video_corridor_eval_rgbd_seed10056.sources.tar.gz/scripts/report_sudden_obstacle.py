#!/usr/bin/env python3
"""Report same-host sudden-obstacle response without discarding stalled trials."""

from __future__ import annotations

import argparse
import csv
import hashlib
import html
import json
from pathlib import Path
import shutil
import sys

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tita_uc_residual_rl.sudden_obstacle_metrics import (
    analyze_response_trial,
    read_jsonl,
    summarize_algorithms,
)


ALGORITHMS = ("neupan", "dct", "rl")
LABELS = {"neupan": "NeuPAN", "dct": "DCT导航核心", "rl": "RL + NeuPAN"}
COLORS = {"neupan": "#3382b8", "dct": "#d18436", "rl": "#58854c"}


def write_csv(path, rows):
    with path.open("x", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _plot_latency(summary, output):
    algorithms = summary["algorithms"]
    figure, axis = plt.subplots(figsize=(13, 7))
    metrics = [
        ("appearance_to_lidar_hit_ms", "LiDAR首次命中", "#b0c9d9"),
        ("appearance_to_first_known_scan_input_ms", "已知新扫描的规划输入首次应用", "#387ca5"),
        ("command_deviation_confirmed_ms", "显著指令偏离确认", "#cf9a4a"),
        ("measured_response_confirmed_ms", "实际减速 / 转向确认", "#728f56"),
    ]
    for index, (name, label, color) in enumerate(metrics):
        position = np.arange(3) + (index - 1.5) * .19
        values = [algorithms[algorithm]["metrics_ms"][name]["mean"]
                  if algorithms[algorithm]["metrics_ms"][name] is not None else np.nan
                  for algorithm in ALGORITHMS]
        bars = axis.bar(position, values, width=.17, label=label, color=color)
        axis.bar_label(bars, labels=[f"{value:.0f}" if np.isfinite(value) else "缺测" for value in values], padding=5, fontsize=10)
        for location, algorithm in zip(position, ALGORITHMS):
            group = [trial for trial in summary["trials"] if trial["algorithm"] == algorithm]
            samples = []
            for trial in group:
                if name in trial["latencies_ms"]:
                    samples.append(trial["latencies_ms"][name])
                else:
                    marker = name.removesuffix("_confirmed_ms")
                    response = trial["response_markers"][marker]
                    if response is not None:
                        samples.append(response["confirmed_wall_ms"])
            axis.scatter([location] * len(samples), samples, color="#263442", s=16, zorder=4, alpha=.7)
    axis.set_xticks(np.arange(3), [LABELS[algorithm] for algorithm in ALGORITHMS], fontsize=13)
    axis.set_ylabel("障碍出现后的墙钟耗时（ms）")
    axis.set_title("突发障碍响应｜相同0.6 m/s上限，每算法3次", loc="left", fontsize=20, pad=18)
    axis.legend(loc="upper left", fontsize=10)
    axis.grid(axis="y", alpha=.15)
    axis.set_axisbelow(True)
    axis.margins(y=.24)
    figure.text(.08, .10, "柱=三次均值，点=每次实测；显著变化相对同种子无障碍轨迹，连续3个控制样本确认。", fontsize=11)
    figure.text(.08, .055, "墙钟包含锁步等待；首次新规划输入不等于已经采取有效避让。40s仿真观察窗内的到达/碰撞另报。", fontsize=11)
    figure.tight_layout(rect=(.02, .15, .99, .99))
    figure.savefig(output / "response_latency.png", dpi=170)
    plt.close(figure)


def _plot_trajectories(summary, batch, output):
    scene = json.loads((batch / "navigation_scene.json").read_text())
    figure, axes = plt.subplots(1, 3, figsize=(16, 7), sharex=True, sharey=True)
    for axis, algorithm in zip(axes, ALGORITHMS):
        for obstacle in scene["boxes"]:
            center, size = obstacle["center"], obstacle["size"]
            axis.add_patch(Rectangle((center[0] - size[0] / 2, center[1] - size[1] / 2),
                                     size[0], size[1], color="#d9dee3", ec="#7c8690"))
        config = summary["probe_config"]
        center, size = config["center_m"], config["size_m"]
        axis.add_patch(Rectangle((center[0] - size[0] / 2, center[1] - size[1] / 2),
                                 size[0], size[1], color="#c54c45", label="突然出现的实体障碍"))
        group = [trial for trial in summary["trials"] if trial["algorithm"] == algorithm]
        for index, trial in enumerate(group):
            trace = read_jsonl(Path(trial["directory"]) / "control_trace.jsonl")
            positions = np.asarray([row["position"][:2] for row in trace])
            if index == 0:
                clean = read_jsonl(Path(trial["clean_reference"]) / "control_trace.jsonl")
                reference = np.asarray([row["position"][:2] for row in clean])
                axis.plot(reference[:, 0], reference[:, 1], "--", color="#9dabb7", label="无突发障碍参考", linewidth=1.4)
            axis.plot(positions[:, 0], positions[:, 1], linewidth=1.7, alpha=.8, linestyle=("-", "--", ":")[index],
                      color=COLORS[algorithm], label=f"seed {trial['seed']}")
            axis.scatter(*positions[-1], marker="x", s=65, color=COLORS[algorithm], zorder=5)
        axis.scatter(*scene["start_xy_m"], marker="o", s=60, color="#3c7258", zorder=5)
        axis.scatter(*scene["goal_xy_m"], marker="*", s=130, color="#d7ac3f", zorder=5)
        axis.set_title(f"{LABELS[algorithm]}｜到达{summary['algorithms'][algorithm]['successes']}/3", fontsize=14)
        axis.set_xlim(-1.6, 9.6)
        axis.set_ylim(-6.4, 6.4)
        axis.set_aspect("equal")
        axis.set_xlabel("x（m）")
        axis.grid(alpha=.12)
    axes[0].set_ylabel("y（m）")
    axes[-1].legend(fontsize=8, loc="upper right")
    figure.suptitle("快速产生指令 ≠ 成功绕过｜×为40s观察窗终点，不是到达", fontsize=19, x=.07, ha="left")
    figure.text(.07, .045, "突发障碍不进入A*地图/路线特征；三条轨迹为每算法全部3次重复，没有删除停滞或超时回合。", fontsize=11)
    figure.tight_layout(rect=(.02, .13, .99, .93))
    figure.savefig(output / "response_trajectories.png", dpi=170)
    plt.close(figure)


def _plot_dynamics(summary, aligned_trials, output):
    figure, axes = plt.subplots(2, 3, figsize=(15, 8), sharex=True, sharey="row")
    for index, algorithm in enumerate(ALGORITHMS):
        for trial in [row for row in summary["trials"] if row["algorithm"] == algorithm]:
            aligned = aligned_trials[f"{algorithm}_{trial['seed']}"]
            times = [row["elapsed_sim_s"] for row in aligned]
            axes[0, index].plot(times, [row["speed_difference_mps"] for row in aligned], label=f"seed {trial['seed']}", linewidth=1.3)
            axes[1, index].plot(times, [row["heading_difference_rad"] for row in aligned], linewidth=1.3)
        axes[0, index].set_title(LABELS[algorithm], fontsize=14)
        axes[0, index].axhline(-.05, ls="--", color="#a45242", alpha=.7)
        for threshold in (-.05, .05):
            axes[1, index].axhline(threshold, ls="--", color="#a45242", alpha=.7)
        for axis in axes[:, index]:
            axis.axvline(0, color="#333333", alpha=.6)
            axis.set_xlim(-1, 4)
            axis.grid(alpha=.15)
        axes[1, index].set_xlabel("障碍出现后的仿真时间（s）")
        axes[0, index].legend(fontsize=9)
    axes[0, 0].set_ylabel("前进速度差（m/s）\n相对同种子无障碍参考")
    axes[1, 0].set_ylabel("航向差（rad）\n相对同种子无障碍参考")
    figure.suptitle("物理运动是否真的改变？｜同物理触发点对齐的轨迹差", fontsize=19, x=.06, ha="left")
    figure.text(.06, .035, "这是仿真时间轴，不是墙钟；参考来自既有静态场景批次，非严格确定性重放，报告保留事前1s配准误差。", fontsize=11)
    figure.tight_layout(rect=(.02, .075, .99, .93))
    figure.savefig(output / "response_dynamics.png", dpi=170)
    plt.close(figure)


def _source_evidence(batch, output, results):
    source_directory = output / "analysis_sources"
    source_directory.mkdir()
    paths = {
        ROOT / "scripts/report_sudden_obstacle.py",
        ROOT / "scripts/run_navigation_benchmark.py",
        ROOT / "scripts/run_tita_residual_lab.py",
        ROOT / "tita_uc_residual_rl/sudden_obstacle.py",
        ROOT / "tita_uc_residual_rl/sudden_obstacle_metrics.py",
        ROOT / "tita_uc_residual_rl/isaaclab_tita_env.py",
        ROOT / "tita_uc_residual_rl/isaac_udp_bridge.py",
        ROOT / "tita_realtime_trace.py",
    }
    expected_hashes = {}
    offline_analysis = {str(ROOT / "tita_uc_residual_rl/sudden_obstacle_metrics.py"), str(ROOT / "scripts/report_sudden_obstacle.py")}
    manifest_occurrences = {}
    for result in results:
        manifest = json.loads((Path(result["directory"]) / "run_manifest.json").read_text())
        for source, digest in manifest["hashes"].items():
            if source in offline_analysis:
                continue
            if source in expected_hashes and expected_hashes[source] != digest:
                raise ValueError(f"runtime source changed across trials: {source}")
            expected_hashes[source] = digest
            manifest_occurrences[source] = manifest_occurrences.get(source, 0) + 1
            paths.add(Path(source))
    audit = []
    for index, path in enumerate(sorted(paths)):
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if str(path) in expected_hashes and actual != expected_hashes[str(path)]:
            raise ValueError(f"runtime source no longer matches measurement: {path}")
        destination = source_directory / f"{index:02d}_{path.name}"
        shutil.copy2(path, destination)
        audit.append({"path": str(path), "sha256": actual, "snapshot": str(destination),
                      "verified_in_all_trial_manifests": manifest_occurrences.get(str(path), 0) == len(results),
                      "manifest_occurrences": manifest_occurrences.get(str(path), 0)})
    inputs = [batch / "comparison_summary.json", batch / "benchmark_manifest.json", batch / "benchmark_config.json",
              batch / "navigation_scene.json"]
    for result in results:
        trial = Path(result["directory"])
        inputs.extend(sorted((trial / "timing").glob("*.jsonl")))
        inputs.extend([trial / "control_trace.jsonl", trial / "run_manifest.json",
                       batch / f"{trial.name}.sudden_obstacle.json",
                       Path(result["clean_reference"]) / "control_trace.jsonl",
                       Path(result["clean_reference"]) / "run_manifest.json",
                       Path(result["clean_reference"]) / "motion_profile.json"])
    return {"offline_analysis_excluded_from_runtime_consistency": sorted(offline_analysis),
            "sources": audit, "data": [{"path": str(path.resolve()), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
                                         for path in inputs]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--batch", type=Path, required=True)
    parser.add_argument("--clean-batch", type=Path, required=True)
    parser.add_argument("--probe-config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    comparison = json.loads((args.batch / "comparison_summary.json").read_text())
    config = json.loads(args.probe_config.read_text())
    planned_trials = len(list(args.batch.glob("*.invocation.json")))
    if comparison["errors"] or len(comparison["results"]) != planned_trials or planned_trials != 9:
        raise ValueError("need all nine planned trials, retaining navigation failures; batch is incomplete or has launcher errors")
    trials, aligned_trials = [], {}
    for result in comparison["results"]:
        directory = Path(result["directory"])
        snapshot = json.loads((args.batch / f"{directory.name}.sudden_obstacle.json").read_text())
        if snapshot != config or result["speed_cap_mps"] != .6:
            raise ValueError("mismatched physical probe or velocity cap")
        if not result["complete"] or not result["action_reward_audit_passed"] or not result["planner_clock_audit"]["passed"]:
            raise ValueError(f"incomplete execution or action/clock audit failed: {directory}")
        response, aligned = analyze_response_trial(directory, config, result, args.clean_batch / directory.name)
        contracts = []
        for path in (directory, args.clean_batch / directory.name):
            manifest = json.loads((path / "run_manifest.json").read_text())
            contracts.append({Path(source).name: digest for source, digest in manifest["hashes"].items()})
        common_roles = ("upper_policy_last.pt", "tita_example_10000.pt", "tita_urdf_mixed_5000.pth",
                        "posture_calibration.json", "velocity_governor_calibration.json",
                        "upper_normalization.json", "navigation_scene.json")
        if any(contracts[0].get(role) is None or contracts[0][role] != contracts[1].get(role) for role in common_roles):
            raise ValueError("clean reference has a different model, motion, calibration, normalization or map")
        response["clean_reference_matching_contract_hashes"] = {role: contracts[0][role] for role in common_roles}
        motions, planner_digests = [], []
        for path in (directory, args.clean_batch / directory.name):
            motion = json.loads((path / "motion_profile.json").read_text())
            planner_path = Path(motion.pop("planner_config"))
            planner_digests.append(hashlib.sha256(planner_path.read_bytes()).hexdigest())
            motions.append(motion)
        if motions[0] != motions[1] or planner_digests[0] != planner_digests[1]:
            raise ValueError("clean reference has different motion values or local planner configuration")
        response["clean_motion_contract"] = {"equal_except_planner_path": True,
                                            "planner_config_sha256": planner_digests[0],
                                            "motion_without_planner_path_sha256": hashlib.sha256(
                                                json.dumps(motions[0], sort_keys=True).encode()).hexdigest()}
        trials.append(response)
        aligned_trials[f"{result['algorithm']}_{result['seed']}"] = aligned
    if any(sorted(row["seed"] for row in trials if row["algorithm"] == algorithm) != [11, 22, 33]
           for algorithm in ALGORITHMS):
        raise ValueError("expected matched algorithms and seeds 11,22,33")
    summary = {"simulation_only": True, "batch": str(args.batch.resolve()), "clean_batch": str(args.clean_batch.resolve()),
               "probe_config": config, "trials": trials, "algorithms": summarize_algorithms(trials),
               "scope": "Three repetitions per algorithm, common .6m/s cap, 40s simulation observation window. Descriptive measurements, not a statistically established ranking or hardware deadline guarantee.",
               "scan_attribution": "Source stamp is the most recent processed scan at solver entry, not a locked snapshot of optimizer inputs. Conservative known-new-scan timing, not exact causality or worst-case latency.",
               "physical_response": "Difference versus existing same-seed clean trajectory, aligned at the same geometric trigger; .05m/s slowdown or .05rad heading difference, sustained for 3 consecutive samples. Not semantic recognition or exact deterministic replay.",
               "baseline_wrapper": "All algorithms use the same upper-level lockstep harness; fixed_mid_max baselines still execute model.act() before overriding its choice. This compares deployed stacks, not bare upstream planner overhead or isolated RL added cost.",
               "clock_scope": "Same host/boot monotonic clock. Wall times include lockstep pauses and instrumentation; simulation times do not. First input does not mean motor-bus actuation or successful avoidance."}
    args.output.mkdir(parents=True, exist_ok=False)
    summary["evidence"] = _source_evidence(args.batch, args.output, trials)
    (args.output / "response_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
    rows = []
    for trial in trials:
        row = {name: trial[name] for name in ("algorithm", "seed", "success", "truncated", "navigation_time_s",
               "minimum_conservative_clearance_m", "obstacle_contact_force_max_n", "stalled_last_5s", "final_goal_distance_m",
               "tail_5s_distance_m", "tail_5s_net_displacement_m", "tail_5s_goal_progress_m", "wall_input_hz", "real_time_factor")}
        row.update(trial["latencies_ms"])
        row["first_known_scan_input_sim_delay_s"] = trial["first_known_scan_input_sim_delay_s"]
        for marker, value in trial["response_markers"].items():
            for field in ("onset_wall_ms", "confirmed_wall_ms", "onset_sim_s", "confirmed_sim_s"):
                row[f"{marker}_{field}"] = None if value is None else value[field]
        row.update({f"pre_event_rms_{name}": value for name, value in trial["reference_pre_event_rms"].items()})
        rows.append(row)
    write_csv(args.output / "per_trial_response.csv", rows)
    for identity, aligned in aligned_trials.items():
        write_csv(args.output / f"reference_deviation_{identity}.csv", aligned)
    plt.rcParams["font.sans-serif"] = ["Noto Sans CJK JP", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False
    _plot_latency(summary, args.output)
    _plot_trajectories(summary, args.batch, args.output)
    _plot_dynamics(summary, aligned_trials, args.output)
    table_rows = []
    for algorithm in ALGORITHMS:
        group = summary["algorithms"][algorithm]
        cells = [LABELS[algorithm]]
        for name in ("appearance_to_lidar_hit_ms", "appearance_to_first_known_scan_input_ms",
                     "command_deviation_confirmed_ms", "measured_response_confirmed_ms"):
            metric = group["metrics_ms"][name]
            cells.append("缺测" if metric is None else f"{metric['mean']:.1f} / {metric['max']:.1f}")
        cells.extend([f"{group['successes']}/{group['n']}", f"{group['contacts']}/{group['n']}",
                      f"{group['stalled']}/{group['n']}", f"{group['minimum_clearance_m']:.3f}"])
        table_rows.append("<tr>" + "".join(f"<td>{html.escape(cell)}</td>" for cell in cells) + "</tr>")
    page = """<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>突发障碍响应实测</title>
<style>body{font:16px/1.7 sans-serif;margin:32px auto;max-width:1250px;color:#24333e;background:#f7f9fb}h1{margin-bottom:8px}img{width:100%;background:white;border-radius:12px}table{border-collapse:collapse;width:100%;background:white;font-size:14px}td,th{padding:10px;border:1px solid #dce2e6;text-align:center}.note{background:#fff1d9;padding:16px;border-radius:10px}section{margin:28px 0}a{color:#2b6e9f}</style>
<h1>突发障碍响应：三算法 × 三次重复</h1><p>共同上限0.6m/s；实体障碍首次进入碰撞和模拟LiDAR场景，不进入A*先验；观察窗40s仿真时间。</p>
<p class="note">频率不是响应时延；快速生成新指令也不等于成功绕过。此处是含锁步等待的墙钟实测，不能直接作为实机实时性或未知复杂地图安全保证。</p>
<table><thead><tr><th>算法</th><th>出现→首次命中<br>均值/最大 ms</th><th>出现→新扫描规划输入<br>均值/最大 ms</th><th>显著指令偏离确认<br>均值/最大 ms</th><th>实际运动响应确认<br>均值/最大 ms</th><th>到达</th><th>障碍接触</th><th>末5s行程&lt;0.25m</th><th>最小保守余量m</th></tr></thead><tbody>TABLE</tbody></table>
<section><img src="response_latency.png"></section><section><img src="response_trajectories.png"></section><section><img src="response_dynamics.png"></section>
<h2>统计口径与边界</h2><p>首次新扫描输入：按扫描header时间戳、求解入口标记和控制应用的solve ID关联；求解器内部输入未加互斥快照，属于保守标记而非精确因果链WCET。显著指令/物理响应相对既有同种子静态参考，按相同几何触发点对齐，连续3个控制样本超过阈值；报告包含事前1s误差。物理响应为速度下降≥0.05m/s或航向差≥0.05rad，不代表完成绕行。</p>
<p>到达0/3仅表示40s窗内未到达；0接触不构成全面安全认证。保守余量用0.45m圆包络，接触用实体障碍接触传感器；没有相机/语义识别模型。三次样本不能确定普遍最快者，墙钟与仿真时间必须分别理解。基线共用锁步上层封装，fixed_mid_max仍执行前向再覆盖动作，因此本表不是原生算法开销或RL独立增量开销测试。</p>
<p><a href="response_summary.json">完整JSON与源码/数据哈希</a> · <a href="per_trial_response.csv">每回合CSV</a></p></html>"""
    (args.output / "index.html").write_text(page.replace("TABLE", "".join(table_rows)))
    print(json.dumps(summary["algorithms"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
